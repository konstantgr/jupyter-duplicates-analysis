## Import libraries needed for setting parameters of operating system 
import os
import sys

## Import library for temporary files creation 
import tempfile 

## Import Pandas library
import pandas as pd

## Import Numpy library
import numpy

## Import Psycopg2 library (interection with postgres database)
import psycopg2 as pg

# Import Math library (usefull for rounding number, e.g.)
import math

## Import Subprocess + subprocess.call
import subprocess
from subprocess import call, Popen, PIPE, STDOUT
# [___CELL_SEPARATOR___]
### Define GRASS GIS environment variables for LINUX UBUNTU Mint 18.1 (Serena)
# Check is environmental variables exists and create them (empty) if not exists.
if not 'PYTHONPATH' in os.environ:
    os.environ['PYTHONPATH']=''
if not 'LD_LIBRARY_PATH' in os.environ:
    os.environ['LD_LIBRARY_PATH']=''
# Set environmental variables
os.environ['GISBASE'] = '/home/tais/SRC/GRASS/grass_trunk/dist.x86_64-pc-linux-gnu'
os.environ['PATH'] += os.pathsep + os.path.join(os.environ['GISBASE'],'bin')
os.environ['PATH'] += os.pathsep + os.path.join(os.environ['GISBASE'],'script')
os.environ['PATH'] += os.pathsep + os.path.join(os.environ['GISBASE'],'lib')
#os.environ['PATH'] += os.pathsep + os.path.join(os.environ['GISBASE'],'etc','python')
os.environ['PYTHONPATH'] += os.pathsep + os.path.join(os.environ['GISBASE'],'etc','python')
os.environ['PYTHONPATH'] += os.pathsep + os.path.join(os.environ['GISBASE'],'etc','python','grass')
os.environ['PYTHONPATH'] += os.pathsep + os.path.join(os.environ['GISBASE'],'etc','python','grass','script')
os.environ['PYTHONLIB'] = '/usr/lib/python2.7'
os.environ['LD_LIBRARY_PATH'] += os.pathsep + os.path.join(os.environ['GISBASE'],'lib')
os.environ['GIS_LOCK'] = '$$'
os.environ['GISRC'] = os.path.join(os.environ['HOME'],'.grass7','rc')
os.environ['PATH'] += os.pathsep + os.path.join(os.environ['HOME'],'.grass7','addons')
os.environ['PATH'] += os.pathsep + os.path.join(os.environ['HOME'],'.grass7','addons','bin')
os.environ['PATH'] += os.pathsep + os.path.join(os.environ['HOME'],'.grass7','addons')
os.environ['PATH'] += os.pathsep + os.path.join(os.environ['HOME'],'.grass7','addons','scripts')

## Define GRASS-Python environment
sys.path.append(os.path.join(os.environ['GISBASE'],'etc','python'))
# [___CELL_SEPARATOR___]
## Display the current defined environment variables
for key in os.environ.keys():
    print "%s = %s \t" % (key,os.environ[key])
# [___CELL_SEPARATOR___]
## Define a empty dictionnary for saving user inputs
user={}
# [___CELL_SEPARATOR___]
## Enter the path to GRASSDATA folder
user["gisdb"] = "/media/tais/My_Book_1/MAUPP/Traitement/Ouagadougou/Segmentation_fullAOI_localapproach/GRASSDATA"

## Enter the name of the location (existing or for a new one)
user["location"] = "Ouaga_32630"

## Enter the EPSG code for this location 
user["locationepsg"] = "32630"

## Enter the name of the mapset to use for segmentation
user["segmentation_mapsetname"] = "LOCAL_SEGMENT"

## Enter the name of the mapset to use for classification
user["classificationA_mapsetname"] = "CLASSIF"
# [___CELL_SEPARATOR___]
## Import libraries needed to launch GRASS GIS in the jupyter notebook
import grass.script.setup as gsetup

## Import libraries needed to call GRASS using Python
import grass.script as grass
# [___CELL_SEPARATOR___]
## Automatic creation of GRASSDATA folder
if os.path.exists(user["gisdb"]):
    print "GRASSDATA folder already exist" 
else: 
    os.makedirs(user["gisdb"]) 
    print "GRASSDATA folder created in "+user["gisdb"]
# [___CELL_SEPARATOR___]
## Automatic creation of GRASS location is doesn't exist
if os.path.exists(os.path.join(user["gisdb"],user["location"])):
    print "Location "+user["location"]+" already exist" 
else : 
    grass.core.create_location(user["gisdb"], user["location"], epsg=user["locationepsg"], overwrite=False)
    print "Location "+user["location"]+" created"
# [___CELL_SEPARATOR___]
### Automatic creation of GRASS GIS mapsets

## Import library for file copying 
import shutil

mapsetname=user["classificationA_mapsetname"]
if os.path.exists(os.path.join(user["gisdb"],user["location"],mapsetname)):
    if not os.path.exists(os.path.join(user["gisdb"],user["location"],mapsetname,'WIND')):
        print "WARNING: '"+mapsetname+"' mapset already exist, but a 'WIND' file is missing. Please solve this issue."
    else: print "'"+mapsetname+"' mapset already exist" 
else: 
    os.makedirs(os.path.join(user["gisdb"],user["location"],mapsetname))
    shutil.copy(os.path.join(user["gisdb"],user["location"],'PERMANENT','WIND'),os.path.join(user["gisdb"],user["location"],mapsetname,'WIND'))
    print "'"+mapsetname+"' mapset created in location '"+user["location"]+"'"
# [___CELL_SEPARATOR___]
### Automatic creation of GRASS GIS mapsets

## Import library for file copying 
import shutil

mapsetname=user["segmentation_mapsetname"]
if os.path.exists(os.path.join(user["gisdb"],user["location"],mapsetname)):
    if not os.path.exists(os.path.join(user["gisdb"],user["location"],mapsetname,'WIND')):
        print "WARNING: '"+mapsetname+"' mapset already exist, but a 'WIND' file is missing. Please solve this issue."
    else: print "'"+mapsetname+"' mapset already exist" 
else: 
    os.makedirs(os.path.join(user["gisdb"],user["location"],mapsetname))
    shutil.copy(os.path.join(user["gisdb"],user["location"],'PERMANENT','WIND'),os.path.join(user["gisdb"],user["location"],mapsetname,'WIND'))
    print "'"+mapsetname+"' mapset created in location '"+user["location"]+"'"
# [___CELL_SEPARATOR___]
## Import library for managing time in python
import time  

## Function "print_processing_time()" compute processing time and printing it.
# The argument "begintime" wait for a variable containing the begintime (result of time.time()) of the process for which to compute processing time.
# The argument "printmessage" wait for a string format with information about the process. 
def print_processing_time(begintime, printmessage):    
    endtime=time.time()           
    processtime=endtime-begintime
    remainingtime=processtime

    days=int((remainingtime)/86400)
    remainingtime-=(days*86400)
    hours=int((remainingtime)/3600)
    remainingtime-=(hours*3600)
    minutes=int((remainingtime)/60)
    remainingtime-=(minutes*60)
    seconds=round((remainingtime)%60,1)

    if processtime<60:
        finalprintmessage=str(printmessage)+str(seconds)+" seconds"
    elif processtime<3600:
        finalprintmessage=str(printmessage)+str(minutes)+" minutes and "+str(seconds)+" seconds"
    elif processtime<86400:
        finalprintmessage=str(printmessage)+str(hours)+" hours and "+str(minutes)+" minutes and "+str(seconds)+" seconds"
    elif processtime>=86400:
        finalprintmessage=str(printmessage)+str(days)+" days, "+str(hours)+" hours and "+str(minutes)+" minutes and "+str(seconds)+" seconds"
    
    return finalprintmessage
# [___CELL_SEPARATOR___]
# Do a VACUUM on the current Postgresql database
def vacuum(db):
    old_isolation_level = db.isolation_level
    db.set_isolation_level(0)
    query = "VACUUM"
    cur.execute(query)
    db.set_isolation_level(old_isolation_level)
# [___CELL_SEPARATOR___]
## Saving current time for processing time management
begintime_full=time.time()
# [___CELL_SEPARATOR___]
# User for postgresql connexion
dbuser="tais"
# Password of user
dbpassword="tais"
# Host of database
host="localhost"
# Name of the new database
dbname="ouaga_fullaoi_localsegment"
# Set name of schema for objects statistics
stat_schema="statistics"
# Set name of schema for samples
sample_schema="samples"
# Set name of schema for classification optical only
classifA_schema="classif_A"
# Set name of schema for classification optical and nDSM
classifB_schema="classif_B"
# Set name of schema for classification SAR only
classifC_schema="classif_C"
# Set name of schema for classification SAR and optical
classifD_schema="classif_D"
# Set name of schema for classification SAR + optical + nDSM + NDVI
classifE_schema="classif_E"
# [___CELL_SEPARATOR___]
# Set name of table with statistics of segmentobject_stats_table="object_stats_sar"s - FOR OPTICAL
object_stats_optical="object_stats_optical"
# Set name of table with statistics of segmentobject_stats_table="object_stats_sar"s - FOR SAR
object_stats_sar="object_stats_sar"
# Set name of table with all the samples
samples_labels="sample_labels"
# Set name of table with samples without outliers
samples_labels_ok="sample_labels_ok"
# Set name of table with samples without outliers in Optical AOI
sample_opt="sample_opt"
# Set name of table with samples without outliers in Optical AOI - Test set
sample_opt_test="sample_opt_test"
# Set name of table with samples without outliers in Optical AOI - Training set
sample_opt_training="sample_opt_training"
# Set name of table with samples without outliers in SAR AOI
sample_sar="sample_sar"
# Set name of table with samples without outliers in SAR AOI - Test set
sample_test="sample_test"
# Set name of table with samples without outliers in SAR AOI - Training set
sample_training="sample_training"
# Set name of table with results of classification
classif="classif"
# Set name of table with results of classification and ground truth
groundtruth_classif="groundtruth_classif"
# [___CELL_SEPARATOR___]
### Automatic creation of GRASS GIS mapsets

## Import library for file copying 
import shutil

## Set the name of the mapset in which to work
mapsetname=classifE_schema

if os.path.exists(os.path.join(user["gisdb"],user["location"],mapsetname)):
    if not os.path.exists(os.path.join(user["gisdb"],user["location"],mapsetname,'WIND')):
        print "WARNING: '"+mapsetname+"' mapset already exist, but a 'WIND' file is missing. Please solve this issue."
    else: print "'"+mapsetname+"' mapset already exist" 
else: 
    os.makedirs(os.path.join(user["gisdb"],user["location"],mapsetname))
    shutil.copy(os.path.join(user["gisdb"],user["location"],'PERMANENT','WIND'),os.path.join(user["gisdb"],user["location"],mapsetname,'WIND'))
    print "'"+mapsetname+"' mapset created in location '"+user["location"]+"'"
# [___CELL_SEPARATOR___]
## Launch GRASS GIS working session in the mapset
if os.path.exists(os.path.join(user["gisdb"],user["location"],mapsetname)):
    gsetup.init(os.environ['GISBASE'], user["gisdb"], user["location"], mapsetname)
    print "You are now working in mapset '"+mapsetname+"'" 
else: 
    print "'"+mapsetname+"' mapset doesn't exists in "+user["gisdb"]
# [___CELL_SEPARATOR___]
from psycopg2.extensions import ISOLATION_LEVEL_AUTOCOMMIT

# Connect to postgres database
db=None
db=pg.connect(dbname=dbname, user='tais', password='tais', host='localhost')

# Allow to create a new database
db.set_isolation_level(ISOLATION_LEVEL_AUTOCOMMIT)

# Execute the CREATE DATABASE query
cur=db.cursor()
#cur.execute('DROP SCHEMA IF EXISTS '+classifE_schema+' CASCADE') #Comment this to avoid deleting existing DB
try:
    cur.execute('CREATE SCHEMA '+classifE_schema)
except Exception as e:
    print ("Exception occured : "+str(e))
cur.close()
db.close()
# [___CELL_SEPARATOR___]
general_path="/media/tais/My_Book_1/MAUPP/Traitement/Ouagadougou/Segmentation_fullAOI_localapproach/Results/CLASSIF"
resultfolder=os.path.join(general_path, classifE_schema)
## Create the folder if does not exists
if not os.path.exists(resultfolder):
    os.makedirs(resultfolder)
    print "Folder '"+resultfolder+"' created"
# [___CELL_SEPARATOR___]
outputfolder=os.path.join(resultfolder, "classification")
## Create the folder if does not exists
if not os.path.exists(outputfolder):
    os.makedirs(outputfolder)
    print "Folder '"+outputfolder+"' created"
# [___CELL_SEPARATOR___]
## Set-up a message
message=""
message+=classifE_schema+" : Classification using Optical, nDSM, NDVI (No SAR). With shadow class."
## Write it in the .txt file
f=open(os.path.join(outputfolder,"readme.txt"),'w')
f.write(message)
f.close()
# [___CELL_SEPARATOR___]
# Connect to an existing database
db=pg.connect(database=dbname, user=dbuser, password=dbpassword, host=host)
# Open a cursor to perform database operations
cur=db.cursor()
# [___CELL_SEPARATOR___]
# Query to find the number of row in the test samples
query="SELECT class, min(class_num) as class_num, count(*) FROM "+sample_schema+"."+sample_opt_test+" \
GROUP BY class \
ORDER BY max(class_num) ASC"
# Execute query through panda
df_countperclass=pd.read_sql(query, db)
# Show dataframe
df_countperclass.head(5000)
# [___CELL_SEPARATOR___]
# Print the total number in sample 
print "Test samples counts "+str(sum(df_countperclass['count']))+" points."
# [___CELL_SEPARATOR___]
# Query to find the number of row in the sample table
query="SELECT class, min(class_num) as class_num, count(*) FROM "+sample_schema+"."+sample_opt_training+" \
GROUP BY class \
ORDER BY max(class_num) ASC"
# Execute query through panda
df_countperclass=pd.read_sql(query, db)
# Show dataframe
df_countperclass.head(5000)
# [___CELL_SEPARATOR___]
# Print the total number in sample 
print "Training samples counts "+str(sum(df_countperclass['count']))+" points."
# [___CELL_SEPARATOR___]
# Drop table if exists:
cur.execute("DROP TABLE IF EXISTS "+classifE_schema+"."+sample_training)
# Make the changes to the database persistent
db.commit()
# [___CELL_SEPARATOR___]
# Create table with 
query="CREATE TABLE "+classifE_schema+"."+sample_training+" AS(\
SELECT a.seg_id, a.class_num, b.* \
FROM "+sample_schema+"."+sample_opt_training+" AS a \
INNER JOIN "+stat_schema+"."+object_stats_optical+" AS b \
ON a.seg_id=b.cat)"
# Execute the query 
cur.execute(query)
# Make the changes to the database persistent
db.commit()

# Drop some non wanted columns
query="ALTER TABLE "+classifE_schema+"."+sample_training+" DROP COLUMN cat"
# Execute the query 
cur.execute(query)
# Make the changes to the database persistent
db.commit()
# [___CELL_SEPARATOR___]
# Query to find the number of row in the sample table
query="SELECT * FROM "+classifE_schema+"."+sample_training
# Execute query through panda
df_countperclass=pd.read_sql(query, db)
# Show dataframe
df_countperclass.head(10)
# [___CELL_SEPARATOR___]
outputfolder
# [___CELL_SEPARATOR___]
## Define the path to the .csv output
sample_training_csv=os.path.join(outputfolder,"sample_training.csv")
# [___CELL_SEPARATOR___]
# Connect to an existing database
db=pg.connect(database=dbname, user=dbuser, password=dbpassword, host=host)
# Open a cursor to perform database operations
cur=db.cursor()
# [___CELL_SEPARATOR___]
#### Export as .csv
# Query
query="COPY "+classifE_schema+"."+sample_training+" TO '"+sample_training_csv+"' DELIMITER ',' CSV HEADER"
# Execute the CREATE TABLE query 
cur.execute(query)
# Make the changes to the database persistent
db.commit()
# [___CELL_SEPARATOR___]
# Close cursor and communication with the database
cur.close()
db.close()
# [___CELL_SEPARATOR___]
import rpy2
# [___CELL_SEPARATOR___]
%load_ext rpy2.ipython
# [___CELL_SEPARATOR___]
%%R -i sample_training_csv -o training
# Import training
training <- read.csv(sample_training_csv, sep=",", header=TRUE, row.names=1)
training$class_num <- as.factor(training$class_num)
# [___CELL_SEPARATOR___]
training.head()
# [___CELL_SEPARATOR___]
%%R -o colname
colname<-colnames(training)
# [___CELL_SEPARATOR___]
# Create a list with the column name
print list(colname)
# [___CELL_SEPARATOR___]
# Set the name of the colum with class
class_column='class_num'
# Set the name of the colum with the first feature to be used
first_feature='area'
# Set the name of the colum with the last feature to be used
last_feature='ndvi_perc_90'
# [___CELL_SEPARATOR___]
%%R -i class_column,first_feature,last_feature -o features

# Save the index of the column
classnumindex=match(c(class_column),colname)
# Save the index where object's features to be used start
startindex=match(c(first_feature),colname)
# Save the index where object's features to be used stop
stopindex=match(c(last_feature),colname)

# Create dataframe with only columns to be used features
temp1<-as.data.frame(training[classnumindex])
temp2<-as.data.frame(training[startindex:stopindex])
merged_df=merge(temp1,temp2, by=0, all=TRUE)
features<-transform(merged_df, row.names=Row.names, Row.names=NULL)
# Set class column as factor
features$class_num <- as.factor(features$class_num)
# [___CELL_SEPARATOR___]
## Display name of columns 
[x for x in features.columns]
# [___CELL_SEPARATOR___]
features.head()
# [___CELL_SEPARATOR___]
%%R 
# Instal library
if(!is.element('parallel', installed.packages()[,1])){
    cat('\n\nInstalling parallel package from CRAN')
    chooseCRANmirror(ind=1)
    install.packages('parallel')}

if(!is.element('doParallel', installed.packages()[,1])){
    cat('\n\nInstalling doParallel package from CRAN')
    chooseCRANmirror(ind=1)
    install.packages('doParallel')}

if(!is.element('VSURF', installed.packages()[,1])){
    cat('\n\nInstalling VSURF package from CRAN')
    chooseCRANmirror(ind=1)
    install.packages('VSURF')}

library(parallel)
require(parallel)
library(doParallel)
require(doParallel)
library(VSURF)
require(VSURF)
# [___CELL_SEPARATOR___]
%%R -o Surf

# Save column names
colname<-colnames(features)
# Save the index of the column
classnumindex<-match(c(class_column),colname)
# Save the index where object's features to be used start
startindex<-match(c(first_feature),colname)
# Save the index where object's features to be used stop
stopindex<-match(c(last_feature),colname)

# Set number of cores to use
usedcores=detectCores()-5
registerDoParallel(usedcores)
# Feature Selection using VSURF
Surf=VSURF(features[startindex:stopindex],features$class_num, parallel=TRUE, ncores=usedcores)
# [___CELL_SEPARATOR___]
## Set the path to the output .txt file with summary of VSURF
output_summary=os.path.join(outputfolder,"VSURF_summary.txt")
# [___CELL_SEPARATOR___]
%%R -i output_summary

# Print and save summary of VSRUF
summaryVSRUF<-summary(Surf)
output<-capture.output(summary(Surf))
print (summaryVSRUF)
cat(output,file=output_summary,sep="\n")
# [___CELL_SEPARATOR___]
## Set the path to the output csv with results of VSURF
output_interp=os.path.join(outputfolder,"VSURF_interp.csv")
output_pred=os.path.join(outputfolder,"VSURF_pred.csv")
# [___CELL_SEPARATOR___]
%%R -i output_interp,output_pred -o Surf_interp_features,Surf_pred_features

# Save interpretation step and prediction step results
Surf_interp<-Surf$varselect.interp
Surf_pred<-Surf$varselect.pred

# Save name of feature in a list ranked with the same index as VSURF output
colname<-colnames(features[startindex:stopindex])

# Declare empty variables of type 'character'
Surf_interp_features <- character()

# Loop on indexes of features selecteds by VSURF to find the corresponding feature name
count<-0
for (x in Surf_interp){
  count<-count+1
  Surf_interp_features[count]<-colname[x]
}

# Write CSV
write.csv(Surf_interp_features, file=output_interp, row.names=TRUE)

# Declare empty variables of type 'character'
Surf_pred_features <- character()

# Loop on indexes of features selecteds by VSURF to find the corresponding feature name
count<-0
for (x in Surf_pred){
  count<-count+1
  Surf_pred_features[count]<-colname[x]
}

# Write CSV
write.csv(Surf_pred_features, file=output_pred, row.names=TRUE)
# [___CELL_SEPARATOR___]
## Print features selected by VSURF at interpretation step
print "Interpretation results"
for i in range(len(Surf_interp_features)):
    print str(i+1)+"    "+Surf_interp_features[i] 
# [___CELL_SEPARATOR___]
## Print features selected by VSURF at interpretation step
print "Prediction results"
for i in range(len(Surf_pred_features)):
    print str(i+1)+"    "+Surf_pred_features[i] 
# [___CELL_SEPARATOR___]
## Set the path to the output plot (PDF)
outputgraph=os.path.join(outputfolder,"VSURF_opt_plot.pdf")
# [___CELL_SEPARATOR___]
%%R -i outputgraph

# Export the plot in pdf
VSURF_plot_export=outputgraph
pdf(VSURF_plot_export)
plot(Surf, var.names = FALSE,
     nvar.interp = length(Surf_pred))
dev.off()
# [___CELL_SEPARATOR___]
## Display graphs
import wand
from wand.image import Image as WImage
img = WImage(filename=outputgraph)
img
# [___CELL_SEPARATOR___]
# Connect to an existing database
db=pg.connect(database=dbname, user=dbuser, password=dbpassword, host=host)
# Open a cursor to perform database operations
cur=db.cursor()
# [___CELL_SEPARATOR___]
### Set if all feature have to be used (vsurfonly=False) 
### or only those resulting from prediction step of VSURF (vsurfonly=True)
vsurfonly=True
# [___CELL_SEPARATOR___]
## Save list of features to be used 
if vsurfonly:
    features_for_classif=Surf_pred_features
else:
    features_for_classif=list(features.columns.values)[1:]
# [___CELL_SEPARATOR___]
','.join(features_for_classif)
# [___CELL_SEPARATOR___]
## Define the path to the .csv
training_csv=os.path.join(outputfolder,"training_csv.csv")
# [___CELL_SEPARATOR___]
#### Export as .csv
# Query
query="COPY (\
SELECT seg_id, class_num, "+", ".join(features_for_classif)+" \
FROM "+classifE_schema+"."+sample_training+") TO '"+training_csv+"' DELIMITER ',' CSV HEADER"
# Execute the CREATE TABLE query 
cur.execute(query)
# Make the changes to the database persistent
db.commit()
# [___CELL_SEPARATOR___]
## Evalutate the number of row in 'object_stat' table
query="SELECT reltuples::bigint AS estimated_object \
FROM pg_class \
WHERE oid='"+stat_schema+"."+object_stats_optical+"'::regclass"  
# Execute query through panda
df=pd.read_sql(query, db)
# Save estimated number of objects
estimate=list(df['estimated_object'])[0]
# Print
print "The table contains "+str(estimate)+" rows (estimate)."
# [___CELL_SEPARATOR___]
# Define number of object to classify on each loop
nbobjloop=1000000
# Add 10% of estimated number of rows to be sure to well cover the full dataset 
remaining_rows=int(estimate*1.05)
# Define number of loops for classification
import math
loops=int(math.ceil(remaining_rows/(nbobjloop*1.0)))
## Print what is going to happend
print "Classification will be made on "+str(loops)+" loop(s)"
# [___CELL_SEPARATOR___]
# Define starting offset and limit (for the firsth loop)
offset=0
# Declare an empty list containing the paths to .csv
list_objstat_csv=[]
# Export object statistics on multiple .csv files
for loop in range(loops):
    ## Define the path to the .csv
    objstat_csv=os.path.join(outputfolder,"objects_stats_"+str(loop+1)+".csv")
    list_objstat_csv.append(objstat_csv)        
    # Query to export as .csv
    query="COPY (WITH \
    stats AS(SELECT * FROM "+stat_schema+"."+object_stats_optical+")\
    \
    SELECT cat, "+", ".join(features_for_classif)+" \
    FROM stats ORDER BY cat \
    OFFSET "+str(offset)+" LIMIT "+str(nbobjloop)+") TO '"+objstat_csv+"' DELIMITER ',' CSV HEADER"
    # Execute the CREATE TABLE query 
    cur.execute(query)  
    # Print
    print "Rows between "+str(offset)+" and "+str(offset+nbobjloop)+" exported in .csv file '"+objstat_csv+"'"
    # Update offset and limit 
    offset+=nbobjloop
# [___CELL_SEPARATOR___]
# Close cursor and communication with the database
cur.close()
db.close()
# [___CELL_SEPARATOR___]
%%R 

# Install package
if(!is.element('caret', installed.packages()[,1])){
  cat('\n\nInstalling caret package from CRAN')
  chooseCRANmirror(ind=1)
  install.packages('caret')}
# Install package
if(!is.element('randomForest', installed.packages()[,1])){
  cat('\n\nInstalling randomForest package from CRAN')
  chooseCRANmirror(ind=1)
  install.packages('randomForest')}
# Install package
if(!is.element('pROC', installed.packages()[,1])){
  cat('\n\nInstalling pROC package from CRAN')
  chooseCRANmirror(ind=1)
  install.packages('pROC')}
# Install package
if(!is.element('e1071', installed.packages()[,1])){
  cat('\n\nInstalling e1071 package from CRAN')
  chooseCRANmirror(ind=1)
  install.packages('e1071')}
# [___CELL_SEPARATOR___]
%%R 

# Load libraries
library(parallel)
require(parallel)
library(doParallel)
require(doParallel)
library(caret)
require(caret)
library(randomForest)
require(randomForest)
library(e1071)
require(e1071)
# [___CELL_SEPARATOR___]
## Set the path to the output of random forest classification
output_accuracy=os.path.join(outputfolder,"accuracy_RF.csv")
# [___CELL_SEPARATOR___]
%%R -i training_csv,output_accuracy

# Set number of cores to use
usedcores=detectCores()-5
registerDoParallel(usedcores)

# Import training
training <- read.csv(training_csv, sep=",", header=TRUE, row.names=1)
# Define factor
training$class_num <- as.factor(training$class_num)

# Cross-validation setting
MyFolds.cv <- createMultiFolds(training$class_num, k=5, times=10)
MyControl.cv <- trainControl(method='repeatedCV', index=MyFolds.cv, allowParallel = TRUE)

# Train Random Forest
rfModel <- train(class_num~.,training,method='rf', trControl=MyControl.cv,tuneLength=10)
resamps.cv <- rfModel$resample
accuracy_means <- mean(resamps.cv$Accuracy)
kappa_means <- mean(resamps.cv$Kappa)
df_means <- data.frame(method='rf',accuracy=accuracy_means, kappa=kappa_means)
write.csv(df_means, output_accuracy, row.names=FALSE, quote=FALSE)
# [___CELL_SEPARATOR___]
#### Show mean accuracy results from cross-validation for tuning
## Import .csv file
accuracy=pd.read_csv(output_accuracy, sep=',',header=0)
## Display table
accuracy.head(15)
# [___CELL_SEPARATOR___]
## Set the path to the output of random forest classification
output_varimp=os.path.join(outputfolder,"VariablesImportance_RF.pdf")
output_rfmodel=os.path.join(outputfolder,"RF_model.txt")
output_cv=os.path.join(outputfolder,"RF_cv.pdf")
# [___CELL_SEPARATOR___]
%%R -i output_varimp,output_rfmodel,output_cv

# Plot variable importance
library(pROC)
importance <- varImp(rfModel, scale=FALSE)
pdf(output_varimp, width = 11, height = ncol(features)/6 )
print(plot(importance))
dev.off()

# Show final model
tmp<-rfModel$finalModel
sink(output_rfmodel)
print(tmp)
sink()

# Plot cross validation tuning results
pdf(output_cv)
print(plot(rfModel))
dev.off()
# [___CELL_SEPARATOR___]
#### Import classifiers tuning parameters and confusion matrix
## Open file
classifier_runs = open(output_rfmodel, 'r')  
## Read file
print classifier_runs.read()
# [___CELL_SEPARATOR___]
## Display graphs
import wand
from wand.image import Image as WImage
img = WImage(filename=output_varimp)
img
# [___CELL_SEPARATOR___]
## Display graphs
import wand
from wand.image import Image as WImage
img = WImage(filename=output_cv)
img
# [___CELL_SEPARATOR___]
%%R -i list_objstat_csv

# Classification using loop
for(i in 1:length(list_objstat_csv)) {
    filepath<-list_objstat_csv[i]
    # Import object statistics as dataframe
    features <- read.csv(filepath, sep=",", header=TRUE, row.names=1)
    # Predict class 
    predicted <- data.frame(predict(rfModel, features))
    name<-paste('resultsdf',i,sep='')
    assign(name,data.frame(id=rownames(features), predicted))
    rm(features)
    rm(predicted)
    gc()
}
# [___CELL_SEPARATOR___]
%%R

# Merge predictions in one single dataframe
listdf<-lapply(ls(pattern = "resultsdf*"), get)
rf_predictions<-do.call(rbind,listdf)
# [___CELL_SEPARATOR___]
## Define outputfile for .csv with training data for R
trainingset_R=os.path.join(outputfolder,"RF_trainingset_R.csv")
## Define outputfile for .csv with predictions of classification
classif_results=os.path.join(outputfolder,"RF_classif_results_R.csv")
# [___CELL_SEPARATOR___]
%%R -i trainingset_R,classif_results
write.csv(training, file=trainingset_R, row.names=FALSE, quote=FALSE)
write.csv(rf_predictions, file=classif_results, row.names=FALSE, quote=FALSE)
# [___CELL_SEPARATOR___]
%%R 

# Remove variables not needed anymore
rm(training)
gc()

rm(list=ls(pattern = "resultsdf*"))
rm(listdf)
gc()
# [___CELL_SEPARATOR___]
for csv in list_objstat_csv:
    os.remove(csv)
# [___CELL_SEPARATOR___]
# Connect to an existing database
db=pg.connect(database=dbname, user=dbuser, password=dbpassword, host=host)
# Open a cursor to perform database operations
cur=db.cursor()
# [___CELL_SEPARATOR___]
# Drop table if exists:
cur.execute("DROP TABLE IF EXISTS "+classifE_schema+"."+classif)
# Make the changes to the database persistent
db.commit()

# Create new table
query="CREATE TABLE "+classifE_schema+"."+classif+" (seg_id integer PRIMARY KEY, rf_pred_l2 integer)"
# Execute the CREATE TABLE query 
cur.execute(query)
# Make the changes to the database persistent
db.commit()

# Create query for copy data from csv
query="COPY "+classifE_schema+"."+classif+" FROM '"+str(classif_results)+"' HEADER DELIMITER ',' CSV" 
# Execute the COPY FROM CSV query 
cur.execute(query)
# Make the changes to the database persistent
db.commit()    
# [___CELL_SEPARATOR___]
## Add column for prediction at level 2b
query="ALTER TABLE "+classifE_schema+"."+classif+" ADD COLUMN rf_pred_l2b integer"
# Execute the query 
cur.execute(query)
# Make the changes to the database persistent
db.commit()
# [___CELL_SEPARATOR___]
# Update the value
query="UPDATE "+classifE_schema+"."+classif+" SET \
rf_pred_l2b = '20' WHERE  rf_pred_l2 IN ('21','22')"
# Execute the query 
cur.execute(query)
# Make the changes to the database persistent
db.commit()
# [___CELL_SEPARATOR___]
# Update the value
query="UPDATE "+classifE_schema+"."+classif+" SET \
rf_pred_l2b = '30' WHERE  rf_pred_l2 IN ('32','33','34')"
# Execute the query 
cur.execute(query)
# Make the changes to the database persistent
db.commit()
# [___CELL_SEPARATOR___]
# Update the value
query="UPDATE "+classifE_schema+"."+classif+" SET \
rf_pred_l2b = rf_pred_l2 WHERE rf_pred_l2b IS NULL"
# Execute the query 
cur.execute(query)
# Make the changes to the database persistent
db.commit()
# [___CELL_SEPARATOR___]
## Add column for prediction at level 1
query="ALTER TABLE "+classifE_schema+"."+classif+" ADD COLUMN rf_pred_l1 integer"
# Execute the query 
cur.execute(query)
## Update column for prediction and ground truth at level 2 
query="UPDATE "+classifE_schema+"."+classif+" SET rf_pred_l1=rf_pred_l2/10"
# Execute the query 
cur.execute(query)
# Make the changes to the database persistent
db.commit()
# [___CELL_SEPARATOR___]
## Define path of .txt file for saving prediction at different level
outputfile=classif_results.split(".")[0]+'_diff_levels.csv'
# [___CELL_SEPARATOR___]
#### Export as .csv
# Query
query="COPY "+classifE_schema+"."+classif+" TO '"+outputfile+"' DELIMITER ',' CSV HEADER"
# Execute the CREATE TABLE query 
cur.execute(query)
# Make the changes to the database persistent
db.commit()
# [___CELL_SEPARATOR___]
# Close cursor and communication with the database
cur.close()
db.close()
# [___CELL_SEPARATOR___]
## Folder in which save processing time output
outputfolder=os.path.join(resultfolder,"accuracy_assess")

## Create the folder if does not exists
if not os.path.exists(outputfolder):
    os.makedirs(outputfolder)
    print "Folder '"+outputfolder+"' created"
# [___CELL_SEPARATOR___]
# Connect to an existing database
db=pg.connect(database=dbname, user=dbuser, password=dbpassword, host=host)
# Open a cursor to perform database operations
cur=db.cursor()
# [___CELL_SEPARATOR___]
# Build a query to drop view if exists
query="DROP TABLE IF EXISTS "+classifE_schema+"."+groundtruth_classif
# Execute the query 
cur.execute(query)
# Make the changes to the database persistent
db.commit()
# [___CELL_SEPARATOR___]
#### Join sample_test and classification results
query="CREATE TABLE "+classifE_schema+"."+groundtruth_classif+" AS (\
SELECT a.cat_point, a.id, \
a.class AS level2_label, \
a.class_b AS level2b_label, \
a.class_l1 AS level1_label, \
a.class_num::integer AS level2_groundtr, \
a.class_num_b::integer AS level2b_groundtr, \
a.class_num_l1::integer AS level1_groundtr, \
c.rf_pred_l2 AS rf_level2, \
c.rf_pred_l2b AS rf_level2b, \
c.rf_pred_l1 AS rf_level1 \
FROM "+sample_schema+"."+sample_opt_test+" AS a \
LEFT JOIN "+classifE_schema+"."+classif+" AS c ON a.seg_id = c.seg_id)"
# Execute the query 
cur.execute(query)
# Make the changes to the database persistent
db.commit()
# [___CELL_SEPARATOR___]
#### Save ground truth, optical_predic, opticalsar_predic as lists, for Level-1 and Level-2
# Query 
query="SELECT * FROM "+classifE_schema+"."+groundtruth_classif+" ORDER BY id"
# Execute query through panda
df=pd.read_sql(query, db)

# Show dataframe
df.head(50)
# [___CELL_SEPARATOR___]
# Save ground truth - Level2
groundtruth_L2=list(df['level2_groundtr'])
# Save ground truth - Level2b
groundtruth_L2b=list(df['level2b_groundtr'])
# Save ground truth - Level1
groundtruth_L1=list(df['level1_groundtr'])

# Save predictions - level2
prediction_L2=list(df['rf_level2'])
# Save predictions - level2b
prediction_L2b=list(df['rf_level2b'])
# Save predictions - level1
prediction_L1=list(df['rf_level1'])
# [___CELL_SEPARATOR___]
# Display number of objects in test sample
nrows=len(groundtruth_L2)
print nrows
# [___CELL_SEPARATOR___]
## Zip the list together - Level 2
ziped_results=zip(groundtruth_L2,prediction_L2)
## Sort
ziped_results.sort()
## Unzip
groundtruth_L2,prediction_L2=zip(*ziped_results)
# [___CELL_SEPARATOR___]
## Zip the list together - Level 2b
ziped_results=zip(groundtruth_L2b,prediction_L2b)
## Sort
ziped_results.sort()
## Unzip
groundtruth_L2b,prediction_L2b=zip(*ziped_results)
# [___CELL_SEPARATOR___]
## Zip the list together - Level 1
ziped_results=zip(groundtruth_L1,prediction_L1)
## Sort
ziped_results.sort()
## Unzip
groundtruth_L1,prediction_L1=zip(*ziped_results)
# [___CELL_SEPARATOR___]
## Check if lists contain th same distinct values
tmp1=list(set(groundtruth_L2))
tmp1.sort()
tmp2=list(set(prediction_L2))
tmp2.sort()
if tmp1 != tmp2:
    sys.exit('WARNING: Lists contain different distinct values. Please check before continue')
    
## Check if lists contain th same distinct values
tmp1=list(set(groundtruth_L2b))
tmp1.sort()
tmp2=list(set(prediction_L2b))
tmp2.sort()
if tmp1 != tmp2:
    sys.exit('WARNING: Lists contain different distinct values. Please check before continue')

## Check if lists contain th same distinct values
tmp1=list(set(groundtruth_L1))
tmp1.sort()
tmp2=list(set(prediction_L1))
tmp2.sort()
if tmp1 != tmp2:
    sys.exit('WARNING: Lists contain different distinct values. Please check before continue')
# [___CELL_SEPARATOR___]
#### Save ground truth, optical_predic, opticalsar_predic as lists, for Level-1 and Level-2
# Query 
query="SELECT DISTINCT level2_groundtr, level2_label \
FROM "+classifE_schema+"."+groundtruth_classif+" ORDER BY level2_groundtr"
# Execute query through panda
df=pd.read_sql(query, db)
# Save ground truth classes labels - Level2
classes_L2=list(df['level2_label'])

# Query 
query="SELECT DISTINCT level2b_groundtr, level2b_label \
FROM "+classifE_schema+"."+groundtruth_classif+" ORDER BY level2b_groundtr"
# Execute query through panda
df=pd.read_sql(query, db)
# Save ground truth classes labels - Level2
classes_L2b=list(df['level2b_label'])

# Query 
query="SELECT DISTINCT level1_groundtr, level1_label \
FROM "+classifE_schema+"."+groundtruth_classif+" ORDER BY level1_groundtr"
# Execute query through panda
df=pd.read_sql(query, db)
# Save ground truth classes labels - Level2
classes_L1=list(df['level1_label'])
# [___CELL_SEPARATOR___]
print "Level 2 classes:\n\n"+'\n'.join(classes_L2)
# [___CELL_SEPARATOR___]
print "Level 2 classes:\n\n"+'\n'.join(classes_L2b)
# [___CELL_SEPARATOR___]
print "Level 2 classes:\n\n"+'\n'.join(classes_L1)
# [___CELL_SEPARATOR___]
## Import libraries
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix
import itertools
import numpy as np
%matplotlib inline  
# [___CELL_SEPARATOR___]
def plot_confusion_matrix(cm, classes,
                          normalize=False,
                          title='Confusion matrix',
                          cmap=plt.cm.Blues):
    """
    This function prints and plots the confusion matrix.
    Normalization can be applied by setting `normalize=True`.
    """
    plt.imshow(cm, interpolation='nearest', cmap=cmap)
    plt.title(title)
    plt.colorbar()
    tick_marks = np.arange(len(classes))
    plt.xticks(tick_marks, classes, ha='right', rotation=45)
    plt.yticks(tick_marks, classes)

    if normalize:
        cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
        print("Normalized confusion matrix")
    else:
        print('Confusion matrix, without normalization')

    #print(cm)

    thresh = cm.max() / 2.
    for i, j in itertools.product(range(cm.shape[0]), range(cm.shape[1])):
        if normalize:
            plt.text(j, i, round(cm[i, j],2),
            horizontalalignment="center",
            color="white" if cm[i, j] > thresh else "black")
        else:
            plt.text(j, i, cm[i, j],
            horizontalalignment="center",
            color="white" if cm[i, j] > thresh else "black")

    plt.tight_layout()
    plt.ylabel('True label')
    plt.xlabel('Predicted label')
# [___CELL_SEPARATOR___]
# Compute confusion matrix
cnf_matrix_L2=confusion_matrix(groundtruth_L2, prediction_L2)
# [___CELL_SEPARATOR___]
## Set the path to the output
output_rowconfmat=os.path.join(outputfolder,"rowconfusionmatrix_L2.txt")

## Export the row confusion matrix
numpy.savetxt(output_rowconfmat, cnf_matrix_L2.astype(np.int), fmt='%d', delimiter=",")
# [___CELL_SEPARATOR___]
# Plot non-normalized confusion matrix
fig_cm=plt.figure(figsize=(15,10))
plot_confusion_matrix(cnf_matrix_L2, classes=classes_L2,
                      title='Confusion matrix, without normalization')
# Plot normalized confusion matrix
fig_cm_normal=plt.figure(figsize=(15,10))
plot_confusion_matrix(cnf_matrix_L2, classes=classes_L2, normalize=True,
                      title='Normalized confusion matrix')

plt.show()
# [___CELL_SEPARATOR___]
## Set the path to the output
output_confmat_pdf=os.path.join(outputfolder,"confusionmatrix_L2.pdf")
output_confmatA_png=os.path.join(outputfolder,"confusionmatrixA_L2.png")
output_confmatB_png=os.path.join(outputfolder,"confusionmatrixB_L2.png")
# [___CELL_SEPARATOR___]
# Export in PDF
from matplotlib.backends.backend_pdf import PdfPages
pp=PdfPages(output_confmat_pdf)
pp.savefig(fig_cm)
pp.savefig(fig_cm_normal)
pp.close()

# Export in PNG
fig_cm.savefig(output_confmatA_png, format='png', dpi=300)
fig_cm_normal.savefig(output_confmatB_png, format='png', dpi=300)
# [___CELL_SEPARATOR___]
# Compute confusion matrix
cnf_matrix_L2b=confusion_matrix(groundtruth_L2b, prediction_L2b)
# [___CELL_SEPARATOR___]
## Set the path to the output
output_rowconfmat=os.path.join(outputfolder,"rowconfusionmatrix_L2b.txt")

## Export the row confusion matrix
numpy.savetxt(output_rowconfmat, cnf_matrix_L2b.astype(np.int), fmt='%d', delimiter=",")
# [___CELL_SEPARATOR___]
# Plot non-normalized confusion matrix
fig_cm=plt.figure(figsize=(15,10))
plot_confusion_matrix(cnf_matrix_L2b, classes=classes_L2b,
                      title='Confusion matrix, without normalization')
# Plot normalized confusion matrix
fig_cm_normal=plt.figure(figsize=(15,10))
plot_confusion_matrix(cnf_matrix_L2b, classes=classes_L2b, normalize=True,
                      title='Normalized confusion matrix')

plt.show()
# [___CELL_SEPARATOR___]
## Set the path to the output
output_confmat_pdf=os.path.join(outputfolder,"confusionmatrix_L2b.pdf")
output_confmatA_png=os.path.join(outputfolder,"confusionmatrixA_L2b.png")
output_confmatB_png=os.path.join(outputfolder,"confusionmatrixB_L2b.png")
# [___CELL_SEPARATOR___]
# Export in PDF
from matplotlib.backends.backend_pdf import PdfPages
pp=PdfPages(output_confmat_pdf)
pp.savefig(fig_cm)
pp.savefig(fig_cm_normal)
pp.close()

# Export in PNG
fig_cm.savefig(output_confmatA_png, format='png', dpi=300)
fig_cm_normal.savefig(output_confmatB_png, format='png', dpi=300)
# [___CELL_SEPARATOR___]
# Compute confusion matrix
cnf_matrix_L1=confusion_matrix(groundtruth_L1, prediction_L1)
# [___CELL_SEPARATOR___]
## Set the path to the output
output_rowconfmat=os.path.join(outputfolder,"rowconfusionmatrix_L1.txt")

## Export the row confusion matrix
numpy.savetxt(output_rowconfmat, cnf_matrix_L1.astype(np.int), fmt='%d', delimiter=",")
# [___CELL_SEPARATOR___]
# Plot non-normalized confusion matrix
fig_cm=plt.figure(figsize=(10,7))
plot_confusion_matrix(cnf_matrix_L1, classes=classes_L1,
                      title='Confusion matrix, without normalization')
# Plot normalized confusion matrix
fig_cm_normal=plt.figure(figsize=(10,7))
plot_confusion_matrix(cnf_matrix_L1, classes=classes_L1, normalize=True,
                      title='Normalized confusion matrix')

plt.show()
# [___CELL_SEPARATOR___]
## Set the path to the output
output_confmat_pdf=os.path.join(outputfolder,"confusionmatrix_L1.pdf")
output_confmatA_png=os.path.join(outputfolder,"confusionmatrixA_L1.png")
output_confmatB_png=os.path.join(outputfolder,"confusionmatrixB_L1.png")
# [___CELL_SEPARATOR___]
# Export in PDF
from matplotlib.backends.backend_pdf import PdfPages
pp=PdfPages(output_confmat_pdf)
pp.savefig(fig_cm)
pp.savefig(fig_cm_normal)
pp.close()

# Export in PNG
fig_cm.savefig(output_confmatA_png, format='png', dpi=300)
fig_cm_normal.savefig(output_confmatB_png, format='png', dpi=300)
# [___CELL_SEPARATOR___]
## Import libraries
from sklearn.metrics import accuracy_score
from sklearn.metrics import cohen_kappa_score
from sklearn.metrics import classification_report

from sklearn.metrics import f1_score
# [___CELL_SEPARATOR___]
## Set the path to the output
output=os.path.join(outputfolder,"RF_classif_repport_L2.txt")
# [___CELL_SEPARATOR___]
# Define dataset to take into account
y_true=groundtruth_L2
y_pred=prediction_L2
class_label=classes_L2

# Compute precision accuracy
accuracy=accuracy_score(y_true, y_pred, normalize=True)
# Compute Cohen's Kappa
cohen_kappa=cohen_kappa_score(y_true, y_pred)
# Compute f1-score
f_1=f1_score(y_true, y_pred, average='weighted')
# Compute 'classification report'
classif_report=classification_report(y_true, y_pred, target_names=class_label)

# Save as .txt file
f=open(output, 'w')
f.write("Performance evalutation: \n")
f.write("Overall Accuracy: "+str(accuracy)+"\n")
f.write("Cohen's Kappa: "+str(cohen_kappa)+"\n")
f.write("F1-score: "+str(f_1)+"\n")
f.write("\n\n")
f.write("Classification report: \n "+classif_report)
f.close()

# Show file content
f=open(output,'r')
file_contents=f.read()
print (file_contents)
f.close()
# [___CELL_SEPARATOR___]
## Set the path to the output
output=os.path.join(outputfolder,"RF_classif_repport_L2b.txt")
# [___CELL_SEPARATOR___]
# Define dataset to take into account
y_true=groundtruth_L2b
y_pred=prediction_L2b
class_label=classes_L2b

# Compute precision accuracy
accuracy=accuracy_score(y_true, y_pred, normalize=True)
# Compute Cohen's Kappa
cohen_kappa=cohen_kappa_score(y_true, y_pred)
# Compute f1-score
f_1=f1_score(y_true, y_pred, average='weighted')
# Compute 'classification report'
classif_report=classification_report(y_true, y_pred, target_names=class_label)

# Save as .txt file
f=open(output, 'w')
f.write("Performance evalutation: \n")
f.write("Overall Accuracy: "+str(accuracy)+"\n")
f.write("Cohen's Kappa: "+str(cohen_kappa)+"\n")
f.write("F1-score: "+str(f_1)+"\n")
f.write("\n\n")
f.write("Classification report: \n "+classif_report)
f.close()

# Show file content
f=open(output,'r')
file_contents=f.read()
print (file_contents)
f.close()
# [___CELL_SEPARATOR___]
## Set the path to the output
output=os.path.join(outputfolder,"RF_classif_repport_L1.txt")
# [___CELL_SEPARATOR___]
# Define dataset to take into account
y_true=groundtruth_L1
y_pred=prediction_L1
class_label=classes_L1

# Compute precision accuracy
accuracy=accuracy_score(y_true, y_pred, normalize=True)
# Compute Cohen's Kappa
cohen_kappa=cohen_kappa_score(y_true, y_pred)
# Compute f1-score
f_1=f1_score(y_true, y_pred, average='weighted')
# Compute 'classification report'
classif_report=classification_report(y_true, y_pred, target_names=class_label)

# Save as .txt file
f=open(output, 'w')
f.write("Performance evalutation: \n")
f.write("Overall Accuracy: "+str(accuracy)+"\n")
f.write("Cohen's Kappa: "+str(cohen_kappa)+"\n")
f.write("F1-score: "+str(f_1)+"\n")
f.write("\n\n")
f.write("Classification report: \n "+classif_report)
f.close()

# Show file content
f=open(output,'r')
file_contents=f.read()
print (file_contents)
f.close()
# [___CELL_SEPARATOR___]
## Print current mapset
print "You are currently working in the <"+str(mapsetname)+"> mapset"
# [___CELL_SEPARATOR___]
## Folder in which save processing time output
outputfolder=os.path.join(resultfolder,"classified_rasters")

## Create the folder if does not exists
if not os.path.exists(outputfolder):
    os.makedirs(outputfolder)
    print "Folder '"+outputfolder+"' created"
# [___CELL_SEPARATOR___]
# Connect to an existing database
db=pg.connect(database=dbname, user=dbuser, password=dbpassword, host=host)
# Open a cursor to perform database operations
cur=db.cursor()
# [___CELL_SEPARATOR___]
print "Start creating classified rasters"

classif_suffix=('l2','l2b','l1')
for x in classif_suffix:
    ## Set name for raster with the prediction at level 2
    prediction_raster='rf_classif_'+x

    #### Save 'seg_id' and the corresponding prediction for in a list
    query="SELECT seg_id, rf_pred_"+x+" FROM "+classifE_schema+"."+classif
    df=pd.read_sql(query, db)

    # Save seg_id of objects in a list
    listsegid=list(df['seg_id'])
    # Save predictions at level_2 in a list
    listpredict=list(df['rf_pred_'+x])

    if len(listsegid) <> len(listpredict):
        sys.exit('WARNING: lenght of lists containing segid and prediction are not the same. Please check before continue')
    else:
        nrows=len(listsegid)
        print str(nrows)+" segment are going to be reclassified"
    
    ##### Reclassify raster
    ## Create a temporary 'reclass_rule.csv' file
    temprulecsv=os.path.join(tempfile.gettempdir(),"reclass_rules.csv") # Define the csv output file name
    f = open(temprulecsv, 'w')
    # Write rules in the csv file
    for i in range(0,nrows-1):
        f.write(str(listsegid[i]))
        f.write("=")
        f.write(str(listpredict[i]))
        f.write("\n")
    f.write("*")
    f.write("=")
    f.write("NULL")
    f.close()

    ## Reclass segments raster layer to keep only outliers segments, using the reclas_rule.csv file (create temporary raster)
    grass.run_command('g.region', overwrite=True, raster="segments"+"@"+user["classificationA_mapsetname"])
    print ("Working on <"+prediction_raster+">: Reclassify original segment layer")
    grass.run_command('r.reclass', overwrite=True, input="segments"+"@"+user["classificationA_mapsetname"], 
                      output=prediction_raster, rules=temprulecsv)
    os.remove(temprulecsv)

    #### Create 'real raster'
    #### Make a copy of the classified maps of faster display in GRASS GIS
    ## Saving current time for processing time management
    print ("Working on <"+prediction_raster+">: Make hard copy of the reclassified layer")
    ## Set computational region
    grass.run_command('g.region', overwrite=True, raster="segments"+"@"+user["classificationA_mapsetname"])
    ## Create the same raster with r.mapcalc
    formula=prediction_raster+"_temp="+prediction_raster
    grass.mapcalc(formula, overwrite=True)
    ## Rename the new raster with the name of the original one (will be overwrited)
    print ("Working on <"+prediction_raster+">: Renaming layer")
    renameformula=prediction_raster+"_temp,"+prediction_raster
    grass.run_command('g.rename', overwrite=True, raster=renameformula)
# [___CELL_SEPARATOR___]
# Define color table. Replace with the RGB values of wanted colors of each class
color_rule="11  227:26:28"+"\n"
color_rule+="12  255:141:1"+"\n"
color_rule+="13  94:221:227"+"\n"
color_rule+="14  102:102:102"+"\n"
color_rule+="21  246:194:142"+"\n"
color_rule+="22  211:217:173"+"\n"
color_rule+="31  0:128:0"+"\n"
color_rule+="32  189:255:185"+"\n"
color_rule+="33  88:190:141"+"\n"
color_rule+="34  29:220:0"+"\n"
color_rule+="41  30:30:192"+"\n"
color_rule+="51  0:0:0"+"\n"

## Create a temporary 'color_table.txt' file
color_table=os.path.join(outputfolder,"color_table_l2.txt") # Define the csv output file name
f = open(color_table, 'w')
f.write(color_rule)
f.close()
# [___CELL_SEPARATOR___]
# Define color table. Replace with the RGB values of wanted colors of each class
color_rule="11  227:26:28"+"\n"
color_rule+="12  255:141:1"+"\n"
color_rule+="13  94:221:227"+"\n"
color_rule+="14  102:102:102"+"\n"
color_rule+="20  211:217:173"+"\n"
color_rule+="30  29:220:0"+"\n"
color_rule+="31  0:128:0"+"\n"
color_rule+="41  30:30:192"+"\n"
color_rule+="51  0:0:0"+"\n"

## Create a temporary 'color_table.txt' file
color_table=os.path.join(outputfolder,"color_table_l2b.txt") # Define the csv output file name
f = open(color_table, 'w')
f.write(color_rule)
f.close()
# [___CELL_SEPARATOR___]
# Define color table. Replace with the RGB values of wanted colors of each class
color_rule="1   227:26:28"+"\n"
color_rule+="2   211:217:173"+"\n"
color_rule+="3   29:220:0"+"\n"
color_rule+="4   30:30:192"+"\n"
color_rule+="5   0:0:0"+"\n"

## Create a temporary 'color_table.txt' file
color_table=os.path.join(outputfolder,"color_table_l1.txt") # Define the csv output file name
f = open(color_table, 'w')
f.write(color_rule)
f.close()
# [___CELL_SEPARATOR___]
# Create a list with classified raster
classifiedraster_list=grass.list_strings("rast", pattern="rf_classif_*", flag='r', mapset=classifE_schema)
print classifiedraster_list
# [___CELL_SEPARATOR___]
for prediction_raster in classifiedraster_list:
    ## Apply new color the existing GRASS colortable (for faster display in GRASS map display)
    suffix=prediction_raster.split("@")[0].split("_")[-1]
    color_table_file=os.path.join(outputfolder,"color_table_"+suffix+".txt")
    grass.run_command('r.colors', map=prediction_raster, rules=color_table_file)
# [___CELL_SEPARATOR___]
## Saving current time for processing time management
print ("Export classified raster maps on " + time.ctime())
begintime_exportraster=time.time()

for prediction_raster in classifiedraster_list:
    outputname=os.path.join(outputfolder,prediction_raster+".tif")
    grass.run_command('g.region', overwrite=True, raster=prediction_raster)
    grass.run_command('r.out.gdal', overwrite=True, input=prediction_raster, output=outputname, format='GTiff')
    
## Compute processing time and print it
print_processing_time(begintime_exportraster, "Classified raster maps exported in ")
# [___CELL_SEPARATOR___]
print("The script ends at "+ time.ctime())
print_processing_time(begintime_segmentation_full, "Entire process has been achieved in ")