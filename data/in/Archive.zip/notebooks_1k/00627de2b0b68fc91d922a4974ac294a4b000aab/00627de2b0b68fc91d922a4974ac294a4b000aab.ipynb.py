import numpy as np
import pandas as pd
import scipy
import statsmodels.api as sm
import matplotlib.pyplot as plt
import seaborn as sns
import sklearn
import statsmodels.graphics.tsaplots as sgt
import statsmodels.tsa.stattools as sts
from statsmodels.tsa.arima_model import ARIMA
from statsmodels.tsa.statespace.sarimax import SARIMAX
from pmdarima.arima import auto_arima
from pmdarima.arima import OCSBTest 
from statsmodels.tsa.arima_model import ARIMA
from arch import arch_model
import seaborn as sns
import yfinance
import warnings
warnings.filterwarnings("ignore")
sns.set()
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
# Starting Date

# First Official Announcement - 49.9%

# Second Official Announcement - 51.1%

#Ending Date

# Dieselgate

# [___CELL_SEPARATOR___]
# Extracting Closing Prices

# Creating Returns


# Creating Squared Returns

# Extracting Volume

# [___CELL_SEPARATOR___]
# Assigning the Frequency and Filling NA Values

# [___CELL_SEPARATOR___]
# Removing Surplus Data

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
#color = "#33B8FF"
#color = "#49FF3A"
#color = "#FEB628"

#color = "#1E7EB2"
#color = "#2FAB25"
#color = "#BA861F"

#color = "#0E3A52"
#color = "#225414"
#color = "#7C5913"

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
