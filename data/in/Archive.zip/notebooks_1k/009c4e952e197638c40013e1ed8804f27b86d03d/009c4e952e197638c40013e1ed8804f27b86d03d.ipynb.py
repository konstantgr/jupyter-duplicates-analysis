from showit import image
import matplotlib.pyplot as plt
# [___CELL_SEPARATOR___]
%matplotlib inline
# [___CELL_SEPARATOR___]
from extraction.utils import make_gaussian
data, series, truth = make_gaussian(n=5, seed=42, noise=0.5, withparams=True)
# [___CELL_SEPARATOR___]
base = data.mean().toarray()
image(base);
# [___CELL_SEPARATOR___]
from extraction import NMF
algorithm = NMF(k=5, percentile=95, overlap=0.1)
# [___CELL_SEPARATOR___]
model = algorithm.fit(data, chunk_size=(100,200))
# [___CELL_SEPARATOR___]
image(model.regions.mask(dims=data.shape[1:], cmap_stroke='rainbow', fill=None, base=base));
# [___CELL_SEPARATOR___]
image(truth.regions.mask(dims=data.shape[1:], cmap='rainbow', stroke='black', base=base));
# [___CELL_SEPARATOR___]
plt.plot(model.transform(data).toarray().T);
plt.axis('off');
# [___CELL_SEPARATOR___]
plt.plot(series.T);
plt.axis('off');