import os
import numpy as np
from sklearn.tree import ExtraTreeRegressor
from sklearn import manifold
import matplotlib.pyplot as plt
from matplotlib.pyplot import imshow
from matplotlib import animation
from PIL import Image
import pickle
from scipy.linalg import norm

import networkx as nx
from scipy import spatial


from bokeh.plotting import figure, output_file, show, ColumnDataSource
from bokeh.models import HoverTool
from bokeh.io import output_notebook
output_notebook()

%matplotlib inline

plt.rcParams["figure.figsize"] = (8,6)
# [___CELL_SEPARATOR___]
import warnings
warnings.filterwarnings('ignore')
# [___CELL_SEPARATOR___]
PATH = './img_align_celeba'
# [___CELL_SEPARATOR___]
def load_image(filepath):
    ''' Loads an image at the path specified by the parameter filepath '''
    im = Image.open(filepath)
    return im
# [___CELL_SEPARATOR___]
def show_image(im):
    ''' Displays an image'''
    fig1, ax1 = plt.subplots(1, 1)
    ax1.imshow(im, cmap='gray');
    return
# [___CELL_SEPARATOR___]
#Loads image files from all sub-directories

imgfiles = [os.path.join(root, name)
             for root, dirs, files in os.walk(PATH)
             for name in files
             if name.endswith((".jpg"))]
# [___CELL_SEPARATOR___]
#N=int(len(imgfiles)/30)
N=len(imgfiles)
print("Number of images = {}".format(N))
test = imgfiles[0:N]
# [___CELL_SEPARATOR___]
test[1]
# [___CELL_SEPARATOR___]
sample_path = imgfiles[0]
sample_im = load_image(sample_path)
sample_im = np.array(sample_im)
img_shape = (sample_im.shape[0],sample_im.shape[1])
# [___CELL_SEPARATOR___]
ims = np.zeros((N, sample_im.shape[1]*sample_im.shape[0]))
for i, filepath in enumerate(test):
    im = load_image(filepath)
    im = np.array(im)
    im = im.mean(axis=2)
    im = np.asarray(im).ravel().astype(float)
    ims[i] = im
# [___CELL_SEPARATOR___]
#iso = manifold.Isomap(n_neighbors=2, n_components=3, max_iter=500, n_jobs=-1)
# [___CELL_SEPARATOR___]
#Z = iso.fit_transform(ims)    #don't run, can load from pickle as in below cells
# [___CELL_SEPARATOR___]
#saving the learnt embedding

#with open('var6753_n2_d3.pkl', 'wb') as f: #model learnt with n_neighbors=2 and n_components=3
#    pickle.dump(Z,f)

#with open('var6753_n2_d2.pkl', 'wb') as f: #model learnt with n_neighbors=2 and n_components=2
#    pickle.dump(Z,f)

#with open('var6753_n4_d3.pkl', 'wb') as f: #model learnt with n_neighbors=4 and n_components=3
#    pickle.dump(Z,f)
# [___CELL_SEPARATOR___]
with open('var6753_n2_d2.pkl', 'rb') as f:
    Z = pickle.load(f)
# [___CELL_SEPARATOR___]
#Visualizing the learnt 3D-manifold in two dimensions

source = ColumnDataSource(
        data=dict(
            x=Z[:, 0],
            y=Z[:, 1],
            desc=list(range(Z.shape[0])),
        )
    )

hover = HoverTool(
        tooltips=[
            ("index", "$index"),
            ("(x,y)", "($x, $y)"),
            ("desc", "@desc"),
        ]
    )

p = figure(plot_width=700, plot_height=700, tools=[hover],title="Mouse over the dots")

p.circle('x', 'y', size=10, source=source)
show(p)
# [___CELL_SEPARATOR___]
#Mapping the regressor from low dimension space to high dimension space

lin = ExtraTreeRegressor(max_depth=19)
lin.fit(Z, ims)
# [___CELL_SEPARATOR___]
lin.score(Z, ims)
# [___CELL_SEPARATOR___]
pred = lin.predict(Z[502].reshape(1, -1));
fig_new, [ax1,ax2] = plt.subplots(1,2)
ax1.imshow(ims[502].reshape(*img_shape), cmap = 'gray')
ax1.set_title('Original')
ax2.imshow(pred.reshape(*img_shape), cmap = 'gray')
ax2.set_title('Reconstructed')
# [___CELL_SEPARATOR___]
person1 = 34
person2 = 35
test = ((Z[person1] + Z[person2]) / 2) #+ 0.5*np.random.randn(*Z[person1].shape)
pred = lin.predict(test.reshape(1, -1))
fig_newer, [ax1, ax2, ax3] = plt.subplots(1, 3)
ax1.imshow(ims[person1].reshape(*img_shape), cmap = 'gray')
ax1.set_title('Face 1')
ax2.imshow(ims[person2].reshape(*img_shape), cmap = 'gray')
ax2.set_title('Face 2')
ax3.imshow(pred.reshape(*img_shape), cmap = 'gray')
ax3.set_title('Face between lying on manifold');
# [___CELL_SEPARATOR___]
distances = spatial.distance.squareform(spatial.distance.pdist(Z, 'braycurtis'))
# [___CELL_SEPARATOR___]
kernel_width = distances.mean()
weights = np.exp(-np.square(distances) / (kernel_width ** 0.1))
for i in range(weights.shape[0]):
    weights[i][i] = 0
# [___CELL_SEPARATOR___]
NEIGHBORS = 2
#NEIGHBORS = 100
# Your code here.

#Find sorted indices of weights for each row
indices = np.argsort(weights, axis = 1)

#Create a zero matrix which would later be filled with sparse weights
n_weights = np.zeros((weights.shape[0], weights.shape[1]))

#Loop that iterates over the 'K' strongest weights in each row, and assigns them to sparse matrix, leaving others zero
for i in range(indices.shape[0]):
    for j in range(indices.shape[1] - NEIGHBORS, indices.shape[1]):
        col = indices[i][j]
        n_weights[i][col] = weights[i][col]  

#Imposing symmetricity
big = n_weights.T > n_weights
n_weights_s = n_weights - n_weights * big + n_weights.T * big
# [___CELL_SEPARATOR___]
G = nx.from_numpy_matrix(n_weights_s)
# [___CELL_SEPARATOR___]
pos = {}
for i in range(Z.shape[0]):
    pos[i] = Z[i,0:2]

fig2,ax2 = plt.subplots()
nx.draw(G, pos, ax=ax2, node_size=10)
# [___CELL_SEPARATOR___]
imlist=nx.all_pairs_dijkstra_path(G)[0][102]   #choosing the path starting at node 0 and ending at node 102
imlist
# [___CELL_SEPARATOR___]
N=25                             #number of sub-samples between each consecutive pair in the path
lbd = np.linspace(0, 1, N)
counter = 0
for count, i in enumerate(imlist):
    if count != len(imlist) - 1:
        person1 = i
        person2 = imlist[count + 1]
        for j in range(N):
            test = (lbd[j] * Z[person2]) + ((1 - lbd[j]) * Z[person1])
            pred = lin.predict(test.reshape(1, -1))
            im = Image.fromarray(pred.reshape(*img_shape))
            im = im.convert('RGB')
            im.save('{}.png'.format(counter))
            counter += 1
# [___CELL_SEPARATOR___]
os.system("ffmpeg -f image2 -r 10 -i ./%d.png -vcodec mpeg4 -y ./method1.mp4")
# [___CELL_SEPARATOR___]
norm_vary = list()
norm_im = list()
lbd = np.linspace(0, 1, 101)
person1=12
person2=14
for i in range(101):
    test = (lbd[i] * Z[person2]) + ((1-lbd[i]) * Z[person1])
    norm_vary.append(norm(test))
    pred = lin.predict(test.reshape(1, -1))
    im = Image.fromarray(pred.reshape(*img_shape))
    norm_im.append(norm(im))
# [___CELL_SEPARATOR___]
f, ax = plt.subplots(1,1)
ax.plot(norm_vary)
ax.set_title('Norm for the mean image in projected space')
# [___CELL_SEPARATOR___]
norm_vary = list()
norm_im = list()
lbd = np.linspace(0, 1, 101)
for i in range(101):
    test = (lbd[i] * Z[person1]) + ((1-lbd[i]) * Z[person2])
    norm_vary.append(norm(test))
    pred = lin.predict(test.reshape(1, -1))
    im = Image.fromarray(pred.reshape(*img_shape))
    norm_im.append(norm(im))
f, ax = plt.subplots(1,1)
ax.plot(norm_im)
ax.set_title('Norm for mean image in original space')
# [___CELL_SEPARATOR___]

#Interesting paths with N4D3 model
#imlist = [1912,3961,2861,4870,146,6648]
#imlist = [3182,5012,5084,1113,2333,1375]
#imlist = [5105,5874,4255,2069,1178]
#imlist = [3583,2134,1034, 3917,3704, 5920,6493]
#imlist = [1678,6535,6699,344,6677,5115,6433]

#Interesting paths with N2D3 model
imlist = [1959,3432,6709,4103, 4850,6231,4418,4324]
#imlist = [369,2749,1542,366,1436,2836]

#Interesting paths with N2D2 model
#imlist = [2617,4574,4939,5682,1917,3599,6324,1927]
# [___CELL_SEPARATOR___]
N=25
lbd = np.linspace(0, 1, N)
counter = 0
for count, i in enumerate(imlist):
    if count != len(imlist) - 1:
        person1 = i
        person2 = imlist[count + 1]
        for j in range(N):
            im = (lbd[j] * ims[person2]) + ((1 - lbd[j]) * ims[person1])
            im = Image.fromarray(im.reshape((218, 178)))
            im = im.convert('RGB')
            im.save('{}.png'.format(counter))
            counter += 1
# [___CELL_SEPARATOR___]
os.system("ffmpeg -f image2 -r 10 -i ./%d.png -vcodec mpeg4 -y ./method2.mp4")