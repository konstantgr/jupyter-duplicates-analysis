%%cython --compile-args=-fopenmp --link-args=-fopenmp --force
# [___CELL_SEPARATOR___]
from cython.parallel import prange