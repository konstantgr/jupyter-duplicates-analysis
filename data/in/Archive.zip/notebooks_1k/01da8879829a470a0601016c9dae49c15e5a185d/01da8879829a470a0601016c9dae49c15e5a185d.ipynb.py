import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as feature
import pandas as pd
from datetime import datetime
import sys

# Need to tell Python where to find `get_Synoptic.py`. 
# This says to look back one directory (relative to this notebook).
sys.path.append('../')

from get_Synoptic import stations_metadata
# [___CELL_SEPARATOR___]
# Basic example
stations_metadata(stid='KSLC', verbose='HIDE')
# [___CELL_SEPARATOR___]
a = stations_metadata(network=229, verbose='HIDE')
a
# [___CELL_SEPARATOR___]
plt.figure(figsize=[10,8])
ax = plt.subplot(projection=ccrs.PlateCarree())

ax.scatter(a.loc['longitude'], a.loc['latitude'], marker='.')


ax.set_title('PG&E Station Locations', loc='left', fontweight='bold')
ax.set_title(f'Total: {len(a.columns)}', loc='right')
ax.add_feature(feature.STATES.with_scale('10m'))
# [___CELL_SEPARATOR___]
plt.figure(figsize=[10,8])
ax = plt.subplot(projection=ccrs.PlateCarree())

# Plot each station artistically, to illustrate station density
ax.scatter(a.loc['longitude'], a.loc['latitude'], s=200, color='0.1', lw=2)
ax.scatter(a.loc['longitude'], a.loc['latitude'], s=200, color='1.0', lw=0)
ax.scatter(a.loc['longitude'], a.loc['latitude'], s=180, color='C1', lw=0, alpha=.1)


ax.set_title('PG&E Station Locations', loc='left', fontweight='bold')
ax.set_title(f'Total: {len(a.columns)}', loc='right')
ax.add_feature(feature.STATES.with_scale('10m'))
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
