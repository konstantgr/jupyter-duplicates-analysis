%load_ext autoreload
%autoreload 2
# [___CELL_SEPARATOR___]
import sys 
import os
sys.path.insert(0, os.getcwd())
# [___CELL_SEPARATOR___]
import torch 
import pickle
import nibabel

from jrieke.utils import load_nifti, save_nifti
from innvestigator import InnvestigateModel
from settings import settings
from utils import load_data, scale_mask
from jrieke import interpretation
from nmm_mask_areas import all_areas

import numpy as np
import pickle
import jrieke.models as models


for k in settings.keys():
    print("Adding " + k + " to namespace")
    globals()[k] = settings[k]
# [___CELL_SEPARATOR___]
device = 6
net = models.ClassificationModel3D_2Node()
net.cuda(device)
net.load_state_dict(torch.load(model_path,
                              map_location='cpu'))
net.eval()
net = torch.nn.Sequential(net, torch.nn.Softmax(dim=1))
inn_model = InnvestigateModel(net, lrp_exponent=1,
                                  method="b-rule",
                                  beta=0, epsilon=1e-6).cuda(device)
inn_model.eval();

# [___CELL_SEPARATOR___]
import h5py
# [___CELL_SEPARATOR___]
def min_max_normalization(subset):
    for i in range(len(subset)):
        subset[i] -= np.min(subset[i])
        subset[i] /= np.max(subset[i])
    return subset
    
def load_data(skip_train=True, skip_val=True, skip_test=False, dtype=np.float32):
    """ Load hdf5 files and extract columns. """
    X_train, y_train, X_val, y_val, X_holdout, y_holdout = np.nan, np.nan, np.nan, np.nan, np.nan, np.nan
    # train
    if not skip_train:
        train_h5_ = h5py.File(train_h5, 'r')
        X_train, y_train = train_h5_['X'], train_h5_['y']
        X_train = np.expand_dims(np.array(X_train, dtype=dtype), 1)
        X_train = min_max_normalization(X_train)
        y_train = np.array(y_train)
        print("Total training set length: {}".format(len(y_train)))
        print("Number of healthy controls: {}".format(len(np.array(y_train)[np.array(y_train)==0.])))
        print("Number of AD patients: {}".format(len(np.array(y_train)[np.array(y_train)==1.])))
    if not skip_val:
        # val
        val_h5_ = h5py.File(val_h5, 'r')
        X_val, y_val = val_h5_['X'], val_h5_['y']
        X_val = np.expand_dims(np.array(X_val, dtype=dtype), 1)
        X_val = min_max_normalization(X_val)
        y_val = np.array(y_val)
        print("Total validation set length: {}".format(len(y_val)))
    if not skip_test:
        # test
        holdout_h5_ = h5py.File(holdout_h5, 'r')
        X_holdout, y_holdout = holdout_h5_['X'], holdout_h5_['y']
        X_holdout = np.expand_dims(np.array(X_holdout, dtype=dtype), 1)
        X_holdout = min_max_normalization(X_holdout)
        y_holdout = np.array(y_holdout)
        print("Total test set length: {}".format(len(y_holdout)))
   
    return X_train, y_train, X_val, y_val, X_holdout, y_holdout

# [___CELL_SEPARATOR___]
X_train, y_train, X_val, y_val, X_holdout, y_holdout = load_data()

image_shape = X_holdout.shape[1:-1]
# [___CELL_SEPARATOR___]
mri_shape = X_holdout.shape[2:]

if False:
    neuromorph_map = nibabel.load(nmm_mask_path).get_data()
    nmm_mask = scale_mask(neuromorph_map, mri_shape)
    save_nifti(nmm_mask_path_scaled, nmm_mask)
else:
    nmm_mask = load_nifti(nmm_mask_path_scaled)

# all_areas holds the area name and a tuple with the minimum 
# idx in the NMM mask and the maximum idx in the NMM mask belonging to that area
area_masks = {k: None for k in all_areas.keys()}
for name, (min_idx, max_idx) in all_areas.items():
    area_mask = np.zeros(mri_shape)
    area_mask[np.logical_and(nmm_mask>=min_idx, nmm_mask<=max_idx)] = 1
    area_masks[name] = area_mask
# [___CELL_SEPARATOR___]
def run_guided_backprop(net, image_tensor):
    return interpretation.guided_backprop(net, image_tensor, cuda=True, verbose=False, apply_softmax=False)

def run_LRP(net, image_tensor):
    return inn_model.innvestigate(in_tensor=image_tensor, rel_for_class=1)
# [___CELL_SEPARATOR___]
cases = ["AD", "HC", "TP", "TN", "FP", "FN"]
mean_maps_GB = {case: np.zeros(mri_shape) for case in cases}
mean_maps_LRP = {case: np.zeros(mri_shape) for case in cases}
rs_per_area_LRP = {case: {k: [] for k in all_areas.keys()} for case in cases}
rs_per_area_GB = {case: {k: [] for k in all_areas.keys()} for case in cases}
counts = {case: 0 for case in cases}
area_sizes = {k: 0 for k in all_areas.keys()}
# [___CELL_SEPARATOR___]
num_samples = len(X_holdout)

ad_score_list = []


for i, (image, label) in enumerate(zip(X_holdout, y_holdout)):
    image_tensor = torch.Tensor(image[None]).cuda(device)   
    GB_map = run_guided_backprop(inn_model, image_tensor).squeeze()
    AD_score, LRP_map = run_LRP(inn_model, image_tensor)
    AD_score = AD_score[0][1].detach().cpu().numpy()
    LRP_map = LRP_map.detach().numpy().squeeze()
    ad_score_list.append(AD_score)
    
    true_case = "AD" if label else "HC"
    if AD_score.round() and label:
        case = "TP"
    elif AD_score.round() and not label:
        case = "FP"
    elif not AD_score.round() and label:
        case = "FN"
    elif not AD_score.round() and not label:
        case = "TN"
    
    mean_maps_GB[case] += GB_map
    mean_maps_LRP[case] += LRP_map
    counts[case] += 1
    mean_maps_GB[true_case] += GB_map
    mean_maps_LRP[true_case] += LRP_map
    counts[true_case] += 1
    
    for name, (min_idx, max_idx) in all_areas.items():
        area_mask = area_masks[name]
        summed_LRP = (LRP_map * area_mask).sum()
        summed_GB = (GB_map * area_mask).sum()
        
        # Keep index in test set for identification
        rs_per_area_LRP[case][name].append((i, summed_LRP))
        rs_per_area_LRP[true_case][name].append((i, summed_LRP))
        rs_per_area_GB[case][name].append((i, summed_GB))
        rs_per_area_GB[true_case][name].append((i, summed_GB))
        
        if i < 1:
            area_size = area_mask.sum()
            area_sizes.update({name:area_size})
    
    print("Completed {0:3.2f}%  \r".format(100*(i+1)/num_samples), end="")
        
# [___CELL_SEPARATOR___]
counts
# [___CELL_SEPARATOR___]
for case in cases:
    mean_maps_LRP[case] /= counts[case]
    mean_maps_GB[case] /= counts[case]
    save_nifti(os.path.join(data_path, "LRP_{case}.nii".format(case=case)),
               mean_maps_LRP[case])
    save_nifti(os.path.join(data_path, "GB_{case}.nii".format(case=case)),
               mean_maps_GB[case])
    with open(os.path.join(data_path, "LRP_area_evdcs_{case}.pkl".format(case=case)), 'wb') as file:
        pickle.dump(rs_per_area_LRP[case], file)
    with open(os.path.join(data_path, "GB_area_evdcs_{case}.pkl".format(case=case)), 'wb') as file:
        pickle.dump(rs_per_area_GB[case], file)

with open(os.path.join(data_path, "area_sizes.pkl"), 'wb') as file:
    pickle.dump(area_sizes, file)

np.savetxt(os.path.join(data_path, "ad_scores.txt"), ad_score_list)
# [___CELL_SEPARATOR___]
import matplotlib as mpl
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
from mpl_toolkits.axes_grid1 import make_axes_locatable
from copy import deepcopy
%matplotlib inline
# [___CELL_SEPARATOR___]
def get_heatmaps(idx):
    image_tensor, label = X_holdout[idx], y_holdout[idx]
    image_tensor_LRP = torch.Tensor(image_tensor[None]).cuda(device)
    print("Running GB")
    rel_GB = run_guided_backprop(inn_model, image_tensor_LRP)
    print("Running LRP")
    AD_score, rel_LRP = run_LRP(inn_model, image_tensor_LRP)
    return rel_LRP.detach().numpy().squeeze(), rel_GB.squeeze()
# [___CELL_SEPARATOR___]
patient_idx = np.random.randint(0, len(X_holdout)-1)
LRP_map, GB_map = get_heatmaps(patient_idx)
# [___CELL_SEPARATOR___]

def plot_idv_brain(heat_map, brain_img, ref_scale, fig=None, ax=None, 
                  x_idx=slice(0, mri_shape[0]), y_idx=slice(0, mri_shape[1]), z_idx=slice(0, mri_shape[2]),
                  vmin=90, vmax=99.9, set_nan=True, cmap=None):

    if fig is None or ax is None:
        fig, ax = plt.subplots(1, figsize=(12, 12))
    
    img = deepcopy(heat_map)
    if set_nan:
        img[nmm_mask==0]=np.nan
    if cmap is None:
        cmap = mcolors.LinearSegmentedColormap.from_list(name='alphared',
                                                  colors=[(1, 0, 0, 0),
                                                         "darkred", "red", "darkorange", "orange", "yellow"],
                                                  N=5000)
        
    if brain_img is not None:
        ax.imshow(brain_img[x_idx, y_idx, z_idx].T, cmap="Greys")

    vmin_val, vmax_val = np.percentile(ref_scale, vmin), np.percentile(ref_scale, vmax)
    im = ax.imshow(img[x_idx, y_idx, z_idx].T, cmap=cmap, 
               vmin=vmin_val, vmax=vmax_val, interpolation="gaussian")
       
    ax.axis('off')
    plt.gca().invert_yaxis()
    
    fig.tight_layout()
    fig.subplots_adjust(right=0.8)

    cbar_ax = fig.add_axes([0.8, 0.15, 0.025, 0.7])
    cbar = fig.colorbar(im, shrink=0.5, ticks=[vmin, vmax], cax=cbar_ax)
    cbar.set_ticks([vmin_val, vmax_val])
    cbar.ax.set_yticklabels(['{0:.1f}%'.format(vmin), '{0:.1f}%'.format(vmax)], fontsize=14)
    cbar.set_label('Percentile of  average AD patient values\n', rotation=270, fontsize=14)
    return fig, ax

# [___CELL_SEPARATOR___]
fig, ax = plot_idv_brain(LRP_map, X_holdout[patient_idx].squeeze(),
                            ref_scale=mean_maps_LRP["AD"],
                            z_idx=90)
# [___CELL_SEPARATOR___]
fig, ax = plot_idv_brain(GB_map, X_holdout[patient_idx].squeeze(),
                            ref_scale=mean_maps_GB["AD"],
                            z_idx=90)
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
