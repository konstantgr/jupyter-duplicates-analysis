%matplotlib inline
from pyqubo import Array, Placeholder, solve_qubo, Constraint, Sum
import matplotlib.pyplot as plt
import networkx as nx
# [___CELL_SEPARATOR___]
def plot_graph(N, E, colors=None):
    G = nx.Graph()
    G.add_nodes_from([n for n in range(N)])
    for (i, j) in E:
        G.add_edge(i, j)
    plt.figure(figsize=(4,4))
    pos = nx.circular_layout(G)
    colorlist = ['#e41a1c', '#377eb8', '#4daf4a', '#984ea3', '#ff7f00', '#ffff33', '#a65628', '#f781bf']
    if colors:
        nx.draw_networkx(G, pos, node_color=[colorlist[colors[node]] for node in G.nodes], node_size=400, font_weight='bold', font_color='w')
    else:
        nx.draw_networkx(G, pos, node_color=[colorlist[0] for _ in G.nodes], node_size=400, font_weight='bold', font_color='w')
    plt.axis("off")
    plt.show()
# [___CELL_SEPARATOR___]
# Given number of vertices (N) and number of colors (K)
N = 6
K = 3

# Given edges
E = {(0, 1), (0, 2), (0, 3), (1, 2), (2, 3), (3, 4)}
plot_graph(N, E)
# [___CELL_SEPARATOR___]
x = Array.create('x', (N, K), 'BINARY')
# [___CELL_SEPARATOR___]
# Define hamiltonian H_{A}: Constraint that every vertex is colored with just one color
onecolor_const = 0.0
for i in range(N):
    onecolor_const += Constraint((Sum(0, K, lambda j: x[i, j]) - 1)**2, label="onecolor{}".format(i))
# [___CELL_SEPARATOR___]
# Define hamiltonian H_{A}: Constraint that no adjacent nodes are colored with the same color
adjacent_const = 0.0
for (i, j) in E:
    for k in range(K):
        adjacent_const += Constraint(x[i, k] * x[j, k], label="adjacent({},{})".format(i, j))
# [___CELL_SEPARATOR___]
# Define hamiltonian H
alpha = Placeholder("alpha")
H = alpha * onecolor_const + adjacent_const
# [___CELL_SEPARATOR___]
# Compile model
model = H.compile()

# Create QUBO with alpha = 1.0
feed_dict = {'alpha': 1.0}
qubo, offset = model.to_qubo(feed_dict=feed_dict)
# [___CELL_SEPARATOR___]
# Solve the QUBO and obtain the optimal solution
solution = solve_qubo(qubo)

# Decode solution
decoded_solution, broken, energy = model.decode_solution(solution, vartype="BINARY", feed_dict=feed_dict)
print("number of broken constarint = {}".format(len(broken)))

# Obtain colors of each vertex
colors = [0 for i in range(N)]
for i in range(N):
    for k in range(K):
        if decoded_solution['x'][i][k] == 1:
            colors[i] = k
            break
# [___CELL_SEPARATOR___]
# Plot graph after coloring
plot_graph(N, E, colors)