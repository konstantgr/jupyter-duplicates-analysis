from matplotlib import pyplot as plt
%matplotlib inline

t = [0,1,2,3,4]
x = [0,2,4,6,8]

plt.scatter(t,x)
plt.show()
# [___CELL_SEPARATOR___]
def position(time):
    return 2*time

print("at t =", 0, "position is", position(0))
print("at t =", 1, "position is", position(1))
print("at t =", 2, "position is", position(2))
print("at t =", 3, "position is", position(3))
print("at t =", 4, "position is", position(4))
# [___CELL_SEPARATOR___]
print("at t =", 2.2351, "position is", position(2.2351))
# [___CELL_SEPARATOR___]
# Demonstration of continuous plotting

import numpy as np

t = np.linspace(0, 4)
x = position(t)

plt.plot(t, x)
plt.show()
# [___CELL_SEPARATOR___]
# EXERCISE
def position_b(time):
    # todo
    pass

# don't forget to plot this function from t=0 to t=6.12  
# Solution is below.
# [___CELL_SEPARATOR___]
#

#

#

# Spoiler alert! Solution below!

#

#

#
# [___CELL_SEPARATOR___]
def position_b(time):
    return -4.9 * time ** 2 + 30 * time

t = np.linspace(0, 6.12)
z = position_b(t)

plt.plot(t, z)
plt.show()
# [___CELL_SEPARATOR___]
def plot_continuous_function(function, t_min, t_max):
    t = np.linspace(t_min, t_max)
    x = function(t)
    plt.plot(t,x)
# [___CELL_SEPARATOR___]
plot_continuous_function(position_b, 0, 6.12)
plt.show()
# [___CELL_SEPARATOR___]
def constant_position_motion(time):
    position = 20
    return position + 0*time

def constant_velocity_motion(time):
    velocity = 10
    return velocity * time

def constant_acceleration_motion(time):
    acceleration = 9.8
    return acceleration / 2 * time ** 2
    
plot_continuous_function(constant_position_motion, 0, 20)
plt.show()
# [___CELL_SEPARATOR___]
# position vs time 
# with constant VELOCITY motion

plot_continuous_function(constant_velocity_motion, 0, 20)
plt.show()
# [___CELL_SEPARATOR___]
# position vs time
# with constant ACCELERATION motion

plot_continuous_function(constant_acceleration_motion, 0, 20)
plt.show()
# [___CELL_SEPARATOR___]
plt.title("Position vs Time for ball thrown upwards")
plt.ylabel("Position above ground (meters)")
plt.xlabel("Time (seconds)")
plot_continuous_function(position_b,0,6.12)
plt.show()
# [___CELL_SEPARATOR___]
DELTA_T = 3.0

# you don't need to touch the code below

t_min = 2 - (DELTA_T / 2)
t_max = 2 + (DELTA_T / 2)

plt.title("Position vs Time for ball thrown upwards")
plt.ylabel("Position above ground (meters)")
plt.xlabel("Time (seconds)")
plot_continuous_function(position_b, t_min, t_max)
plt.show()
# [___CELL_SEPARATOR___]
DELTA_Z = position_b(2.03) - position_b(1.97)
DELTA_T = 0.06
SLOPE = DELTA_Z / DELTA_T

print("the graph goes from", position_b(1.97), "at t=1.97")
print("to", position_b(2.03), "at t=2.03")
print("which is a delta z of", DELTA_Z)
print()
print("This gives a slope of", SLOPE)
# [___CELL_SEPARATOR___]
# Your code here!



# [___CELL_SEPARATOR___]
#

#

#

# Spoiler alert! Solution below!

#

#

#

#
# [___CELL_SEPARATOR___]
# SOLUTION - FIRST ATTEMPT

# 1. set some relevant parameters
TIME    = 3.45
DELTA_T = 0.02

# 2. The "window" should extend 0.01 to the left and 
#    0.01 to the right of the target TIME
t_min = TIME - (DELTA_T / 2)
t_max = TIME + (DELTA_T / 2)

# 3. calculate the value of the function at the left and
#    right edges of our "window"
z_at_t_min = position_b(t_min)
z_at_t_max = position_b(t_max)

# 4. calculate vertical change
delta_z = z_at_t_max - z_at_t_min

# 5. calculate slope
slope = delta_z / DELTA_T

print("speed is",slope, "m/s at t =", TIME)
# [___CELL_SEPARATOR___]
# SOLUTION - second (better) version
def approximate_derivative(f, t):
    # 1. Set delta_t. Note that I've made it REALLY small.
    delta_t = 0.00001
    
    # 2. calculate the vertical change of the function
    #    NOTE that the "window" is not centered on our 
    #    target time anymore. This shouldn't be a problem
    #    if delta_t is small enough.
    vertical_change = f(t + delta_t) - f(t)
    
    # 3. return the slope
    return vertical_change / delta_t

deriv_at_3_point_45 = approximate_derivative(position_b, 3.45)
print("The derivative at t = 3.45 is", deriv_at_3_point_45)
# [___CELL_SEPARATOR___]
# These four lines of code do exactly what we wanted!
# There is a good chance that this will be the 
# hardest-to-understand code you see in this whole 
# Nanodegree, so don't worry if you're confused. 

def get_derivative(f):
    def f_dot(t):
        return approximate_derivative(f,t)
    return f_dot
# [___CELL_SEPARATOR___]
# plot 1 - a reminder of what our position function looks like.
#         Remember, this is a plot of vertical POSITION vs TIME
#         for a ball that was thrown upwards.

plt.title("Position vs Time for ball thrown upwards")
plt.ylabel("Position above ground (meters)")
plt.xlabel("Time (seconds)")
plot_continuous_function(position_b, 0, 6.12)
plt.show()
# [___CELL_SEPARATOR___]
# plot 2 - a plot of VELOCITY vs TIME for the same ball! Note 
#    how the ball begins with a large positive velocity (since
#    it's moving upwards) and ends with a large negative 
#    velocity (downwards motion right before it hits the ground)

velocity_b = get_derivative(position_b)
plot_continuous_function(velocity_b, 0, 6.12)
plt.show()
# [___CELL_SEPARATOR___]
# plot 3 - a plot of ACCELERATION vs TIME for the same ball.
#    Note that the acceleration is a constant value 
#    of -9.8 m/s/s. That's because gravity always causes 
#    objects to accelerate DOWNWARDS at that rate.

acceleration_b = get_derivative(velocity_b)
plt.ylim([-11, -9])
plot_continuous_function(acceleration_b, 0, 6.12)
plt.show()
# [___CELL_SEPARATOR___]
# plot 4 - All 3 plots at once!
plot_continuous_function(position_b, 0, 6.12)
plot_continuous_function(velocity_b, 0, 6.12)
plot_continuous_function(acceleration_b, 0, 6.12)
plt.show()