import numpy as np

%matplotlib inline
import matplotlib.pyplot as plt
plt.style.use('ggplot')
# [___CELL_SEPARATOR___]
faces = np.arange(1,5)
faces
# [___CELL_SEPARATOR___]
p_A = lambda x: 1/4
p_B = lambda x: x/10
p_C = lambda x: 12/(25*x)
# [___CELL_SEPARATOR___]
f, axs = plt.subplots(1,3,figsize=(12,4), sharey=True)

models = (p_A, p_B, p_C)
for i, m in enumerate(models):
    probs = list(map(m, faces))
    axs[i].bar(faces, probs, align='center')
    axs[i].set_xticks(faces)

axs[0].set_title('model A')
axs[1].set_title('model B')
axs[2].set_title('model C')
axs[0].set_ylabel('p(x)')

plt.show()
# [___CELL_SEPARATOR___]
die1 = [25, 25, 25, 25]
die2 = [48, 24, 16, 12]
# [___CELL_SEPARATOR___]
f, axs = plt.subplots(1,2,figsize=(8,4), sharey=True)

axs[0].bar(faces, die1, align='center', color='tomato')
axs[0].set_xticks(faces)
axs[0].set_title('die 1')

axs[1].bar(faces, die2, align='center', color='tomato')
axs[1].set_xticks(faces)
axs[1].set_title('die 2')

axs[0].set_ylabel('# of rolls')

plt.show()
# [___CELL_SEPARATOR___]
p_healthy_coin = lambda side: .95 if side == 'neg' else .05
p_disease_coin = lambda side: .95 if side == 'pos' else .05
# [___CELL_SEPARATOR___]
n_coins = 10000
healthy_factory_prior = .99

n_healthy = n_coins * healthy_factory_prior
n_disease = n_coins * (1 - healthy_factory_prior)
n_healthy, n_disease
# [___CELL_SEPARATOR___]
n_pos_healthy = n_healthy * p_healthy_coin('pos')
n_pos_healthy
# [___CELL_SEPARATOR___]
n_pos_disease = n_disease * p_disease_coin('pos')
n_pos_disease
# [___CELL_SEPARATOR___]
disease_factory_posterior = n_pos_disease / (n_pos_healthy + n_pos_disease)
disease_factory_posterior