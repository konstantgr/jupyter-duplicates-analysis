using LatPhysBase
using LatPhysUnitcellLibrary
using LatPhysLatticeConstruction
# [___CELL_SEPARATOR___]
# 2D unitcell is honeycomb
unitcell_2d = getUnitcellHoneycomb(4);

# 3D unitcell is pyrochlore
unitcell_3d = getUnitcellPyrochlore(1);
# [___CELL_SEPARATOR___]
# construct a 2D lattice which is 5x10 unitcells in size
getLatticePeriodic(unitcell_2d, (5,10))
# [___CELL_SEPARATOR___]
# construct a 3D lattice which is 5x2x3 unitcells in size
getLatticePeriodic(unitcell_3d, (5,2,3))
# [___CELL_SEPARATOR___]
# construct a 2D lattice which is 7x7 unitcells in size
getLatticePeriodic(unitcell_2d, 7)
# [___CELL_SEPARATOR___]
# construct a 3D lattice which is 4x4x4 unitcells in size
getLatticePeriodic(unitcell_3d, 4)
# [___CELL_SEPARATOR___]
# construct a 10x5 periodic 2d lattice with explicit type
lt = getLatticePeriodic(
    Lattice{Site{Int64,2}, Bond{Int64,2}, Unitcell{Site{Int64,2},Bond{Int64,2}}},
    unitcell_2d,
    (10,5)
)
# [___CELL_SEPARATOR___]
# construct a lattice up to bond distance 15 in 2D
lt = getLatticeByBondDistance(unitcell_2d, 15)
# [___CELL_SEPARATOR___]
# construct a lattice up to bond distance 15 in 2D originating from site 2 of the unitcell
lt = getLatticeByBondDistance(unitcell_2d, 15, 2)
# [___CELL_SEPARATOR___]
# construct a lattice up to bond distance 10 in 3D
lt = getLatticeByBondDistance(unitcell_3d, 10)
# [___CELL_SEPARATOR___]
# construct a lattice up to bond distance 8 in 2D with explicit lattice type
lt = getLatticeByBondDistance(
    Lattice{Site{Int64,2}, Bond{Int64,0}, Unitcell{Site{Int64,2},Bond{Int64,2}}},
    unitcell_2d,
    8
)
# [___CELL_SEPARATOR___]
# shape function of the sphere in 2D: is the point inside the circle with radius 3.0 or not
shape(position :: Vector{Float64}) = sum(position.*position) < 3.0*3.0

# build the lattice inside this shape
lt = getLatticeInShape(unitcell_2d, shape)
# [___CELL_SEPARATOR___]
# build a 2d lattice inside a circle of radius 3 around [0,0]
lt = getLatticeInSphere(unitcell_2d, 3, [0,0])
# [___CELL_SEPARATOR___]
# build a 3d lattice inside a sphere of radius 3 around [0,0,0]
lt = getLatticeInSphere(unitcell_3d, 3, [0,0,0])
# [___CELL_SEPARATOR___]
# build a 2d lattice in a box of dimension 10x7 around [0,0]
lt = getLatticeInBox(unitcell_2d, [10,7], [0,0])
# [___CELL_SEPARATOR___]
# build a 3d lattice in a box of dimension 5x3x7 around [0,0,0]
lt = getLatticeInBox(unitcell_2d, [5,3,7], [0,0,0])