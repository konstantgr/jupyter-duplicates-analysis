# This is a 'code' cell
print("Hello, world")
# [___CELL_SEPARATOR___]
for i in range(10):
    print(i, end='')
    if i % 2==0:
        print(' Even')
    else:
        print(' Odd')

a = [ '{} Odd'.format(i) if i % 2 else '{} Even'.format(i) for i in range(10)]
print(a)
# [___CELL_SEPARATOR___]
!ls -l
# [___CELL_SEPARATOR___]
# Receive command rsult with a Python variable
res=!ls -l
for a in res:
    print(a)

# Pass information to linux command (via environment variable)
import os
os.environ['TEST']='hello'
!echo "\$TEST=${TEST}"