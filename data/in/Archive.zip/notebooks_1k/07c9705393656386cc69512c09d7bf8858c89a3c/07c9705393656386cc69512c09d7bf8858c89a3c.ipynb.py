#! setup
import numpy as np
import moldesign as mdt
from moldesign import units as u
from IPython.display import display

acetylene=mdt.read("""4
acetylene
C           0.86130672439060          -0.03429540246582           0.03562730537765
C          -0.33899621346835          -0.03429540246582           0.03562730537765
H           1.92711178889567          -0.03429540246582           0.03562730537765
H          -1.40480127797341          -0.03429540246582           0.03562730537765
""", format='xyz')

cyclohexane = mdt.read("""18
cyclohexane
C           0.72459854477848           1.26176676081555          -0.22980933268480
C          -0.72964565907845           1.25689879707042           0.23587232712339
C          -1.45125684865964           0.00009541534346          -0.24385400156897
C          -0.73068866953508          -1.25710673148803           0.23642625773656
C           0.72374705626021          -1.26341586400266          -0.22869629348233
C           1.45630892735770          -0.00086822863166           0.22169529310120
H           1.23716125524085           2.14821232571702           0.16060338826431
H           0.75536279079703           1.32903994493943          -1.32391383723302
H          -0.76379438095384           1.30322937926981           1.33108876057444
H          -1.24423546187030           2.14833854254201          -0.13985790455878
H          -1.49420132202878          -0.00011275714537          -1.33977123513977
H          -2.48504606386685           0.00060204516646           0.11887614360894
H          -1.24587149468131          -2.14825488162298          -0.13919214010059
H          -0.76524095448971          -1.30307294199167           1.33164097377765
H           0.75488632679830          -1.33189942689561          -1.32271228302583
H           1.23552562648700          -2.14981918748604           0.16285578233159
H           2.47619380227094          -0.00139028106171          -0.17945839471814
H           1.54143894897504          -0.00041355646012           1.31490392873224""",
                      format='xyz')

ethylene = mdt.read(""" 6
C=C
C          -0.66789360886407          -0.00000000000000           0.00000000000000
C           0.66789360886407           0.00000000000000          -0.00000000000000
H          -1.22777819703723           0.57883370119454          -0.72785534836319
H          -1.22777819703723          -0.57883370119454           0.72785534836319
H           1.22777819703723           0.57883370119454          -0.72785534836319
H           1.22777819703723          -0.57883370119454           0.72785534836319""",
               format='xyz')
# [___CELL_SEPARATOR___]
#! test_small_molecule_draw3d
cyclohexane.draw3d()
# [___CELL_SEPARATOR___]
#! test_small_molecule_draw2d
cyclohexane.draw2d()
# [___CELL_SEPARATOR___]
#! test_small_molecule_draw_panes
cyclohexane.draw()
# [___CELL_SEPARATOR___]
#! test_small_molecule_draw_with_selection
panes = cyclohexane.draw()
panes.viewer.selected_atom_indices=[1,2,3]
panes
# [___CELL_SEPARATOR___]
#! test_small_molecule_with_double_bonds
ethylene.draw()
# [___CELL_SEPARATOR___]
#! test_small_molecule_with_triple_bonds
viewer = acetylene.draw()
viewer
# [___CELL_SEPARATOR___]
#! test_draw_shapes
viewer = ethylene.draw3d()
viewer.draw_sphere(np.ones(3), color='green', opacity=0.5)
viewer.draw_cylinder(start=np.ones(3)-9, end=[0,0,-4], color='purple', opacity=0.8, radius=1.0)
viewer.draw_arrow(start=[0,0,0], end=[0,0,-4], color=0xaabbcc, opacity=0.8, radius=1.0)
viewer
# [___CELL_SEPARATOR___]
#! test_draw_outline_default
viewer = ethylene.draw3d()
viewer.set_outline()
viewer
# [___CELL_SEPARATOR___]
#! test_draw_outline_with_parameters
viewer = ethylene.draw3d()
viewer.set_outline(0.3, 'purple')
viewer
# [___CELL_SEPARATOR___]
#! test_draw_axes
#! fixture: axes_on
viewer = ethylene.draw3d()
viewer.draw_axes(True)
viewer
# [___CELL_SEPARATOR___]
#! test_turn_off_axes
#! with_fixture: axes_on
display(viewer)
viewer.draw_axes(False)
# [___CELL_SEPARATOR___]
#! test_draw_arrowvec
viewer = ethylene.draw3d()
viewer.draw_atom_vectors(ethylene.positions, scale_factor=1.0)
viewer
# [___CELL_SEPARATOR___]
#! test_draw_forces
ethylene.set_energy_model(mdt.models.HarmonicOscillator, k = 1.0 * u.eV / u.angstrom**2)
ethylene.calculate_forces()
viewer = ethylene.draw3d()
viewer.draw_forces()
viewer
# [___CELL_SEPARATOR___]
