ls
# [___CELL_SEPARATOR___]
pwd
# [___CELL_SEPARATOR___]
cd /
# [___CELL_SEPARATOR___]
pwd
# [___CELL_SEPARATOR___]
ls
# [___CELL_SEPARATOR___]
cd home
# [___CELL_SEPARATOR___]
ls
# [___CELL_SEPARATOR___]
cd jupyter-inkar601
# [___CELL_SEPARATOR___]
ls
# [___CELL_SEPARATOR___]
cd homework3
# [___CELL_SEPARATOR___]
ls
# [___CELL_SEPARATOR___]
mkdir test2
# [___CELL_SEPARATOR___]
mkdir test3
# [___CELL_SEPARATOR___]
mkdir test36
# [___CELL_SEPARATOR___]
cd test36
# [___CELL_SEPARATOR___]
touch 11.txt
# [___CELL_SEPARATOR___]
touch 2.txt
# [___CELL_SEPARATOR___]
touch 1.mp3
# [___CELL_SEPARATOR___]
touch 111.mp3
# [___CELL_SEPARATOR___]
touch 4.png
# [___CELL_SEPARATOR___]
ls
# [___CELL_SEPARATOR___]
touch a.png
# [___CELL_SEPARATOR___]
touch a.txt
# [___CELL_SEPARATOR___]
touch b.mp3
# [___CELL_SEPARATOR___]
touch c.txt
# [___CELL_SEPARATOR___]
ls
# [___CELL_SEPARATOR___]
pwd
# [___CELL_SEPARATOR___]
ls *.txt
# [___CELL_SEPARATOR___]
ls *.mp3
# [___CELL_SEPARATOR___]
ls 1*.mp3
# [___CELL_SEPARATOR___]
ls *.png
# [___CELL_SEPARATOR___]
ls *[a-z].txt
# [___CELL_SEPARATOR___]
ls -al
# [___CELL_SEPARATOR___]
ls -l
# [___CELL_SEPARATOR___]
touch test36
# [___CELL_SEPARATOR___]
ls
# [___CELL_SEPARATOR___]
ls -l test36
# [___CELL_SEPARATOR___]
chmod u-w test36
# [___CELL_SEPARATOR___]
ls -l test36
# [___CELL_SEPARATOR___]
chmod u+x test36
# [___CELL_SEPARATOR___]
ls -l test36
# [___CELL_SEPARATOR___]
chmod u+w test36
# [___CELL_SEPARATOR___]
ls -l test36
# [___CELL_SEPARATOR___]
chmod o+x test36
# [___CELL_SEPARATOR___]
ls -l test36
# [___CELL_SEPARATOR___]
man chmod
# [___CELL_SEPARATOR___]
date