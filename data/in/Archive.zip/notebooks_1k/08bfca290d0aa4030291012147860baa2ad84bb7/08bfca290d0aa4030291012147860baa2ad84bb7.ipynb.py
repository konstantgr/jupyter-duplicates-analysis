import pandas as pd 
from sklearn.linear_model import LinearRegression
from sklearn.linear_model import Lasso
from sklearn.linear_model import Ridge
from matplotlib import pyplot as plt 
from sklearn.ensemble import RandomForestRegressor
from sklearn.ensemble import GradientBoostingRegressor
from joblib import Parallel, delayed
from sklearn.metrics import r2_score
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import mean_squared_error
from statsmodels.graphics.tsaplots import plot_pacf
from sklearn.ensemble import RandomForestRegressor
%matplotlib inline 
import numpy as np
plt.rcParams['figure.figsize'] = (16, 8)
from tqdm import tqdm_notebook as tqdm
import warnings
warnings.filterwarnings(action="ignore")
warnings.filterwarnings(action="ignore", module="scipy", message="^internal gelsd")

import utils
# [___CELL_SEPARATOR___]
store = utils.get_store_data()
store['date'] = pd.to_datetime(store['date'], format='%Y-%m-%d')
store = store.set_index('date')
store = store.sort_index()
# [___CELL_SEPARATOR___]
def build_target(series_, number_of_periods_ahead):
    """ 
    takes a series, turns it into a dataframe, and adds a new column called target
    This column is the input series, lagged number_of_periods_ahead into the future
    """
    
    # make a copy 
    series_ = series_.copy()
    series_.name = 'customers'
    
    # make a dataframe from the series
    df_ = pd.DataFrame(series_)
    
    # the target column will be the input series, lagged into the future
    df_['target'] = series_.shift(-number_of_periods_ahead)
    return df_
# [___CELL_SEPARATOR___]
def separate_last_day(df_):
    
    """
    takes a dataset which has the target and features built 
    and separates it into the last day
    """
    # take the last period 
    last_period = df_.iloc[-1]
    
    # the last period is now a series, so it's name will be the timestamp
    training_data = df_.loc[df_.index < last_period.name]

    return last_period, training_data
# [___CELL_SEPARATOR___]
def build_some_features(df_, num_periods_lagged=1, num_periods_diffed=0, weekday=False, month=False, rolling=[], holidays=False): 
    """
    Builds some features by calculating differences between periods  
    """
    # make a copy 
    df_ = df_.copy()
        
    # for a few values, get the lags  
    for i in range(1, num_periods_lagged+1):
        # make a new feature, with the lags in the observed values column
        df_['lagged_%s' % str(i)] = df_['customers'].shift(i)
        
    # for a few values, get the diffs  
    for i in range(1, num_periods_diffed+1):
        # make a new feature, with the diffs in the observed values column
        df_['diff_%s' % str(i)] = df_['customers'].diff(i)
    
    for stat in rolling:
        df_['rolling_%s'%str(stat)] = df_['customers'].rolling('7D').aggregate(stat)
        
    if weekday == True:
        df_['sin_weekday'] = np.sin(2*np.pi*df_.index.weekday/7)
        df_['cos_weekday'] = np.sin(2*np.pi*df_.index.weekday/7)
        
    if month == True:
        df_['sin_month'] = np.sin(2*np.pi*df_.index.month/12)
        df_['cos_month'] = np.sin(2*np.pi*df_.index.month/12)
        
    if holidays == True:
        holidays = df_[((df_.index.month==12) & (df_.index.day==25))
              |((df_.index.month==1) & (df_.index.day==1))].customers
        df_['holidays'] = holidays + 1
        df_['holidays'] = df_['holidays'].fillna(0)
    
    return df_
# [___CELL_SEPARATOR___]
def separate_train_and_test_set(last_period_, training_data_, target='target'): 
    
    """ 
    separates training and test set (clue was in the name, really... )
    Ok, we were lazy and left the target hardcoded as 'target'. Shame on us. 
    """
    
    # anything that isn't a target is a feature 
    features = [feature for feature in training_data_.columns if feature != target]
    
    # adding a sneaky little dropna to avoid the missing data problem above 
    X_train = training_data_.dropna()[features]
    y_train = training_data_.dropna()[target]
    
    X_last_period = last_period_[features]
    
    return X_train, y_train, X_last_period
# [___CELL_SEPARATOR___]
def prepare_for_prediction(series_, number_of_periods_ahead, num_periods_lagged, num_periods_diffed, weekday, month, rolling, holidays):
    
    """ 
    Wrapper to go from the original series to X_train, y_train, X_last_period 
    
    """
    
    # build the target 
    data_with_target = build_target(series_, 
                                    number_of_periods_ahead)
    
    # build the features 
    data_with_target_and_features = build_some_features(data_with_target, 
                                                        num_periods_lagged=num_periods_lagged,
                                                       num_periods_diffed=num_periods_diffed,
                                                       weekday=weekday,
                                                       month=month,
                                                       rolling=rolling,
                                                       holidays=holidays)
    # separate train and test data 
    last_period, training_data = separate_last_day(data_with_target_and_features)

    # separate X_train, y_train, and X_test 
    X_train, y_train, X_last_period = separate_train_and_test_set(last_period, 
                                                           training_data, 
                                                           target='target')
    
    # return ALL OF THE THINGS! (well, actually just the ones we need)
    return X_train, y_train, X_last_period 
# [___CELL_SEPARATOR___]
def predict_period_n(series_, model, number_of_periods_ahead, num_periods_lagged, num_periods_diffed, weekday, month, rolling, holidays): 
    
        X_train, y_train, X_last_period = prepare_for_prediction(series_, 
                                                             number_of_periods_ahead, 
                                                             num_periods_lagged,
                                                             num_periods_diffed,
                                                             weekday,
                                                             month,
                                                             rolling,
                                                             holidays)
        
        model.fit(X_train, y_train)
        return model.predict(X_last_period.values.reshape(1, -1))
# [___CELL_SEPARATOR___]
def predict_n_periods(series_, n_periods, model, num_periods_lagged, num_periods_diffed=0, weekday=False, month=False,rolling=[], holidays=False): 
    predictions = []

    for period_ahead in range(1, n_periods+1):
        pred = predict_period_n(series_=series_, 
                                model=model, 
                                number_of_periods_ahead=period_ahead, 
                                num_periods_lagged=num_periods_lagged,
                                num_periods_diffed=num_periods_diffed,
                                weekday=weekday,
                                month=month,
                                rolling=rolling,
                                holidays=holidays)
        
        predictions.append(pred[0])
        
    return predictions 
# [___CELL_SEPARATOR___]
store.head()
# [___CELL_SEPARATOR___]
store.isnull().sum()
# [___CELL_SEPARATOR___]
store_resampled = store.resample('D').mean()
# [___CELL_SEPARATOR___]
store_resampled.isnull().sum()
# [___CELL_SEPARATOR___]
store_resampled[store_resampled.isnull()['customers']]
# [___CELL_SEPARATOR___]
store_cleaned = store_resampled.fillna(0)
# [___CELL_SEPARATOR___]
store_cleaned.isnull().sum()
# [___CELL_SEPARATOR___]
split_date = '2017-6'
train = store_cleaned.loc[store_cleaned.index < split_date]
test = store_cleaned.loc[store_cleaned.index >= split_date]
# [___CELL_SEPARATOR___]
predictions = predict_n_periods(series_=train, 
                  n_periods=len(test), 
                  model=LinearRegression(), 
                  num_periods_lagged=30
                  )
# [___CELL_SEPARATOR___]
store[1500:].plot(label="original data")
pd.Series(predictions, index=test.index).plot(label="pred")
plt.legend();
# [___CELL_SEPARATOR___]
mean_absolute_error(test,predictions)
# [___CELL_SEPARATOR___]
store_features = store_cleaned.copy()
# [___CELL_SEPARATOR___]
store_features['diff'] = store_cleaned.diff()
# [___CELL_SEPARATOR___]
store_cleaned.head()
# [___CELL_SEPARATOR___]
store_features.head()
# [___CELL_SEPARATOR___]
store_features['rolling_max'] = store_features['customers'].rolling('7D').max()
store_features['rolling_min'] = store_features['customers'].rolling('7D').min()
store_features['rolling_mean'] = store_features['customers'].rolling('7D').mean()
store_features['rolling_std'] = store_features['customers'].rolling('7D').std()
# [___CELL_SEPARATOR___]
holidays = store_features[((store_features.index.month==12) & (store_features.index.day==25))
              |((store_features.index.month==1) & (store_features.index.day==1))].customers
# [___CELL_SEPARATOR___]
store_features['holidays'] = holidays + 1
# [___CELL_SEPARATOR___]
store_features['holidays'] = store_features['holidays'].fillna(0)
# [___CELL_SEPARATOR___]
store_features['day_of_week'] = store_features.index.weekday
store_features['month'] = store_features.index.month
# [___CELL_SEPARATOR___]
store_features.head(10)
# [___CELL_SEPARATOR___]
store_features['sin_weekday'] = np.sin(2*np.pi*store_features.index.weekday/7)
store_features['cos_weekday'] = np.sin(2*np.pi*store_features.index.weekday/7)
        
store_features['sin_month'] = np.sin(2*np.pi*store_features.index.month/12)
store_features['cos_month'] = np.sin(2*np.pi*store_features.index.month/12)
# [___CELL_SEPARATOR___]
store_features = store_features.drop(['day_of_week','month'], axis=1)
# [___CELL_SEPARATOR___]
store_features.head()
# [___CELL_SEPARATOR___]
def build_some_features(df_, num_periods_lagged=1, num_periods_diffed=0, weekday=False, month=False, rolling=[], holidays=False): 
    """
    Builds some features by calculating differences between periods  
    """
    # make a copy 
    df_ = df_.copy()
        
    # for a few values, get the lags  
    for i in range(1, num_periods_lagged+1):
        # make a new feature, with the lags in the observed values column
        df_['lagged_%s' % str(i)] = df_['customers'].shift(i)
        
    # for a few values, get the diffs  
    for i in range(1, num_periods_diffed+1):
        # make a new feature, with the diffs in the observed values column
        df_['diff_%s' % str(i)] = df_['customers'].diff(i)
    
    for stat in rolling:
        df_['rolling_%s'%str(stat)] = df_['customers'].rolling('7D').aggregate(stat)
        
    if weekday == True:
        df_['sin_weekday'] = np.sin(2*np.pi*df_.index.weekday/7)
        df_['cos_weekday'] = np.sin(2*np.pi*df_.index.weekday/7)
        
    if month == True:
        df_['sin_month'] = np.sin(2*np.pi*df_.index.month/12)
        df_['cos_month'] = np.sin(2*np.pi*df_.index.month/12)
        
    if holidays == True:
        holidays = df_[((df_.index.month==12) & (df_.index.day==25)) |((df_.index.month==1) & (df_.index.day==1))].customers
        df_['holidays'] = holidays + 1
        df_['holidays'] = df_['holidays'].fillna(0)
    
    return df_
# [___CELL_SEPARATOR___]
from sklearn.model_selection import ParameterGrid
param_grid = {'model': [LinearRegression(), GradientBoostingRegressor()], 
              'num_periods_lagged':np.arange(1,3),
              'num_periods_diffed':np.arange(0,3),
              'weekday':[True,False],
              'month':[True,False],
              'holidays': [True],
              'rolling' : [[np.mean,np.min,np.max,np.std]]
             }

grid = ParameterGrid(param_grid)
# [___CELL_SEPARATOR___]
val_split_date = '2017-3'
test_split_date = '2017-6'
train = store_cleaned.loc[store_cleaned.index < val_split_date]
val = store_cleaned.loc[(val_split_date <= store_cleaned.index) & (store_cleaned.index < test_split_date)]
test = store_cleaned.loc[store_cleaned.index >= test_split_date]
# [___CELL_SEPARATOR___]
#error_lst = []

#for params in tqdm(grid):
#    predictions = predict_n_periods(series_=train, 
#                      n_periods=30, 
#                      model=params['model'], 
#                      num_periods_lagged=params['num_periods_lagged'],
#                      num_periods_diffed=params['num_periods_diffed'],
#                      weekday=params['weekday'],
#                      month=params['month'],
#                      rolling=[np.mean,np.max,np.min]
#                    )
#
#    error_lst.append(mean_absolute_error(val,predictions))
# pd.Series(error_lst).idxmin()
# [___CELL_SEPARATOR___]
%%time 
# This is another cell that will take a long time to run. 

def wrap_model_selection(params): 
    predictions = predict_n_periods(series_=train, 
                      n_periods=len(val), 
                      model=params['model'], 
                      num_periods_lagged=params['num_periods_lagged'],
                      num_periods_diffed=params['num_periods_diffed'],
                      weekday=params['weekday'],
                      month=params['month'],
                      rolling=[np.mean,np.max,np.min]
                    )
    return [params,mean_absolute_error(val,predictions)]

res = Parallel(n_jobs=-1)(delayed(wrap_model_selection)(params=params) 
                          for params in tqdm(grid))
# [___CELL_SEPARATOR___]
df = pd.DataFrame(res, columns=['params','error'])
df.sort_values('error').head()
# [___CELL_SEPARATOR___]
df.sort_values('error').iloc[0][0]
# [___CELL_SEPARATOR___]
train = train.append(val)
# [___CELL_SEPARATOR___]
predictions = predict_n_periods(series_=train, 
                  n_periods=len(test), 
                  model=GradientBoostingRegressor(), 
                  num_periods_lagged=2,
                  num_periods_diffed=0,
                  weekday=True,
                  month=False,
                  rolling=[np.mean,np.min,np.max,np.std],
                  holidays=True
                  )
# [___CELL_SEPARATOR___]
store[1500:].plot(label="original data")
pd.Series(predictions, index=test.index).plot(label="pred")
plt.legend();
# [___CELL_SEPARATOR___]
mean_absolute_error(test,predictions)