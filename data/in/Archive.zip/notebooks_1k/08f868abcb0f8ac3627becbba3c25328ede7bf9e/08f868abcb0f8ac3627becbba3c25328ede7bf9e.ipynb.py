import random
import numpy as np
import os

import matplotlib
import matplotlib.pyplot as plt

from PIL import Image
import cv2

import scipy
from scipy import ndimage

from features import rgb2gray

from sklearn.cluster import DBSCAN
from sklearn import metrics
from sklearn.datasets.samples_generator import make_blobs
from sklearn.preprocessing import StandardScaler

import imageio

# This is a bit of magic to make matplotlib figures appear inline in the notebook
# rather than in a new window.
%matplotlib inline
plt.rcParams['figure.figsize'] = (30.0, 16.0) # set default size of plots
plt.rcParams['image.interpolation'] = 'nearest'
plt.rcParams['image.cmap'] = 'gray'

# Some more magic so that the notebook will reload external python modules;
# see http://stackoverflow.com/questions/1907993/autoreload-of-modules-in-ipython
%load_ext autoreload
%autoreload 2
# [___CELL_SEPARATOR___]
def parse_labels(label_arr):
    """    
    None = Normal
    1 = missing data (expected)
    2 = missing data (unexpected)
    3 = miscoloration
    4 = edge warping
    5 = eclipse (missing data)
    6 = eclipse (miscoloration)
    """
    label = 0
    
    # No label!
    if len(label_arr) == 0:
        label = 0
        return label
    
    # Detect the miscoloration labels
    if 3 in label_arr or 6 in label_arr:
        label = 1
    
    return label
# [___CELL_SEPARATOR___]
layer_name = 'VIIRS_SNPP_CorrectedReflectance_TrueColor'
img_extension = ".jpg"
data_dir = 'data/4326/'
labels_file = os.path.join(data_dir, layer_name + ".txt")
img_size = (2048, 1024)

# Check the labels file exists!
assert os.path.exists(labels_file), "Cannot find the {} file".format(layer_name + ".txt")
normal_image_hist = np.zeros((1024, 2048, 360))
print(normal_image_hist.shape)

# Read in the file line by line
with open(labels_file) as f:
    file_lines = f.read().splitlines()
    num_total_img = len(file_lines)
    for line in file_lines:
        line_list = line.split()  
        split = line_list[0]
        datestring = line_list[1]
        label_arr = [int(item) for item in line_list[2:]]
        label = parse_labels(label_arr)
        
        # Skip non-normal images
        if label == 1: 
            continue        
        
        # Print the non-normal image date!
        print(datestring)
        
        # Construct and resize the image
        filename = os.path.join(data_dir, datestring, layer_name + img_extension)
        image_rgb = np.asarray(Image.open(filename).resize(img_size, Image.NEAREST))
        image_hsv = matplotlib.colors.rgb_to_hsv(image_rgb)
        
        # (H, W) = Hue values as indices
        image_hue = 360.0 * image_hsv[:,:,0]
        image_hue = image_hue.astype(int)
        
        # Create height and width indices
        h, w = image_hue.shape
        h_idx, w_idx = np.indices((h, w))
                
        # Height, Width, Hue Indexing!
        normal_image_hist[h_idx, w_idx, image_hue] += 1
# [___CELL_SEPARATOR___]
print(normal_image_hist.shape)
pos = np.arange(normal_image_hist.shape[2])
global_hue_hist = np.sum(normal_image_hist, axis=(0,1)).astype(int)
print(global_hue_hist)
plt.bar(pos, global_hue_hist, 1.0)
plt.xlabel('Hue Value (0-360)')
plt.ylabel('Frequency')
plt.title('Histogram of Hue Values')
# plt.grid(True)
plt.show()
# [___CELL_SEPARATOR___]
datestring = '2016-04-12'
print(datestring)

# Construct and resize the image
filename = os.path.join(data_dir, datestring, layer_name + img_extension)
image_rgb = np.asarray(Image.open(filename).resize(img_size, Image.BILINEAR))
image_hsv = matplotlib.colors.rgb_to_hsv(image_rgb)
# [___CELL_SEPARATOR___]
# (H, W) = Hue values as indices
image_hue = 360.0 * image_hsv[:,:,0]
image_value = image_hsv[:,:,2]
image_hue = image_hue.astype(int)

# Create height and width indices
h, w = image_hue.shape
labels_im = np.zeros_like(image_hue)

for h_idx in range(h):
    for w_idx in range(w):
        test_value = int(image_value[h_idx, w_idx])
        test_hue = int(image_hue[h_idx, w_idx])
        hue_histogram = normal_image_hist[h_idx, w_idx, :].astype(int)

        # skip black pixels in text image
        if test_value == 0:
            continue

#         # Reconstruct original data values
#         hue_values = []
#         for hue, count in enumerate(hue_histogram):
#             if count != 0 :
#                 hue_values = hue_values + [hue] * count
#         hue_values = np.array(hue_values)
        
#         # Compute basic statistcs on hue histogram
#         mean = np.mean(hue_values, axis=0)
#         std_dev = np.std(hue_values, axis=0)

#         # Clustered Data (Low STD) and outside the std
#         if std_dev < 40 and abs(mean - test_hue) > 2.0 * std_dev:
#             # Non-existent value

        if global_hue_hist[test_hue] == 0: # no occurences!
            labels_im[h_idx, w_idx] = 1

plt.imshow(labels_im)
# [___CELL_SEPARATOR___]
# Grayscaled image features!
def get_img_feature_vector(img):
    # Create the feature vector for the images
    indices = np.dstack(np.indices(img.shape[:2]))
    xycolors = np.concatenate((np.expand_dims(img, axis=2), indices), axis=-1) 
    features = np.reshape(xycolors, [-1,3])    
    return features
    # features_normalized = features / features.max(axis = 0)
    # return features_normalized

# DBSCAN        
# Featurize the image for DBscan
X = get_img_feature_vector(labels_im)
X_white = X[X[:,0] == 1]
X_white = X_white[:,1:]
X = X_white
# [___CELL_SEPARATOR___]
# Run DBscan clustering algorithm!
db = DBSCAN(eps=3.5, min_samples=30).fit(X)
core_samples_mask = np.zeros_like(db.labels_, dtype=bool)
core_samples_mask[db.core_sample_indices_] = True
labels = db.labels_

# Number of clusters in labels, ignoring noise if present.
n_clusters_ = len(set(labels)) - (1 if -1 in labels else 0)
print('Estimated number of clusters: %d' % n_clusters_)

# Create an image mask fore labels
filtered_labels_im = np.zeros_like(labels_im)

# Black removed and is used for noise instead.
unique_labels = set(labels)
colors = [plt.cm.Spectral(each) for each in np.linspace(0, 1, len(unique_labels))]
for k, col in zip(unique_labels, colors):
    if k == -1:
        # Black used for noise.
        col = [0, 0, 0, 1]

    # Hide the outliers!
    if col == [0, 0, 0, 1]:
         continue

    class_member_mask = (labels == k)

    # Retrieve the xy (hw) points
    class_xy = X[class_member_mask] # x = h, y = w

    # Label the target pixels as white (= 1)!
    filtered_labels_im[class_xy[:,0], class_xy[:,1]] = 1

    # Plot the clusters!
    core_xy = X[class_member_mask & core_samples_mask]
    plt.plot(core_xy[:, 1], core_xy[:, 0], 'o', markerfacecolor=tuple(col), markeredgecolor='k', markersize=14)

    noncore_xy = X[class_member_mask & ~core_samples_mask]
    plt.plot(noncore_xy[:, 1], noncore_xy[:, 0], 'o', markerfacecolor=tuple(col), markeredgecolor='k', markersize=6)

# Plot result
plt.title('Estimated number of clusters: %d' % n_clusters_)
plt.xlim(0, img_size[0])  # decreasing x
plt.ylim(img_size[1], 0)  # decreasing y
plt.show()
# [___CELL_SEPARATOR___]
plt.imshow(image_rgb)
# [___CELL_SEPARATOR___]
labels_filename = os.path.join(data_dir, datestring, 'VIIRS_SNPP_CorrectedReflectance_Miscoloration_Certain' + '.png')
print("Writing labels to:", labels_filename)
imageio.imwrite(labels_filename, 255 * filtered_labels_im)
# [___CELL_SEPARATOR___]
# Read in the file line by line
with open(labels_file) as f:
    file_lines = f.read().splitlines()
    num_total_img = len(file_lines)
    for line in file_lines:
        line_list = line.split()  
        split = line_list[0]
        datestring = line_list[1]
        label_arr = [int(item) for item in line_list[2:]]
        label = parse_labels(label_arr)
        
        # Skip normal images
        if label == 0: 
            continue        
        
        # Print the non-normal image date!
        print(datestring)
        
        # Construct and resize the image
        filename = os.path.join(data_dir, datestring, layer_name + img_extension)
        image_rgb = np.asarray(Image.open(filename).resize(img_size, Image.NEAREST))
        image_hsv = matplotlib.colors.rgb_to_hsv(image_rgb)
        
        # (H, W) = Hue values as indices
        image_hue = 360.0 * image_hsv[:,:,0]
        image_value = image_hsv[:,:,2]
        image_hue = image_hue.astype(int)

        # Create height and width indices
        h, w = image_hue.shape
        labels_im = np.zeros_like(image_hue, dtype=int)

        for h_idx in range(h):
            for w_idx in range(w):
                test_value = int(image_value[h_idx, w_idx])
                test_hue = int(image_hue[h_idx, w_idx])
                hue_histogram = normal_image_hist[h_idx, w_idx, :].astype(int)

                # Skip black pixels in text image
                if test_value == 0:
                    continue
                
                # Hue value has NEVER appeared!
                if global_hue_hist[test_hue] < 10000: # low occurences!
                    labels_im[h_idx, w_idx] = 1
            
        # Featurize the image for DBscan
        X = get_img_feature_vector(labels_im)
        X_white = X[X[:,0] == 1]
        X_white = X_white[:,1:]
        X = X_white
        
        # Run DBscan clustering algorithm!
        db = DBSCAN(eps=15, min_samples=20).fit(X)
        core_samples_mask = np.zeros_like(db.labels_, dtype=bool)
        core_samples_mask[db.core_sample_indices_] = True
        labels = db.labels_

        # Number of clusters in labels, ignoring noise if present.
        n_clusters_ = len(set(labels)) - (1 if -1 in labels else 0)
        print('Estimated number of clusters: %d' % n_clusters_)

        # Create an image mask fore labels
        filtered_labels_im = np.zeros_like(labels_im)

        # Black removed and is used for noise instead.
        unique_labels = set(labels)
        colors = [plt.cm.Spectral(each) for each in np.linspace(0, 1, len(unique_labels))]
        for k, col in zip(unique_labels, colors):
            if k == -1:
                # Black used for noise.
                col = [0, 0, 0, 1]

            # Hide the outliers!
            if col == [0, 0, 0, 1]:
                 continue

            class_member_mask = (labels == k)

            # Retrieve the xy (hw) points
            class_xy = X[class_member_mask] # x = h, y = w

            # Label the target pixels as white (= 1)!
            filtered_labels_im[class_xy[:,0], class_xy[:,1]] = 1

#             # Plot the clusters!
#             core_xy = X[class_member_mask & core_samples_mask]
#             plt.plot(core_xy[:, 1], core_xy[:, 0], 'o', markerfacecolor=tuple(col), markeredgecolor='k', markersize=14)

#             noncore_xy = X[class_member_mask & ~core_samples_mask]
#             plt.plot(noncore_xy[:, 1], noncore_xy[:, 0], 'o', markerfacecolor=tuple(col), markeredgecolor='k', markersize=6)

#         # Plot result
#         plt.title('Estimated number of clusters: %d' % n_clusters_)
#         plt.xlim(0, img_size[0])  # decreasing x
#         plt.ylim(img_size[1], 0)  # decreasing y
#         plt.show()        
        
        labels_filename = os.path.join(data_dir, datestring, 'VIIRS_SNPP_CorrectedReflectance_Miscoloration_Certain' + '.png')
        print("Writing labels to:", labels_filename)
        imageio.imwrite(labels_filename, 255 * filtered_labels_im)
# [___CELL_SEPARATOR___]
