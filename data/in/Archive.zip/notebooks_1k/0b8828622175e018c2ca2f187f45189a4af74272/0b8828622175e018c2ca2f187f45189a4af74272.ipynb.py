import helpers
from helpers import Loader

import numpy as np
import pandas as pd
from sqlalchemy import create_engine
from matplotlib import pyplot as plt
from sklearn.ensemble import GradientBoostingClassifier
from sklearn import metrics
from sklearn.grid_search import GridSearchCV
from collections import Counter
from sklearn import preprocessing
# [___CELL_SEPARATOR___]
loader = Loader()
# [___CELL_SEPARATOR___]
X_trn_encoded.shape
# [___CELL_SEPARATOR___]
X_trn, Y_trn = loader.load("trn_set", ignore_categorical=True, nrows=100000)
X_dev, Y_dev = loader.load("dev_set", ignore_categorical=True, nrows=10000)
# [___CELL_SEPARATOR___]
gbm = GradientBoostingClassifier(random_state=0)
gbm.fit(X_trn, Y_trn)
# [___CELL_SEPARATOR___]
plt.figure(figsize=(12, 8))
feat_imp = pd.Series(gbm.feature_importances_, X_trn.columns).sort_values(ascending=False)
feat_imp.plot(kind='bar', title='Feature Importances')
plt.ylabel('Feature Importance Score')
plt.savefig("figs/features_ranking.png")
# [___CELL_SEPARATOR___]
Y_pred = gbm.predict(X_dev)
# [___CELL_SEPARATOR___]
plt.figure(figsize=(15, 7))

ax1 = plt.subplot(1, 2, 1)

value_counts = Counter(Y_dev)
_ = ax1.pie(x = list(value_counts.values()), 
            labels = list(value_counts.keys()),
            autopct='%1.1f%%', 
            labeldistance = 1.1)
ax1.set_title('Development Set Label')

ax2 = plt.subplot(1, 2, 2)

value_counts = Counter(Y_pred)
_ = ax2.pie(x = list(value_counts.values()), 
            labels = list(value_counts.keys()),
            autopct='%1.1f%%',
            labeldistance = 1.1)

ax2.set_title('Predicted Label')

plt.show()
# [___CELL_SEPARATOR___]
print("Accuracy : %.4g" % metrics.accuracy_score(Y_dev.values, Y_pred))
# [___CELL_SEPARATOR___]
X_trn, Y_trn = loader.load("trn_set", ignore_categorical=False, nrows=100000)
X_dev, Y_dev = loader.load("dev_set", ignore_categorical=False, nrows=10000)
# [___CELL_SEPARATOR___]
ohe = preprocessing.OneHotEncoder(handle_unknown="ignore")
ohe.fit(X_trn[loader.cat_cols].fillna(0))
# [___CELL_SEPARATOR___]
X_trn_encoded = loader.encode(ohe, X_trn)
X_dev_encoded = loader.encode(ohe, X_dev)
# [___CELL_SEPARATOR___]
gbm = GradientBoostingClassifier(random_state=0)
gbm.fit(X_trn_encoded, Y_trn)
# [___CELL_SEPARATOR___]
Y_pred = gbm.predict(X_dev_encoded)
# [___CELL_SEPARATOR___]
Y_dev.value_counts() / len(Y_dev)
# [___CELL_SEPARATOR___]
print("Accuracy : %.4g" % metrics.accuracy_score(Y_dev.values, Y_pred))
# [___CELL_SEPARATOR___]
X_trn.shape