%lsmagic
# [___CELL_SEPARATOR___]
%timeit a = range(10000)
%timeit a = range(100)
# [___CELL_SEPARATOR___]
%%timeit
a = range(10000)
b = range(100)
# [___CELL_SEPARATOR___]
%%prun
import numpy as np

# [___CELL_SEPARATOR___]
%%prun
a = np.ones((1000,1000))
# [___CELL_SEPARATOR___]
