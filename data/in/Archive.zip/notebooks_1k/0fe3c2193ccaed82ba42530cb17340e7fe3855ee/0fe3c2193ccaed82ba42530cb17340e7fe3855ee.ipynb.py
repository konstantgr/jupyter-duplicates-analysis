1 + 1
# [___CELL_SEPARATOR___]
x = 1 + 1
# [___CELL_SEPARATOR___]
print(x) # Printing outputs what is stored inside a variable below a notebook cell.
# [___CELL_SEPARATOR___]
print?
# [___CELL_SEPARATOR___]
y = x * 3 # An asterisk is used to multiply in python. 
# [___CELL_SEPARATOR___]
print(y)
# [___CELL_SEPARATOR___]
z = y/x
# [___CELL_SEPARATOR___]
print(z)
# [___CELL_SEPARATOR___]
3 ** 3
# The double asterisk takes an exponent to the power of whatever number follows
# [___CELL_SEPARATOR___]
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
# [___CELL_SEPARATOR___]
np
# [___CELL_SEPARATOR___]
# We can write words into python code by surrounding a word or number with quotation marks.
# This is called a string, and we have stored our five strings in a list.
names = ['Liam', 'Emma', 'Noah', 'Olivia', 'Ava']

#Whole numbers are called integers.
birth_count = [19837, 18688, 18267, 17921, 14924]

#Decimals or fractions are called floats.
percentage_of_births = [0.0102, 0.0101, 0.0097, 0.0095, 0.0081]
# [___CELL_SEPARATOR___]
type(names)
# [___CELL_SEPARATOR___]
type?
# [___CELL_SEPARATOR___]
data = {'names': names, 'count': birth_count, 'percentage': percentage_of_births}
# [___CELL_SEPARATOR___]
type(data)
# [___CELL_SEPARATOR___]
df = pd.DataFrame(data)
# [___CELL_SEPARATOR___]
df
# [___CELL_SEPARATOR___]
df.to_csv('save_the_pandas.csv')
# [___CELL_SEPARATOR___]
names_df = pd.read_csv('baby-names.csv')

#This csv file was created by Hadley Wickham and is available at https://github.com/hadley/data-baby-names
# [___CELL_SEPARATOR___]
names_df
# [___CELL_SEPARATOR___]
names_df.columns

# Note that the data for this csv file is taken from the US Social Security website. 
# The SSO has historically assigned a binary gender at birth and is therefore biased in its collection.
# It is always important to keep in mind bias that might be included in data collection!
# [___CELL_SEPARATOR___]
names_df.head(8)
# [___CELL_SEPARATOR___]
len(names_df)
# [___CELL_SEPARATOR___]
#First we isolate the column including information about each year

years = names_df['year']
# [___CELL_SEPARATOR___]
# Now we find the minimum value in that column, using the .min() command
years.min()
# [___CELL_SEPARATOR___]
years.max()
# [___CELL_SEPARATOR___]
plt.figure(figsize = (12,8))
years.hist(bins=129, edgecolor='black', linewidth=1)
plt.xlabel('Year', fontsize=16)
# [___CELL_SEPARATOR___]
percentage = names_df['percent']
# [___CELL_SEPARATOR___]
percentage.max() #the most popular name was given to 8% of the population that year
# [___CELL_SEPARATOR___]
percentage.min() #the least popular name was given to 0.002% of the population
# [___CELL_SEPARATOR___]
names_df['percent'].mean()
# [___CELL_SEPARATOR___]
names_df['percent'].median()
# [___CELL_SEPARATOR___]
names_df['percent'].mode()
# [___CELL_SEPARATOR___]
subset = names_df.loc[(years >= 1960) & (years < 1970) & (names_df['gender'] == 'girl')]
# [___CELL_SEPARATOR___]
subset.head(12)
# [___CELL_SEPARATOR___]
subset.sort_values(by='percent', ascending=False)
# [___CELL_SEPARATOR___]
eighteen_df = names_df.loc[years < 1900].copy()
# [___CELL_SEPARATOR___]
nineteen_df = names_df.loc[(years >= 1900) & (years < 2000)].copy()
millenium_df = names_df.loc[years >= 2000].copy()
# [___CELL_SEPARATOR___]
total_df = pd.concat([eighteen_df, nineteen_df, millenium_df])
# [___CELL_SEPARATOR___]
len(total_df)
# [___CELL_SEPARATOR___]
names = ['Peter', 'Paul', 'Mary']
percent_1960 = [0.004949, 0.011837, 0.024750]

percent_1961 = [0.004794, 0.011890, 0.022958]

percent_1962 = [0.004560, 0.011321, 0.021457]
# [___CELL_SEPARATOR___]
sixty_df = pd.DataFrame({'name': names, 'percent_1960': percent_1960})
# [___CELL_SEPARATOR___]
sixtyone_df = pd.DataFrame({'name': names, 'percent_1961': percent_1961})
# [___CELL_SEPARATOR___]
sixtytwo_df = pd.DataFrame({'name': names, 'percent_1962': percent_1962})
# [___CELL_SEPARATOR___]
sixty_df
# [___CELL_SEPARATOR___]
sixtyone_df
# [___CELL_SEPARATOR___]
name = names_df['name']
# [___CELL_SEPARATOR___]
sixty_df = names_df[['name', 'percent']].loc[(years == 1960) & ((name == 'Mary') | (name == 'Peter') | (name == 'Paul'))]
sixty_df.columns = ['name', 'percent_1960']
# [___CELL_SEPARATOR___]
sixtyone_df = names_df[['name', 'percent']].loc[(years == 1961) & ((name == 'Mary') | (name == 'Peter') | (name == 'Paul'))]
sixtyone_df.columns = ['name', 'percent_1961']
# [___CELL_SEPARATOR___]
sixtytwo_df = names_df[['name', 'percent']].loc[(years == 1962) & ((name == 'Mary') | (name == 'Peter') | (name == 'Paul'))]
sixtytwo_df.columns = ['name', 'percent_1962']
# [___CELL_SEPARATOR___]
sixty_sixtyone_df = pd.merge(sixty_df, sixtyone_df, how='right', on='name')
# [___CELL_SEPARATOR___]
sixty_sixtyone_df
# [___CELL_SEPARATOR___]
total_df = sixty_df.merge(sixtyone_df, how='right', on='name').merge(sixtytwo_df, how='inner', on='name')
# [___CELL_SEPARATOR___]
total_df
# [___CELL_SEPARATOR___]
# HINT: It's very useful to break coding down into written steps and then complete each step one by one.

# Here is a sample of the first step that I might write
# Step 1: Create a subset of the name Lisa in the 1960s.
# Step 2: Create a variable equal to the percentage column
# Step 3: Make a histogram of that variable

#Step 1
lisa60s_df = names_df.loc[(name == 'Lisa') & (years >= 1960) & (years < 1970)]
# [___CELL_SEPARATOR___]
#Step 2
lisa_popularity = lisa60s_df['percent']
# [___CELL_SEPARATOR___]
#Step 3
lisa_popularity.hist(bins=10, facecolor='Tomato')
plt.xlabel('Percentage Popularity of the name Lisa in the 1960s')
# [___CELL_SEPARATOR___]
#Step 1
mary60s_df = names_df.loc[(name == 'Mary') & (years >= 1960) & (years < 1970)]
# [___CELL_SEPARATOR___]
#Step 2
mary_popularity = mary60s_df['percent']
# [___CELL_SEPARATOR___]
#Step 3
mary_popularity.hist(bins=10, facecolor='c')
plt.xlabel('Percentage Popularity of the name Mary in the 1960s')
# [___CELL_SEPARATOR___]
lisa_popularity.hist(bins=10, facecolor='Tomato', label='Lisa')
mary_popularity.hist(bins=10, facecolor='c', label='Mary', alpha=0.5)
plt.xlabel('Percentage Popularity of the names Lisa and Mary in the 1960s')
plt.legend()

plt.savefig('name_popularity.png')
#We can see that Lisa was a more popular name overall in the 1960s, for both boys and girls.
# [___CELL_SEPARATOR___]
lisa60s_df.to_csv('lisa_1960s.csv')
mary60s_df.to_csv('mary_1960s.csv')
# [___CELL_SEPARATOR___]
#There are many correct ways to answer this question, that's one of the beautiful things about coding
#Here's one way to answer the question in one line
names_df.loc[(years >= 1980) & (years < 1990)].drop_duplicates(subset='name', keep=False).sort_values(by='percent', ascending=False).head(5)
# [___CELL_SEPARATOR___]
#Now let's save this dataframe in its entirety (not just the first 5 lines), to answer the next part
onehit_df = names_df.loc[(years >= 1980) & (years < 1990)].drop_duplicates(subset='name', keep=False).sort_values(by='percent', ascending=False)
# [___CELL_SEPARATOR___]
len(onehit_df)
# [___CELL_SEPARATOR___]
onehit_df['percent'].hist(bins=30)
plt.xlabel('Percentage Popularity of Names that Only Made the Most Popular List Once in the 1980s')
plt.savefig('onehit_hist.png')
# [___CELL_SEPARATOR___]
onehit_df['percent'].hist(bins=10)
plt.xlabel('Percentage Popularity of Names that Only Made the Most Popular List Once in the 1980s')
# [___CELL_SEPARATOR___]
onehit_df['percent'].hist(bins=200)
plt.xlabel('Percentage Popularity of Names that Only Made the Most Popular List Once in the 1980s')
# [___CELL_SEPARATOR___]
onehit_df['percent'].hist(bins=50)
plt.xlabel('Percentage Popularity of Names that Only Made the Most Popular List Once in the 1980s')
# [___CELL_SEPARATOR___]
merge_df = onehit_df[['name']].merge(names_df, how='left', on='name')
# [___CELL_SEPARATOR___]
merge_df.head(25)
# [___CELL_SEPARATOR___]
len(merge_df)
# [___CELL_SEPARATOR___]
merge_df.loc[merge_df['year'] < 1890].drop_duplicates(subset='name')