from downloader import BiliDownloader

# ---------------下载路径 & Cookie-----------------
DIRNAME = 'E:/downloads'
COOKIE = 'SESSDATA=3f5081db%2C1b02652790%2C8c420*41'
# --------------------------------------------------
    
    
url = 'https://www.bilibili.com/video/BV1pt411h7aT'
page = [1, 2, 3]
quality = 3
bili_downloader = BiliDownloader(url, DIRNAME, COOKIE)
bili_downloader(page, quality)
# [___CELL_SEPARATOR___]
