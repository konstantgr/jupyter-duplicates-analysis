# Import pandas
import pandas as pd

# Load in data
df = pd.read_csv('data/user_ex_python.csv')
df
# [___CELL_SEPARATOR___]
# Check out index
df.index
# [___CELL_SEPARATOR___]
# Slice and dice data
df.loc[:1]
# [___CELL_SEPARATOR___]
# Set new index
df.set_index(pd.DatetimeIndex(df['date']), inplace=True)
df
# [___CELL_SEPARATOR___]
# Check out new index
df.index
# [___CELL_SEPARATOR___]
# Slice and dice data w/ new index
df.loc['2017-01-02']
# [___CELL_SEPARATOR___]
# Check out columns
df.columns
# [___CELL_SEPARATOR___]
# Import and check out data
df = pd.read_csv('data/user_ex.csv')
df
# [___CELL_SEPARATOR___]
# Set index
df.set_index(['date', 'language'], inplace=True)
df
# [___CELL_SEPARATOR___]
# Check out multi-index
df.index
# [___CELL_SEPARATOR___]
# Sort index
df.sort_index(inplace=True)
df
# [___CELL_SEPARATOR___]
# Slice & dice your DataFrame
df.loc[('2017-01-02', 'r')]
# [___CELL_SEPARATOR___]
# Import and check out data
import seaborn as sns
tips = sns.load_dataset("tips")
tips.head()
# [___CELL_SEPARATOR___]
# Check out index
tips.index
# [___CELL_SEPARATOR___]
# Import pyplot, figures inline, set style, plot pairplot
import matplotlib.pyplot as plt
%matplotlib inline
sns.set()
sns.pairplot(tips, hue='day');
# [___CELL_SEPARATOR___]
# Get mean of smoker/non-smoker groups
df = tips.groupby('smoker').mean()
df
# [___CELL_SEPARATOR___]
# Check out new index
df.index
# [___CELL_SEPARATOR___]
# Reset the index
df.reset_index()
# [___CELL_SEPARATOR___]
# Group by two columns
df = tips.groupby(['smoker','time']).mean()
df
# [___CELL_SEPARATOR___]
# Check out index
df.index
# [___CELL_SEPARATOR___]
# Group by two features
tips.groupby(['smoker','time']).size()
# [___CELL_SEPARATOR___]
# Swap levels of multi-index
df.swaplevel()
# [___CELL_SEPARATOR___]
# Unstack your multi-index
df.unstack()
# [___CELL_SEPARATOR___]
# Unsstack the outer index
df.unstack(level=0)
# [___CELL_SEPARATOR___]
# Check out index
df.unstack().index