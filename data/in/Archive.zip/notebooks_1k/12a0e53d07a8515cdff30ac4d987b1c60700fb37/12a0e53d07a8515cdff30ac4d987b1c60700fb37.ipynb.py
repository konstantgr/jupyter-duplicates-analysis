from deeputil.datasets import Australia
# [___CELL_SEPARATOR___]
df = Australia.load_data_as_pandas_df()
# [___CELL_SEPARATOR___]
df.shape
# [___CELL_SEPARATOR___]
df.describe
# [___CELL_SEPARATOR___]
