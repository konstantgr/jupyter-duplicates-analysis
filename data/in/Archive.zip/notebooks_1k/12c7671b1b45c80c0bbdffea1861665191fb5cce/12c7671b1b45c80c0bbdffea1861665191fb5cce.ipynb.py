import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
# [___CELL_SEPARATOR___]
file_url = 'https://raw.githubusercontent.com/PacktWorkshops/The-Data-Science-Workshop/master/Chapter04/Dataset/phpB0xrNj.csv'
# [___CELL_SEPARATOR___]
df = pd.read_csv(file_url)
# [___CELL_SEPARATOR___]
df.head()
# [___CELL_SEPARATOR___]
y = df.pop('class')
# [___CELL_SEPARATOR___]
X_train, X_test, y_train, y_test = train_test_split(df, y, test_size=0.3, random_state=888)
# [___CELL_SEPARATOR___]
def train_rf(X_train, y_train, random_state=888, n_estimators=10, max_depth=None, min_samples_leaf=1, max_features='sqrt'):
  rf_model = RandomForestClassifier(random_state=random_state, n_estimators=n_estimators, max_depth=max_depth, min_samples_leaf=min_samples_leaf, max_features=max_features)
  rf_model.fit(X_train, y_train)
  return rf_model
# [___CELL_SEPARATOR___]
rf_1 = train_rf(X_train, y_train)
rf_1.get_params()
# [___CELL_SEPARATOR___]
def get_preds(rf_model, X_train, X_test):
  train_preds = rf_model.predict(X_train)
  test_preds = rf_model.predict(X_test)
  return train_preds, test_preds
# [___CELL_SEPARATOR___]
trn_preds, tst_preds = get_preds(rf_1, X_train, X_test)
# [___CELL_SEPARATOR___]
def print_accuracy(y_train, y_test, train_preds, test_preds):
  train_acc = accuracy_score(y_train, train_preds)
  test_acc = accuracy_score(y_test, test_preds)
  print(train_acc)
  print(test_acc)
  return train_acc, test_acc
# [___CELL_SEPARATOR___]
trn_acc, tst_preds = print_accuracy(y_train, y_test, trn_preds, tst_preds)
# [___CELL_SEPARATOR___]
def fit_predict_rf(X_train, X_test, y_train, y_test, random_state=888, n_estimators=10, max_depth=None, min_samples_leaf=1, max_features='sqrt'):
  rf_model = train_rf(X_train, y_train, random_state=random_state, n_estimators=n_estimators, max_depth=max_depth, min_samples_leaf=min_samples_leaf, max_features=max_features)
  train_preds, test_preds = get_preds(rf_model, X_train, X_test)
  train_acc, test_acc = print_accuracy(y_train, y_test, train_preds, test_preds)
  return rf_model, train_preds, test_preds, train_acc, test_acc
# [___CELL_SEPARATOR___]
rf_model_1, trn_preds_1, tst_preds_1, trn_acc_1, tst_acc_1 = fit_predict_rf(X_train, X_test, y_train, y_test, random_state=888, n_estimators=20, max_depth=None, min_samples_leaf=1, max_features='sqrt')
# [___CELL_SEPARATOR___]
rf_model_2, trn_preds_2, tst_preds_2, trn_acc_2, tst_acc_2 = fit_predict_rf(X_train, X_test, y_train, y_test, random_state=888, n_estimators=50, max_depth=None, min_samples_leaf=1, max_features='sqrt')
# [___CELL_SEPARATOR___]
rf_model_3, trn_preds_3, tst_preds_3, trn_acc_3, tst_acc_3 = fit_predict_rf(X_train, X_test, y_train, y_test, random_state=888, n_estimators=50, max_depth=5, min_samples_leaf=1, max_features='sqrt')
# [___CELL_SEPARATOR___]
rf_model_4, trn_preds_4, tst_preds_4, trn_acc_4, tst_acc_4 = fit_predict_rf(X_train, X_test, y_train, y_test, random_state=888, n_estimators=50, max_depth=10, min_samples_leaf=1, max_features='sqrt')
# [___CELL_SEPARATOR___]
rf_model_5, trn_preds_5, tst_preds_5, trn_acc_5, tst_acc_5 = fit_predict_rf(X_train, X_test, y_train, y_test, random_state=888, n_estimators=50, max_depth=10, min_samples_leaf=10, max_features='sqrt')
# [___CELL_SEPARATOR___]
rf_model_6, trn_preds_6, tst_preds_6, trn_acc_6, tst_acc_6 = fit_predict_rf(X_train, X_test, y_train, y_test, random_state=888, n_estimators=50, max_depth=10, min_samples_leaf=50, max_features='sqrt')
# [___CELL_SEPARATOR___]
rf_model_7, trn_preds_7, tst_preds_7, trn_acc_7, tst_acc_7 = fit_predict_rf(X_train, X_test, y_train, y_test, random_state=888, n_estimators=50, max_depth=10, min_samples_leaf=50, max_features=0.5)
# [___CELL_SEPARATOR___]
rf_model_8, trn_preds_8, tst_preds_8, trn_acc_8, tst_acc_8 = fit_predict_rf(X_train, X_test, y_train, y_test, random_state=888, n_estimators=50, max_depth=10, min_samples_leaf=50, max_features=0.3)