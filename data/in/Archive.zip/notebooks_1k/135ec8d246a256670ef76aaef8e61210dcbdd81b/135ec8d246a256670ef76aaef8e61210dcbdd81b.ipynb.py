import warnings
warnings.filterwarnings('ignore')


required_modules = ['os', 'sys', 'shutil', 'warnings', 'fnmatch', 'datetime', 'logging',\
                    're', 'requests', 'lxml', 'glob', 'tempfile', 'configparser',\
                    'fileinput', 'subprocess', 'numpy', 'netCDF4', 'xarray', 'matplotlib',\
                    'cartopy','math','pandas','shapely']

optional_modules = ['plotly','scipy','rasterio','earthpy','sklearn']

missing_module_flag = False

for module in required_modules:
    cmd='import ' + module
    try:
        exec(cmd)
    except:
        missing_module_flag = True
        print('Required module ' + module + ' not installed')

for module in optional_modules:
    cmd='import ' + module
    try:
        exec(cmd)
    except:
        missing_module_flag = True
        print('Optional module ' + module + ' not installed')

if missing_module_flag:
    print('------------------------------------------------------')
    print('To install a package, please run the following in your conda prompt:')
    print(' ')    
    print('conda install <replace-with-missing-module-name>')
    print(' ')    
    print(' -------- or --------')
    print(' ')
    print('conda install -c conda-forge <replace-with-missing-module-name>')
    print('------------------------------------------------------')
else:
    print('------------------------------------------------------')
    print('Everything required is installed - you are good to go!')  
    print('------------------------------------------------------')
# [___CELL_SEPARATOR___]
