#导入requests库
import requests
# [___CELL_SEPARATOR___]
# 访问httpbin，httpbin返回了所有的请求信息。
r = requests.get('http://httpbin.org/get')
print(r.text)
# [___CELL_SEPARATOR___]
#输出状态码
r.status_code
# [___CELL_SEPARATOR___]
r = requests.get('http://www.weather.com.cn/data/sk/101210701.html')
print(r.text)
# [___CELL_SEPARATOR___]
r.encoding="uft-8"
print(r.text)
# [___CELL_SEPARATOR___]
j=r.json()
j
# [___CELL_SEPARATOR___]
print(j['weatherinfo']['city'])
print(j['weatherinfo']['temp'])
# [___CELL_SEPARATOR___]
payload = {'key1': 'value1', 'key2': 'value2'}
r = requests.get("http://httpbin.org/get", params=payload)
# [___CELL_SEPARATOR___]
print(r.url)
# [___CELL_SEPARATOR___]
payload = {'key1': 'value1', 'key2': ['value2', 'value3']}
r = requests.get('http://httpbin.org/get', params=payload)
print(r.url)
# [___CELL_SEPARATOR___]
r = requests.get('http://www.baidu.com/s', params = {'wd':'温州中学','pn':'1'})
print(r.text)
# [___CELL_SEPARATOR___]
#POST请求
r = requests.post('http://httpbin.org/post', data = {'key':'value'})
print(r.text)
# [___CELL_SEPARATOR___]
payload = {'key1': 'value1', 'key2': 'value2'}
r = requests.post('http://httpbin.org/post', data=payload)
print(r.text)
# [___CELL_SEPARATOR___]
headers = {
    'User-Agent':'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) '
                 'Chrome/72.0.3626.121 Safari/537.36'
}
r = requests.get('https://www.zhihu.com/explore',headers=headers)
print(r.text)
# [___CELL_SEPARATOR___]
# 保存虚谷号的logo信息
r = requests.get("http://www.vvboard.com.cn/templets/default/images/logo.png")
type(r.content)
# [___CELL_SEPARATOR___]
#另存为 vvboard.png
with open("vvboard.png", "wb") as f:
    f.write(r.content)
# [___CELL_SEPARATOR___]
r = requests.get("http://www.zhihu.com",timeout=5)
# [___CELL_SEPARATOR___]
