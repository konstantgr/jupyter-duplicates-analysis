cd /content/drive/My Drive/Dava with ML
# [___CELL_SEPARATOR___]
!unzip heart-disease-uci.zip
# [___CELL_SEPARATOR___]
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
import sklearn.metrics as m
# [___CELL_SEPARATOR___]
ls
# [___CELL_SEPARATOR___]
dataset=pd.read_csv('heart.csv')
dataset
# [___CELL_SEPARATOR___]
dataset.isnull().values.any()
# [___CELL_SEPARATOR___]
plt.figure(figsize=(30,15))
sns.heatmap(dataset.corr(),annot=True)
plt.show()
# [___CELL_SEPARATOR___]
#dataset=dataset.drop('slope',axis=1)
# [___CELL_SEPARATOR___]
plt.figure(figsize=(30,15))
sns.heatmap(dataset.corr(),annot=True)
plt.show()
# [___CELL_SEPARATOR___]
dataset
# [___CELL_SEPARATOR___]
features=dataset.iloc[:,:-1]
labels=dataset.iloc[:,[-1]]
# [___CELL_SEPARATOR___]
features
# [___CELL_SEPARATOR___]
feature_train,feature_test,label_train,label_test=train_test_split(features,labels,test_size=0.2,random_state=42)
# [___CELL_SEPARATOR___]
model=LogisticRegression(max_iter=1000)
model.fit(feature_train,label_train)
# [___CELL_SEPARATOR___]
label_pred=model.predict(feature_test)
# [___CELL_SEPARATOR___]
m.accuracy_score(label_test,label_pred)
# [___CELL_SEPARATOR___]
label_pred
# [___CELL_SEPARATOR___]
label_test
# [___CELL_SEPARATOR___]
print(m.classification_report(label_test,label_pred))
# [___CELL_SEPARATOR___]
print(m.confusion_matrix(label_test,label_pred))
# [___CELL_SEPARATOR___]
from sklearn.model_selection import GridSearchCV
knn=KNeighborsClassifier()
param={'n_neighbors':list(np.arange(1,20))}

# [___CELL_SEPARATOR___]
model=GridSearchCV(knn,param_grid=param)
model.fit(feature_train,label_train)
# [___CELL_SEPARATOR___]
model.best_params_
# [___CELL_SEPARATOR___]
model=KNeighborsClassifier(n_neighbors=13)
model.fit(feature_train,label_train)
# [___CELL_SEPARATOR___]
label_pred=model.predict(feature_test)
# [___CELL_SEPARATOR___]
m.accuracy_score(label_test,label_pred)
# [___CELL_SEPARATOR___]
label_pred_train=model.predict(feature_train)
# [___CELL_SEPARATOR___]
m.accuracy_score(label_train,label_pred_train)
# [___CELL_SEPARATOR___]
print(m.classification_report(label_test,label_pred))
# [___CELL_SEPARATOR___]
print(m.confusion_matrix(label_test,label_pred))
# [___CELL_SEPARATOR___]
label_pred
# [___CELL_SEPARATOR___]
label_test
# [___CELL_SEPARATOR___]
from sklearn.model_selection import GridSearchCV
dt=DecisionTreeClassifier()
param={'max_depth':list(np.arange(1,20))}

# [___CELL_SEPARATOR___]
model=GridSearchCV(dt,param_grid=param)
model.fit(feature_train,label_train)
# [___CELL_SEPARATOR___]
model.best_params_
# [___CELL_SEPARATOR___]
model=DecisionTreeClassifier(max_depth=8)
model.fit(feature_train,label_train)
# [___CELL_SEPARATOR___]
label_pred=model.predict(feature_test)
# [___CELL_SEPARATOR___]
m.accuracy_score(label_test,label_pred)
# [___CELL_SEPARATOR___]
print(m.classification_report(label_test,label_pred))
# [___CELL_SEPARATOR___]
print(m.confusion_matrix(label_test,label_pred))
# [___CELL_SEPARATOR___]
label_pred
# [___CELL_SEPARATOR___]
label_test
# [___CELL_SEPARATOR___]
model=SVC(kernel='linear')
model.fit(feature_train,label_train)
# [___CELL_SEPARATOR___]
label_pred=model.predict(feature_test)
# [___CELL_SEPARATOR___]
m.accuracy_score(label_test,label_pred)
# [___CELL_SEPARATOR___]
print(m.classification_report(label_test,label_pred))
# [___CELL_SEPARATOR___]
print(m.confusion_matrix(label_test,label_pred))
# [___CELL_SEPARATOR___]
label_pred
# [___CELL_SEPARATOR___]
label_test
# [___CELL_SEPARATOR___]
from sklearn.model_selection import GridSearchCV
rfc=RandomForestClassifier()
param={'n_estimators':[10,20,30,40,50,60,70,80,90,100,110,120,130,140,150,160,170,180,190,200],'max_depth':list(np.arange(1,20))}

# [___CELL_SEPARATOR___]
model=GridSearchCV(rfc,param_grid=param)
model.fit(feature_train,label_train)
# [___CELL_SEPARATOR___]
model.best_params_
# [___CELL_SEPARATOR___]
model=model.best_estimator_
# [___CELL_SEPARATOR___]
label_pred=model.predict(feature_test)
# [___CELL_SEPARATOR___]
m.accuracy_score(label_test,label_pred)
# [___CELL_SEPARATOR___]
print(m.classification_report(label_test,label_pred))
# [___CELL_SEPARATOR___]
print(m.confusion_matrix(label_test,label_pred))
# [___CELL_SEPARATOR___]
label_pred
# [___CELL_SEPARATOR___]
label_test
# [___CELL_SEPARATOR___]
