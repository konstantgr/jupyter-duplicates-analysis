import numpy as np
from netCDF4 import Dataset
import holoviews as hv
from postladim import ParticleFile
hv.extension('bokeh')
# [___CELL_SEPARATOR___]
# Read bathymetry and land mask
with Dataset('../data/ocean_avg_0014.nc') as ncid:
    H = ncid.variables['h'][:, :]
    M = ncid.variables['mask_rho'][:, :]
jmax, imax = M.shape

# Select sea and land features
H = np.where(M > 0, H, np.nan)  # valid at sea
M = np.where(M < 1, M, np.nan)  # valid on land

# Make land image
ds_land = hv.Dataset((np.arange(imax), np.arange(jmax), M), ['x', 'y'], 'Land mask')
im_land = ds_land.to(hv.Image, kdims=['x', 'y'], group='land')

# Make bathymetry image
ds_bathy = hv.Dataset((np.arange(imax), np.arange(jmax), -np.log10(H)),
                      ['x', 'y'], 'Bathymetry')
im_bathy = ds_bathy.to(hv.Image, kdims=['x', 'y'])

background = im_bathy * im_land
# [___CELL_SEPARATOR___]
pf = ParticleFile('line.nc')

def pplot(timestep):
    """Scatter plot of particle distibution at a given time step"""
    X, Y = pf.position(timestep)
    return background * hv.Scatter((X, Y))
# [___CELL_SEPARATOR___]
%%opts Image (cmap='blues_r' alpha=0.7) 
%%opts Image.land (cmap=['#AABBAA'])    
%%opts Scatter (color='red')

pplot(0) + pplot(pf.num_times-1)  # Final particle distribution
# [___CELL_SEPARATOR___]
%%output size=150
%%opts Scatter (color='red')

dmap = hv.DynamicMap(pplot, kdims=['timestep'])
dmap.redim.range(timestep=(0, pf.num_times-1))
# [___CELL_SEPARATOR___]
