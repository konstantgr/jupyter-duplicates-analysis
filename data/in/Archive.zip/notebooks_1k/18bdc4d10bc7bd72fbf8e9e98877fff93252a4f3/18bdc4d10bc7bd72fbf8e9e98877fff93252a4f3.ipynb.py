import os

import numpy as np
np.random.seed(123)
print("NumPy:{}".format(np.__version__))

import matplotlib as mpl
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from matplotlib.pylab import rcParams
rcParams['figure.figsize']=15,10
print("Matplotlib:{}".format(mpl.__version__))

import tensorflow as tf
tf.set_random_seed(123)
print("TensorFlow:{}".format(tf.__version__))

from tensorflow.contrib import slim
# [___CELL_SEPARATOR___]
DATASETSLIB_HOME = os.path.expanduser('~/dl-ts/datasetslib')
import sys
if not DATASETSLIB_HOME in sys.path:
    sys.path.append(DATASETSLIB_HOME)
%reload_ext autoreload
%autoreload 2
import datasetslib

from datasetslib import util as dsu
datasetslib.datasets_root = os.path.join(os.path.expanduser('~'),'datasets')
models_root = os.path.join(os.path.expanduser('~'),'models')
# [___CELL_SEPARATOR___]
# load the inception v3 model
model_name='inception_v3'
model_url='http://download.tensorflow.org/models/'
model_files=['inception_v3_2016_08_28.tar.gz']
model_home=os.path.join(models_root,model_name)        
        
dsu.download_dataset(source_url=model_url,
                        source_files=model_files,
                        dest_dir = model_home,
                        force=False,
                        extract=True)
# [___CELL_SEPARATOR___]
# helper function

def disp(images,id2label=None,probs=None,n_top=5,scale=False):
    if scale:
        imgs = (images / 2.0) + 0.5
    else:
        imgs = images

    ids={}
    for j in range(len(images)):
        if scale:
            plt.figure(figsize=(5,5))
            plt.imshow(imgs[j])
        else:
            plt.imshow(imgs[j].astype(np.uint8) )
        plt.show()
        if probs is not None:
            ids[j] = [i[0] for i in sorted(enumerate(-probs[j]), key=lambda x:x[1])]
            for k in range(n_top):
                id = ids[j][k]
                print('Probability {0:1.2f}% of [{1:}]'
                      .format(100*probs[j,id],id2label[id]))
# [___CELL_SEPARATOR___]
# Load the dataset
from datasetslib.coco import coco_animals

coco = coco_animals()
x_train_files, y_train, x_val_files, x_val = coco.load_data()
x_test = [x_val_files[25*x] for x in range(8)]
images_test=np.array([coco.preprocess_for_inception(x) for x in x_test])
# [___CELL_SEPARATOR___]
images=np.array([mpimg.imread(x) for x in x_test])

disp(images)
# [___CELL_SEPARATOR___]
print([x.shape for x in images])
# [___CELL_SEPARATOR___]
print(images_test.shape)
# [___CELL_SEPARATOR___]
disp(images_test)
# [___CELL_SEPARATOR___]
disp(images_test,scale=True)
# [___CELL_SEPARATOR___]
### Load ImageNet dataset for labels
from datasetslib.imagenet import imageNet
inet = imageNet()
inet.load_data(n_classes=1001)
# [___CELL_SEPARATOR___]
### define common imports and variables
from tensorflow.contrib.slim.nets import inception
image_height=inception.inception_v3.default_image_size
image_width=inception.inception_v3.default_image_size
# [___CELL_SEPARATOR___]
tf.reset_default_graph()
# [___CELL_SEPARATOR___]
x_p = tf.placeholder(shape=(None,image_height, image_width,3),
                     dtype=tf.float32,
                     name='x_p'
                    )
print(x_p)
# [___CELL_SEPARATOR___]
with slim.arg_scope(inception.inception_v3_arg_scope()):
    logits,_ = inception.inception_v3(x_p,
                                      num_classes=inet.n_classes,
                                      is_training=False
                                     )
probabilities = tf.nn.softmax(logits)

init = slim.assign_from_checkpoint_fn(
        os.path.join(model_home, '{}.ckpt'.format(model_name)),
        slim.get_variables_to_restore())
# [___CELL_SEPARATOR___]
with tf.Session() as tfs:
    init(tfs)
    probs = tfs.run([probabilities],feed_dict={x_p:images_test})
    probs=probs[0]
# [___CELL_SEPARATOR___]
disp(images_test,id2label=inet.id2label,probs=probs,scale=True)
# [___CELL_SEPARATOR___]
tf.reset_default_graph()
# [___CELL_SEPARATOR___]
def tf_preprocess(filelist):
    images=[]
    for filename in filelist:
        image_string = tf.read_file(filename)
        image_decoded = tf.image.decode_jpeg(image_string, channels=3)
        image_float = tf.cast(image_decoded, tf.float32)
        resize_fn = tf.image.resize_image_with_crop_or_pad
        image_resized = resize_fn(image_float, 
                                  image_height, 
                                  image_width
                                 )
        image =  ((image_resized / 255.0) - 0.5) * 2.0
        images.append(image)
        
    images = tf.stack(images)
    return images
# [___CELL_SEPARATOR___]
images=tf_preprocess([x for x in x_test])
print(images)
# [___CELL_SEPARATOR___]
with slim.arg_scope(inception.inception_v3_arg_scope()):
    logits,_ = inception.inception_v3(images,
                                      num_classes=inet.n_classes,
                                      is_training=False
                                     )
probabilities = tf.nn.softmax(logits)

init = slim.assign_from_checkpoint_fn(
        os.path.join(model_home, '{}.ckpt'.format(model_name)),
        slim.get_variables_to_restore())
# [___CELL_SEPARATOR___]
with tf.Session() as tfs:
    init(tfs)
    np_images,probs = tfs.run([images,probabilities])
# [___CELL_SEPARATOR___]
disp(np_images,id2label=inet.id2label,probs=probs,scale=True)
# [___CELL_SEPARATOR___]
tf.reset_default_graph()
# [___CELL_SEPARATOR___]
is_training = tf.placeholder(tf.bool,name='is_training')
x_p = tf.placeholder(shape=(None,
                            image_height, 
                            image_width,
                            3
                           ),
                     dtype=tf.float32,
                     name='x_p')
y_p = tf.placeholder(shape=(None,coco.n_classes),
                     dtype=tf.int32,
                     name='y_p')
# [___CELL_SEPARATOR___]
with slim.arg_scope(inception.inception_v3_arg_scope()):
    logits,_ = inception.inception_v3(x_p,
                                      num_classes=coco.n_classes,
                                      is_training=True
                                     )
probabilities = tf.nn.softmax(logits)
    
# restore except last layer
checkpoint_exclude_scopes=["InceptionV3/Logits", "InceptionV3/AuxLogits"]
exclusions = [scope.strip() for scope in checkpoint_exclude_scopes]

variables_to_restore = []
for var in slim.get_model_variables():
    excluded = False
    for exclusion in exclusions:
        if var.op.name.startswith(exclusion):
            excluded = True
            break
    if not excluded:
        variables_to_restore.append(var)

init_fn = slim.assign_from_checkpoint_fn(
    os.path.join(model_home, '{}.ckpt'.format(model_name)),
    variables_to_restore)
# [___CELL_SEPARATOR___]
tf.losses.softmax_cross_entropy(onehot_labels=y_p, logits=logits)
loss = tf.losses.get_total_loss()
# [___CELL_SEPARATOR___]
learning_rate = 0.001
optimizer = tf.train.GradientDescentOptimizer(learning_rate = learning_rate)
train_op = optimizer.minimize(loss)    
# [___CELL_SEPARATOR___]
#y_pred = tf.to_int32(tf.argmax(logits, 1))
#n_correct_pred = tf.equal(y_pred, y_p)
#accuracy = tf.reduce_mean(tf.cast(n_correct_pred, tf.float32))
# [___CELL_SEPARATOR___]
n_epochs=10
coco.y_onehot = True
coco.batch_size = 32
coco.batch_shuffle = True
total_images = len(x_train_files)
n_batches = total_images // coco.batch_size

with tf.Session() as tfs:
        tfs.run(tf.global_variables_initializer())
        init_fn(tfs)  
        
        for epoch in range(n_epochs):
            print('Starting epoch ',epoch)
            coco.reset_index()
            epoch_accuracy=0
            epoch_loss=0
            for batch in range(n_batches):
                try:
                    x_batch, y_batch = coco.next_batch()
                    images=np.array([coco.preprocess_for_inception(x) for x in x_batch])
                    
                    feed_dict = {x_p: images,y_p: y_batch,is_training: True}
                    batch_loss,_ = tfs.run([loss,train_op], feed_dict = feed_dict)

                    #feed_dict={x_p: images, y_p: y_onehot,is_training: False}
                    #batch_accuracy = tfs.run(accuracy,feed_dict=feed_dict)
                    epoch_loss += batch_loss 
                    #epoch_accuracy += batch_accuracy
                except Exception as ex:
                    print('error in epoch {} batch {}'.format(epoch,batch))
                    print(ex)
            #epoch_accuracy /= n_batches
            epoch_loss /= n_batches
            
            print('Train loss in epoch {}:{}'.format(epoch,epoch_loss))
            
        # now run the predictions
        feed_dict={x_p:images_test,is_training: False}
        probs = tfs.run([probabilities],feed_dict=feed_dict)
        probs=probs[0]
# [___CELL_SEPARATOR___]
disp(images_test,id2label=coco.id2label,probs=probs,scale=True)