%matplotlib inline
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sb
import pandas as pd
from sklearn import datasets
from utils import plot_prediction
# [___CELL_SEPARATOR___]
iris = pd.read_csv('./data/Iris.csv')
iris.head()
# [___CELL_SEPARATOR___]
sepalPlt = sb.FacetGrid(iris, hue="Species", size=6).map(plt.scatter, "SepalLengthCm", "SepalWidthCm")
plt.legend(loc='upper left');
# [___CELL_SEPARATOR___]
X = iris.iloc[:, 1:3]
Y = (iris['Species'] != 'Iris-setosa') * 1
# [___CELL_SEPARATOR___]
plt.figure(figsize=(10, 6))
plt.scatter(X[Y == 0].iloc[:, 0], X[Y == 0].iloc[:, 1], color='b', label='Iris-setosa')
plt.scatter(X[Y == 1].iloc[:, 0], X[Y == 1].iloc[:, 1], color='r', label='Others')
plt.xlabel('SepalLengthCm')
plt.ylabel('SepalWidthCm')
plt.legend()
# [___CELL_SEPARATOR___]
def linear_mult(X, w, b):
    return np.dot(w.T, X) + b
# [___CELL_SEPARATOR___]
def initialize_with_zeros(dim):
    """
    This function creates a vector of zeros of shape (dim, 1) for w and initializes b to 0.
    
    Argument:
    dim -- size of the w vector we want (or number of parameters in this case)
    
    Returns:
    w -- initialized vector of shape (dim, 1)
    b -- initialized scalar (corresponds to the bias)
    """
    
    w = np.zeros((dim,1))
    b = 0

    assert(w.shape == (dim, 1))
    assert(isinstance(b, float) or isinstance(b, int))
    
    return w, b
# [___CELL_SEPARATOR___]
def sigmoid(z):
    return 1 / (1 + np.exp(-z))
# [___CELL_SEPARATOR___]
def cost_function(y, a):
    return -np.mean(y*np.log(a) + (1-y)*np.log(1-a))
# [___CELL_SEPARATOR___]
def forward_propagate(w, b, X, Y):
    
    m = X.shape[1]
    
    Z = linear_mult(X, w, b)
    A = sigmoid(Z)                                 
    cost = cost_function(Y, A)  
    cost = np.squeeze(cost)

    assert(cost.shape == ())
    
    back_require = {
        'A': A
    }
    
    return back_require, cost
# [___CELL_SEPARATOR___]
def backward_propagate(w, b, X, Y, back_require):
    
    m = X.shape[1]
    
    A = back_require['A']
    
    dw = (1/m) * np.dot(X,(A-Y).T)
    db = (1/m) * np.sum(A - Y)
    
    assert(dw.shape == w.shape)
    assert(db.dtype == float)
    
    grads = {"dw": dw,
             "db": db}
    
    return grads
# [___CELL_SEPARATOR___]
def propagate(w, b, X, Y):
    """
    Implement the cost function and its gradient for the propagation explained above

    Arguments:
    w -- weights, a numpy array of size (num_px * num_px * 3, 1)
    b -- bias, a scalar
    X -- data of size (num_px * num_px * 3, number of examples)
    Y -- true "label" vector (containing 0 if non-cat, 1 if cat) of size (1, number of examples)

    Return:
    cost -- negative log-likelihood cost for logistic regression
    dw -- gradient of the loss with respect to w, thus same shape as w
    db -- gradient of the loss with respect to b, thus same shape as b
    
    Tips:
    - Write your code step by step for the propagation. np.log(), np.dot()
    """
    
    # FORWARD PROPAGATION
    back_require, cost = forward_propagate(w, b, X, Y)
    
    # BACKWARD PROPAGATION
    grads = backward_propagate(w, b, X, Y, back_require)

    
    return grads, cost
# [___CELL_SEPARATOR___]
# GRADED FUNCTION: optimize

def optimize(w, b, X, Y, num_iterations, learning_rate, print_cost = False):
    """
    This function optimizes w and b by running a gradient descent algorithm
    
    Arguments:
    w -- weights, a numpy array of size (num_px * num_px * 3, 1)
    b -- bias, a scalar
    X -- data of shape (num_px * num_px * 3, number of examples)
    Y -- true "label" vector (containing 0 if non-cat, 1 if cat), of shape (1, number of examples)
    num_iterations -- number of iterations of the optimization loop
    learning_rate -- learning rate of the gradient descent update rule
    print_cost -- True to print the loss every 100 steps
    
    Returns:
    params -- dictionary containing the weights w and bias b
    grads -- dictionary containing the gradients of the weights and bias with respect to the cost function
    costs -- list of all the costs computed during the optimization, this will be used to plot the learning curve.
    
    Tips:
    You basically need to write down two steps and iterate through them:
        1) Calculate the cost and the gradient for the current parameters. Use propagate().
        2) Update the parameters using gradient descent rule for w and b.
    """
    
    costs = []
    
    for i in range(num_iterations):
        
        
        grads, cost = propagate(w,b,X,Y)
        
        dw = grads["dw"]
        db = grads["db"]
        

        w -= learning_rate*dw
        b -= learning_rate*db
        
        # Record the costs
        if i % 100 == 0:
            costs.append(cost)
        
        # Print the cost every 100 training iterations
        if print_cost and i % 100 == 0:
            print ("Cost after iteration %i: %f" %(i, cost))
    
    params = {"w": w,
              "b": b}
    
    grads = {"dw": dw,
             "db": db}
    
    return params, grads, costs
# [___CELL_SEPARATOR___]
X_t, Y_t = np.array(X.T), np.array(Y.T)
w, b = initialize_with_zeros(2)
params, grads, costs = optimize(w, b, X_t, Y_t, num_iterations= 5000, learning_rate = 0.009, print_cost = False)
# [___CELL_SEPARATOR___]
plt.plot(range(len(costs)),costs)
plt.xlabel('Iterations')
plt.ylabel('Cost(loss) value')
# [___CELL_SEPARATOR___]
def predict(w, b, X):
    '''
    Predict whether the label is 0 or 1 using learned logistic regression parameters (w, b)
    
    Arguments:
    w -- weights, a numpy array of size (num_px * num_px * 3, 1)
    b -- bias, a scalar
    X -- data of size (num_px * num_px * 3, number of examples)
    
    Returns:
    Y_prediction -- a numpy array (vector) containing all predictions (0/1) for the examples in X
    '''
    
    m = X.shape[1]
    Y_prediction = np.zeros((1,m))
    
    Z = linear_mult(X, w, b)
    A = sigmoid(Z)
    
    for i in range(m):
        
        Y_prediction[0][i] = 1 if A[0][i] > .5 else 0
    
    assert(Y_prediction.shape == (1, m))
    
    return Y_prediction
# [___CELL_SEPARATOR___]
preds = predict(params['w'], params['b'], X_t)
print('Accuracy on training set: %{}'.format((preds[0] == Y).mean()*100))
# [___CELL_SEPARATOR___]
plot_prediction(X, Y, predict, params)