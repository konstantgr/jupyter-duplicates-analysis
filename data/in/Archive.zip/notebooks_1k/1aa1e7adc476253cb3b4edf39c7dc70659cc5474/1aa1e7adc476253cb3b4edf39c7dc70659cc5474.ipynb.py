import numpy as np
import pandas as pd
import linearsolve as ls
import matplotlib.pyplot as plt
plt.style.use('classic')
%matplotlib inline
# [___CELL_SEPARATOR___]
# Read business_cycle_data_actual_trend.csv into a Pandas DataFrame with the first column set as the index and parse_dates=True


# Print the last five rows of the data

# [___CELL_SEPARATOR___]
# Construct plot


# Place legend to right of figure. PROVIDED
plt.legend(loc='center left', bbox_to_anchor=(1, 0.5))
# [___CELL_SEPARATOR___]
# Construct plot


# Place legend to right of figure. PROVIDED
plt.legend(loc='center left', bbox_to_anchor=(1, 0.5))
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
# Create a variable called 'parameters' that stores the model parameter values in a Pandas Series


# Print the model's parameters

# [___CELL_SEPARATOR___]
# Create variable called 'varNames' that stores the variable names in a list with state variables ordered first


# Create variable called 'shockNames' that stores an exogenous shock name for each state variable.


# Define a function that evaluates the equilibrium conditions of the model solved for zero. PROVIDED
def equilibrium_equations(variables_forward,variables_current,parameters):

    # Parameters. PROVIDED
    p = parameters

    # Current variables. PROVIDED
    cur = variables_current

    # Forward variables. PROVIDED
    fwd = variables_forward

    # IS equation


    # Fisher_equation


    # Monetary policy


    # Phillips curve


    # Demand process


    # Monetary policy process


    # Inflation process


    # Stack equilibrium conditions into a numpy array


# Initialize the model into a variable named 'nk_model'



# [___CELL_SEPARATOR___]
# Compute the steady state numerically using .compute_ss() method of nk_model


# Print the computed steady state

# [___CELL_SEPARATOR___]
# Find the log-linear approximation around the non-stochastic steady state and solve using .approximate_and_solve() method of nk_model
# set argumement 'loglinear' to False



# [___CELL_SEPARATOR___]
# Compute impulse responses


# Print the first 10 rows of the computed impulse responses to the monetary policy shock

# [___CELL_SEPARATOR___]
# Create figure. PROVIDED
fig = plt.figure(figsize=(12,8))

# Create upper-left axis. PROVIDED
ax1 = fig.add_subplot(2,2,1)


# Create upper-right axis. PROVIDED
ax2 = fig.add_subplot(2,2,2)


# Create lower-left axis. PROVIDED
ax3 = fig.add_subplot(2,2,3)


# Create lower-right axis. PROVIDED
ax4 = fig.add_subplot(2,2,4)


