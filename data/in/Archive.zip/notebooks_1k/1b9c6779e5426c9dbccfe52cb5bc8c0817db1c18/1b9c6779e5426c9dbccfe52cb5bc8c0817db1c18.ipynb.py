Using Stochastic Gradient Descent for classification
# [___CELL_SEPARATOR___]
from sklearn import datasets
X, y = datasets.make_classification(n_samples = 500)
# [___CELL_SEPARATOR___]
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X,y,stratify=y)


from sklearn import linear_model
sgd_clf = linear_model.SGDClassifier()
#As usual, we'll fit the model:
sgd_clf.fit(X_train, y_train)
# [___CELL_SEPARATOR___]
from sklearn.metrics import accuracy_score
accuracy_score(y_test,sgd_clf.predict(X_test))