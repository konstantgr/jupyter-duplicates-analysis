# to run in google colab
import sys
if 'google.colab' in sys.modules:
    import subprocess
    subprocess.call('apt-get install subversion'.split())
    subprocess.call('svn export https://github.com/YoniChechik/AI_is_Math/trunk/c_02a_basic_image_processing/grass.jpg'.split())


# [___CELL_SEPARATOR___]
# Adopted from: https://opencv-python-tutroals.readthedocs.io/en/latest/py_tutorials/py_imgproc/py_colorspaces/py_colorspaces.html

import numpy as np
import cv2
import matplotlib.pyplot as plt 

figsize = (10,10)


# [___CELL_SEPARATOR___]
im = cv2.imread("grass.jpg")

plt.figure(figsize=figsize)
plt.imshow(cv2.cvtColor(im,cv2.COLOR_BGR2RGB))
plt.title("original image")

# [___CELL_SEPARATOR___]
rgb_green = np.uint8([[[0,255,0 ]]])
hsv_green = cv2.cvtColor(rgb_green,cv2.COLOR_RGB2HSV)[0,0,:]
print(hsv_green)


# [___CELL_SEPARATOR___]
# Convert BGR to HSV
hsv = cv2.cvtColor(im, cv2.COLOR_BGR2HSV)

# define range of hue and intensity 
lower_blue = hsv_green-np.array([70,200,200])
upper_blue = hsv_green+np.array([30,0,0])

# Threshold the HSV image
mask = cv2.inRange(hsv, lower_blue, upper_blue)

# Bitwise-AND mask and original image
res = cv2.bitwise_and(im,im, mask= mask)


plt.figure(figsize=figsize)
plt.imshow(mask)
plt.title("resulted mask")
plt.figure(figsize=figsize)
plt.imshow(cv2.cvtColor(res,cv2.COLOR_BGR2RGB))
plt.title("output image")