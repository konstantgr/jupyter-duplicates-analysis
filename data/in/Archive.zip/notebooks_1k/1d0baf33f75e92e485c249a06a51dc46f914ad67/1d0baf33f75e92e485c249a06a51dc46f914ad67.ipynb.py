# import libraries
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
# [___CELL_SEPARATOR___]
# data doesn't have headers, so let's create headers
_headers = ['buying', 'maint', 'doors', 'persons', 'lug_boot', 'safety', 'car']
# read in cars dataset
df = pd.read_csv('https://raw.githubusercontent.com/PacktWorkshops/The-Data-Science-Workshop/master/Chapter06/Dataset/car.data', names=_headers, index_col=None)
df.head()

# target column is 'car'
# [___CELL_SEPARATOR___]
# encode categorical variables
_df = pd.get_dummies(df, columns=['buying', 'maint', 'doors', 'persons', 'lug_boot', 'safety'])
_df.head()
# [___CELL_SEPARATOR___]
# target column is 'car'

features = _df.drop(['car'], axis=1).values
labels = _df[['car']].values

# split 80% for training and 20% into an evaluation set
X_train, X_eval, y_train, y_eval = train_test_split(features, labels, test_size=0.3, random_state=0)

# further split the evaluation set into validation and test sets of 10% each
X_val, X_test, y_val, y_test = train_test_split(X_eval, y_eval, test_size=0.5, random_state=0)
# [___CELL_SEPARATOR___]
# train a Logistic Regression model
model = LogisticRegression()
model.fit(X_train, y_train)
# [___CELL_SEPARATOR___]
# make predictions for the validation dataset
y_pred = model.predict(X_val)
y_pred[0:9]
# [___CELL_SEPARATOR___]
