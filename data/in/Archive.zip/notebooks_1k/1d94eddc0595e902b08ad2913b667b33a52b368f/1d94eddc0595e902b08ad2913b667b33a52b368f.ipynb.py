import toytree       # a tree plotting library
import toyplot       # a general plotting library
import numpy as np   # numerical library
# [___CELL_SEPARATOR___]
print(toytree.__version__)
print(toyplot.__version__)
print(np.__version__)
# [___CELL_SEPARATOR___]
# load a toytree from a newick string at a URL
tre = toytree.tree("https://eaton-lab.org/data/Cyathophora.tre")
# [___CELL_SEPARATOR___]
# root and draw the tree (more details on this coming up...)
rtre = tre.root(wildcard="prz")
rtre.draw(tip_labels_align=True);
# [___CELL_SEPARATOR___]
# newick with edge-lengths & support values
newick = "((a:1,b:1)90:3,(c:3,(d:1, e:1)100:2)100:1)100;"
tre0 = toytree.tree(newick, tree_format=0)

# newick with edge-lengths & string node-labels
newick = "((a:1,b:1)A:3,(c:3,(d:1, e:1)B:2)C:1)root;"
tre1 = toytree.tree(newick, tree_format=1)
# [___CELL_SEPARATOR___]
# parse an NHX format string with node supports and names
nhx = "((a:3[&&NHX:name=a:support=100],b:2[&&NHX:name=b:support=100]):4[&&NHX:name=ab:support=60],c:5[&&NHX:name=c:support=100]);"
ntre = toytree.tree(nhx)

# parse a mrbayes format file with NHX-like node and edge info
mb = "((a[&prob=100]:0.1[&length=0.1],b[&prob=100]:0.2[&length=0.2])[&prob=90]:0.4[&length=0.4],c[&prob=100]:0.6[&length=0.6]);"
mtre = toytree.tree(mb, tree_format=10)

# parse a NEXUS formatted file containing a tree of any supported format
nex = """
#NEXUS 
begin trees;
    translate;
           1       apple,
           2       blueberry,
           3       cantaloupe,
           4       durian,
           ;
    tree tree0 = [&U] ((1,2),(3,4));
end;
"""
xtre = toytree.tree(nex)
# [___CELL_SEPARATOR___]
rtre.ntips
# [___CELL_SEPARATOR___]
rtre.nnodes
# [___CELL_SEPARATOR___]
tre.is_rooted(), rtre.is_rooted()
# [___CELL_SEPARATOR___]
rtre.get_tip_labels()
# [___CELL_SEPARATOR___]
rtre.get_edges()
# [___CELL_SEPARATOR___]
# a TreeNode object is contained within every ToyTree at .tree
tre.treenode
# [___CELL_SEPARATOR___]
# a ToyTree object
toytree.tree("((a, b), c);")
# [___CELL_SEPARATOR___]
# a MultiTree object
toytree.mtree([tre, tre, tre])
# [___CELL_SEPARATOR___]
rtre.draw()
# [___CELL_SEPARATOR___]
# the semicolon hides the returned text of the Canvas and Cartesian objects
rtre.draw();
# [___CELL_SEPARATOR___]
# or, we can store them as variables (this allows more editing on them later)
canvas, axes, mark = rtre.draw()
# [___CELL_SEPARATOR___]
# drawing with pre-built tree_styles
rtre.draw(tree_style='n');  # normal-style
rtre.draw(tree_style='d');  # dark-style

# 'ts' is also a shortcut for tree_style
rtre.draw(ts='o');          # umlaut-style
# [___CELL_SEPARATOR___]
# define a style dictionary
mystyle = {
    "layout": 'd',
    "edge_type": 'p',
    "edge_style": {
        "stroke": toytree.colors[2],
        "stroke-width": 2.5,
    },
    "tip_labels_align": True, 
    "tip_labels_colors": toytree.colors[0],
    "tip_labels_style": {
        "font-size": "10px"
    },
    "node_labels": False,
    "node_sizes": 8,
    "node_colors": toytree.colors[2],
}
# [___CELL_SEPARATOR___]
# use your custom style dictionary in one or more tree drawings
rtre.draw(height=400, **mystyle);
# [___CELL_SEPARATOR___]
# hover over nodes to see pop-up elements
rtre.draw(height=350, node_hover=True, node_sizes=10, tip_labels_align=True);
# [___CELL_SEPARATOR___]
rtre.draw(node_labels='support', node_sizes=15);
# [___CELL_SEPARATOR___]
# You can do the same without printing the 'idx' label on nodes.
rtre.draw(
    node_labels=None,
    node_sizes=10,
    node_colors='grey'
);
# [___CELL_SEPARATOR___]
tre0.get_node_values("support", show_root=1, show_tips=1)
# [___CELL_SEPARATOR___]
tre0.get_node_values("support", show_root=1, show_tips=0)
# [___CELL_SEPARATOR___]
tre0.get_node_values("support", show_root=0, show_tips=0)
# [___CELL_SEPARATOR___]
# show support values 
tre0.draw(
    node_labels=tre0.get_node_values("support", 0, 0),
    node_sizes=20,
    );
# [___CELL_SEPARATOR___]
# show support values 
tre0.draw(
    node_labels=tre0.get_node_values("support", 1, 1),
    node_sizes=20,
    );
# [___CELL_SEPARATOR___]
# build a color list in node plot order with different values based on support
colors = [
    toytree.colors[0] if i==100 else toytree.colors[1] 
    for i in rtre.get_node_values('support', 1, 1)
]

# You can do the same without printing the 'idx' label on nodes.
rtre.draw(
    node_sizes=10,
    node_colors=colors
);
# [___CELL_SEPARATOR___]
# draw a plot and store the Canvas object to a variable
canvas, axes, mark = rtre.draw(width=400, height=300);
# [___CELL_SEPARATOR___]
# for sharing through web-links (or even email!) html is great!
toyplot.html.render(canvas, "/tmp/tree-plot.html")
# [___CELL_SEPARATOR___]
# for creating scientific figures SVG is often the most useful format
import toyplot.svg
toyplot.svg.render(canvas, "/tmp/tree-plot.svg")
# [___CELL_SEPARATOR___]
import toyplot.pdf
toyplot.pdf.render(canvas, "/tmp/tree-plot.pdf")
# [___CELL_SEPARATOR___]
# set dimensions of the canvas
canvas = toyplot.Canvas(width=700, height=250)

# dissect canvas into multiple cartesian areas (x1, x2, y1, y2)
ax0 = canvas.cartesian(bounds=('10%', '45%', '10%', '90%'))
ax1 = canvas.cartesian(bounds=('55%', '90%', '10%', '90%'))

# call draw with the 'axes' argument to pass it to a specific cartesian area
style = {
    "tip_labels_align": True,
    "tip_labels_style": {
        "font-size": "9px"
    },
}
rtre.draw(axes=ax0, **style);
rtre.draw(axes=ax1, tip_labels_colors='indigo', **style);

# hide the axes (e.g, ticks and splines)
ax0.show=False
ax1.show=False
# [___CELL_SEPARATOR___]
# store the returned Canvas and Axes objects
canvas, axes, makr = rtre.draw(
    width=300, 
    height=300, 
    tip_labels_align=True,
    tip_labels=False,
)

# show the axes coordinates
axes.show = True
axes.x.ticks.show = True
axes.y.ticks.show = True

# overlay a grid 
axes.hlines(np.arange(0, 13, 2), style={"stroke": "red", "stroke-dasharray": "2,4"})
axes.vlines(0, style={"stroke": "blue", "stroke-dasharray": "2,4"});
# [___CELL_SEPARATOR___]
# store the returned Canvas and Axes objects
canvas, axes, mark = rtre.draw(
    width=300, 
    height=300, 
    tip_labels=False, 
    tip_labels_align=True,
    layout='d',
)

# show the axes coordinates
axes.show = True
axes.x.ticks.show = True
axes.y.ticks.show = True

# overlay a grid 
axes.vlines(np.arange(0, 13, 2), style={"stroke": "red", "stroke-dasharray": "2,4"})
axes.hlines(0, style={"stroke": "blue", "stroke-dasharray": "2,4"});