import cv2
import numpy as np
img = cv2.imread('image0.jpg',1)
cv2.imshow('src',img)
imgInfo = img.shape
# 旧图片的info信息
height = imgInfo[0]
width = imgInfo[1]
deep = imgInfo[2]

# 新图片的info信息
newImgInfo = (height*2,width,deep)
# 创建空白模板
dst = np.zeros(newImgInfo,np.uint8)# uint8

for i in range(0,height):
    for j in range(0,width):
        # 绘制上半部分
        dst[i,j] = img[i,j]
        # 下半部分: x值不变, y值变为 = 2*h - y -1
        dst[height*2-i-1,j] = img[i,j]
# 添加分割线
for i in range(0,width):
    dst[height,i] = (0,0,255)# BGR
cv2.imshow('dst',dst)
cv2.waitKey(0)