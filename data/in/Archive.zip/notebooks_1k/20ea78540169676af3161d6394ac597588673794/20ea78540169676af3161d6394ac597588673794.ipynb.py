import os
import pandas as pd
import numpy as np
import json

from ftk import TimeSeriesDataFrame, ForecastDataFrame
from ftk.operationalization import ScoreContext
from ftk.transforms import TimeSeriesImputer, TimeIndexFeaturizer, DropColumns, GrainIndexFeaturizer 
from ftk.models import RegressionForecaster
from sklearn.ensemble import RandomForestRegressor
from ftk.pipeline import AzureMLForecastPipeline
from ftk.data import load_dominicks_oj_dataset
# [___CELL_SEPARATOR___]
train_tsdf, test_tsdf = load_dominicks_oj_dataset()
# Use a TimeSeriesImputer to linearly interpolate missing values
imputer = TimeSeriesImputer(input_column='Quantity', 
                            option='interpolate',
                            method='linear',
                            freq='W-WED')

train_imputed_tsdf = imputer.transform(train_tsdf)
# [___CELL_SEPARATOR___]
oj_series_freq = 'W-WED'
oj_series_seasonality = 52

# DropColumns: Drop columns that should not be included for modeling. `logmove` is the log of the number of 
# units sold, so providing this number would be cheating. `WeekFirstDay` would be 
# redundant since we already have a feature for the last day of the week.
columns_to_drop = ['logmove', 'WeekFirstDay', 'week']
column_dropper = DropColumns(columns_to_drop)
# TimeSeriesImputer: Fill missing values in the features
# First, we need to create a dictionary with key as column names and value as values used to fill missing 
# values for that column. We are going to use the mean to fill missing values for each column.
columns_with_missing_values = train_imputed_tsdf.columns[pd.DataFrame(train_imputed_tsdf).isnull().any()].tolist()
columns_with_missing_values = [c for c in columns_with_missing_values if c not in columns_to_drop]
missing_value_imputation_dictionary = {}
for c in columns_with_missing_values:
    missing_value_imputation_dictionary[c] = train_imputed_tsdf[c].mean()
fillna_imputer = TimeSeriesImputer(option='fillna', 
                                   input_column=columns_with_missing_values,
                                   value=missing_value_imputation_dictionary)
# TimeIndexFeaturizer: extract temporal features from timestamps
time_index_featurizer = TimeIndexFeaturizer(correlation_cutoff=0.1, overwrite_columns=True)

# GrainIndexFeaturizer: create indicator variables for stores and brands
grain_featurizer = GrainIndexFeaturizer(overwrite_columns=True, ts_frequency=oj_series_freq)

random_forest_model_deploy = RegressionForecaster(estimator=RandomForestRegressor(), make_grain_features=False)

pipeline_deploy = AzureMLForecastPipeline([('drop_columns', column_dropper), 
                                           ('fillna_imputer', fillna_imputer),
                                           ('time_index_featurizer', time_index_featurizer),
                                           ('random_forest_estimator', random_forest_model_deploy)
                                          ])
# [___CELL_SEPARATOR___]
import pickle
with open('pipeline.pkl', 'wb') as f:
    pickle.dump(pipeline_deploy, f)
# [___CELL_SEPARATOR___]
%%writefile conda_dependencies.yml
################################################################################
#
# Create Azure ML Forecasting Toolkit Conda environments on Linux platforms. 
# This yml is used specifically in creating containers on ACR for use 
# AML deployments.
#
################################################################################

name: azuremlftk_nov2018
dependencies:
  # AzureML FTK dependencies
  - pyodbc
  - statsmodels
  - pandas
  - scikit-learn==0.19.1
  - tensorflow
  - keras
  - distributed==1.23.1

  - pip:
    # AML logging
    - https://azuremldownloads.azureedge.net/history-packages/preview/azureml.primitives-1.0.11.491405-py3-none-any.whl
    - https://azuremldownloads.azureedge.net/history-packages/preview/azureml.logging-1.0.81-py3-none-any.whl
    
    #azure ml
    - azureml-sdk[automl]
    
    #Dependencies from other AML packages
    - https://azuremlftkrelease.blob.core.windows.net/azpkgdaily/azpkgcore-1.0.18309.1b1-py3-none-any.whl
    - https://azuremlftkrelease.blob.core.windows.net/azpkgdaily/azpkgsql-1.0.18309.1b1-py3-none-any.whl

    # AMLPF package  
    - https://azuremlftkrelease.blob.core.windows.net/dailyrelease/azuremlftk-0.1.18305.1a1-py3-none-any.whl

# [___CELL_SEPARATOR___]
# Check core SDK version number
import azureml.core

print("SDK version:", azureml.core.VERSION)
# [___CELL_SEPARATOR___]
%%writefile workspace_aci.json
{
    "subscription_id": "<subscription id>",
    "resource_group": "<resource group>",
    "workspace_name": "<workspace name>",
    "location": "<location>"
}
# [___CELL_SEPARATOR___]
from azureml.core import Workspace
from azureml.exceptions import ProjectSystemException
ws = None
try:
    #Try to get the workspace if it exists.
    ws = Workspace.from_config("workspace_aci.json")
except ProjectSystemException:
    #If the workspace was not found, create it.
    with open("workspace_aci.json", 'r') as config:
        ws_data = json.load(config)
    ws = Workspace.create(name = ws_data["workspace_name"],
                          subscription_id = ws_data["subscription_id"],
                          resource_group = ws_data["resource_group"],
                          location = ws_data["location"])
print(ws.name, ws.resource_group, ws.location, ws.subscription_id, sep = '\n')
# [___CELL_SEPARATOR___]
from azureml.core.model import Model

model = Model.register(model_path = "pipeline.pkl",
                       model_name = "aciforecast",
                       workspace = ws)
# [___CELL_SEPARATOR___]
regression_models = Model.list(ws)
for m in regression_models:
    print("Name:", m.name,"\tVersion:", m.version, "\tDescription:", m.description, m.tags)
# [___CELL_SEPARATOR___]
print(model.name, model.description, model.version, sep = '\t')
# [___CELL_SEPARATOR___]
%%writefile score.py
import pickle
import json

from ftk.operationalization.score_script_helper import run_impl
from azureml.core.model import Model

def init():
    #init method will be executed once at start of the docker - load the model
    global pipeline
    #Get the model path.
    pipeline_pickle_file = Model.get_model_path("aciforecast")
    #Load the model.
    with open(pipeline_pickle_file, 'rb') as f:
        pipeline = pickle.load(f)

#Run method is executed once per call.
def run(input_data):
    #The JSON encoded input_data will be interpreted as a TimeSeriedData frame and will 
    #be used for forecasting.
    #Return the JSON encoded data frame with forecast.
    return run_impl(input_data, pipeline=pipeline)
# [___CELL_SEPARATOR___]
from azureml.core.image import Image, ContainerImage

image_config = ContainerImage.image_configuration(runtime= "python",
                                 execution_script="score.py",
                                 conda_file="conda_dependencies.yml")

image = Image.create(name = "ftkimage1",
                     # this is the model object 
                     models = [model],
                     image_config = image_config, 
                     workspace = ws)
# [___CELL_SEPARATOR___]
image.wait_for_creation(show_output = True)
# [___CELL_SEPARATOR___]
for i in Image.list(workspace = ws):
    print('{}(v.{} [{}]) stored at {} with build log {}'.format(i.name, i.version, i.creation_state, i.image_location, i.image_build_log_uri))
# [___CELL_SEPARATOR___]
from azureml.core.webservice import AciWebservice

aciconfig = AciWebservice.deploy_configuration(cpu_cores = 1, 
                                               memory_gb = 1)
# [___CELL_SEPARATOR___]
from azureml.core.webservice import Webservice

aci_service_name = 'ftk-service-1'
print(aci_service_name)
aci_service = Webservice.deploy_from_image(deployment_config = aciconfig,
                                           image = image,
                                           name = aci_service_name,
                                           workspace = ws)
aci_service.wait_for_deployment(True)
print(aci_service.state)
# [___CELL_SEPARATOR___]
print(aci_service.get_logs())
# [___CELL_SEPARATOR___]
imputer = TimeSeriesImputer(input_column='Quantity', 
                            option='interpolate',
                            method='linear',
                            freq='W-WED')    
train_imputed_tsdf = imputer.transform(train_tsdf)
validate_ts = train_imputed_tsdf.assign(PointForecast=0.0, DistributionForecast=np.nan)
validate_fdf = ForecastDataFrame(validate_ts, pred_point='PointForecast', pred_dist='DistributionForecast')
sc_validate = ScoreContext(input_training_data_tsdf=train_imputed_tsdf,
                           input_scoring_data_fcdf=validate_fdf, 
                           pipeline_execution_type='train_predict')
# [___CELL_SEPARATOR___]
train_imputed_tsdf.head()
# [___CELL_SEPARATOR___]
validate_fdf.head()
# [___CELL_SEPARATOR___]
json_direct =aci_service.run(sc_validate.to_json())
fcdf_direct=ForecastDataFrame.construct_from_json(json_direct)
fcdf_direct.head()
# [___CELL_SEPARATOR___]
aci_service.delete()
# [___CELL_SEPARATOR___]
[svc.name for svc in Webservice.list(ws)]
# [___CELL_SEPARATOR___]
from azpkgamlsdk.deployment.utils_environment import delete_resource_group

delete_resource_group(ws.resource_group, ws.subscription_id)