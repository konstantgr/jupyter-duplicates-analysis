%pylab inline
%load_ext autoreload
%autoreload 2
# [___CELL_SEPARATOR___]
import os
import sprinter
import getpass
# [___CELL_SEPARATOR___]
qfib_dir = '/home/'+getpass.getuser()+'/Dropbox/TRAKODATA/qfib-data/'
qfib_ext = '.tck'
dpy_dir = '/home/'+getpass.getuser()+'/Dropbox/TRAKODATA/qfib-data/'
dpy_ext = '.tck'
tko_dir = '/home/'+getpass.getuser()+'/Dropbox/TRAKODATA/qfib-data/'
tko_ext = '.vtk'

files = '''/home/d/Downloads/tracto60kiFOD10.1.tck,/home/d/Downloads/tracto60kSD_STREAM0.1.tck,
/home/d/Downloads/tracto60kiFOD10.2.tck,/home/d/Downloads/tracto60kSD_STREAM0.2.tck,
/home/d/Downloads/tracto60kiFOD10.5.tck,/home/d/Downloads/tracto60kSD_STREAM0.5.tck,
/home/d/Downloads/tracto60kiFOD11.tck,/home/d/Downloads/tracto60kSD_STREAM1.tck'''
files = files.replace('/home/d/Downloads/','').replace('.tck','').replace('\n','').split(',')
        
# files = files[0:2]

input_size = 0
for f in files:
    print(os.path.join(tko_dir, f+tko_ext), os.path.getsize(os.path.join(tko_dir, f+tko_ext)))
    input_size += os.path.getsize(os.path.join(tko_dir, f+tko_ext))
input_size /= float(len(files))

qfib_files = [(qfib_dir, f+qfib_ext) for f in files]
qfib_bits = [8, 16]
tko_files = [(tko_dir, f+tko_ext) for f in files]
tko_bits = [9,10,11,12,13]
dpy_files =  [(dpy_dir, f+dpy_ext) for f in files]

# [___CELL_SEPARATOR___]
files
# [___CELL_SEPARATOR___]
dpy_sizes, dpy_errors, dpy_stds, dpy_advstats = sprinter.Sprinter.run_dpy(qfib_files)
# [___CELL_SEPARATOR___]
qfib_sizes, qfib_errors, qfib_stds, qfib_advstats = sprinter.Sprinter.run_qfib(qfib_files, qfib_bits)
# [___CELL_SEPARATOR___]
runs = {}
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
config = {
    'POSITION': {
        'position':True,
        'sequential':True,
        'quantization_bits':None,
        'compression_level':10,
        'quantization_range':-1,
        'quantization_origin':None
    },
    'INDICES': {
        'position':False,
        'sequential':True,
        'quantization_bits':None,
        'compression_level':10,
        'quantization_range':-1,
        'quantization_origin':None
    },
    'name': 'qbi{bits}'
}
tko_sizes, tko_errors, tko_stds, tko_advstats = sprinter.Sprinter.run_trako(config, tko_files, tko_bits, binary=False)
runs[config['name']] = [tko_sizes, tko_errors, tko_stds, tko_advstats]
# [___CELL_SEPARATOR___]
config = {
    'POSITION': {
        'position':True,
        'sequential':True,
        'quantization_bits':None,
        'compression_level':10,
        'quantization_range':-1,
        'quantization_origin':None
    },
    'INDICES': {
        'position':False,
        'sequential':True,
        'quantization_bits':None,
        'compression_level':10,
        'quantization_range':-1,
        'quantization_origin':None
    },
    'name': 'qbi{bits}_binary'
}
tko_sizes, tko_errors, tko_stds, tko_advstats = sprinter.Sprinter.run_trako(config, tko_files, tko_bits, binary=True)
runs[config['name']] = [tko_sizes, tko_errors, tko_stds, tko_advstats]
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
# sprinter.Sprinter.bitsplot(plt, tkoruns=runs, qfibruns=[qfib_sizes, qfib_errors, qfib_stds], ylim=(0,1), filename='/tmp/out.pdf')
sprinter.Sprinter.bitsplot(plt, tkoruns=runs, filename='/tmp/qfib_full.pdf')
# [___CELL_SEPARATOR___]
print(input_size/1000000)
# [___CELL_SEPARATOR___]
qfib_sizes, qfib_errors, qfib_stds, qfib_advstats = sprinter.Sprinter.run_qfib(qfib_files, qfib_bits)
# [___CELL_SEPARATOR___]
sprinter.Sprinter.createtable('qfib-data', input_size, {'qfib': [qfib_sizes, qfib_errors, qfib_stds, qfib_advstats]}, selector=1)
# [___CELL_SEPARATOR___]
sprinter.Sprinter.createtable('qfib-data', input_size, {'dpy': [dpy_sizes, dpy_errors, dpy_stds, dpy_advstats]}, selector=0)
# [___CELL_SEPARATOR___]
sprinter.Sprinter.createtable('qfib-data', input_size, runs, selector=1)
# [___CELL_SEPARATOR___]
DATASETNAME = 'qfib-data'

import collections
all_runs = collections.OrderedDict()
all_runs['qfib (8bit)'] = [0, qfib_sizes, qfib_errors, qfib_stds, qfib_advstats]
all_runs['qfib (16bit)'] = [1, qfib_sizes, qfib_errors, qfib_stds, qfib_advstats]
all_runs['zfib'] = [0, dpy_sizes, dpy_errors, dpy_stds, dpy_advstats]

for r in runs.keys():
    all_runs[r] = [4] + runs[r]
    
sprinter.Sprinter.createfulltable(DATASETNAME, input_size, all_runs)
# [___CELL_SEPARATOR___]
