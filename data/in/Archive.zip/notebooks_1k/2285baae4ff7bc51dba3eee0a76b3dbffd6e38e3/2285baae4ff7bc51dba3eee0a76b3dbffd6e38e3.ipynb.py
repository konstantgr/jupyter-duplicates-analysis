# ML model restructure
        
# Simplified stacked 3-layer model
    # Keras sequential model
        # Stateful + Return sequence set to True
        # Stateful + Return sequence set to False
    # Keras functional API
        # Stateful + Return sequence set to True
        # Stateful + Return sequence set to False
    # Raw tensorflow 
        # Stateful + Return sequence set to True
        # Stateful + Return sequence set to False
        
# Single LSTM with 10 nodes
    # Keras sequential model
    # Keras functional API
    # Raw tensorflow 

# Implement Bao, Yue, Rao deep learning framework (WT, stacked SAE, Stacked LSTM Model)
    # Wavelet transform, python: https://pywavelets.readthedocs.io/en/latest/
    # Keras Functional API
    # Raw tensorflow
# [___CELL_SEPARATOR___]
# Imports
import tensorflow as tf
import keras
from keras.models import Sequential
from keras.layers import Dense, Activation, Dropout
from keras.layers import Embedding, Flatten
from keras.layers import LSTM, GRU
from keras.models import load_model
from keras.models import model_from_json
from keras import backend as K
from keras import optimizers
from keras.layers import Bidirectional
from keras.layers import TimeDistributed

from keras.models import Model
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
# Simplified stacked 3-layer model
    # Keras sequential model, Stateful + Return sequence set to True
    
batch_size = 10
    # Batch size must be provided/known if RNN/Stateful = True
timesteps = 10 
data_dim = 10

model = Sequential()
model.add(Bidirectional(LSTM(32, return_sequences = True,
                            use_bias= False, bias_initializer = 'ones',
                            recurrent_dropout = 0.5, dropout = 0.5,
                            go_backwards=False,name='main_input'),
                            batch_input_shape=(batch_size , timesteps, data_dim ),name="LSTM_1")) 
                                #input_shape(batch_size, timesteps,features)
                                #input_shape(timesteps,features)  
        
model.add(Bidirectional(LSTM(32, return_sequences=True,stateful=True,
                            use_bias= False, bias_initializer = 'ones',
                            recurrent_dropout = 0.2, dropout = 0.2),name="LSTM_2"))

model.add(Bidirectional(LSTM(32, return_sequences=False,stateful=True, 
                            use_bias= False, bias_initializer = 'ones',
                            recurrent_dropout = 0.2, dropout = 0.2),name="LSTM_3"))


model.add(Dense(2, activation='sigmoid',name="Dense_2_output"))

sgd = optimizers.SGD(lr=0.03, decay=1e-6, momentum=0.975, nesterov=True)

model.compile(loss = "binary_crossentropy", optimizer = 'sgd', metrics = ['accuracy'])
model.summary()
# [___CELL_SEPARATOR___]
# Single layer LSTM with Dense output test in Keras Functional API
    
from keras.layers import Input
visible = Input(shape=(10,10))
hidden1 = LSTM(32, return_sequences=True)(visible)
output = Dense(2, activation='sigmoid')(hidden1)
model = Model(inputs=visible, outputs=output)

model.summary()
# [___CELL_SEPARATOR___]
# Simplified stacked 3-layer model
    # Keras Functional model, Stateful + Return sequence set to True
    # batch_shape enabled for return sequences and stateful
        # Enable stateful after succesful batch test

# input layer
visible = Input(batch_shape=(10,10,10))

# feature extraction
extract = LSTM(32, return_sequences=True)(visible)
extract2 = LSTM(32, return_sequences=True)(extract)
extract3 = LSTM(32,return_sequences=False)(extract2)

# classifier from extraction
output = Dense(2, activation='sigmoid')(extract3)

# output 
model = Model(inputs=visible, outputs=output)
print(model.summary())
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
# Non-simplified model from 8_program_structure_improvement.ipynb
# [___CELL_SEPARATOR___]
# batch_size parameter calculation:
# Size of entire batch or batch sizes
    # required parameter for LSTM if stateful = True
        # Calculation of batch size multipler for snapshot states:
            #1 × 27819 = 27,819
            #3 × 9273 = 27,819
            #9 × 3091 = 27,819
            #11 × 2529 = 27,819
            #33 × 843 = 27,819
            #99 × 281 = 27,819 
# [___CELL_SEPARATOR___]
### ML Model construction/layer definition ###

data_dim = X1_shaped.shape[2]
    # Features    
timesteps = X1_shaped.shape[1]
    # Timesteps    
batch_size = 2529
    # required parameter for LSTM if stateful = True
          
model = Sequential()
model.add(Bidirectional(LSTM(32, return_sequences = True,
                            use_bias= False, bias_initializer = 'ones',
                            recurrent_dropout = 0.5, dropout = 0.5,
                            go_backwards=False,name='main_input'),
                            batch_input_shape=(batch_size , timesteps, data_dim ),name="LSTM_1")) 
                                #input_shape(batch_size, timesteps,features)
                                #input_shape(timesteps,features)        
# GRU layers #############################################

# Set use_bias = True
model.add(Bidirectional(GRU(16, return_sequences=True,stateful=True, 
                            use_bias= True, bias_initializer = 'ones', 
                            activation='relu',  
                            recurrent_dropout = 0.2, dropout = 0.2),name="GRU_1_biased_relu"))

# Set use_bias = True
model.add(Bidirectional(GRU(24, return_sequences=True,stateful=True,
                            use_bias= True, bias_initializer = 'ones',  
                            recurrent_dropout = 0.2, dropout = 0.2),name="GRU_2_biased"))

# Set use_bias = False
model.add(Bidirectional(GRU(32, return_sequences=True,stateful=True,
                            use_bias= False, bias_initializer = 'ones',
                            recurrent_dropout = 0.2, dropout = 0.2),name="GRU_3"))
# Set use_bias = False
model.add(Bidirectional(GRU(64, return_sequences=True,stateful=True,
                            use_bias= False, bias_initializer = 'ones',
                            recurrent_dropout = 0.2, dropout = 0.2),name="GRU_4"))

# Set bias to True for this GRU/LSTM:
model.add(Bidirectional(GRU(128, return_sequences=True,stateful=True,
                            use_bias= True, bias_initializer = 'ones',
                            recurrent_dropout = 0.2, dropout = 0.2),name="GRU_5_biased"))
# Set use_bias = False
model.add(Bidirectional(GRU(16, return_sequences=True,stateful=True,
                            use_bias= False, bias_initializer = 'ones', 
                            recurrent_dropout = 0.2, dropout = 0.2),name="GRU_6"))
###########################################################
model.add(Bidirectional(LSTM(32, return_sequences=True,stateful=True,
                            use_bias= False, bias_initializer = 'ones',
                            recurrent_dropout = 0.2, dropout = 0.2),name="LSTM_2"))

model.add(TimeDistributed(Dense(2,activation='sigmoid'),name="Dense_1_DT"))

model.add(Bidirectional(LSTM(16, return_sequences=False,stateful=True, 
                            use_bias= False, bias_initializer = 'ones',
                            recurrent_dropout = 0.5, dropout = 0.5),name="LSTM_3"))
#return_sequences = False for last LSTM to flatten output
    
model.add(Dropout(0.2,name="Dropout_1"))
model.add(Dense(2, activation='sigmoid',name="Dense_2_output"))

sgd = optimizers.SGD(lr=0.03, decay=1e-6, momentum=0.975, nesterov=True)
model.compile(loss = "binary_crossentropy", optimizer = 'sgd', metrics = ['accuracy'])
model.summary()
# [___CELL_SEPARATOR___]
