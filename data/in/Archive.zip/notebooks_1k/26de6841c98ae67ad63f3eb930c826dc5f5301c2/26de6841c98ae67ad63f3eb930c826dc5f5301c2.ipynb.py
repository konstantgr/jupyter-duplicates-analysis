import glob

data_path = "../data/"
bhaga_cases = glob.glob(data_path + "bhaga_0[2-4]_l16")
water_cases = glob.glob(data_path + "water_0[1-5]_l16")
cases = sorted(bhaga_cases + water_cases)
for i, case in enumerate(cases):
    print(i, case)
# [___CELL_SEPARATOR___]
import helper_module as hm

times = [30, 30, 20, 12, 14, 14] # Basilisk simulation time
Ga = [15.2400, 134.626, 30.8340, 98.6715, 163.450, 238.287]
U_b = []

all_fields = {}
for i, case in enumerate(cases):
    case_name = case.split("/")[-1]
    log_path = case + "/log." + case_name + ".csv"
    log = hm.Logfile(log_path)
    log.read_logfile(usecols=['time', 'u_x', 'x'])
    row = log.find_closest("time", times[i])
    U_b.append(row.u_x.values[0])
    field_path = case + "/" + case_name + "_t{:2d}.csv".format(times[i])
    all_fields[case_name] = hm.CenterFieldValues2D(field_path, [0.0, row.x.values[0]], [0.0, row.u_x.values[0]])
    
print("Rise velocities:\n", U_b)
# [___CELL_SEPARATOR___]
# additional plot settings
nx = 200
ny = 400

output_path = "../output/"

def savefig(name):
    plt.savefig(output_path + name + ".png", bbox_inches="tight")
    plt.savefig(output_path + name + ".pdf", bbox_inches="tight")
# [___CELL_SEPARATOR___]
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rc

%matplotlib inline

rc('text', usetex=True)

fig, axarr = plt.subplots(1, 3, sharey=True, figsize=(hm.figure_width, 9.4))

xi_right = np.linspace(0.0, 1.0, nx)
xi_left = np.linspace(-1.0, 0.0, nx)
xi_full = np.linspace(-1.0, 1.0, 2*nx)
yi = np.linspace(-2.2, 1.3, ny)
Xi_left, Yi_left = np.meshgrid(xi_left, yi)
Xi_right, Yi_right = np.meshgrid(xi_right, yi)
Xi_full, Yi_full = np.meshgrid(xi_full, yi)

# bhaga
contours = []
for i, name in enumerate(["bhaga_02_l16", "bhaga_03_l16", "bhaga_04_l16"]):
    mag_U = all_fields[name].interpolate_velocity(Xi_left, Yi_left)
    U_x, U_y = all_fields[name].interpolate_velocity(Xi_right, Yi_right, True, False)
    vol_f =  all_fields[name].interpolate_volume_fraction(Xi_full, Yi_full)

    axarr[i].contourf(xi_left, yi, mag_U/U_b[i], cmap='jet', alpha=hm.alpha_contour)
    contours.append(axarr[i].contour(xi_left, yi, mag_U/U_b[i], colors='k'))
    axarr[i].clabel(contours[-1], inline=True, fontsize=hm.fontsize_contour, fmt='%1.2f')
    axarr[i].streamplot(Xi_right, Yi_right, U_x, U_y, color=mag_U[:,::-1]/U_b[i], cmap='jet', density=(1.5, 3.0), minlength=0.1, maxlength=8.0)
    axarr[i].contour(xi_full, yi, vol_f, levels=[0.5], colors=['k'], linewidths=2.0)

for ax in axarr:
    ax.axis('equal')
    ax.label_outer()
    ax.set_xticks([-0.9,-0.5, 0.0, 0.5, 0.9])
    ax.tick_params(labelsize=hm.fontsize_tick)

for contour in contours:
    for line in contour.collections:
        line.set_linestyle('dashed')

fig.subplots_adjust(wspace=0.05)
fig.text(0.5, 0.05, r"$\tilde{x}$", ha='center', fontsize=hm.fontsize_label)
fig.text(0.05, 0.5, r"$\tilde{y}$", va='center', rotation='vertical', fontsize=hm.fontsize_label)

savefig("bhaga_velocity_fields")
# [___CELL_SEPARATOR___]
fig, axarr = plt.subplots(1, 3, sharey=True, figsize=(hm.figure_width, 9.4))

# water
contours = []
for i, name in enumerate(["water_01_l16", "water_03_l16", "water_05_l16"]):
    mag_U = all_fields[name].interpolate_velocity(Xi_left, Yi_left)
    U_x, U_y = all_fields[name].interpolate_velocity(Xi_right, Yi_right, True, False)
    vol_f =  all_fields[name].interpolate_volume_fraction(Xi_full, Yi_full)

    axarr[i].contourf(xi_left, yi, mag_U/U_b[3+i], cmap='jet', alpha=hm.alpha_contour)
    contours.append(axarr[i].contour(xi_left, yi, mag_U/U_b[3+i], colors='k'))
    axarr[i].clabel(contours[-1], inline=True, fontsize=hm.fontsize_contour, fmt='%1.2f')
    axarr[i].streamplot(Xi_right, Yi_right, U_x, U_y, color=mag_U[:,::-1]/U_b[3+i], cmap='jet', density=(1.5, 3.0), minlength=0.1, maxlength=8.0)
    axarr[i].contour(xi_full, yi, vol_f, levels=[0.5], colors=['k'], linewidths=2.0)

for ax in axarr:
    ax.axis('equal')
    ax.label_outer()
    ax.set_xticks([-0.9,-0.5, 0.0, 0.5, 0.9])
    ax.tick_params(labelsize=hm.fontsize_tick)

for contour in contours:
    for line in contour.collections:
        line.set_linestyle('dashed')

fig.subplots_adjust(wspace=0.05)
fig.text(0.5, 0.05, r"$\tilde{x}$", ha='center', fontsize=hm.fontsize_label)
fig.text(0.05, 0.5, r"$\tilde{y}$", va='center', rotation='vertical', fontsize=hm.fontsize_label)

savefig("water_velocity_fields")
# [___CELL_SEPARATOR___]
