import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

df = pd.read_csv('raw-data.csv')
df['time'] = pd.to_datetime(df['ts'],unit='ms')
df.set_index('time', inplace=True)
df.drop(columns=['ts'], inplace=True)
# [___CELL_SEPARATOR___]
df.head(20)
# [___CELL_SEPARATOR___]
df1 = df.loc[df['id'] == 'pump-1']
df1 = df1.drop(columns=['id','label'])
df1.plot(figsize=(20,5),  fontsize=12,subplots=True,  title = "Pump 1")
plt.show()
# [___CELL_SEPARATOR___]
df1 = df.loc[df['id'] == 'pump-2']
df1 = df1.drop(columns=['id','label'])
df1.plot(figsize=(20,5),  fontsize=12,subplots=True,  title = "Pump 2")
plt.show()
# [___CELL_SEPARATOR___]
df1 = df.loc[df['id'] == 'pump-1']
df1 = df1.drop(columns=['id'])
# [___CELL_SEPARATOR___]
df1.head(10)
# [___CELL_SEPARATOR___]
df1 = df.loc[df['id'] == 'pump-1']
df1 = df1.drop(columns=['id'])
df1.plot(figsize=(20,10),  fontsize=12,subplots=True,  title = "Pump 1")
plt.show()
# [___CELL_SEPARATOR___]

df2 = df.loc[df['id'] == 'pump-2']
df2 = df2.drop(columns=['id'])
df2.plot(figsize=(20,10),  fontsize=12,subplots=True, title = "Pump 2")
plt.show()
# [___CELL_SEPARATOR___]
df21 = df2.head(100)
df21.plot(figsize=(20,10), fontsize=12,subplots=True, title = "Pump 2 - 100 Values")
plt.show()
# [___CELL_SEPARATOR___]
#
# Few helper functions
#

# Get list with column names: F1, F2, Fn, L
def get_columns(n):
    f = []
    for x in range(1,n+1):
        f.append("F"+str(x))
    f.append("L")
    return f

# Create empty data frame
def create_empty_df(n):
    d= ([0.]*n)
    d.append(0)
    dfx = pd.DataFrame([d], columns=get_columns(n))
    dfx.drop(dfx.index[0], inplace=True)
    return dfx

# Create data frame with one row
def create_df(vals: list, label: int = 0):
    if not isinstance(vals, list):
        raise TypeError
    #vals.append(label)    
    dfx = pd.DataFrame([vals+[label]], columns=get_columns(len(vals)))
    return dfx


# [___CELL_SEPARATOR___]
length = 5 # Episode lenght

df_epis = create_empty_df(length)

for id in df.id.unique():
    print("Convert data for: ", id)
    
    df2 = df.loc[df['id'] == id]

    epi = []
    for index, row in df2.iterrows():
        # print('%6.2f, %d' % (row['value'], row['label']))
        epi.append(row['value'])
        if len(epi) == length :
            df_row = create_df(epi,row['label'] )
            df_epis = df_epis.append(df_row, ignore_index=True)
            del(epi[0])


# [___CELL_SEPARATOR___]
df_epis.head(20)
# [___CELL_SEPARATOR___]
df_epis.describe()
# [___CELL_SEPARATOR___]
# Calculate number of episodes
n_episodes = df_epis.shape[0]

# Calculate number of features
n_features = df_epis.shape[1] - 1

# Calculate passing students
n_anomaly = df_epis[df_epis['L']==1].shape[0]

# TODO: Calculate failing students
n_normal = df_epis[df_epis['L']==0].shape[0]

# TODO: Calculate graduation rate
anomaly_rate = n_anomaly / float(n_episodes) *100

# Print the results
print ("Total number of episodes: {}".format(n_episodes))
print ("Number of features: {}".format(n_features))
print ("Number of episodes with anomaly: {}".format(n_anomaly))
print ("Number of episodes witManipulatehout anomaly: {}".format(n_normal))
print ("Anomaly rate in dataset: {:.2f}%".format(anomaly_rate))
# [___CELL_SEPARATOR___]
factor = 5 # Number of copies
dfr = df_epis.copy()
for i in range(1,factor):

    f = 0.5 + ((i - 1 ) * 0.5 / (factor-1)) # vary the anomaly by a factor 
    #print(i,f)
    
    dfi = df_epis.copy()
    dfi['F5'] = np.where(dfi['L']==1, dfi['F5']*f, dfi['F5']) # Lower the outliers
    dfr = dfr.append(dfi)
    
df_epis = dfr.copy()
# [___CELL_SEPARATOR___]
# Calculate number of episodes
n_episodes = df_epis.shape[0]

# Calculate number of features
n_features = df_epis.shape[1] - 1

# Calculate passing students
n_anomaly = df_epis[df_epis['L']==1].shape[0]

# TODO: Calculate failing students
n_normal = df_epis[df_epis['L']==0].shape[0]

# TODO: Calculate graduation rate
anomaly_rate = n_anomaly / float(n_episodes) *100

# Print the results
print ("Total number of episodes: {}".format(n_episodes))
print ("Number of features: {}".format(n_features))
print ("Number of episodes with anomaly: {}".format(n_anomaly))
print ("Number of episodes without anomaly: {}".format(n_normal))
print ("Anomaly rate in dataset: {:.2f}%".format(anomaly_rate))
# [___CELL_SEPARATOR___]
df_epis.to_csv ('sensor-training-data.csv', index = False, header=True, float_format='%.2f')
# [___CELL_SEPARATOR___]
# Extract feature columns
feature_cols = list(df_epis.columns[:-1])

# Extract target column 'label'
target_col = df_epis.columns[-1] 

# Show the list of columns
print ("Feature columns:\n{}".format(feature_cols))
print ("\nTarget column: {}".format(target_col))

# Separate the data into feature data and target data (X_all and y_all, respectively)
X_all = df_epis[feature_cols]
y_all = df_epis[target_col]

# Show the feature information by printing the first five rows
print ("\nFeature values:")
print (X_all.head())
# [___CELL_SEPARATOR___]
from sklearn.model_selection import train_test_split

X_train, X_test, y_train, y_test = train_test_split( X_all, y_all, test_size=0.33, random_state=42)


# Show the results of the split
print ("Training set has {} samples.".format(X_train.shape[0]))
print ("Testing set has {} samples.".format(X_test.shape[0]))

print ("Anomaly rate of the training set: {:.2f}%".format(100 * (y_train == 1).mean()))
print ("Anomaly rate of the testing set: {:.2f}%".format(100 * (y_test == 1).mean()))
# [___CELL_SEPARATOR___]
def train_classifier(clf, X_train, y_train):
    ''' Fits a classifier to the training data. '''
    
    # Start the clock, train the classifier, then stop the clock
    start = time()
    clf.fit(X_train, y_train)
    end = time()
    
    # Print the results
    print ("Trained model in {:.4f} seconds".format(end - start))

    
def predict_labels(clf, features, target):
    ''' Makes predictions using a fit classifier based on F1 score. '''
    
    # Start the clock, make predictions, then stop the clock
    start = time()
    y_pred = clf.predict(features)
    end = time()
    
    # Print and return results
    print ("Made predictions in {:.4f} seconds.".format(end - start))
    return f1_score(target.values, y_pred)


def train_predict(clf, X_train, y_train, X_test, y_test):
    ''' Train and predict using a classifer based on F1 score. '''
    
    # Indicate the classifier and the training set size
    print ("Training a {} using a training set size of {}. . .".format(clf.__class__.__name__, len(X_train)))
    
    # Train the classifier
    train_classifier(clf, X_train, y_train)
    
    # Print the results of prediction for both training and testing
    print ("F1 score for training set: {:.4f}.".format(predict_labels(clf, X_train, y_train)))
    print ("F1 score for test set: {:.4f}.".format(predict_labels(clf, X_test, y_test)))
# [___CELL_SEPARATOR___]
# from sklearn import model_A
from sklearn.tree import DecisionTreeClassifier

# from sklearn import model_B
from sklearn.svm import SVC

# from skearln import model_C
from sklearn.naive_bayes import GaussianNB

from sklearn.metrics import f1_score

from time import time


my_random_seed = 42

# Initialize the three models
clf_A = DecisionTreeClassifier(random_state=my_random_seed)
clf_B = SVC(random_state=my_random_seed)
clf_C = GaussianNB()


# loop thru models, then thru train sizes
for clf in [clf_A, clf_B, clf_C]:
    print ("\n{}: \n".format(clf.__class__.__name__))
    train_predict(clf, X_train, y_train, X_test, y_test)
        
                    
            
from sklearn.metrics import classification_report
for clf in [clf_A, clf_B, clf_C]:
    print ('\nReport for {}:\n'.format(clf.__class__.__name__))
    print (classification_report(y_test, clf.predict(X_test)))
    print ('-'*52)  
# [___CELL_SEPARATOR___]
from joblib import dump, load

filename = 'model.joblib'
dump(clf_A, open(filename, 'wb'))

# Validate that the model can be loaded

# load the model from disk
loaded_model = load(open(filename, 'rb'))
result = loaded_model.score(X_test, y_test)
print("Score:", result)
# [___CELL_SEPARATOR___]
import os, sys

class AnomalyDetection(object):
    def __init__(self):
        print("Initializing...")
        self.model_file = os.environ.get('MODEL_FILE', 'model.joblib')

        print("Load modelfile: %s" % (self.model_file))
        self.clf = load(open(self.model_file, 'rb'))

    def predict(self, X, feature_names):
        print("Predict features: ", X) 

        prediction = self.clf.predict(X)
        print("Prediction: " , prediction)
        
        return prediction


# [___CELL_SEPARATOR___]
p = AnomalyDetection()
    
X = np.asarray([[16.1,  15.40,  15.32,  13.47,  17.70]], dtype=np.float32)
print("Features types: ", type(X),  type(X[0][0]))
print("Predict features: ", X)

prediction = p.clf.predict(X)
print("Prediction: " , prediction)
# [___CELL_SEPARATOR___]
