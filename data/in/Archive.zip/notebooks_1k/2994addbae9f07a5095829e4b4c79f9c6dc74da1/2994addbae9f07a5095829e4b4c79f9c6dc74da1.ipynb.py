# Imports

import os
import warnings
import numpy as np

import tensorflow as tf

from tensorflow.keras import layers, models, optimizers
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import SimpleRNN, Dense, Bidirectional

from data_repository import DataRepository
from sklearn.model_selection import KFold, StratifiedKFold

# Ignore future warnings
warnings.simplefilter(action='ignore', category=FutureWarning)
# [___CELL_SEPARATOR___]
# Root CSV files directory
dirname = "./data/absolute/2D/"  

repo = DataRepository(dirname, verbose=False)

#load all
x, y = repo.getDataAndLabels()
# [___CELL_SEPARATOR___]
physical_devices = tf.config.list_physical_devices('GPU') 
print("Num GPUs:", len(physical_devices)) 

from tensorflow.compat.v1 import ConfigProto
from tensorflow.compat.v1 import InteractiveSession

config = ConfigProto()
config.gpu_options.per_process_gpu_memory_fraction = 0.3
config.gpu_options.allow_growth = True
session = InteractiveSession(config=config)
# [___CELL_SEPARATOR___]
with open('tokens_json.txt', 'r') as outfile:
    json_ex = outfile.read()
    

tokenizer = tf.keras.preprocessing.text.tokenizer_from_json(json_ex)
print(tokenizer.word_index)
token_labels = {y:x for x,y in tokenizer.word_index.items()}

y_integer = np.argmax(y, axis=1)
y_name= ([token_labels[p] for p in y_integer])

# [___CELL_SEPARATOR___]
y_name
# [___CELL_SEPARATOR___]
skfold = StratifiedKFold(n_splits=5, shuffle=True, random_state=7)
cvscores = []
for train, test in skfold.split(x, y_name):
    print("size_x_train: ", len(x[train]))
    print("size_y_train: ", len(y[train]))
    print("size_x_test: ", len(x[test]))
    print("size_y_test: ", len(y[test]))
    model = Sequential()
    model.add(layers.LSTM(128, return_sequences=True, input_shape=(x.shape[1], x.shape[2])))
    model.add(layers.LSTM(64, return_sequences=True)) 
    model.add(layers.LSTM(96))  
    model.add(layers.Dense(12, activation='softmax'))
    model.compile(loss='categorical_crossentropy', optimizer='adam',metrics=['accuracy',tf.keras.metrics.Precision(),tf.keras.metrics.Recall()])
    model.summary()

    history=model.fit(x[train],y[train],epochs=170,validation_data=(x[test],y[test]),verbose=2)
    scores = model.evaluate(x[test], y[test], verbose=0)
    print("%s: %.2f%%" % (model.metrics_names[1], scores[1]*100))
    cvscores.append(scores[1] * 100)
    print("Scores: ", scores)
    print("%.2f%% (+/- %.2f%%)" % (np.mean(cvscores), np.std(cvscores)))




# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
