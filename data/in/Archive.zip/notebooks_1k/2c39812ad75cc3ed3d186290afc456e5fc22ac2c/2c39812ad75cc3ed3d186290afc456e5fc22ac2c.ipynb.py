all = get_all_securities()
sec_list = all.index.values.tolist()

start = '2015-01-01'
end = '2019-06-25'
panel = get_price(sec_list, start_date=start, end_date=end, fields=['close'])
df = panel['close']
df.to_pickle('2015-2019_close.pkl')

panel = get_price(sec_list, start_date=start, end_date=end, fields=['money'])
df = panel['money']
df.to_pickle('2015-2019_turnover_val.pkl')

panel = get_price(sec_list, start_date=start, end_date=end, fields=['volume'])
df = panel['volume']
df.to_pickle('2015-2019_volume.pkl')

panel = get_price(sec_list, start_date=start, end_date=end, fields=['paused'])
df = panel['paused']
df.to_pickle('2015-2019_paused.pkl')

df = get_extras('is_st', sec_list, start_date=start, end_date=end)
df.to_pickle('2015-2019_is_st.pkl')