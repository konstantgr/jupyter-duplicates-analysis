#import relevant packages
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
# [___CELL_SEPARATOR___]
#import arrests dataset
arrests = pd.read_excel('https://github.com/philiplindsay/storytelling-with-data/raw/master/data-stories/police-brutality/police-data.xls', sheet_name = 0)

#create violent crimes total percentage by race
arrests['Violent Total'] = ((arrests['Murder and nonnegligent manslaughter'] + arrests['Rape'] + arrests['Robbery'] + arrests["Aggravated assault"]) / 4)

#generate pie chart for arrests by race
fig1 = px.pie(arrests, values = 'Total', names = 'Race', title = 'Arrests by Race (2018)')

#generate piece chart for violent crime arrests by race
fig2 = px.pie(arrests, values = 'Violent Total', names = 'Race', title = 'Violent Crime Arrests by Race (2018)')

#generate total population graph
fig3 = px.pie(arrests, values = 'Total population', names = 'Race', title = 'U.S. Races by Population (2018)')
# [___CELL_SEPARATOR___]
#import fatalities dataset
fatalities = pd.read_excel('https://github.com/philiplindsay/storytelling-with-data/raw/master/data-stories/police-brutality/police-data.xls', sheet_name = 1)

#sum numbers of fatalities by race
print(fatalities[fatalities.Race == 'W'].shape[0]) ##241
print(fatalities[fatalities.Race == 'B'].shape[0]) ##127
print(fatalities[fatalities.Race == 'H'].shape[0]) ##91
print(fatalities[fatalities.Race == 'O'].shape[0]) ##2

#make dataframe with aggregate fatalities
fatal = [['White', 241], ['Black', 127], ['Hispanic', 91], ['Other', 2]] 
fatal = pd.DataFrame(fatal, columns = ['Race', 'Fatalities'])

#graph police fatalities by race
fig4 = px.pie(fatal, values = 'Fatalities', names = 'Race', title = 'Police Shootings by Race (2017)')

#graph deaths against population and arrests
race = ['White', 'Black']

fig5 = go.Figure(data = [
    go.Bar(name = 'Deaths per million citizens', x = race, y = [0.9655, 2.9195]),
    go.Bar(name = 'Deaths per 100,000 arrests', x = race, y = [0.42838, 0.571653])
])

fig5.update_layout(title_text = 'Police Shootings by Race (2017)')
# [___CELL_SEPARATOR___]
fig1
# [___CELL_SEPARATOR___]
fig2
# [___CELL_SEPARATOR___]
fig3
# [___CELL_SEPARATOR___]
fig4