%matplotlib inline

import matplotlib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
# [___CELL_SEPARATOR___]

from sklearn import datasets ## imports datasets from scikit-learn
from sklearn.model_selection import train_test_split
from sklearn import model_selection
from sklearn.svm import SVR #for doing support vector regression
# [___CELL_SEPARATOR___]
data = datasets.load_boston() ## loads Boston dataset from datasets library 
# [___CELL_SEPARATOR___]
# define the data/predictors as the pre-set feature names  
X = pd.DataFrame(data.data, columns=data.feature_names)
# [___CELL_SEPARATOR___]
# Put the target (housing value -- MEDV) in another DataFrame
Y = pd.DataFrame(data.target, columns=["MEDV"])
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
#split the data
X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size = .25, random_state=25) #25% hold out for testing
# [___CELL_SEPARATOR___]
model = SVR() #variable model stores scikit's SVR model
# [___CELL_SEPARATOR___]
model.fit(X_train, y_train)
# [___CELL_SEPARATOR___]
Y_pred = model.predict(X_test) #predicted Y values on the 25% hold out predictor data
# [___CELL_SEPARATOR___]
from sklearn.metrics import mean_squared_error
# [___CELL_SEPARATOR___]
mean_squared_error(y_test, Y_pred) #MSE
# [___CELL_SEPARATOR___]
from sklearn.metrics import r2_score
# [___CELL_SEPARATOR___]
r2_score(y_test, Y_pred)  
# [___CELL_SEPARATOR___]
