import matplotlib.pyplot as plt
import numpy as np

import lightlab.util.sweep as sUtil
# [___CELL_SEPARATOR___]
# Define the system used for this notebook
class Plant():
    def __init__(self):
        self.x = 2
        
    def actuateX(self, newX, rounded=False):
        self.x = round(newX) if rounded else newX
        
    def measure(self):
        return np.sin(self.x)
# [___CELL_SEPARATOR___]
p = Plant()
x = np.linspace(0,10,100)
y = sUtil.simpleSweep(p.actuateX, x, p.measure)
plt.plot(x,y)
# [___CELL_SEPARATOR___]
# Now with a lambda function
y = sUtil.simpleSweep(lambda v: p.actuateX(v, rounded=True), x, p.measure)
plt.plot(x,y)
# [___CELL_SEPARATOR___]
