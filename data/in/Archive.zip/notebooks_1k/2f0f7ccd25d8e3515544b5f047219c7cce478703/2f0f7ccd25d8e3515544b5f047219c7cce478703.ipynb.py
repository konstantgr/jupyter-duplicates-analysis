# !wget https://malaya-dataset.s3-ap-southeast-1.amazonaws.com/dumping/common-crawl/feather.zip
# !unzip feather.zip
# !pip3 install gpt-2-simple
# [___CELL_SEPARATOR___]
from glob import glob
files = glob('feather/*.feather')
len(files)
# [___CELL_SEPARATOR___]
texts = []
# [___CELL_SEPARATOR___]
def combined(rows):
    rows = rows.sort_index(ascending=True)
    return [row for row in rows]     
# [___CELL_SEPARATOR___]
import pandas as pd
from tqdm import tqdm

for f in tqdm(files):
    df = pd.read_feather(f)
    sentences = df.groupby(['domain', 'tld']).agg({'sentence': combined})['sentence'].tolist()
    for sentence in sentences:
        texts.extend(sentence + [''])
# [___CELL_SEPARATOR___]
with open('dumping-commmon-crawl.txt', 'w') as fopen:
    fopen.write('\n'.join(texts))
# [___CELL_SEPARATOR___]
