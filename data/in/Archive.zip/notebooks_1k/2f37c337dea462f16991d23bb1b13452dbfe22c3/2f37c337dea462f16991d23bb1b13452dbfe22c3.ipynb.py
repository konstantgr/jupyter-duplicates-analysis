import requests
import pandas as pd #diese Library werdet ihr am Mittwoch und Donnerstag viel genauer anschauen
# [___CELL_SEPARATOR___]
url = 'https://earthquake.usgs.gov/fdsnws/event/1/'
# [___CELL_SEPARATOR___]
response = requests.get(url)
# [___CELL_SEPARATOR___]
response
# [___CELL_SEPARATOR___]
response.text
# [___CELL_SEPARATOR___]
url = 'https://earthquake.usgs.gov/fdsnws/event/1/count?starttime=2019-09-01&endtime=2019-09-30'
# [___CELL_SEPARATOR___]
response = requests.get(url)
# [___CELL_SEPARATOR___]
response.text
# [___CELL_SEPARATOR___]
url = 'https://earthquake.usgs.gov/fdsnws/event/1/count?starttime=2019-09-01T24:00:00&endtime=2019-09-30T08:00:00'
# [___CELL_SEPARATOR___]
response = requests.get(url)
response.text
# [___CELL_SEPARATOR___]
url1 = 'https://earthquake.usgs.gov/fdsnws/event/1/query?format=geojson'
# [___CELL_SEPARATOR___]
urlzeit = '&starttime=2018-07-29T24:00:00&endtime=2018-07-31T08:00:00'
# [___CELL_SEPARATOR___]
url1 + urlzeit
# [___CELL_SEPARATOR___]
response = requests.get(url1+urlzeit)
response.json()
# [___CELL_SEPARATOR___]
urlloc = '&minlatitude=13&maxlatitude=33&minlongitude=-120&maxlongitude=-85'
# [___CELL_SEPARATOR___]
url1+urlzeit+urlloc
# [___CELL_SEPARATOR___]
response = requests.get(url1+urlzeit+urlloc)
response.text
# [___CELL_SEPARATOR___]
response.json()
# [___CELL_SEPARATOR___]
dct = response.json()
# [___CELL_SEPARATOR___]
type(dct)
# [___CELL_SEPARATOR___]
len(dct)
# [___CELL_SEPARATOR___]
for key in dct:
    print(key)
# [___CELL_SEPARATOR___]
dct['features']
# [___CELL_SEPARATOR___]
type(dct['features'])
# [___CELL_SEPARATOR___]
dct['features'][0]
# [___CELL_SEPARATOR___]
dct['features'][0]
# [___CELL_SEPARATOR___]
for key in dct['features'][0]:
    print(key)
# [___CELL_SEPARATOR___]
dct['features'][0]['properties']
# [___CELL_SEPARATOR___]
earthquakes = []

for elem in dct['features']:
    
    t = elem['properties']['type']
    m = elem['properties']['mag']
    p = elem['properties']['place']
    tm = elem['properties']['time']
    
    mini_dict = {'Type': t,
                 'Mag': m,
                 'Place': p,
                 'Time': tm}
    
    earthquakes.append(mini_dict)
# [___CELL_SEPARATOR___]
earthquakes[:3]
# [___CELL_SEPARATOR___]
pd.DataFrame(earthquakes)
# [___CELL_SEPARATOR___]
df = pd.DataFrame(earthquakes)
# [___CELL_SEPARATOR___]
df.to_csv('erdbeben.csv')