"""
basic operations
"""

import numpy as np

a = np.array([1, 2, 5, 3])

# add 1 to every element
a = None
print("Adding 1 to every element:", a)

# subtract 3 from each element
b = None
print("Subtracting 3 from each element:", b)

# multiply each element by 10
c = None
print("Multiplying each element by 10:", c)

# square each element
d = None
print("Squaring each element:", d)

# Doubled each element of original array
print("Doubled each element of original array:", arr)
