import os
import openeye.oechem as oechem
# [___CELL_SEPARATOR___]
from collections import defaultdict
import re

def checkConsecutive(l): 
    # Source: https://tinyurl.com/y4h2dtd7
    return sorted(l) == list(range(min(l), max(l)+1)) 

def natural_sort(l): 
    # Source: https://tinyurl.com/y7kfa964
    convert = lambda text: int(text) if text.isdigit() else text.lower() 
    alphanum_key = lambda key: [ convert(c) for c in re.split('([0-9]+)', key) ] 
    return sorted(l, key = alphanum_key)
# [___CELL_SEPARATOR___]
infile = 'whole_01.sdf'

ifs = oechem.oemolistream()

# OEDefaultConfTest, OEIsomericConfTest, OEOmegaConfTest, OEAbsoluteConfTest, OEAbsCanonicalConfTest
# https://docs.eyesopen.com/toolkits/python/oechemtk/oemol.html
ifs.SetConfTest(oechem.OEAbsCanonicalConfTest()) 

if not ifs.open(infile):
    raise FileNotFoundError(f"Unable to open {infile} for reading")
mols = ifs.GetOEMols()
# [___CELL_SEPARATOR___]
smi_dict = defaultdict(list)
tlist = []
index = 0

for i, mol in enumerate(mols):
    for j, conf in enumerate(mol.GetConfs()):
        smi_dict[oechem.OEMolToSmiles(conf)].append(index)
        tlist.append(conf.GetTitle())
        index += 1
# [___CELL_SEPARATOR___]
fix_dict = defaultdict(list)

for key, val in smi_dict.items():
    
    if not checkConsecutive(val):
        fix_dict[key] = val
# [___CELL_SEPARATOR___]
# preview a few items in the dictionary
{k: fix_dict[k] for k in list(fix_dict)[:2]}
# [___CELL_SEPARATOR___]
print('\n', len(tlist), len(smi_dict), len(fix_dict))
# [___CELL_SEPARATOR___]
tlist_redo = []
tlist_good = []

for key, val in fix_dict.items():
    for v in val:
        tlist_redo.append(tlist[v])

        
tlist_good = natural_sort(list(set(tlist).difference(tlist_redo)))
print(len(tlist_redo), len(tlist_good))
# [___CELL_SEPARATOR___]
tlist_redo[:6]
# [___CELL_SEPARATOR___]
tlist_good[:6]
# [___CELL_SEPARATOR___]
with open('titles_redo.txt', 'w') as f:
    for item in tlist_redo:
        f.write("%s\n" % item)
# [___CELL_SEPARATOR___]
with open('titles_good.txt', 'w') as f:
    for item in tlist_good:
        f.write("%s\n" % item)
# [___CELL_SEPARATOR___]
infile = 'whole_02_redo.sdf'

ifs = oechem.oemolistream()

# OEDefaultConfTest, OEIsomericConfTest, OEOmegaConfTest, OEAbsoluteConfTest, OEAbsCanonicalConfTest
# https://docs.eyesopen.com/toolkits/python/oechemtk/oemol.html
ifs.SetConfTest(oechem.OEAbsCanonicalConfTest()) 

if not ifs.open(infile):
    raise FileNotFoundError(f"Unable to open {infile} for reading")
mols = ifs.GetOEMols()
# [___CELL_SEPARATOR___]
list_mols = []
list_names = []

for i, mol in enumerate(mols):
    for j, conf in enumerate(mol.GetConfs()):
        list_mols.append(oechem.OEGraphMol(conf))
        list_names.append(conf.GetTitle())
# [___CELL_SEPARATOR___]
[list_mols[i].GetTitle() for i in range(6)]
# [___CELL_SEPARATOR___]
index_redo = []
for t in tlist_redo:
    index_redo.append(list_names.index(t))
# [___CELL_SEPARATOR___]
index_redo[:6]
# [___CELL_SEPARATOR___]
sort_mols = [list_mols[i] for i in index_redo]
# [___CELL_SEPARATOR___]
[sort_mols[i].GetTitle() for i in range(6)]
# [___CELL_SEPARATOR___]
outfile = 'whole_03_redosort.sdf'

ofs = oechem.oemolostream()

if not ofs.open(outfile):
    oechem.OEThrow.Fatal("Unable to open %s for writing" % outfile)

for mol in sort_mols:
    oechem.OEWriteConstMolecule(ofs, mol)
ofs.close()
# [___CELL_SEPARATOR___]
infile = 'whole_04_combine.sdf'

ifs = oechem.oemolistream()

# OEDefaultConfTest, OEIsomericConfTest, OEOmegaConfTest, OEAbsoluteConfTest, OEAbsCanonicalConfTest
# https://docs.eyesopen.com/toolkits/python/oechemtk/oemol.html
ifs.SetConfTest(oechem.OEAbsCanonicalConfTest()) 

if not ifs.open(infile):
    raise FileNotFoundError(f"Unable to open {infile} for reading")
mols = ifs.GetOEMols()
# [___CELL_SEPARATOR___]
# open an outstream file
outfile = 'whole_05_renew.sdf'
ofs = oechem.oemolostream()

if not ofs.open(outfile):
    oechem.OEThrow.Fatal("Unable to open %s for writing" % outfile)

for i, mol in enumerate(mols):
    for j, conf in enumerate(mol.GetConfs()):
        conf.SetTitle(f'full_{i+1}')
        oechem.OEWriteConstMolecule(ofs, conf)
ofs.close()