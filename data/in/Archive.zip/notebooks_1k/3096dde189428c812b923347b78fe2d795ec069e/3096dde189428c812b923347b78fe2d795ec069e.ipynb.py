import os
import sys
import sys
sys.path.append("../..")
from src.data.bank_additional import BandAdditionalParser
from src.data.income_evaluation import IncomeEvaluationParser
from src.data.skyserver import SkyserverParser
from src.data.sonar import SonarParser
from src.data.weather_aus import WeatherAUSParser



avaliable_restul_files = {
    "sonar_results.csv": SonarParser,
    "Skyserver_results.csv": SkyserverParser,
    "income_evaluation_results.csv": IncomeEvaluationParser,
    "bank-additional_results.csv": BandAdditionalParser,
    "weatherAUS_results.csv": WeatherAUSParser
}


# Pick one of the keys name in the above dictionarys and paste it in results_file variable. Then run all the cells
results_file = "income_evaluation_results.csv"
# [___CELL_SEPARATOR___]
# Pick the wanted parser and run the cells
parser = avaliable_restul_files[results_file]()
X,y = parser.X, parser.y
X.head(5)
# [___CELL_SEPARATOR___]
print("Data shape: ", X.shape)
print(y.value_counts())
# [___CELL_SEPARATOR___]
import os
import pandas as pd


results_df = pd.read_csv(os.path.join("..", "..", "data", "processed", results_file)).dropna().round(3)
results_df
# [___CELL_SEPARATOR___]
import operator
results_df.loc[operator.and_(results_df["Classifier_Name"].str.startswith("_"), ~results_df["Classifier_Name"].str.endswith("PCA"))].dropna()
# [___CELL_SEPARATOR___]
import operator
import numpy as np


temp = results_df.loc[~results_df["Classifier_Name"].str.endswith("PCA")].dropna()
temp["model"] = results_df["Classifier_Name"].apply(lambda sen: sen.split("_")[1])
temp["scaler"] = results_df["Classifier_Name"].apply(lambda sen: sen.split("_")[0])

def df_style(val):
    return 'font-weight: 800'
    

pivot_t = pd.pivot_table(temp, values='CV_mean', index=["scaler"], columns=['model'], aggfunc=np.sum)
pivot_t_bold = pivot_t.style.applymap(df_style,
                      subset=pd.IndexSlice[pivot_t["CART"].idxmax(),"CART"])
for col in list(pivot_t):
    pivot_t_bold = pivot_t_bold.applymap(df_style,
                      subset=pd.IndexSlice[pivot_t[col].idxmax(),col])
pivot_t_bold
# [___CELL_SEPARATOR___]
# Print table for the Medium article

pd.set_option('display.max_rows', 500)
pd.set_option('display.max_columns', 500)
pd.set_option('display.width', 100000)
pd.options.display.max_rows
pd.set_option('display.max_colwidth', -1)

dict2 = {'StandardScaler': "StandardScaler",
'MinMaxScaler':"MinMaxScaler",
'MaxAbsScaler':"MaxAbsScaler",
'RobustScaler':"RobustScaler",
'QuantileTransformer-Normal':"QuantileTransformer(output_distribution='normal')",
'QuantileTransformer-Uniform':"QuantileTransformer(output_distribution='uniform')",
'PowerTransformer-Yeo-Johnson':"PowerTransformer(method='yeo-johnson')",
'Normalizer':"Normalizer"}

scalers_df = pd.DataFrame(list(dict2.items()), columns=["Name","Sklearn_Class"])
s = scalers_df.style.set_properties(subset=["Name", "Sklearn_Class"], **{'text-align': 'left'})
s.set_table_styles([ dict(selector='th', props=[('text-align', 'left')] ) ])
# [___CELL_SEPARATOR___]
# Print table for the Medium article
pd.set_option('display.max_rows', 500)
pd.set_option('display.max_columns', 500)
pd.set_option('display.width', 100000)
pd.options.display.max_rows
pd.set_option('display.max_colwidth', -1)

dict2 = {'LR': "LogisticRegression",
'LDA':"LinearDiscriminantAnalysis",
'KNN':"KNeighborsClassifier",
'CART':"DecisionTreeClassifier",
'NB':"GaussianNB",
'SVM':"SVC",
'RF':"RandomForestClassifier",
'MLP':"MLPClassifier"}

scalers_df = pd.DataFrame(list(dict2.items()), columns=["Name","Sklearn_Class"])
s = scalers_df.style.set_properties(subset=["Name", "Sklearn_Class"], **{'text-align': 'left'})
s.set_table_styles([ dict(selector='th', props=[('text-align', 'left')] ) ])
# [___CELL_SEPARATOR___]
import operator

cols_max_vals = {}
cols_max_row_names = {}
for col in list(pivot_t):
    row_name = pivot_t[col].idxmax()
    cell_val = pivot_t[col].max()
    cols_max_vals[col] = cell_val
    cols_max_row_names[col] = row_name
    
sorted_cols_max_vals = sorted(cols_max_vals.items(), key=lambda kv: kv[1], reverse=True)

print("Best classifiers sorted:\n")
counter = 1
for model, score in sorted_cols_max_vals:
    print(str(counter) + ". " + model + " + " +cols_max_row_names[model] + " : " +str(score))
    counter +=1
# [___CELL_SEPARATOR___]
import operator
temp = results_df.copy()
temp["model"] = results_df["Classifier_Name"].apply(lambda sen: sen.split("_")[1])
temp["scaler"] = results_df["Classifier_Name"].apply(lambda sen: sen.split("_")[0])

def df_style(val):
    return 'font-weight: 800'
    

pivot_t = pd.pivot_table(temp, values='CV_mean', index=["scaler"], columns=['model'], aggfunc=np.sum)
pivot_t_bold = pivot_t.style.applymap(df_style,
                      subset=pd.IndexSlice[pivot_t["CART"].idxmax(),"CART"])
for col in list(pivot_t):
    pivot_t_bold = pivot_t_bold.applymap(df_style,
                      subset=pd.IndexSlice[pivot_t[col].idxmax(),col])
pivot_t_bold
# [___CELL_SEPARATOR___]
import operator

import os
import pandas as pd

results_hyper_file = "sonar_results_hypertuned.csv"
results_hyper_df = pd.read_csv(os.path.join("..", "..", "data", "processed", results_hyper_file)).dropna().round(3)


temp = results_hyper_df.copy()
temp["model"] = results_hyper_df["Classifier_Name"].apply(lambda sen: sen.split("_")[1])
temp["scaler"] = results_hyper_df["Classifier_Name"].apply(lambda sen: sen.split("_")[0])

def df_style(val):
    return 'font-weight: 800'
    

pivot_t = pd.pivot_table(temp, values='CV_mean', index=["scaler"], columns=['model'], aggfunc=np.sum)
pivot_t_bold = pivot_t.style.applymap(df_style,
                      subset=pd.IndexSlice[pivot_t["KNN"].idxmax(),"KNN"])
for col in list(pivot_t):
    pivot_t_bold = pivot_t_bold.applymap(df_style,
                      subset=pd.IndexSlice[pivot_t[col].idxmax(),col])
pivot_t_bold
# [___CELL_SEPARATOR___]
