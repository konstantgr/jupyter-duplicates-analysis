!apt-get update 
!apt-get install g++ openjdk-8-jdk python-dev python3-dev 
!pip3 install JPype1-py3 
!pip3 install konlpy 
!JAVA_HOME="C:\Program Files\Java\jdk-13.0.2"
!pip install wordcloud
# [___CELL_SEPARATOR___]
import pandas as pd
import numpy as np 
import re
# [___CELL_SEPARATOR___]
from wordcloud import WordCloud
import matplotlib.pyplot as plt
import platform

from matplotlib import font_manager, rc
if platform.system() == 'Windows':
  font_name = font_manager.FontProperties(fname = font_fname).get_name()
  plt.rcParams["font.family"] = font_family

%matplotlib inline
# [___CELL_SEPARATOR___]
%config InlineBackend.figure_format = 'retina'

!apt -qq -y install fonts-nanum > /dev/null
import matplotlib.font_manager as fm
fontpath = '/usr/share/fonts/truetype/nanum/NanumBarunGothic.ttf'
font = fm.FontProperties(fname = fontpath,size=9)
# [___CELL_SEPARATOR___]
import nltk 
from konlpy.tag import Okt 
# [___CELL_SEPARATOR___]
def make_wordcloud_data(df, stopwords): 
  okt = Okt()
  sentences = ''

  for each_line in df['청원내용']: 
    sentences = sentences + each_line + '\n'

  tokens_ko = okt.nouns(sentences)
  tokens_ko = [each_word for each_word in tokens_ko if each_word not in stop_words]
  ko = nltk.Text(tokens_ko, name='청원내용 분석')
  
  data = dict(ko.vocab().most_common(150))
  return data
# [___CELL_SEPARATOR___]
def make_wordcloud(data):
    wordcloud = WordCloud(font_path=fontpath,
                      max_font_size = 100, 
                      relative_scaling = 0.4,
                      background_color='white',).generate_from_frequencies(data)
    plt.figure(figsize=(10,8))
    plt.imshow(wordcloud)
    plt.axis("off")
    plt.show()
    wordcloud.to_file('wordcloud image.png')
# [___CELL_SEPARATOR___]
petition1 = pd.read_csv('petition-0.csv', index_col=0)
petition1 = petition1.sort_values('청원시작일')
petition1.head()
# [___CELL_SEPARATOR___]
petition2 = pd.read_csv('petition-1.csv', index_col=0)
petition2 = petition2.sort_values('청원시작일')
petition2.head()
# [___CELL_SEPARATOR___]
petition = pd.concat([petition1, petition2])
petition.shape
# [___CELL_SEPARATOR___]
petition = petition[(petition['청원시작일'] >= '2020-02-06') & (petition['청원시작일'] <= '2020-02-12')]
petition.head()
# [___CELL_SEPARATOR___]
stop_words = ['.','을','이','의','를','에',',','가','들','은','는','으로','한','도',
              '수','에서','로','것','그','과','제','입니다','할','하고','적',"'",'하는',
              '합니다','와','에게','고','인',')','?','하여','등','저','있습니다','말','까지',
              '(','1','그리고','다','2','만','딸','했습니다','안','된','못','일','더','위',
              '있는','해','\n','또한','명','하지','..','정말','물','많은','"',
              '중','3','게','너무','A','자','이런','때','되지','위해','에는','없는',
              '및','요','때문','관련','대한','전','라고','되었습니다','하기','나','후','같은','해서',
              '글','되어','주','차','하','내','없이','대해','잘','**','...','19','[',']', '이라는','이며','이미',
              '이번','지','이고','부터','서','-','시','라는','한다고','아니라','님','게시','곳',
              '구','니까','다른','대', '되고','될','됩니다','모두','모든','바랍니다','번','본','보다',
              '부탁드립니다','분','분들','뿐','아닌','않고','알','없습니다','에서는','에서도',
              '여','원','의해','이나','인해','있도록','저희','진자','아닌','앓고','알','큰','통해','하게',
              '하며','하게','하지만','확','왜','몸','돈','비']
# [___CELL_SEPARATOR___]
# petition_feb에 df 넣고, stop_words 수정
data = make_wordcloud_data(petition, stop_words)
# [___CELL_SEPARATOR___]
make_wordcloud(data)
# [___CELL_SEPARATOR___]
