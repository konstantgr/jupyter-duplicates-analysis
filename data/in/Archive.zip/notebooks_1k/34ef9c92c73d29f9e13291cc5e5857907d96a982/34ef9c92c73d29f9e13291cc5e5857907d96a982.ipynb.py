import re
import sys
import warnings
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

sys.path.append("..")
warnings.filterwarnings('ignore')
pd.set_option('display.max_rows', 800)
plt.rcParams["figure.figsize"] = (40,10)
pd.set_option('display.max_colwidth', -1)
# [___CELL_SEPARATOR___]
fp = open("../datasets/semeval_relatioship_classification/TRAIN_FILE.TXT","r")
lines = fp.readlines()
sent_ids = []
sentences = []
labels = []
for i,line in enumerate(lines):
    if i%4==0:
        sent = line.split("\t")[-1].strip()[1:-1]
        sent_id = line.split("\t")[0].strip()
        sent = sent.replace("<e1>", "#").replace("</e1>", "#")
        sent = sent.replace("<e2>", "$").replace("</e2>", "$")
        sentences.append(sent)
        sent_ids.append(sent_id)
        label = lines[i+1].strip()
        print(sent_id,sent,label)
        labels.append(label)
# [___CELL_SEPARATOR___]
df = pd.DataFrame({"id":sent_ids,"text":sentences, "label":labels})
df.head()
# [___CELL_SEPARATOR___]
df.label.unique()
# [___CELL_SEPARATOR___]
data_classes = ['Component-Whole(e2,e1)', 'Other', 'Instrument-Agency(e2,e1)',
       'Member-Collection(e1,e2)', 'Cause-Effect(e2,e1)',
       'Entity-Destination(e1,e2)', 'Content-Container(e1,e2)',
       'Message-Topic(e1,e2)', 'Product-Producer(e2,e1)',
       'Member-Collection(e2,e1)', 'Entity-Origin(e1,e2)',
       'Cause-Effect(e1,e2)', 'Component-Whole(e1,e2)',
       'Message-Topic(e2,e1)', 'Product-Producer(e1,e2)',
       'Entity-Origin(e2,e1)', 'Content-Container(e2,e1)',
       'Instrument-Agency(e1,e2)', 'Entity-Destination(e2,e1)']

df['class'] = df['label']
df['label'] = df['label'].apply(data_classes.index)
# [___CELL_SEPARATOR___]
df.label.unique()
# [___CELL_SEPARATOR___]
df.nunique()
# [___CELL_SEPARATOR___]
df.shape
# [___CELL_SEPARATOR___]
df.head()
# [___CELL_SEPARATOR___]
df['class'].value_counts()
# [___CELL_SEPARATOR___]
df.text.map(lambda x: len(x.split())).describe([0.7,0.8,0.9,0.95,0.999])
# [___CELL_SEPARATOR___]
fp = open("../datasets/semeval_relatioship_classification/TEST_FILE_FULL.TXT","r")
lines = fp.readlines()
sentences = []
sent_ids = []
labels = []
for i,line in enumerate(lines):
    if i%4==0:
        sent = line.split("\t")[-1].strip()[1:-1]
        sent_id = line.split("\t")[0].strip()
        sent = sent.replace("<e1>", "#").replace("</e1>", "#")
        sent = sent.replace("<e2>", "$").replace("</e2>", "$")
        sentences.append(sent)
        sent_ids.append(sent_id)
        label = lines[i+1].strip()
        print(sent_id,sent,label)
        labels.append(label)
# [___CELL_SEPARATOR___]
df_test = pd.DataFrame({"id":sent_ids,"text":sentences,"label":labels})
# [___CELL_SEPARATOR___]
data_classes = ['Component-Whole(e2,e1)', 'Other', 'Instrument-Agency(e2,e1)',
       'Member-Collection(e1,e2)', 'Cause-Effect(e2,e1)',
       'Entity-Destination(e1,e2)', 'Content-Container(e1,e2)',
       'Message-Topic(e1,e2)', 'Product-Producer(e2,e1)',
       'Member-Collection(e2,e1)', 'Entity-Origin(e1,e2)',
       'Cause-Effect(e1,e2)', 'Component-Whole(e1,e2)',
       'Message-Topic(e2,e1)', 'Product-Producer(e1,e2)',
       'Entity-Origin(e2,e1)', 'Content-Container(e2,e1)',
       'Instrument-Agency(e1,e2)', 'Entity-Destination(e2,e1)']

df_test['class'] = df_test['label']
df_test['label'] = df_test['label'].apply(data_classes.index)
df_test.shape
# [___CELL_SEPARATOR___]
df.to_csv('../datasets/semeval_relatioship_classification/train.csv', index=False)
df_test.to_csv('../datasets/semeval_relatioship_classification/test.csv', index=False)
# [___CELL_SEPARATOR___]
# from tfelectra import ElectraClassification

from classitransformers.report import metrics
from classitransformers.configs import Configs
from classitransformers.tfbert import BertClassification
# [___CELL_SEPARATOR___]
# config = Configs(pretrained_model_dir = '../models/Electra_base/', 
#                  num_train_epochs = 4,
#                  train_batch_size = 64, 
#                  eval_batch_size = 8, 
#                  predict_batch_size = 8, 
#                  do_train = True, 
#                  do_eval = False, 
#                  label_list = ["0", "1", "2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18"], 
#                  max_seq_length = 64,
#                  data_dir='../datasets/semeval_relatioship_classification/',
#                  output_dir = '../electra_output_entity_relationship/')

# model = ElectraClassification(config)


config = Configs(pretrained_model_dir = '../models/Bert_base/',
                 model_name = 'bert',
                 num_train_epochs = 4, 
                 train_batch_size = 64, 
                 eval_batch_size = 8, 
                 predict_batch_size = 8, 
                 do_train = True, do_eval = False, 
                 label_list = ["0", "1", "2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18"], 
                 max_seq_length = 64, 
                 data_dir='../datasets/semeval_relatioship_classification/',
                 output_dir = '../bert_output_entity_relationship/')

model = BertClassification(config)
# [___CELL_SEPARATOR___]
model.train()
# [___CELL_SEPARATOR___]
prediction = model.test()
# [___CELL_SEPARATOR___]
# Currently does not have support for Electra

model.export_model()
# [___CELL_SEPARATOR___]
# Currently does not have support for Electra

predictions = model.inference(test_filename = '../datasets/semeval_relatioship_classification/test.csv', batch_size = 256)
# [___CELL_SEPARATOR___]
model.text_inference(['The #ear# of the African $elephant$ is significantly larger--measuring 183 cm by 114 cm in the bush elephant.'])
# [___CELL_SEPARATOR___]
y_pred = [np.argmax(tup) for tup in predictions]
y = df_test.label
# [___CELL_SEPARATOR___]
metrics(y, y_pred)