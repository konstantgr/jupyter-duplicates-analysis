from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait, Select
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, StaleElementReferenceException
from joblib import Parallel, delayed
import json
import numpy as np
# [___CELL_SEPARATOR___]
def get_links(link):
    option = webdriver.ChromeOptions()
    option.add_argument('--incognito')
    option.add_argument('--disable-extensions')

    try:
        browser = webdriver.Chrome(executable_path='C:/Users/chris/ChromeDriver/chromedriver',
                                   chrome_options=option)
        timeout = 5
        browser.get(link)

        try:
            WebDriverWait(browser, timeout).until(EC.presence_of_element_located((By.XPATH, '//table[@class="items"]')))
        except TimeoutException:
            browser.quit()
            return [link]

        pages = browser.find_elements_by_xpath('//li[@class="page"]/a')
        i_links = [link]
        if len(pages) > 0:
            for page in pages:
                i_links.append(page.get_attribute('href'))
        browser.quit()
        return i_links

    except Exception as e:
        browser.quit()
        return [link]
# [___CELL_SEPARATOR___]
indices = ['4380', '3332', '26399', '47082', '63200', '28003', '8198', '18922', '65278', '227961',
               '80351', '64793', '28936', '29605', '35743', '38253', '58358', '39106', '48298', '21175',

               '50362', '44068', '3333', '35518', '35664', '31909', '65230', '34601', '39381', '32467',
               '44017', '57995', '30059', '35207', '38410', '26105', '44162', '38593', '41982', '44716',

               '20007', '102258', '15773', '69751', '85258', '44501', '33648', '96718','57500', '34691',
               '33947', '35208', '25727', '40605', '49723', '16631', '55769', '85605', '11', '21763',

               '67355', '42412', '47713', '9594', '76277', '67080', '18944', '25557', '54928', '184767',
               '26485', '39728', '43512', '51676', '52348', '29260', '39983', '111347', '34198', '102745']
links = []
for index in indices:
    links.append('https://www.transfermarkt.us/lionel-messi/verletzungen/spieler/{}'.format(index))

results = Parallel(n_jobs=-1)(delayed(get_links)(link) for link in links)

open('injurylinks.txt', 'w').close()
f = open('injurylinks.txt', 'a+')
for lists in results:
    for entry in lists:
        f.write(entry)
        f.write('\n')
f.close()
# [___CELL_SEPARATOR___]
def get_injury_data(link):
    option = webdriver.ChromeOptions()
    option.add_argument('--incognito')
    option.add_argument('--disable-extensions')

    try:
        browser = webdriver.Chrome(executable_path='C:/Users/chris/ChromeDriver/chromedriver',
                                   chrome_options=option)
        timeout=10
        browser.get(link)

        try:
            WebDriverWait(browser, timeout).until(EC.presence_of_element_located((By.XPATH, '//table[@class="items"]')))
        except TimeoutException:
            browser.close()
            return 'Timed Out with link {}'.format(link)

        name = browser.find_element_by_xpath('//h1[@itemprop="name"]').text
        injuries = browser.find_elements_by_xpath('//tbody/tr')
        injury_data = {'name': name}
        for injury in injuries:
            cells = injury.find_elements_by_tag_name('td')
            cell_data = [x.text for x in cells]
            if cell_data[0] in injury_data.keys():
                injury_data[cell_data[0]].append(cell_data[1:])
            else:
                injury_data[cell_data[0]] = [cell_data[1:]]

        browser.close()
        return injury_data


    except Exception as e:
        browser.close()
        return 'Error {} has happened with link {}'.format(str(e), link)
# [___CELL_SEPARATOR___]
g = open('injurylinks.txt', 'r')
links = g.read().splitlines()

data_players = Parallel(n_jobs=-1)(delayed(get_injury_data)(link) for link in links)
open('injurydata.json', 'w').close()
f = open('injurydata.json', 'a+')
for entry in data_players:
    json.dump(entry, f)
    f.write('\n')
f.close()
# [___CELL_SEPARATOR___]
g = open('injurydata.json', 'r')
players = g.read().splitlines()
player_table = []
player_dict = {}
for player_string in players:
    player = json.loads(player_string)
    print(player)
    if not player['name'] in player_dict.keys():
        player_dict[player['name']] = {}
    player_data = player_dict[player['name']]
    player_keys = player.keys()
    for player_key in player_keys:
        if not (player_key == 'name'):
            year = int(player_key.split('/')[0]) + 2000
            if year >= 2009:
                injuries = player[player_key]
                if year not in player_data.keys():
                    player_data[year] = {}
                    player_data[year]['n_injuries'] = len(injuries)
                    player_data[year]['n_major_injuries'] = 0
                    player_data[year]['n_games_missed'] = 0
                    player_data[year]['n_rested'] = 0
                else:
                    player_data[year]['n_injuries'] += len(injuries)
                for injury in injuries:
                    if injury[0] == 'Rest':
                        player_data[year]['n_injuries'] -= 1
                        player_data[year]['n_rested'] += 1
                    if int(injury[-2].split(' ')[0]) > 28:
                        player_data[year]['n_major_injuries'] += 1
                        player_data[year]['n_games_missed'] += int(injury[-1].replace('-', '0').replace('?', '-1'))

all_players = player_dict.keys()

for k in all_players:
    all_years = player_dict[k].keys()
    for y in all_years:
        p = player_dict[k][y]
        player_table.append([k, str(y), str(p['n_injuries']), str(p['n_major_injuries']),
                             str(p['n_games_missed']), str(p['n_rested'])])

h = open('player_injuries.csv', 'w')
for entry in player_table:
    h.write(','.join(entry))
    h.write('\n')
h.close()
# [___CELL_SEPARATOR___]
def get_whoscored_data(link):
    option = webdriver.ChromeOptions()
    option.add_argument('--incognito')
    option.add_argument('--disable-extensions')
    browser = webdriver.Chrome(executable_path='C:/Users/chris/ChromeDriver/chromedriver',
                               chrome_options=option)

    try:
        timeout=30
        browser.get(link)

        try:
            WebDriverWait(browser, timeout).until(EC.presence_of_element_located((
                By.ID, 'player-table-statistics-body')))
        except TimeoutException:
            browser.close()
            return None

        name = browser.find_element_by_xpath('//tr[@class=" selected"]/td/a[@class="player-link "]').text
        positions = browser.find_element_by_xpath('//tr[@class=" selected"]/td[@class="pos"]').text
        player_stats = {'name': name, 'positions': positions.split(',')}
        rows = browser.find_elements_by_xpath('//tbody[@id="player-table-statistics-body"]/tr')
        for row in rows[0:-1]:
            competition = row.find_element_by_xpath('.//td[@class="tournament"]/a').text.strip()
            if competition in ['SLL', 'EPL', 'GB', 'ISA']:
                cells = row.find_elements_by_tag_name('td')
                cells_data = [x.text for x in cells]
                player_stats[cells_data[0]] = [cells_data[1:]]
        browser.close()
        return player_stats





    except Exception as e:
        browser.close()
        return e
# [___CELL_SEPARATOR___]
indices = ['4564', '3859', '14260', '23736', '33386', '11119', '5583', '14296', '44055', '140771',
               '29400', '37099', '21488', '30110', '10103', '43194', '95822', '25820', '19792', '15438',

               '27213', '25363', '4511', '14102', '13756', '31772', '44721', '11386', '13812', '22732',
               '14091','44142', '29940', '41330', '82362', '12032', '30226', '13475', '52380', '20211',

               '25931', '15764', '14244', '80067', '18181', '44288', '44739', '20241', '20592', '78500',
               '106590', '43364', '11090', '136753', '69467', '23206', '64271', '33870', '15302', '18723',

               '8408', '22079', '29575', '10136', '30051', '79708', '12712', '9909', '26059', '100881',
               '23589', '21541', '43589', '80418', '133346', '9991', '20664', '128740', '14157', '93211']

links = []
for index in indices:
    links.append('https://www.whoscored.com/Players/{}/History/Lionel-Messi'.format(index))

results = Parallel(n_jobs=-1)(delayed(get_whoscored_data)(link) for link in links)

open('players_whoscored.json', 'w').close()
f = open('players_whoscored.json', 'a+')
for entry in results:
    json.dump(entry, f)
    f.write('\n')
f.close()
# [___CELL_SEPARATOR___]
g = open('players_whoscored.json', 'r')
players = g.read().splitlines()
player_table = []
for player_string in players:
    player = json.loads(player_string)
    player_data = [player['name']]
    pos = player['positions']
    if 'FW' in pos:
        player_data.append('Forward')
    elif '(' not in pos[0]:
        player_data.append("Midfielder")
    else:
        pos_1 = pos[0].split('(')[0]
        pos_2 = pos[0].split('(')[1].split(')')[0][0]
        if pos_1 == 'D':
            if pos_2 == 'R' or pos_2 == 'L':
                player_data.append('Full Back')
            else:
                player_data.append('Center Back')
        else:
            player_data.append('Midfielder')
    player_keys = player.keys()
    for key in player_keys:
        if key not in ['name', 'positions']:
            year_data = [key.split('/')[0], player[key][0][-1]]
            player_table.append(player_data + year_data)

h = open('player_ratings.csv', 'w')
for entry in player_table:
    h.write(','.join(entry))
    h.write('\n')
h.close()
# [___CELL_SEPARATOR___]
df_ratings = pd.read_csv('C:/Users/chris/Documents/Python36/COGS108/player_ratings.csv')
df_injuries = pd.read_csv('C:/Users/chris/Documents/Python36/COGS108/player_injuries.csv')
total_df = df_ratings.merge(df_injuries, on=['name', 'year'])
total_df.to_csv('total_df.csv')
# [___CELL_SEPARATOR___]
# Importing libraries that are relevant to create plots from csv data
# Display plots directly in the notebook instead of in a new window
%matplotlib inline

# Import libraries
import numpy as np
import pandas as pd
import seaborn as sns
import seaborn as sns
import statistics
# [___CELL_SEPARATOR___]
# Configure libraries
# The seaborn library makes plots look nicer
sns.set()
sns.set_context('talk')

# Displaying a set amout of rows when printing dataframe at a time
pd.options.display.max_rows = 7
pd.options.display.max_columns = 8

# Round decimals when displaying DataFrames
pd.set_option('precision', 2)
# [___CELL_SEPARATOR___]
df_soccer = pd.read_csv('total_df.csv', index_col = 0)
# [___CELL_SEPARATOR___]
df_soccer.drop(labels = ['name','year', 'rating', 'n_major_injuries', 'n_rested'], axis = 1, inplace = True)
# [___CELL_SEPARATOR___]
print(df_soccer)
# [___CELL_SEPARATOR___]
tot_injuries_forward = 0
tot_injuries_mid = 0
tot_injuries_cb = 0
tot_injuries_fb = 0
tot_forward = 0
tot_mid = 0
tot_cb = 0
tot_fb = 0
for i in range(0, len(df_soccer)):
    x = df_soccer['pos'][i]
    if x == 'Forward':
        tot_injuries_forward = tot_injuries_forward + df_soccer['n_injuries'][i]
        tot_forward = tot_forward + 1
    elif x == 'Midfielder':
        tot_injuries_mid = tot_injuries_mid + df_soccer['n_injuries'][i]
        tot_mid = tot_mid + 1
    elif x == 'Center Back':
        tot_injuries_cb = tot_injuries_cb + df_soccer['n_injuries'][i]
        tot_cb = tot_cb + 1
    elif x == 'Full Back':
        tot_injuries_fb = tot_injuries_fb + df_soccer['n_injuries'][i]
        tot_fb = tot_fb + 1
        
avg_injuries_forward = tot_injuries_forward/tot_forward
avg_injuries_mid = tot_injuries_mid/tot_mid
avg_injuries_cb = tot_injuries_cb/tot_cb
avg_injuries_fb = tot_injuries_fb/tot_fb
# [___CELL_SEPARATOR___]
position = ['Forward', 'Midfielder', 'Center Back', 'Full Back']
avg_injured_byPosition = [avg_injuries_forward, avg_injuries_mid, avg_injuries_cb, avg_injuries_fb]
df_injuries = pd.DataFrame({'Position': position, 'average injuries':avg_injured_byPosition})
plot = df_injuries.plot.bar(x='Position', y='average injuries', rot=0, figsize = (10,5))
plot.set_ylabel('Average Injuries')
# [___CELL_SEPARATOR___]
tot_missed_forward = 0
tot_missed_mid = 0
tot_missed_cb = 0
tot_missed_fb = 0
tot_forward = 0
tot_mid = 0
tot_cb = 0
tot_fb = 0
for i in range(0, len(df_soccer)):
    x = df_soccer['pos'][i]
    if x == 'Forward':
        tot_missed_forward = tot_missed_forward + df_soccer['n_games_missed'][i]
        tot_forward = tot_forward + 1
    elif x == 'Midfielder':
        tot_missed_mid = tot_missed_mid + df_soccer['n_games_missed'][i]
        tot_mid = tot_mid + 1
    elif x == 'Center Back':
        tot_missed_cb = tot_missed_cb + df_soccer['n_games_missed'][i]
        tot_cb = tot_cb + 1
    elif x == 'Full Back':
        tot_missed_fb = tot_missed_fb + df_soccer['n_games_missed'][i]
        tot_fb = tot_fb + 1
        
avg_missed_forward = tot_missed_forward/tot_forward
avg_missed_mid = tot_missed_mid/tot_mid
avg_missed_cb = tot_missed_cb/tot_cb
avg_missed_fb = tot_missed_fb/tot_fb
# [___CELL_SEPARATOR___]
position = ['Forward', 'Midfielder', 'Center Back', 'Full Back']
avg_missed_byPosition = [avg_missed_forward, avg_missed_mid, avg_missed_cb, avg_missed_fb]
df_injuries = pd.DataFrame({'Position': position, 'average missed':avg_missed_byPosition})
plot = df_injuries.plot.bar(x='Position', y='average missed', rot=0, figsize = (10,5))
plot.set_ylabel('Average Games Missed')
# [___CELL_SEPARATOR___]
df = pd.read_csv('total_df.csv')
# [___CELL_SEPARATOR___]
df = df.drop(['Unnamed: 0','name', 'pos', 'year', 'n_major_injuries', 'n_rested'], axis=1)
# [___CELL_SEPARATOR___]
df_one = df[df['n_injuries'] <= 1]
df_two = df[df['n_injuries'] == 2]
df_three = df[df['n_injuries'] == 3]
df_four = df[df['n_injuries'] == 4]
df_five = df[df['n_injuries'] == 5]
df_sixPlus = df[df['n_injuries'] >= 6]

df_lessThanTen = df.loc[(df['n_games_missed'] < 10)]
df_tenToTwenty = df.loc[(df['n_games_missed'] >= 10) & (df['n_games_missed'] < 20)]
df_twentyToThirty = df.loc[(df['n_games_missed'] >= 20) & (df['n_games_missed'] < 30)]
df_thirtyToFourty = df.loc[(df['n_games_missed'] >= 30) & (df['n_games_missed'] < 39)]
# [___CELL_SEPARATOR___]
mean_one = statistics.mean(df_one['rating'])
mean_two = statistics.mean(df_two['rating'])
mean_three = statistics.mean(df_three['rating'])
mean_four = statistics.mean(df_four['rating'])
mean_five = statistics.mean(df_five['rating'])
mean_sixPlus = statistics.mean(df_sixPlus['rating'])

mean_o = statistics.mean(df_lessThanTen['rating'])
mean_t = statistics.mean(df_tenToTwenty['rating'])
mean_th = statistics.mean(df_twentyToThirty['rating'])
mean_f = statistics.mean(df_thirtyToFourty['rating'])
# [___CELL_SEPARATOR___]
final_df = pd.DataFrame({'Number of Injuries':['>=1', '2', '3', '4', '5', '<=6'], 'Average Rating':[mean_one, mean_two, mean_three, mean_four, mean_five, mean_sixPlus]})
final_df2 = pd.DataFrame({'Number of Games Missed':['>10', '10 to 20','20 to 30', '30 to 40'], 'Average Rating':[mean_o, mean_t, mean_th, mean_f]})
# [___CELL_SEPARATOR___]
ax = final_df.plot(x='Number of Injuries', y='Average Rating', rot=0, xticks=final_df.index)
ax.set_ylabel("Average Rating")

ax2 = final_df2.plot(x='Number of Games Missed', y='Average Rating', rot=0, xticks=final_df2.index)
ax2.set_ylabel("Average Rating")