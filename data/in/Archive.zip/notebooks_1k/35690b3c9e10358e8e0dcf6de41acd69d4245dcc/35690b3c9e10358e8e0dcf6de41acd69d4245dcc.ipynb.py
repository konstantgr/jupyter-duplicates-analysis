%load_ext autoreload
%autoreload 2
from cord import ResearchPapers
# [___CELL_SEPARATOR___]
research_papers = ResearchPapers.from_data_dir()
# [___CELL_SEPARATOR___]
research_papers.search("antivirals", display='table')
# [___CELL_SEPARATOR___]
research_papers.searchbar('antivirals', display='html')
# [___CELL_SEPARATOR___]
import pandas as pd
pd.options.display.max_colwidth = 120