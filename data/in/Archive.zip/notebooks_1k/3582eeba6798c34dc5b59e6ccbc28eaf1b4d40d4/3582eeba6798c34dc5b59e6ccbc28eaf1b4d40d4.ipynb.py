import xarray as xr
import xclim as xc
# [___CELL_SEPARATOR___]
tasmax = xr.tutorial.open_dataset('air_temperature').air.resample(time='D').max(keep_attrs=True)
tasmax = tasmax.where(tasmax.time.dt.day % 10 != 0)
# [___CELL_SEPARATOR___]
tx_mean = xc.atmos.tx_mean(tasmax=tasmax, freq='MS') # compute monthly max tasmax
# [___CELL_SEPARATOR___]
xc.set_options(cf_compliance='log')

tx_mean = xc.atmos.tx_mean(tasmax=tasmax, freq='MS') # compute monthly max tasmax
# [___CELL_SEPARATOR___]
xc.set_options(check_missing='pct', missing_options={'pct': {'tolerance': 0.08}})

tx_mean = xc.atmos.tx_mean(tasmax=tasmax, freq='MS') # compute monthly max tasmax
tx_mean.sel(time='2013', lat=75, lon=200)
# [___CELL_SEPARATOR___]
with xc.set_options(check_missing="wmo"):
    tx_mean = xc.atmos.tx_mean(tasmax=tasmax, freq='MS') # compute monthly max tasmax
tx_mean.sel(time='2013', lat=75, lon=200)
# [___CELL_SEPARATOR___]
from xclim.core.missing import register_missing_method
from xclim.core.missing import MissingBase
from xclim.indices.run_length import longest_run

@register_missing_method("consecutive")
class MissingConsecutive(MissingBase):
    """Any period with more than max_n consecutive missing values is considered invalid"""
    def is_missing(self, null, count, max_n=5):
        return null.map(longest_run, dim="time") >= max_n

    @staticmethod
    def validate(max_n):
        return max_n > 0

# [___CELL_SEPARATOR___]
with xc.set_options(check_missing="consecutive", missing_options={'consecutive': {'max_n': 2}}):
    tx_mean = xc.atmos.tx_mean(tasmax=tasmax, freq='MS') # compute monthly max tasmax
tx_mean.sel(time='2013', lat=75, lon=200)