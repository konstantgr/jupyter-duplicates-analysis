%pylab inline
import pandas as pd
import plotnine as p
p.theme_set(p.theme_classic())

plt.rcParams['axes.spines.top'] = False
plt.rcParams['axes.spines.right'] = False
# [___CELL_SEPARATOR___]
counts = pd.read_parquet('mca_brain_counts.parquet')
# [___CELL_SEPARATOR___]
sample_info = pd.read_parquet('mca_brain_cell_info.parquet')
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
sample_info['super_cell_type'].value_counts()
# [___CELL_SEPARATOR___]
sub_samples = sample_info.query('super_cell_type in ["Microglia", "Astrocyte"]').copy()
# [___CELL_SEPARATOR___]
sub_counts = counts.reindex(index=sub_samples.index)
# [___CELL_SEPARATOR___]
sub_counts.shape
# [___CELL_SEPARATOR___]
sub_samples['is_astrocyte'] = sub_samples['super_cell_type'] == 'Astrocyte'
# [___CELL_SEPARATOR___]
import NaiveDE
# [___CELL_SEPARATOR___]
sub_samples['total_count'] = sub_counts.sum(1)
# [___CELL_SEPARATOR___]
figsize(11, 3)
sub_samples.total_count.hist(grid=False, fc='w', ec='k')
# [___CELL_SEPARATOR___]
sub_samples.total_count.median(), sub_samples.total_count.mean()
# [___CELL_SEPARATOR___]
print(sub_samples.head())
# [___CELL_SEPARATOR___]
%%time
lr_results = NaiveDE.lr_tests(sub_samples, np.log1p(sub_counts.T),
                              alt_model='C(is_astrocyte) + np.log(total_count) + 1',
                              null_model='np.log(total_count) + 1')
# [___CELL_SEPARATOR___]
lr_results.pval = lr_results.pval.clip_lower(lr_results.query('pval != 0')['pval'].min())
lr_results.qval = lr_results.qval.clip_lower(lr_results.query('qval != 0')['qval'].min())
# [___CELL_SEPARATOR___]
print(lr_results.sort_values('pval').head())
# [___CELL_SEPARATOR___]
example_genes = ['Apoe', 'Sparcl1', 'Tmsb4x', 'C1qa']
examples = lr_results.loc[example_genes]
# [___CELL_SEPARATOR___]
img = \
p.qplot('C(is_astrocyte)[T.True]', '-np.log10(pval)', lr_results) \
    + p.annotate('text',
                 x=examples['C(is_astrocyte)[T.True]'] + 0.33,
                 y=-np.log10(examples['pval']),
                 label=examples.index) \
    + p.labs(title='Brain cell data')
    
img.save('4.png', verbose=False)
img
# [___CELL_SEPARATOR___]
img = \
p.qplot('C(is_astrocyte)[T.True]', 'np.log(total_count)', lr_results) \
    + p.annotate('text',
                 x=examples['C(is_astrocyte)[T.True]'] + 0.33,
                 y=examples['np.log(total_count)'],
                 label=examples.index) \
    + p.labs(title='Brain cell data')

img.save('5.png', verbose=False)
img
# [___CELL_SEPARATOR___]
print(lr_results.sort_values('C(is_astrocyte)[T.True]').head())
# [___CELL_SEPARATOR___]
print(lr_results.sort_values('C(is_astrocyte)[T.True]').tail())
# [___CELL_SEPARATOR___]
img = \
p.qplot(sub_counts.sum(0).clip_lower(1), lr_results['np.log(total_count)'],
        log='x') \
    + p.labs(x='Gene count across dataset', y='np.log(total_count)', 
             title='Brain cell data')
    
img.save('6.png', verbose=False)
img
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
xx = np.linspace(np.log(sub_samples.total_count.min()),
                 np.log(sub_samples.total_count.max()))

def linres(gene):
    yy = \
    lr_results.loc[gene, 'np.log(total_count)'] * xx \
        + lr_results.loc[gene, 'Intercept']

    yy1 = np.exp(yy)
    yy2 = np.exp(yy + lr_results.loc[gene, 'C(is_astrocyte)[T.True]'])
    
    return yy1, yy2
# [___CELL_SEPARATOR___]
figsize(11, 3)


ax = plt.gca()
for i, gene in enumerate(['Apoe', 'Sparcl1', 'Tmsb4x', 'C1qa']):
    sub_samples['gene'] = counts[gene]
    
    plt.subplot(1, 4, i + 1, sharey=ax)
    if i == 0:
        plt.ylabel('Counts + 1')
    
    plt.loglog()

    plt.scatter(sub_samples.loc[~sub_samples.is_astrocyte]['total_count'],
                sub_samples.loc[~sub_samples.is_astrocyte]['gene'] + 1,
                c='grey', marker='o', label='Microglia')
    
    
    plt.scatter(sub_samples.loc[sub_samples.is_astrocyte]['total_count'],
                sub_samples.loc[sub_samples.is_astrocyte]['gene'] + 1,
                c='k', marker='x', label='Astrocyte')

    yy1, yy2 = linres(gene)

    plt.plot(np.exp(xx), yy1, c='w', lw=5)
    plt.plot(np.exp(xx), yy1, c='r', lw=3, ls=':')

    plt.plot(np.exp(xx), yy2, c='w', lw=5)
    plt.plot(np.exp(xx), yy2, c='r', lw=3)
    
    plt.title(gene)
    plt.xlabel('Total counts')

plt.legend(scatterpoints=3);
    
plt.tight_layout()
plt.savefig('7.png', bbox_inches='tight')
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
