import numpy as np
from scipy.misc import factorial
# [___CELL_SEPARATOR___]
N = 45
z = 3
theta = 1/6
# [___CELL_SEPARATOR___]
def binomial(theta, N, z):
    coef = factorial(N) / factorial(N-z) / factorial(z)
    p = coef * theta**z * (1 - theta)**(N-z)
    return p
# [___CELL_SEPARATOR___]
tail = np.arange(z+1)
tail
# [___CELL_SEPARATOR___]
p = binomial(theta, N, tail).sum() * 2 # left and right tail probability
p
# [___CELL_SEPARATOR___]
right_tail = np.arange(z, N)
p_right = z / right_tail * binomial(theta, right_tail, z)
p = (1 - p_right.sum()) * 2
p
# [___CELL_SEPARATOR___]
N = 45
z = 3
# [___CELL_SEPARATOR___]
left_tail = np.arange(z+1)
theta = np.arange(0.170, 0.190, 0.001)
# [___CELL_SEPARATOR___]
p = map(lambda t: binomial(t, N, left_tail).sum()*2, theta)
p = list(p)
# [___CELL_SEPARATOR___]
list(zip(theta, p))
# [___CELL_SEPARATOR___]
p = np.array(p)
p_idx = np.nonzero(p > 0.05)[0][-1]
theta1 = theta[p_idx]
p[p_idx], theta1
# [___CELL_SEPARATOR___]
right_tail = np.arange(z, N)
theta = np.arange(0.005, 0.020, 0.001)
# [___CELL_SEPARATOR___]
p = map(lambda t: binomial(t, N, right_tail).sum()*2, theta)
p = list(p)
# [___CELL_SEPARATOR___]
p = np.array(p)
p_idx = np.nonzero(p > 0.05)[0][0]
theta2 = theta[p_idx]
p[p_idx], theta2
# [___CELL_SEPARATOR___]
theta2, theta1
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
theta = np.arange(0.150, 0.160, 0.001)
# [___CELL_SEPARATOR___]
low_tail = np.arange(z, N)

def p_greated_than(theta):
    p_right = z / low_tail * binomial(theta, low_tail, z)
    p = (1 - p_right.sum()) * 2
    return p

p = map(p_greated_than, theta)
p = list(p)
# [___CELL_SEPARATOR___]
list(zip(theta, p))
# [___CELL_SEPARATOR___]
p_idx = np.nonzero(np.array(p) > 0.05)[0][-1]
theta1 = theta[p_idx]
p[p_idx], theta1
# [___CELL_SEPARATOR___]
theta = np.arange(0.005, 0.020, 0.001)
high_tail = np.arange(z+1)
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
high_tail = np.arange(z, N+1)

def p_less_than(theta):
    p = z / high_tail * binomial(theta, high_tail, z)
    p = 2 * p.sum()
    return p

p = map(p_less_than, theta)
p = list(p)
# [___CELL_SEPARATOR___]
p = np.array(p)
p_idx = np.nonzero(p > 0.05)[0][0]
theta2 = theta[p_idx]
p[p_idx], theta2
# [___CELL_SEPARATOR___]
theta2, theta1
# [___CELL_SEPARATOR___]
N = 45
z = 3
theta = 1/6
# [___CELL_SEPARATOR___]
Ns = np.arange(40, 51)
p_N = np.ones_like(Ns) / len(Ns)
# [___CELL_SEPARATOR___]
p_total = 0
for i, n in enumerate(Ns):
    # For the current `n`, determine the max z that is in the low tail:
    z_max = np.arange(0, n+1) / n
    z_max = np.nonzero(z_max <= z/N)[0][-1]
    low_tail = np.arange(0, z_max+1)
    p = 2*binomial(theta, n, low_tail).sum()
    p_total += p_N[i] * p
    print(n, p)
# [___CELL_SEPARATOR___]
p_total
# [___CELL_SEPARATOR___]
