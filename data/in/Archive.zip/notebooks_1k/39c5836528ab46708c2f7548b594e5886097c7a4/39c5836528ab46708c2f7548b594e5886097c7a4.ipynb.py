import openpathsampling as paths
# storage = 

# trajectory = storage.trajectory[0] 
# ensemble = 
# stateA = 
# stateB = 
# interface =
# [___CELL_SEPARATOR___]
# ensemble(trajectory)
# [___CELL_SEPARATOR___]
# ensemble.trajectory_summary(trajectory)
# [___CELL_SEPARATOR___]
# ensemble.trajectory_summary_str(trajectory)
# [___CELL_SEPARATOR___]
# trajectory.summarize_by_volumes({"A" : stateA, "B" : stateB, "I" : interface & ~stateA, "X" : ~interface & ~stateB})
# [___CELL_SEPARATOR___]
# trajectory.summarize_by_volumes({"A" : stateA, "B" : stateB, "X" : ~interface & ~stateB})
# [___CELL_SEPARATOR___]
# cv(trajectory)
# [___CELL_SEPARATOR___]
# trajectory.coordinates
# [___CELL_SEPARATOR___]
# trajectory.xyz
# [___CELL_SEPARATOR___]
# trajectory[5].coordinates
# [___CELL_SEPARATOR___]
#print ensemble
# [___CELL_SEPARATOR___]
#repr(ensemble)
# [___CELL_SEPARATOR___]
#ensemble.description()
# [___CELL_SEPARATOR___]
# redflags = paths.analysis.RedFlags(storage)
# [___CELL_SEPARATOR___]
# subflags = paths.analysis.RedFlags()
# subflags.check_zero_acceptance(storage.pathmovers, storage.steps)
# [___CELL_SEPARATOR___]
