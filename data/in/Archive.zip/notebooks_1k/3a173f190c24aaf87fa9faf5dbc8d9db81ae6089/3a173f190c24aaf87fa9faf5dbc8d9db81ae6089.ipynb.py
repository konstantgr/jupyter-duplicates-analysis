from pymongo import MongoClient

articles = MongoClient()['pmc']['articles']
# [___CELL_SEPARATOR___]
geonames = MongoClient()['geonames']['allCountries']

articles.create_index("index.infectious")

cursor = articles.find({'keywords.disease-ontology': {'$type': 'object'}})

articles.update_many({'keywords.disease-ontology': {'$type': 'object'}},
                     {'$set': {'index.infectious': 1}})
# [___CELL_SEPARATOR___]
print("Hello World")
# [___CELL_SEPARATOR___]
articles.create_index("meta.article-type")
# [___CELL_SEPARATOR___]
