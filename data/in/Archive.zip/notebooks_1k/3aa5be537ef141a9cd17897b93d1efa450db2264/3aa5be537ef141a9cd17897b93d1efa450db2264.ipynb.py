from pyiron import Project
# [___CELL_SEPARATOR___]
pr = Project('sqs')
# [___CELL_SEPARATOR___]
pr.remove_jobs(recursive=True)
# [___CELL_SEPARATOR___]
ni_fcc = pr.create_ase_bulk("Ni", cubic=True)
ni_fcc.set_repeat([2,2,2])
# [___CELL_SEPARATOR___]
job = pr.create_job(pr.job_type.SQSJob, "ni_cr_fcc_sqs")
job.structure = ni_fcc
job.input['mole_fractions'] = {"Ni": 0.8, 'Cr': 0.2}
job.input['iterations'] = 1e6
job.server.cores = 2
job.run()
# [___CELL_SEPARATOR___]
job["output"]
# [___CELL_SEPARATOR___]
job["output/cycle_time"]
# [___CELL_SEPARATOR___]
job["output/decmp"]
# [___CELL_SEPARATOR___]
job["output/iterations"]
# [___CELL_SEPARATOR___]
pr.job_table()