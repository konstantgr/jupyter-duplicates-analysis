from astropy.units import Quantity, pix, deg
from astropy.cosmology import Planck15
import numpy as np

# On first import, XGA checks the information in its config file, and updates its observation census, so it knows 
#  what observations are available and approximately where they are pointing.
from xga.sources import ExtendedSource, BaseSource, GalaxyCluster
from xga.sas import evselect_image, emosaic, eexpmap, evselect_spectrum
from xga.utils import xmm_sky, xmm_det
from xga.xspec import single_temp_apec
# [___CELL_SEPARATOR___]
# These are all Galaxy Clusters, but I'm using the ExtendedSource class because it requires fewer inputs 
#  for a simple demonstration

# Radius quantity used for demonstration of custom region - can be defined in degrees 
#  if a redshift is supplied to the source object.
cust_rad = Quantity(1000, 'kpc')

# My favourite test cluster, you can give the object a name, otherwise it'll generate one based on position
# You can also choose the cosmology you want to use for the analysis, it gets passed through to XSPEC too
a907 = ExtendedSource(149.5904478, -11.0628750, redshift=0.16, name="A907", cosmology=Planck15, load_products=True,
                      load_fits=True, custom_region_radius=cust_rad)

# This cluster I just pulled from the XCS-SDSS paper
# The default cosmology is actually Planck15, so I don't bother to set it here
rand_clust_0 = ExtendedSource(250.0833, 46.7075, 0.233, "XMMXCSJ164020.2+464227.1", load_products=True, 
                              load_fits=True)

# I don't bother setting a name for this one, to generate the auto generation of names
rand_clust_1 = ExtendedSource(216.5042, 37.8269, redshift=0.175, load_products=True, load_fits=True)

# Final random cluster, XMMXCSJ224154.6+173216.8
rand_clust_2 = ExtendedSource(340.4775000, 17.5380000, redshift=0.313, name="XMMXCSJ224154.6+173216.8", 
                              load_products=True, load_fits=True)
# [___CELL_SEPARATOR___]
a907.info()
rand_clust_0.info()
rand_clust_1.info()
rand_clust_2.info()
# [___CELL_SEPARATOR___]
# For instance, here I grab the mask that I'll use later to demonstrate the view method of image products
# This mask is generated from the region file, but if I used "custom" rather than "region" I could get a mask
#  for the custom region we defined earlier.

# This method returns both the source and background masks
example_source_mask, example_back_mask = a907.get_mask("region", "0201903501", "pn")

# Actually I will grab the custom region as well - this was made on the merged products, so won't be applicable to
#  non-merged images
example_custom_mask, example_custom_back_mask = a907.get_mask("custom", "0201903501", "pn")
# [___CELL_SEPARATOR___]
# Define the energy range you want the images in, if such an image already exists it will be detected
#  and won't be generated again

# The limits need to be astropy quantities, so they can be any energy unit, they'll be auto converted to eV and then
#  to XMM channels
l = Quantity(0.5, 'keV')
u = Quantity(4.0, 'keV')

# XGA is designed to deal with populations of objects, every generation can take N sources
# The way it executes SAS tasks will change dependant on the system you're running on. If you're on a local machine,
#  the SAS tasks will run in parallel, using 90% of your cores by default, if you're on an HPC it will 
#  submit jobs (but that isn't implemented yet).

# So, we generate the images in this new energy band for all our sources
all_sources = [a907, rand_clust_0, rand_clust_1, rand_clust_2]
# Once the images are generated, they are read into XGA 'Product' classes, and assigned to a source, which is 
#  why this returns the source objects afterwards.
all_sources = evselect_image(all_sources, l, u)

# But images are of limited use without exposure maps, so now we need them to!
# eexpmap first checks that there are appropriate cif files available, as they are required for 
#  exposure map generation, if there aren't, then it makes them
all_sources = eexpmap(all_sources, l, u)

# Generating exposure maps actually requires images as a base, so what if you decided you wanted exposure maps in 
#  a new energy band but you forgot to make the images first?
l = Quantity(4.0, 'keV')
u = Quantity(8.0, 'keV')
all_sources = eexpmap(all_sources, l, u)  
# All is fine! XGA checks that the required images exist, finds that they don't, and then generates them first.
# [___CELL_SEPARATOR___]
# Just going to use Abell 907 as an example, not the other three

# Every source object has a get_products method, which can be used to grab specific product types
a907_images = a907.get_products("image")
print("All A907 Image Objects:\n", a907_images, "\n")

# It can be used more specifically, just retrieving products from a specific observation and instrument
a907_specific_images = a907.get_products("image", obs_id="0201903501", inst="pn")
print("More specific A907 images:\n", a907_specific_images, "\n")

# There is a boolean flag that will return more information about the image with the actual object
a907_specific_images = a907.get_products("image", obs_id="0201903501", inst="pn", just_obj=False)
print("More specific A907 images with more information:\n", a907_specific_images, "\n")

# The extra information returned with that flag can also be accessed from an image object itself
example_image = a907.get_products("image", obs_id="0201903501", inst="pn")[0]
print(example_image.obs_id, example_image.instrument, example_image.energy_bounds, '\n')

# Each type of product has different abilities, don't have time to show them all off right now
# But one useful function of image objects is a coordinate conversion method that will go from any relevant 
#  XMM coordinates to pixels/radec and back again. I've also created custom astropy units for detector and sky XMM
#  coords.
# There will be a view() method to get a quick look at the image, but I haven't written that yet.

# When the SAS interface generates a product, it will parse the terminal output for errors and warnings.
#  Currently the default behaviour is to throw a Python error if there is a proper SAS error, but errors 
#  and warnings are stored within the product as well, for instance:
print("SAS Errors", example_image.sas_errors)
print("SAS Warnings", example_image.sas_warnings, '\n')

# And quickly, XGA ExpMap objects are pretty bare bones currently, but it can return the exposure at 
#  a specific coordinate! This example prints the exposure at the user supplied ra and dec.
example_expmap = a907.get_products("expmap", obs_id="0201903501", inst="pn")[0]
print("Exposure time at A907 initilisation coordinates:", example_expmap.get_exp(a907.ra_dec))
# [___CELL_SEPARATOR___]
# Having a look at the example image and exposure map
example_image.view()

example_expmap.view()
# [___CELL_SEPARATOR___]
# So first I plot the cross hair at the user supplied coordinates
example_image.view(cross_hair=a907.ra_dec)

# And then I plot the X-ray centroid measured from the combined ratemap
example_image.view(cross_hair=a907.peak)
# [___CELL_SEPARATOR___]
# First look at the source region
example_image.view(cross_hair=a907.peak, mask=example_source_mask)

# Then have a look at the corresponding background region that was auto generated 
example_image.view(cross_hair=a907.peak, mask=example_back_mask)
# [___CELL_SEPARATOR___]
# We can also look at the custom region mask, BUT ONLY ON THE MERGED IMAGE, as that 
#  was what the custom mask was made for.
merged_image = a907.get_products("combined_image")[0]

merged_image.view(cross_hair=a907.peak, mask=example_custom_mask)
merged_image.view(cross_hair=a907.peak, mask=example_custom_back_mask)
# [___CELL_SEPARATOR___]
# We'll just look at the combined ratemap for a quick demonstration
merged_ratemap = a907.get_products("combined_ratemap")[0]

# It doesn't look that different for on axis objects (like this one), but off axis the 
#  image and ratemap could look quite different
merged_ratemap.view(cross_hair=a907.peak, mask=example_custom_mask)
merged_ratemap.view(cross_hair=a907.peak, mask=example_custom_back_mask)
# [___CELL_SEPARATOR___]
# Giving evselect_spectrum reg_type="region" tells it to try and use the regions from region files to 
#  generate spectra. Each observation may have some variation in the size and positioning of the region file,
#  and some sources may not have had a long enough exposure for the source finder to detect the object at all.
all_sources = evselect_spectrum(all_sources, reg_type="region")
# [___CELL_SEPARATOR___]
# Generates A907 spectra for the custom region
a907 = evselect_spectrum(a907, reg_type="custom")
# [___CELL_SEPARATOR___]
# These are all clusters I've defined, so a single temperature apec is appropriate. 
# There are many many options that can be passed to this fit, but I won't go into them here
all_sources = single_temp_apec(all_sources, "region")

# This will fit the same model to the custom region for A907
a907 = single_temp_apec(a907, "custom")
# [___CELL_SEPARATOR___]
# Once a fit has been performed, extra information and plotting data is added to the relevant 
#  spectrum product objects
# This grabs a specific region file region spectrum, and demonstrates the view() method
example_region_spec = a907.get_products("spectrum", obs_id="0201903501", inst="pn", extra_key="region")[0]
example_region_spec.view()

# Here I get the equivalent A907 spectrum, but for the custom region we defined earlier.
example_custom_spec = a907.get_products("spectrum", obs_id="0201903501", inst="pn", extra_key="custom")[0]
example_custom_spec.view()
# [___CELL_SEPARATOR___]
# As each spectrum has its own luminosity calculated separately, luminosities can be retrieved from every spectrum
# This will return all lums associated with the single temperature apec model, and you can ask for a 
#  luminosity calculated within certain energy limits specifically if you want.

# This returns a dictionary with the different energy band luminosities that were measured (they can be changed
#  in the original fit call) - provides the result, then - and + errors
region_lums = example_region_spec.get_luminosities("tbabs*apec")
print('Region Luminosities:\n', region_lums, "\n")

custom_lums = example_custom_spec.get_luminosities("tbabs*apec")
print('Custom Region Luminosities:\n', custom_lums)
# [___CELL_SEPARATOR___]
# Retrieving the temperature from the region spectra fit - the GalaxyCluster 
#  class has a method just to get temperature, though this general one can still be used.
region_temp = a907.get_results("region", "tbabs*apec", "kT")
# This returns a numpy array with the temperature value, and its minus and plus errors

print("Temperature in region spectra is", "{0} -{1} +{2}".format(*region_temp))

# Do the same for the custom region
custom_temp = a907.get_results("custom", "tbabs*apec", "kT")

print("Temperature in custom spectra is", "{0} -{1} +{2}".format(*custom_temp))