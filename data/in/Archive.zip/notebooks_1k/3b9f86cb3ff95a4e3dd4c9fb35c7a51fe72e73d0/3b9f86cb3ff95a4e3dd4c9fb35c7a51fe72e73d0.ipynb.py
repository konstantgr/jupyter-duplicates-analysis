from dateutil.parser import parse 
import matplotlib as mpl
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import pandas as pd
from sklearn import metrics
from scipy import interpolate
# [___CELL_SEPARATOR___]
%run -i 'ts.py'
# [___CELL_SEPARATOR___]
# EXAMPLE OF TIME SERIE (DRUG DATASET)

# Import as Dataframe
df_drugs = pd.read_csv('https://raw.githubusercontent.com/selva86/datasets/master/a10.csv', parse_dates=['date'])
print(f'Shape: {df_drugs.shape}')
df_drugs.head()
# [___CELL_SEPARATOR___]
# EXAMPLE OF PANNEL DATA
# dataset source: https://github.com/rouseguy

df_pannel = pd.read_csv('https://raw.githubusercontent.com/selva86/datasets/master/MarketArrivals.csv')
df_pannel = df_pannel.loc[df_pannel.market=='MUMBAI', :]
df_pannel.head()
# [___CELL_SEPARATOR___]
# MANUALLY GENERATION OF TIME SERIE

def generate_time_series(batch_size, n_steps):
    """
    Generate a new time serie based on Batch_size and n_steps.
    Return a Numpy array and Pandas Dataframe
    """
    
    freq1, freq2, offset1, offset2 = np.random.rand(4, batch_size, 1)
    time = np.linspace(0,1,n_steps)
    series = 0.5 * np.sin((time-offset1) * (freq1*10+10)) #wave1
    series += 0.2 * np.sin((time-offset2) * (freq2 *20+20)) #wave2
    series += 0.1 * (np.random.rand(batch_size, n_steps) - 0.5) #noise
    
    serie_generated = series[...,np.newaxis].astype(np.float32)
    print(f"Serie Generated: {serie_generated.shape}")
    
    #Transform numpy array generated to dataframe
    df_gen = pd.DataFrame(data=serie_generated[0:1000,0:,0])    # values
    print(f'Shape: {df_gen.shape}')
    
    print("Generation Completed")
    
    return serie_generated, df_gen


#Generate an example time series (using function)
n_steps = 50
series, df_gen = generate_time_series(10000, n_steps + 1)

# [___CELL_SEPARATOR___]
# AIR PASSENGERS DATA

# The data contains a particular month and number of passengers travelling in that month. 
#In order to read the data as a time series, we have to pass special arguments to the read_csv command:
dateparse = lambda dates: pd.datetime.strptime(dates, '%Y-%m')
air_pass = pd.read_csv('AirPassengers.csv', parse_dates=['Month'], index_col='Month',date_parser=dateparse)

air_pass.columns = ['value']
date = air_pass.index
air_pass['date'] = date
air_pass.reset_index(drop=True, inplace=True)

print('\n Parsed Data:')
print(air_pass.head())
print(f'Data Shape: {air_pass.shape}') 
# [___CELL_SEPARATOR___]
# FPP R PACKAGE EXAMPLE DATA

# Time series data source: fpp pacakge in R.
df = pd.read_csv('a10.csv', parse_dates=['date'], index_col='date')
df_missing = pd.read_csv('a10-missing.csv', parse_dates=['date'], index_col='date')

print(f'Full data: {df.shape}')
print(f'Manual Missing data: {df_missing.shape}')
# [___CELL_SEPARATOR___]
# Draw Plot
def plot_df(df, x, y, title="", xlabel='Date', ylabel='Value', dpi=100):
    plt.figure(figsize=(16,5), dpi=dpi)
    plt.plot(x, y, color='tab:red')
    plt.gca().set(title=title, xlabel=xlabel, ylabel=ylabel)
    plt.show()

plot_df(df, x=df.index, y=df.value, title='Monthly anti-diabetic drug sales in Australia from 1992 to 2008.')
# [___CELL_SEPARATOR___]
# Visualize Air Passengers Time Series
# Plot
x = air_pass['date'].values
y1 = air_pass['value'].values

fig, ax = plt.subplots(1, 1, figsize=(16,5), dpi= 120)
plt.fill_between(x, y1=y1, y2=-y1, alpha=0.5, linewidth=2, color='seagreen')
plt.ylim(-800, 800)
plt.title('Air Passengers (Two Side View)', fontsize=16)
plt.hlines(y=0, xmin=np.min(air_pass.date), xmax=np.max(air_pass.date), linewidth=.5)
plt.show()

# [___CELL_SEPARATOR___]
## DEFINE THE PLOT

fig, axes = plt.subplots(5, 1, sharex=True, figsize=(16, 16))
plt.rcParams.update({'xtick.bottom' : False})


## 1. ACTUAL DATA

df.value.plot(title='Actual', ax=axes[0], label='Actual', color='red', style=".-")
df_missing.plot(title='Actual', ax=axes[0], label='Actual', color='green', style=".-")
axes[0].legend(["Available Data","Missing Data"])

## 2. FORWARD FILL (CLASSIC)

df_ffill = df_missing.ffill()

error = np.round(metrics.mean_squared_error(df['value'], df_ffill['value']), 2)

df_ffill['value'].plot(title='Forward Fill (MSE: ' + str(error) +")", ax=axes[1], label='Forward Fill', style=".-")


## 3. BACKWARD FILL (CLASSIC)

df_bfill = df_missing.bfill()

error = np.round(metrics.mean_squared_error(df['value'], df_bfill['value']), 2)

df_bfill['value'].plot(title="Backward Fill (MSE: " + str(error) +")", ax=axes[2], label='Back Fill', color='firebrick', style=".-")


## 4. LINEAR INTERPOLATION
df_linear = df_missing.copy()

df_linear['rownum'] = np.arange(df_linear.shape[0])

df_nona = df_linear.dropna(subset = ['value'])

f = interpolate.interp1d(df_nona['rownum'], df_nona['value'])

df_linear['linear_fill'] = f(df_linear['rownum'])
error = np.round(metrics.mean_squared_error(df['value'], df_linear['linear_fill']), 2)

df_linear['linear_fill'].plot(title="Linear Fill (MSE: " + str(error) +")", ax=axes[3], label='Cubic Fill', color='brown', style=".-")



## 5. CUBIC INTERPOLATION
df_cubic = df_missing.copy()

f2 = interpolate.interp1d(df_nona['rownum'], df_nona['value'], kind='cubic')

df_cubic['cubic_fill'] = f2(df_linear['rownum'])

error = np.round(metrics.mean_squared_error(df['value'], df_cubic['cubic_fill']), 2)

df_cubic['cubic_fill'].plot(title="Cubic Fill (MSE: " + str(error) +")", ax=axes[4], label='Cubic Fill', color='red', style=".-")


# [___CELL_SEPARATOR___]
# Interpolation References:
# https://docs.scipy.org/doc/scipy/reference/tutorial/interpolate.html
# https://docs.scipy.org/doc/scipy/reference/interpolate.html
# [___CELL_SEPARATOR___]
df.index
# [___CELL_SEPARATOR___]
result_gaps = find_timegaps(df_missing.index,'30 days',gap_comparison='equal',divergent_only=True)
print('Result Gaps:',result_gaps.head())
print(f'\nShape: {result_gaps.shape}')
# [___CELL_SEPARATOR___]
pd.infer_freq(df.index)
# [___CELL_SEPARATOR___]
plot_interval(df,['value'],'month')
# [___CELL_SEPARATOR___]
##GENERATE SET OF DATA TO LAG
np.random.seed(0) # ensures the same set of random numbers are generated
date = ['2019-01-01']*3 + ['2019-01-02']*3 + ['2019-01-03']*3
var1, var2 = np.random.randn(9), np.random.randn(9)*20 
group = ["group1", "group2", "group3"]*3 # to assign the groups for the multiple group case

df_manygrp = pd.DataFrame({"date": date, "group":group, "var1": var1}) # one var, many groups
df_combo = pd.DataFrame({"date": date, "group":group, "var1": var1, "var2": var2}) # many vars, many groups
df_onegrp = df_manygrp[df_manygrp["group"]=="group1"] # one var, one group

for d in [df_onegrp, df_manygrp, df_combo]: # loop to apply the change to both dfs
    d["date"] = pd.to_datetime(d['date'])
    print("Column changed to: ", d.date.dtype.name)

    
print(f'Manygrp: {df_manygrp.shape}')
print(f'Combo: {df_combo.shape}')
print(f'OneGrp: {df_onegrp.shape}')
print('\n',df_manygrp.head())
print('\n',df_combo.head())
print('\n',df_onegrp.head())
# [___CELL_SEPARATOR___]
df_onegrp
# [___CELL_SEPARATOR___]
df_onegrp.set_index(["date"]).shift(1)
# [___CELL_SEPARATOR___]
df_manygrp
# [___CELL_SEPARATOR___]
df_mlt = df_manygrp.set_index(["date", "group"]) # index
df_mlt = df.unstack().shift(1)          # pull out the groups, shift with lag step=1
df_mlt = df.stack(dropna=False);df       # stack the groups back, keep the missing values

#Rearrange index data
df_mlt.reset_index().sort_values("group")
# [___CELL_SEPARATOR___]
# Group the data
grouped_df = df_combo.groupby(["group"])
# [___CELL_SEPARATOR___]
# Make Function with assign and method-chaining:
def lag_by_group(key, value_df):
    df = value_df.assign(group = key) # this pandas method returns a copy of the df, with group columns assigned the key value
    return (df.sort_values(by=["date"], ascending=True)
        .set_index(["date"])
        .shift(1)
               ) # the parenthesis allow you to chain methods and avoid intermediate variable assignment
# [___CELL_SEPARATOR___]
# Apply function to each group using list comprehension then concatenate vertically:
dflist = [lag_by_group(g, grouped_df.get_group(g)) for g in grouped_df.groups.keys()]
pd.concat(dflist, axis=0).reset_index()
# [___CELL_SEPARATOR___]
from pandas.plotting import lag_plot
plt.rcParams.update({'ytick.left' : False, 'axes.titlepad':10})

# Import
ss = pd.read_csv('https://raw.githubusercontent.com/selva86/datasets/master/sunspotarea.csv')


# Plot
fig, axes = plt.subplots(1, 4, figsize=(11,5), sharex=True, sharey=True, dpi=100)
for i, ax in enumerate(axes.flatten()[:4]):
    lag_plot(ss.value, lag=i+1, ax=ax, c='firebrick')
    ax.set_title('Lag ' + str(i+1))

fig.suptitle('Lag Plots of Sun Spots Area \n(Points get wide and scattered with increasing lag -> lesser correlation)\n', y=1.15)    

fig, axes = plt.subplots(1, 4, figsize=(11,5), sharex=True, sharey=True, dpi=100)
for i, ax in enumerate(axes.flatten()[:4]):
    lag_plot(df_drugs.value, lag=i+1, ax=ax, c='firebrick')
    ax.set_title('Lag ' + str(i+1))

fig.suptitle('Lag Plots of Drug Sales', y=1.05)    
plt.show()
# [___CELL_SEPARATOR___]
plt.plot(df.index, df.values)
# [___CELL_SEPARATOR___]
from statsmodels.tsa.stattools import acf, pacf
from statsmodels.graphics.tsaplots import plot_acf, plot_pacf

# Calculate ACF and PACF upto 50 lags
# acf_50 = acf(df.value, nlags=50)
# pacf_50 = pacf(df.value, nlags=50)

# Draw Plot
fig, axes = plt.subplots(1,2,figsize=(20,6), dpi= 120)
plot_acf(df.value.tolist(), lags=50, ax=axes[0])
plot_pacf(df.value.tolist(), lags=50, ax=axes[1])
plt.show()
# [___CELL_SEPARATOR___]
# Prepare data

df_drugs['year'] = [d.year for d in df_drugs.date]
df_drugs['month'] = [d.strftime('%b') for d in df_drugs.date]
years = df_drugs['year'].unique()
# [___CELL_SEPARATOR___]
# Prep Colors
np.random.seed(100)
mycolors = np.random.choice(list(mpl.colors.XKCD_COLORS.keys()), len(years), replace=False)

# Draw Plot
plt.figure(figsize=(14,10), dpi= 100)
for i, y in enumerate(years):
    if i > 0:        
        plt.plot('month', 'value', data=df_drugs.loc[df_drugs.year==y, :], color=mycolors[i], label=y)
        plt.text(df_drugs.loc[df_drugs.year==y, :].shape[0]-.9, df_drugs.loc[df_drugs.year==y, 'value'][-1:].values[0], y, fontsize=12, color=mycolors[i])

# Decoration
plt.gca().set(xlim=(-0.3, 11), ylim=(2, 30), ylabel='$Drug Sales$', xlabel='$Month$')
plt.yticks(fontsize=12, alpha=.7)
plt.title("Seasonal Plot of Drug Sales Time Series", fontsize=20)
plt.show()
# [___CELL_SEPARATOR___]
# Draw Plot
fig, axes = plt.subplots(1, 2, figsize=(20,7), dpi= 80)
sns.boxplot(x='year', y='value', data=df_drugs, ax=axes[0])
sns.boxplot(x='month', y='value', data=df_drugs.loc[~df_drugs.year.isin([1991, 2008]), :])

# Set Title
axes[0].set_title('Year-wise Box Plot\n(The Trend)', fontsize=18); 
axes[1].set_title('Month-wise Box Plot\n(The Seasonality)', fontsize=18)
plt.show()
# [___CELL_SEPARATOR___]
from pylab import rcParams
import statsmodels.api as sm
# [___CELL_SEPARATOR___]
# Modify the data
y = df_drugs.copy()
y.index = y['date']
y = y.drop(['date','year','month'],axis=1)
# [___CELL_SEPARATOR___]
#Decompose the serie
rcParams['figure.figsize'] = 18, 8
decomposition = sm.tsa.seasonal_decompose(y, model='additive')
fig = decomposition.plot()
plt.show()
# [___CELL_SEPARATOR___]
fig, axes = plt.subplots(1,3, figsize=(20,4), dpi=100)
pd.read_csv('https://raw.githubusercontent.com/selva86/datasets/master/guinearice.csv', parse_dates=['date'], index_col='date').plot(title='Trend Only', legend=False, ax=axes[0])

pd.read_csv('https://raw.githubusercontent.com/selva86/datasets/master/sunspotarea.csv', parse_dates=['date'], index_col='date').plot(title='Seasonality Only', legend=False, ax=axes[1])

pd.read_csv('https://raw.githubusercontent.com/selva86/datasets/master/AirPassengers.csv', parse_dates=['date'], index_col='date').plot(title='Trend and Seasonality', legend=False, ax=axes[2])
# [___CELL_SEPARATOR___]
from statsmodels.tsa.seasonal import seasonal_decompose
from dateutil.parser import parse

# Multiplicative Decomposition 
result_mul = seasonal_decompose(y['value'], model='multiplicative', extrapolate_trend='freq')

# Additive Decomposition
result_add = seasonal_decompose(y['value'], model='additive', extrapolate_trend='freq')

# Plot
plt.rcParams.update({'figure.figsize': (10,10)})
result_mul.plot().suptitle('Multiplicative Decompose', fontsize=22)
result_add.plot().suptitle('Additive Decompose', fontsize=22)
plt.show()
# [___CELL_SEPARATOR___]
# Extract the Components ----
# Actual Values = Product of (Seasonal * Trend * Resid)
df_reconstructed = pd.concat([result_mul.seasonal, result_mul.trend, result_mul.resid, result_mul.observed], axis=1)
df_reconstructed.columns = ['seas', 'trend', 'resid', 'actual_values']
print(df_reconstructed.head())
print(df_reconstructed.tail())
# [___CELL_SEPARATOR___]
x = air_pass['date'].values
y1 = air_pass['value'].values
plt.plot(y1)
# [___CELL_SEPARATOR___]
from statsmodels.tsa.stattools import adfuller

def test_stationarity(timeseries):
    """
    Check Stationariety of time series.
    Please use np.array or pd.series as Input with your TS data only
    """
    #Convert numpy array to pandas serie
    if type(timeseries) is np.ndarray:
        df_timeseries = pd.Series(timeseries) 
        
    try:
        #Determing rolling statistics
        rolmean = df_timeseries.rolling(window=12).mean()
        rolstd = df_timeseries.rolling(window=12).std()

        #Plot rolling statistics:
        orig = plt.plot(timeseries, color='blue',label='Original')
        mean = plt.plot(rolmean, color='red', label='Rolling Mean')
        std = plt.plot(rolstd, color='black', label = 'Rolling Std')
        plt.legend(loc='best')
        plt.title('Rolling Mean & Standard Deviation')
        plt.show(block=False)

        #Perform Dickey-Fuller test:
        print('Results of Dickey-Fuller Test:')

        dftest = adfuller(timeseries, autolag='AIC')
        dfoutput = pd.Series(dftest[0:4], index=['Test Statistic','p-value','#Lags Used','Number of Observations Used'])
        for key,value in dftest[4].items():
            dfoutput['Critical Value (%s)'%key] = value
        
        # print(dfoutput)
    
        return dftest, dfoutput
    except Exception as message:
        print(f"Impossible to calc the stationariery of your TS: {message}")
        return None, None
# [___CELL_SEPARATOR___]
dftest, dfoutput = test_stationarity(y1)
dfoutput
# [___CELL_SEPARATOR___]
randvals = np.random.randn(1000)
pd.Series(randvals).plot(title='Random White Noise', color='k')
# [___CELL_SEPARATOR___]
#This is our TS
df_detrend = df_drugs.copy()
df_detrend.index = df_detrend.date
df_detrend = df_detrend.drop('date',axis=1)
plt.plot(df_detrend.index, df_detrend.value)
# [___CELL_SEPARATOR___]
from scipy import signal
from statsmodels.tsa.seasonal import seasonal_decompose
# [___CELL_SEPARATOR___]
# Using scipy: Subtract the line of best fit

detrended = signal.detrend(df_detrend.value.values)
plt.plot(df_detrend.index, detrended)
plt.title('Drug Sales detrended by subtracting the least squares fit', fontsize=16)
# [___CELL_SEPARATOR___]
# Using statmodels: Subtracting the Trend Component.

result_mul = seasonal_decompose(df_detrend['value'], model='multiplicative', extrapolate_trend='freq')
detrended = df_detrend.value.values - result_mul.trend
plt.plot(df_detrend.index, detrended)
plt.title('Drug Sales detrended by subtracting the trend component (multiplicative)', fontsize=16)
# [___CELL_SEPARATOR___]
# Using statmodels: Subtracting the Trend Component.

result_mul = seasonal_decompose(df_detrend['value'], model='additive', extrapolate_trend='freq')
detrended = df_detrend.value.values - result_mul.trend
plt.plot(df_detrend.index, detrended)
plt.title('Drug Sales detrended by subtracting the trend component (additive)', fontsize=16)
# [___CELL_SEPARATOR___]
plt.plot(df_detrend.value)
# [___CELL_SEPARATOR___]
# Subtracting the Trend Component.
df_deseason = df_detrend.copy()

# Time Series Decomposition
result_mul = seasonal_decompose(df_deseason['value'], model='multiplicative', extrapolate_trend='freq')

# Deseasonalize
deseasonalized = df_deseason.value.values / result_mul.seasonal

# Plot
plt.plot(df_deseason.index, deseasonalized)
plt.title('Drug Sales Deseasonalized', fontsize=16)
plt.plot()
# [___CELL_SEPARATOR___]
from statsmodels.nonparametric.smoothers_lowess import lowess

plt.rcParams.update({'xtick.bottom' : False, 'axes.titlepad':5})

# Import
df_smoote = df.copy()

# 1. Moving Average
df_ma = df_smoote.value.rolling(3, center=True, closed='both').mean()

# 2. Loess Smoothing (5% and 15%)
df_loess_5 = pd.DataFrame(lowess(df_smoote.value, np.arange(len(df_smoote.value)), frac=0.05)[:, 1], index=df_smoote.index, columns=['value'])
df_loess_15 = pd.DataFrame(lowess(df_smoote.value, np.arange(len(df_smoote.value)), frac=0.15)[:, 1], index=df_smoote.index, columns=['value'])

# Plot
fig, axes = plt.subplots(4,1, figsize=(12, 8), sharex=True, dpi=100)
df_smoote['value'].plot(ax=axes[0], color='k', title='Original Series')
df_loess_5['value'].plot(ax=axes[1], title='Loess Smoothed 5%')
df_loess_15['value'].plot(ax=axes[2], title='Loess Smoothed 15%')
df_ma.plot(ax=axes[3], title='Moving Average (3)')
fig.suptitle('TS Smooting', y=0.95, fontsize=14)
plt.show()
# [___CELL_SEPARATOR___]
# https://en.wikipedia.org/wiki/Approximate_entropy

rand_small = np.random.randint(0, 100, size=36)
rand_big = np.random.randint(0, 100, size=136)

def ApEn(U, m, r):
    """Compute Aproximate entropy"""
    def _maxdist(x_i, x_j):
        return max([abs(ua - va) for ua, va in zip(x_i, x_j)])

    def _phi(m):
        x = [[U[j] for j in range(i, i + m - 1 + 1)] for i in range(N - m + 1)]
        C = [len([1 for x_j in x if _maxdist(x_i, x_j) <= r]) / (N - m + 1.0) for x_i in x]
        return (N - m + 1.0)**(-1) * sum(np.log(C))

    N = len(U)
    return abs(_phi(m+1) - _phi(m))

print(f'Dataset ss: {ApEn(ss.value, m=2, r=0.2*np.std(ss.value))}')     # 0.651
print(f'Dataset df: {ApEn(df.value, m=2, r=0.2*np.std(df.value))}')   # 0.537
print(ApEn(rand_small, m=2, r=0.2*np.std(rand_small))) # 0.143
print(ApEn(rand_big, m=2, r=0.2*np.std(rand_big)))     # 0.716
# [___CELL_SEPARATOR___]
# https://en.wikipedia.org/wiki/Sample_entropy

rand_small = np.random.randint(0, 100, size=36)
rand_big = np.random.randint(0, 100, size=136)

def SampEn(U, m, r):
    """Compute Sample entropy"""
    def _maxdist(x_i, x_j):
        return max([abs(ua - va) for ua, va in zip(x_i, x_j)])

    def _phi(m):
        x = [[U[j] for j in range(i, i + m - 1 + 1)] for i in range(N - m + 1)]
        C = [len([1 for j in range(len(x)) if i != j and _maxdist(x[i], x[j]) <= r]) for i in range(len(x))]
        return sum(C)

    N = len(U)
    return -np.log(_phi(m+1) / _phi(m))

print(SampEn(ss.value, m=2, r=0.2*np.std(ss.value)))      # 0.78
print(SampEn(df.value, m=2, r=0.2*np.std(df.value)))    # 0.41
print(SampEn(rand_small, m=2, r=0.2*np.std(rand_small)))  # 1.79
print(SampEn(rand_big, m=2, r=0.2*np.std(rand_big)))      # 2.42
# [___CELL_SEPARATOR___]
complete_date = df.index
month = pd.DatetimeIndex(complete_date).month
year = pd.DatetimeIndex(complete_date).year

df_features = df.copy()
df_features = df_features.reset_index()
df_features['month'] = month
df_features['year'] = year
df_features = df_features.drop('date',axis=1)
df_features.head()
# [___CELL_SEPARATOR___]
df_features.month.plot();
# [___CELL_SEPARATOR___]
time_frame = 12 #months
df_features['sin_time'] = np.sin(2*np.pi*df_features.month/time_frame)
df_features['cos_time'] = np.cos(2*np.pi*df_features.month/time_frame)
df_features.head()
# [___CELL_SEPARATOR___]
df_features.sin_time.plot()
# [___CELL_SEPARATOR___]
df_features.plot.scatter('sin_time','cos_time').set_aspect('equal');