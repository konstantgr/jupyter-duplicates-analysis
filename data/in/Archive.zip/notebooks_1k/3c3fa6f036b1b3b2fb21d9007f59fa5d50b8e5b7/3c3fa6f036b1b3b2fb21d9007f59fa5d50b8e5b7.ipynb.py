import os, warnings, shutil
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from tokenizers import ByteLevelBPETokenizer
from sklearn.utils import shuffle
from sklearn.model_selection import StratifiedKFold
from tweet_utility_scripts import *
from tweet_utility_preprocess_roberta_scripts_aux import *
import tweet_utility_preprocess_roberta_scripts_text as preprocess_text


SEED = 0
warnings.filterwarnings("ignore")
# [___CELL_SEPARATOR___]
MAX_LEN = 64
base_path = '/kaggle/input/qa-transformers/roberta/'
vocab_path = base_path + 'roberta-base-vocab.json'
merges_path = base_path + 'roberta-base-merges.txt'

tokenizer = ByteLevelBPETokenizer(vocab_file=vocab_path, merges_file=merges_path, lowercase=True, add_prefix_space=True)
tokenizer.save('./')
# [___CELL_SEPARATOR___]
train_df = pd.read_csv('/kaggle/input/tweet-sentiment-extraction/train.csv')

# pre-process
train_df.dropna(inplace=True)
train_df = train_df.reset_index()
train_df.drop('index', axis=1, inplace=True)
train_df["text"] = train_df["text"].apply(lambda x: x.strip())
train_df["selected_text"] = train_df["selected_text"].apply(lambda x: x.strip())
train_df["text"] = train_df["text"].apply(lambda x: x.lower())
train_df["selected_text"] = train_df["selected_text"].apply(lambda x: x.lower())

train_df['jaccard'] = train_df.apply(lambda x: jaccard(x['text'], x['selected_text']), axis=1)
train_df['text_len'] = train_df['text'].apply(lambda x : len(x))
train_df['text_wordCnt'] = train_df['text'].apply(lambda x : len(x.split(' ')))
train_df['text_tokenCnt'] = train_df['text'].apply(lambda x : len(tokenizer.encode(x).ids))
train_df['selected_text_len'] = train_df['selected_text'].apply(lambda x : len(x))
train_df['selected_text_wordCnt'] = train_df['selected_text'].apply(lambda x : len(x.split(' ')))
train_df['selected_text_tokenCnt'] = train_df['selected_text'].apply(lambda x : len(tokenizer.encode(x).ids))

sentiment_cols = train_df['sentiment'].unique()

print('Train samples: %s' % len(train_df))
display(train_df.head())
display(train_df.describe())
# [___CELL_SEPARATOR___]
for idx in range(10):
    print('\nRow %d' % idx)
    max_seq_len = 32
    text = train_df['text'].values[idx]
    selected_text = train_df['selected_text'].values[idx]
    question = train_df['sentiment'].values[idx]
    
    _,  (target_start, target_end, _) = preprocess_roberta(' ' + text, selected_text, ' ' + question, tokenizer, max_seq_len)
    
    question_encoded = tokenizer.encode(question).ids
    question_size = len(question_encoded) + 3
    
    decoded_text = decode(target_start.argmax(), target_end.argmax(), text, question_size, tokenizer)
    
    print('text         : "%s"' % text)
    print('selected_text: "%s"' % selected_text)
    print('decoded_text : "%s"' % decoded_text)
    
    assert selected_text == decoded_text
# [___CELL_SEPARATOR___]
for idx in range(5):
    print('\nRow %d' % idx)
    max_seq_len = 24
    text = train_df['text'].values[idx]
    selected_text = train_df['selected_text'].values[idx]
    question = train_df['sentiment'].values[idx]
    jaccard = train_df['jaccard'].values[idx]
    selected_text_wordCnt = train_df['selected_text_wordCnt'].values[idx]
    
    x_train, x_train_aux, x_train_aux_2, y_train, y_train_mask, y_train_aux = get_data(train_df[idx:idx+1], tokenizer, max_seq_len, 
                                                                         preprocess_fn=preprocess_roberta)
    
    print('text          : "%s"'   % text)
    print('jaccard       : "%.4f"' % jaccard)
    print('sentiment     : "%s"'   % question)
    print('word count    : "%d"'   % selected_text_wordCnt)
    
    print('input_ids     : "%s"'   % x_train[0][0])
    print('attention_mask: "%s"'   % x_train[1][0])
    print('sentiment     : "%d"'   % x_train_aux[0])
    print('sentiment OHE : "%s"'   % x_train_aux_2[0])
    
    print('selected_text : "%s"'   % selected_text)
    print('start         : "%s"'   % y_train[0][0])
    print('end           : "%s"'   % y_train[1][0])
    print('mask          : "%s"'   % y_train_mask[0])
    print('jaccard       : "%.4f"' % y_train_aux[0][0])
    print('word count    : "%d"'   % y_train_aux[1][0])
    
    assert len(x_train) == 2
    assert len(x_train_aux) == 1
    assert len(x_train_aux_2) == 1
    assert len(y_train) == 2
    assert len(y_train_mask) == 1
    assert len(y_train_aux) == 3
    
    assert len(x_train[0][0]) == len(x_train[1][0]) == max_seq_len
    assert len(y_train[0][0]) == len(y_train[1][0]) == len(y_train_mask[0]) == max_seq_len
# [___CELL_SEPARATOR___]
folds = StratifiedKFold(n_splits=5, shuffle=True, random_state=SEED)

for fold_n, (train_idx, val_idx) in enumerate(folds.split(train_df, train_df['sentiment'])):
    print('Fold: %s, Train size: %s, Validation size %s' % (fold_n+1, len(train_idx), len(val_idx)))
    train_df[('fold_%s' % str(fold_n+1))] = 0
    train_df[('fold_%s' % str(fold_n+1))].loc[train_idx] = 'train'
    train_df[('fold_%s' % str(fold_n+1))].loc[val_idx] = 'validation'
# [___CELL_SEPARATOR___]
for fold_n in range(folds.n_splits):
    fold_n += 1
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(20, 8.7))
    fig.suptitle('Fold %s' % fold_n, fontsize=22)    
    sns.countplot(x="sentiment", data=train_df[train_df[('fold_%s' % fold_n)] == 'train'], palette="GnBu_d", order=sentiment_cols, ax=ax1).set_title('Train')
    sns.countplot(x="sentiment", data=train_df[train_df[('fold_%s' % fold_n)] == 'validation'], palette="GnBu_d", order=sentiment_cols, ax=ax2).set_title('Validation')
    sns.despine()
    plt.show()
# [___CELL_SEPARATOR___]
for fold_n in range(folds.n_splits):
    fold_n += 1
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(20, 8.7), sharex=True)
    fig.suptitle('Fold %s' % fold_n, fontsize=22)
    sns.distplot(train_df[train_df[('fold_%s' % fold_n)] == 'train']['text_wordCnt'], ax=ax1).set_title("Train")
    sns.distplot(train_df[train_df[('fold_%s' % fold_n)] == 'validation']['text_wordCnt'], ax=ax2).set_title("Validation")
    sns.despine()
    plt.show()
# [___CELL_SEPARATOR___]
train_df.to_csv('5-fold.csv', index=False)
display(train_df.head())

for fold_n in range(folds.n_splits):
    fold_n += 1
    
    base_path = 'fold_%d/' % fold_n
    # Create dir
    os.makedirs(base_path)
    
    x_train, x_train_aux, x_train_aux_2, y_train, y_train_mask, y_train_aux = get_data(train_df[train_df[('fold_%s' % fold_n)] == 'train'], tokenizer, 
                                                                                       MAX_LEN, preprocess_fn=preprocess_roberta)
    x_valid, x_valid_aux, x_valid_aux_2, y_valid, y_valid_mask, y_valid_aux = get_data(train_df[train_df[('fold_%s' % fold_n)] == 'validation'], tokenizer, 
                                                                                       MAX_LEN, preprocess_fn=preprocess_roberta)
    
    
    np.save(base_path + 'x_train', np.array(x_train))
    np.save(base_path + 'y_train', np.array(y_train))
    np.save(base_path + 'x_valid', np.array(x_valid))
    np.save(base_path + 'y_valid', np.array(y_valid))
    
    np.save(base_path + 'x_train_aux', np.array(x_train_aux))
    np.save(base_path + 'x_train_aux2', np.array(x_train_aux_2))
    np.save(base_path + 'y_train_mask', np.array(y_train_mask))
    np.save(base_path + 'y_train_aux', np.array(y_train_aux))
    
    np.save(base_path + 'x_valid_aux', np.array(x_valid_aux))
    np.save(base_path + 'x_valid_aux2', np.array(x_valid_aux_2))
    np.save(base_path + 'y_valid_mask', np.array(y_valid_mask))
    np.save(base_path + 'y_valid_aux', np.array(y_valid_aux))
    
#  Compress logs dir
!tar -cvzf fold_1.tar.gz fold_1
!tar -cvzf fold_2.tar.gz fold_2
!tar -cvzf fold_3.tar.gz fold_3
!tar -cvzf fold_4.tar.gz fold_4
!tar -cvzf fold_5.tar.gz fold_5

# Delete logs dir
shutil.rmtree('fold_1')
shutil.rmtree('fold_2')
shutil.rmtree('fold_3')
shutil.rmtree('fold_4')
shutil.rmtree('fold_5')
# [___CELL_SEPARATOR___]
train_df.to_csv('5-fold.csv', index=False)
display(train_df.head())

for fold_n in range(folds.n_splits):
    fold_n += 1
    
    base_path = 'balanced_fold_%d/' % fold_n
    # Create dir
    os.makedirs(base_path)
    
    
    train_fold = train_df[train_df[('fold_%s' % fold_n)] == 'train'].copy()
    valid_fold = train_df[train_df[('fold_%s' % fold_n)] == 'validation'].copy()
    
    # Sample data by lower bound
    lower_count_train = min(len(train_fold[train_fold['sentiment'] == 'neutral']), 
                            len(train_fold[train_fold['sentiment'] == 'negative']), 
                            len(train_fold[train_fold['sentiment'] == 'positive']))
    lower_count_valid = min(len(valid_fold[valid_fold['sentiment'] == 'neutral']), 
                            len(valid_fold[valid_fold['sentiment'] == 'negative']), 
                            len(valid_fold[valid_fold['sentiment'] == 'positive']))

    train_fold = pd.concat([train_fold[train_fold['sentiment'] == 'neutral'].sample(n=lower_count_train, random_state=SEED),
                            train_fold[train_fold['sentiment'] == 'negative'].sample(n=lower_count_train, random_state=SEED),
                            train_fold[train_fold['sentiment'] == 'positive'].sample(n=lower_count_train, random_state=SEED),
                           ])
    valid_fold = pd.concat([valid_fold[valid_fold['sentiment'] == 'neutral'].sample(n=lower_count_valid, random_state=SEED),
                            valid_fold[valid_fold['sentiment'] == 'negative'].sample(n=lower_count_valid, random_state=SEED),
                            valid_fold[valid_fold['sentiment'] == 'positive'].sample(n=lower_count_valid, random_state=SEED),
                           ])
    
    train_fold = shuffle(train_fold, random_state=SEED).reset_index(drop=True)
    valid_fold = shuffle(valid_fold, random_state=SEED).reset_index(drop=True)
    
    
    x_train, x_train_aux, x_train_aux_2, y_train, y_train_mask, y_train_aux = get_data(train_fold, tokenizer, MAX_LEN, preprocess_fn=preprocess_roberta)
    x_valid, x_valid_aux, x_valid_aux_2, y_valid, y_valid_mask, y_valid_aux = get_data(valid_fold, tokenizer, MAX_LEN, preprocess_fn=preprocess_roberta)
    
    
    np.save(base_path + 'x_train', np.array(x_train))
    np.save(base_path + 'y_train', np.array(y_train))
    np.save(base_path + 'x_valid', np.array(x_valid))
    np.save(base_path + 'y_valid', np.array(y_valid))
    
    np.save(base_path + 'x_train_aux', np.array(x_train_aux))
    np.save(base_path + 'x_train_aux2', np.array(x_train_aux_2))
    np.save(base_path + 'y_train_mask', np.array(y_train_mask))
    np.save(base_path + 'y_train_aux', np.array(y_train_aux))
    
    np.save(base_path + 'x_valid_aux', np.array(x_valid_aux))
    np.save(base_path + 'x_valid_aux2', np.array(x_valid_aux_2))
    np.save(base_path + 'y_valid_mask', np.array(y_valid_mask))
    np.save(base_path + 'y_valid_aux', np.array(y_valid_aux))
    
#  Compress logs dir
!tar -cvzf balanced_fold_1.tar.gz balanced_fold_1
!tar -cvzf balanced_fold_2.tar.gz balanced_fold_2
!tar -cvzf balanced_fold_3.tar.gz balanced_fold_3
!tar -cvzf balanced_fold_4.tar.gz balanced_fold_4
!tar -cvzf balanced_fold_5.tar.gz balanced_fold_5

# Delete logs dir
shutil.rmtree('balanced_fold_1')
shutil.rmtree('balanced_fold_2')
shutil.rmtree('balanced_fold_3')
shutil.rmtree('balanced_fold_4')
shutil.rmtree('balanced_fold_5')
# [___CELL_SEPARATOR___]
for idx in range(5):
    print('\nRow %d' % idx)
    max_seq_len = 32
    text = train_df['text'].values[idx]
    selected_text = train_df['selected_text'].values[idx]
    
    _,  (target_start, target_end, _) = preprocess_text.preprocess_roberta(' ' + text, selected_text, tokenizer, max_seq_len)
    
    decoded_text = preprocess_text.decode(target_start.argmax(), target_end.argmax(), text, tokenizer)
    
    print('text         : "%s"' % text)
    print('selected_text: "%s"' % selected_text)
    print('decoded_text : "%s"' % decoded_text)
    
    assert selected_text == decoded_text
# [___CELL_SEPARATOR___]
for idx in range(5):
    print('\nRow %d' % idx)
    max_seq_len = 24
    text = train_df['text'].values[idx]
    selected_text = train_df['selected_text'].values[idx]
    jaccard = train_df['jaccard'].values[idx]
    selected_text_wordCnt = train_df['selected_text_wordCnt'].values[idx]
    
    x_train, x_train_aux, x_train_aux_2, y_train, y_train_mask, y_train_aux = preprocess_text.get_data(train_df[idx:idx+1], tokenizer, max_seq_len, 
                                                                                                       preprocess_fn=preprocess_roberta)
    
    print('text          : "%s"'   % text)
    print('jaccard       : "%.4f"' % jaccard)
    print('sentiment     : "%s"'   % question)
    print('word count    : "%d"'   % selected_text_wordCnt)
    
    print('input_ids     : "%s"'   % x_train[0][0])
    print('attention_mask: "%s"'   % x_train[1][0])
    print('sentiment     : "%d"'   % x_train_aux[0])
    print('sentiment OHE : "%s"'   % x_train_aux_2[0])
    
    print('selected_text : "%s"'   % selected_text)
    print('start         : "%s"'   % y_train[0][0])
    print('end           : "%s"'   % y_train[1][0])
    print('mask          : "%s"'   % y_train_mask[0])
    print('jaccard       : "%.4f"' % y_train_aux[0][0])
    print('word count    : "%d"'   % y_train_aux[1][0])
    
    assert len(x_train) == 2
    assert len(x_train_aux) == 1
    assert len(x_train_aux_2) == 1
    assert len(y_train) == 2
    assert len(y_train_mask) == 1
    assert len(y_train_aux) == 3
    
    assert len(x_train[0][0]) == len(x_train[1][0]) == max_seq_len
    assert len(y_train[0][0]) == len(y_train[1][0]) == len(y_train_mask[0]) == max_seq_len
# [___CELL_SEPARATOR___]
train_df.to_csv('5-fold.csv', index=False)
display(train_df.head())

for fold_n in range(folds.n_splits):
    fold_n += 1
    
    base_path = 'no_qa_fold_%d/' % fold_n
    # Create dir
    os.makedirs(base_path)
    
    x_train, x_train_aux, x_train_aux_2, y_train, y_train_mask, y_train_aux = preprocess_text.get_data(train_df[train_df[('fold_%s' % fold_n)] == 'train'], tokenizer, 
                                                                                                       MAX_LEN, preprocess_fn=preprocess_roberta)
    x_valid, x_valid_aux, x_valid_aux_2, y_valid, y_valid_mask, y_valid_aux = preprocess_text.get_data(train_df[train_df[('fold_%s' % fold_n)] == 'validation'], tokenizer, 
                                                                                                       MAX_LEN, preprocess_fn=preprocess_roberta)
    
    np.save(base_path + 'x_train', np.array(x_train))
    np.save(base_path + 'y_train', np.array(y_train))
    np.save(base_path + 'x_valid', np.array(x_valid))
    np.save(base_path + 'y_valid', np.array(y_valid))
    
    np.save(base_path + 'x_train_aux', np.array(x_train_aux))
    np.save(base_path + 'x_train_aux2', np.array(x_train_aux_2))
    np.save(base_path + 'y_train_mask', np.array(y_train_mask))
    np.save(base_path + 'y_train_aux', np.array(y_train_aux))
    
    np.save(base_path + 'x_valid_aux', np.array(x_valid_aux))
    np.save(base_path + 'x_valid_aux2', np.array(x_valid_aux_2))
    np.save(base_path + 'y_valid_mask', np.array(y_valid_mask))
    np.save(base_path + 'y_valid_aux', np.array(y_valid_aux))
    
#  Compress logs dir
!tar -cvzf no_qa_fold_1.tar.gz no_qa_fold_1
!tar -cvzf no_qa_fold_2.tar.gz no_qa_fold_2
!tar -cvzf no_qa_fold_3.tar.gz no_qa_fold_3
!tar -cvzf no_qa_fold_4.tar.gz no_qa_fold_4
!tar -cvzf no_qa_fold_5.tar.gz no_qa_fold_5

# Delete logs dir
shutil.rmtree('no_qa_fold_1')
shutil.rmtree('no_qa_fold_2')
shutil.rmtree('no_qa_fold_3')
shutil.rmtree('no_qa_fold_4')
shutil.rmtree('no_qa_fold_5')
# [___CELL_SEPARATOR___]
test_df = pd.read_csv('/kaggle/input/tweet-sentiment-extraction/test.csv')

# pre-process
test_df["text"] = test_df["text"].apply(lambda x: x.strip())
test_df["text"] = test_df["text"].apply(lambda x: x.lower())
test_df['text_len'] = test_df['text'].apply(lambda x : len(x))
test_df['text_wordCnt'] = test_df['text'].apply(lambda x : len(x.split(' ')))
test_df['text_tokenCnt'] = test_df['text'].apply(lambda x : len(tokenizer.encode(x).ids))

print('Test samples: %s' % len(test_df))
display(test_df.head())
display(test_df.describe())
# [___CELL_SEPARATOR___]
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(20, 8.7))
sns.countplot(x="sentiment", data=train_df, palette="GnBu_d", order=sentiment_cols, ax=ax1).set_title('Train')
sns.countplot(x="sentiment", data=test_df, palette="GnBu_d", order=sentiment_cols, ax=ax2).set_title('Test')
sns.despine()
plt.show()
# [___CELL_SEPARATOR___]
fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(20, 8.7), sharex=True)
sns.distplot(train_df['text_wordCnt'], ax=ax1).set_title("Train")
sns.distplot(test_df['text_wordCnt'], ax=ax2).set_title("Test")
sns.despine()
plt.show()
# [___CELL_SEPARATOR___]
fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(20, 8.7), sharex=True)
sns.distplot(train_df['text_tokenCnt'], ax=ax1).set_title("Train")
sns.distplot(test_df['text_tokenCnt'], ax=ax2).set_title("Test")
sns.despine()
plt.show()