import tushare as ts
import pandas as pd
from IPython.display import HTML
# [___CELL_SEPARATOR___]
StockCode='300036'

#历年前十大股东持股情况
#df1为季度统计摘要，data1为前十大持股明细统计
df1, data1 = ts.top10_holders(code=StockCode, gdtype='0') #gdtype等于1时表示流通股，默认为0 
# [___CELL_SEPARATOR___]
df1 = df1.sort_values('quarter', ascending=True)
# [___CELL_SEPARATOR___]
df1.tail(10)
# [___CELL_SEPARATOR___]
data1
# [___CELL_SEPARATOR___]
import matplotlib
import numpy as np
import matplotlib.pyplot as plt
# [___CELL_SEPARATOR___]
x = df1["quarter"]
y = df1["amount"]
plt.plot(x, y)
plt.title('A simple chirp')
plt.show()
# [___CELL_SEPARATOR___]
HTML("<h1 font-color=ff00ff>Hello</h1>")
# [___CELL_SEPARATOR___]
