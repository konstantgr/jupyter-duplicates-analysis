import pandas as pd
# [___CELL_SEPARATOR___]
train_test = pd.read_csv('../../data/user-feats2_train_test.csv')
train_val = pd.read_csv('../../data/user-feats2_train_val.csv')
# [___CELL_SEPARATOR___]
train_test.shape
# [___CELL_SEPARATOR___]
train_val.shape
# [___CELL_SEPARATOR___]
train_test.head()
# [___CELL_SEPARATOR___]
train_val.head()
# [___CELL_SEPARATOR___]
tr013 = pd.read_parquet('../../data/train_FE013.parquet')
te013 = pd.read_parquet('../../data/test_FE013.parquet')
# [___CELL_SEPARATOR___]
tt13 = pd.concat([tr013, te013], axis=0).copy()
# [___CELL_SEPARATOR___]
tr013.shape
# [___CELL_SEPARATOR___]
import gc
del tr013, te013
gc.collect()
# [___CELL_SEPARATOR___]
tt13['mFraud'] = train_test['mFraud']
tt13['sFraud'] = train_test['sFraud']
tt13['cFraud'] = train_test['cFraud']
# [___CELL_SEPARATOR___]
tt13.to_parquet('../../data/FE014_train_test.parquet')
# [___CELL_SEPARATOR___]
# tt13['mFraud']
# [___CELL_SEPARATOR___]
train_val.head()
# [___CELL_SEPARATOR___]
tr013.head()
# [___CELL_SEPARATOR___]
tr013['mFraud'] = train_val['mFraud']
tr013['sFraud'] = train_val['sFraud']
tr013['cFraud'] = train_val['cFraud']
# [___CELL_SEPARATOR___]
# tr013['mFraud']
# [___CELL_SEPARATOR___]
tr013.to_parquet('../../data/FE014_train_val.parquet')
# [___CELL_SEPARATOR___]
tr013.head()
# [___CELL_SEPARATOR___]
tr013.loc[tr013['TransactionDT'] <= 1300000]