class Demo:
    """This class demonstrates how to document a class.
    
       This class is just a demonstration, and does nothing.
       
       However the principles of documentation are still valid!
    """
    
    def __init__(self, name):
        """You should document the constructor, saying what it expects to 
           create a valid class. In this case
           
           name -- the name of an object of this class
        """
        self._name = name
    
    def getName(self):
        """You should then document all of the member functions, just as
           you do for normal functions. In this case, returns
           the name of the object
        """
        return self._name
# [___CELL_SEPARATOR___]
d = Demo("cat")
# [___CELL_SEPARATOR___]
help(d)
# [___CELL_SEPARATOR___]
class Demo:
    """This class demonstrates how to document a class.
    
       This class is just a demonstration, and does nothing.
       
       However the principles of documentation are still valid!
    """
    
    def __init__(self, name):
        """You should document the constructor, saying what it expects to 
           create a valid class. In this case
           
           name -- the name of an object of this class
        """
        self._name = name
    
    def _getName(self):
        """You should then document all of the member functions, just as
           you do for normal functions. In this case, returns
           the name of the object
        """
        return self._name
# [___CELL_SEPARATOR___]
d = Demo("cat")
# [___CELL_SEPARATOR___]
help(d)
# [___CELL_SEPARATOR___]
class Person1:
    """Class that holds a person's height"""
    def __init__(self):
        """Construct a person who has zero height"""
        self.height = 0
# [___CELL_SEPARATOR___]
class Person2:
    """Class that holds a person's height"""
    def __init__(self):
        """Construct a person who has zero height"""
        self._height = 0
    
    def setHeight(self, height):
        """Set the person's height to 'height', returning whether or 
           not the height was set successfully
        """
        if height < 0 or height > 300:
            print("This is an invalid height! %s" % height)
            return False
        else:
            self._height = height
            return True
        
    def getHeight(self):
        """Return the person's height"""
        return self._height
# [___CELL_SEPARATOR___]
p = Person1()
# [___CELL_SEPARATOR___]
p.height = -50
# [___CELL_SEPARATOR___]
p.height
# [___CELL_SEPARATOR___]
p.height = "cat"
# [___CELL_SEPARATOR___]
p.height
# [___CELL_SEPARATOR___]
p = Person2()
# [___CELL_SEPARATOR___]
p.setHeight(-50)
# [___CELL_SEPARATOR___]
p.getHeight()
# [___CELL_SEPARATOR___]
p.setHeight("cat")
# [___CELL_SEPARATOR___]
p.getHeight()
# [___CELL_SEPARATOR___]
class GuessGame:
    """
        This class provides a simple guessing game. You create an object
        of the class with its own secret, with the aim that a user
        then needs to try to guess what the secret is.
    """
    def __init__(self, secret, max_guesses=5):
        """Create a new guess game
        
           secret -- the secret that must be guessed
           max_guesses -- the maximum number of guesses allowed by the user
        """
        self._secret = secret
        self._nguesses = 0
        self._max_guesses = max_guesses
    
    def guess(self, value):
        """Try to guess the secret. This will print out to the screen whether
           or not the secret has been guessed.
        
           value -- the user-supplied guess
        """
        if (self.nGuesses() >= self.maxGuesses()):
            print("Sorry, you have run out of guesses")
        elif (value == self._secret):
            print("Well done - you have guessed my secret")
        else:
            self._nguesses += 1
            print("Try again...")
    
    def nGuesses(self):
        """Return the number of incorrect guesses made so far"""
        return self._nguesses
    
    def maxGuesses(self):
        """Return the maximum number of incorrect guesses allowed"""
        return self._max_guesses
# [___CELL_SEPARATOR___]
help(GuessGame)
# [___CELL_SEPARATOR___]
class Person:
    """Class the represents a Person, holding their name and age"""
    def __init__(self, name="unknown", age=0):
        """Construct a person with unknown name and an age of 0"""
        self.setName(name)
        self.setAge(age)
        
    def setName(self, name):
        """Set the person's name to 'name'"""
        self._name = str(name)  # str ensures the name is a string
        
    def getName(self):
        """Return the person's name"""
        return self._name
    
    def setAge(self, age):
        """Set the person's age. This must be a number between 0 and 130"""
        if (age < 0 or age > 130):
            print("Cannot set the age to an invalid value: %s" % age)
            
        self._age = age
        
    def getAge(self):
        """Return the person's age"""
        return self._age
# [___CELL_SEPARATOR___]
p = Person(name="Peter Parker", age=21)
# [___CELL_SEPARATOR___]
p.getName()
# [___CELL_SEPARATOR___]
p.getAge()
# [___CELL_SEPARATOR___]
class Person:
    """Class the represents a Person, holding their name and age"""
    def __init__(self, name="unknown", age=0):
        """Construct a person with unknown name and an age of 0"""
        self.setName(name)
        self.setAge(age)
        
    def setName(self, name):
        """Set the person's name to 'name'"""
        self._name = str(name)  # str ensures the name is a string
        
    def getName(self):
        """Return the person's name"""
        return self._name
    
    def setAge(self, age):
        """Set the person's age. This must be a number between 0 and 130"""
        if (age < 0 or age > 130):
            print("Cannot set the age to an invalid value: %s" % age)
            
        self._age = age
        
    def getAge(self):
        """Return the person's age"""
        return self._age
    
    def _splitName(self):
        """Private function that splits the name into parts"""
        return self._name.split(" ")
    
    def getFirstName(self):
        """Return the first name of the person"""
        return self._splitName()[0]
    
    def getSurname(self):
        """Return the surname of the person"""
        return self._splitName()[-1]
# [___CELL_SEPARATOR___]
p = Person(name="Peter Parker", age=21)
# [___CELL_SEPARATOR___]
p.getFirstName()
# [___CELL_SEPARATOR___]
p.getSurname()
# [___CELL_SEPARATOR___]
