%reload_ext autoreload
%autoreload 2
%matplotlib inline
# [___CELL_SEPARATOR___]
# dev version
# !pip install https://github.com/PyThaiNLP/pythainlp/archive/dev.zip

# release version 
! pip install pythainlp
# [___CELL_SEPARATOR___]
import warnings
warnings.filterwarnings('ignore')
# [___CELL_SEPARATOR___]
import pythainlp

pythainlp.__version__
# [___CELL_SEPARATOR___]
from pythainlp import spell
# [___CELL_SEPARATOR___]
spell("รั๊ว") # รัว ไม้ตรี
# [___CELL_SEPARATOR___]
spell("กวาา") 
# [___CELL_SEPARATOR___]
spell("น้ำสม")
# [___CELL_SEPARATOR___]
spell("ศาธารณสุบ")
# [___CELL_SEPARATOR___]
spell("ร้อ4")
# [___CELL_SEPARATOR___]
spell("รั้o")
# [___CELL_SEPARATOR___]
spell("ชhอน")
# [___CELL_SEPARATOR___]
spell("miraclx")
# [___CELL_SEPARATOR___]
from pythainlp.spell import NorvigSpellChecker
# [___CELL_SEPARATOR___]
checker = NorvigSpellChecker()  # use default filter (remove any word with number or non-Thai character)
len(checker.dictionary())
# [___CELL_SEPARATOR___]
list(checker.dictionary())[:20]
# [___CELL_SEPARATOR___]
from pythainlp.corpus import ttc  # Thai Textbook Corpus
# [___CELL_SEPARATOR___]
# ttc??
# NorvigSpellChecker??
# [___CELL_SEPARATOR___]
checker = NorvigSpellChecker(custom_dict=ttc.word_freqs())
checker.spell("เจียง")
# [___CELL_SEPARATOR___]
len(checker.dictionary()), len(ttc.word_freqs())
# [___CELL_SEPARATOR___]
list(checker.dictionary())[0:20]
# [___CELL_SEPARATOR___]
checker = NorvigSpellChecker(min_freq=5, min_len=2, max_len=15)
len(checker.dictionary())
# [___CELL_SEPARATOR___]
checker_no_filter = NorvigSpellChecker(dict_filter=None)  # use no filter
len(checker_no_filter.dictionary())
# [___CELL_SEPARATOR___]
def remove_smallpiyan(word):
    return False if "ฯ" in word else True

checker_custom_filter = NorvigSpellChecker(dict_filter=remove_smallpiyan)  # use custom filter
len(checker_custom_filter.dictionary())
# [___CELL_SEPARATOR___]
from pythainlp import correct
# [___CELL_SEPARATOR___]
correct("รั๊ว") # รัว ไม้ตรี
# [___CELL_SEPARATOR___]
correct("กวาา") 
# [___CELL_SEPARATOR___]
correct("น้ำสม")
# [___CELL_SEPARATOR___]
correct("ศาธารณสุบ")
# [___CELL_SEPARATOR___]
correct("ร้อ4")
# [___CELL_SEPARATOR___]
correct("รั้o")
# [___CELL_SEPARATOR___]
correct("ชhอน")
# [___CELL_SEPARATOR___]
correct("miraclx")
# [___CELL_SEPARATOR___]
from pythainlp.util import normalize
# [___CELL_SEPARATOR___]
# normalize??
# [___CELL_SEPARATOR___]
normalize("กิิิ่ง") == "กิ่ง"  # กิ่ง สระ อิ 3 ตัว
# [___CELL_SEPARATOR___]
normalize("ก้าาาน") == "ก้าน"  # ก้าน สระ อา 3 ตัว
# [___CELL_SEPARATOR___]
normalize("ก้้้าน") == "ก้าน"   # ก้าน ไม้โท 3 ตัว
# [___CELL_SEPARATOR___]
normalize("ก้าาานน") == "ก้าน"  
# [___CELL_SEPARATOR___]
normalize("ก้านน") == "ก้าน"  
# [___CELL_SEPARATOR___]
normalize("สััั้้้น") == "สั้น"  # สั้น ไม้หันอากาศ 3 ตัว และ ไม้โท 3 ตัว
# [___CELL_SEPARATOR___]
normalize("ใใบ") == "ใบ"  
# [___CELL_SEPARATOR___]
normalize("ไใบ") == "ใบ"  
# [___CELL_SEPARATOR___]
normalize("เเปลก") == "แปลก"  # เ เ ป ล ก  vs แ ป ล ก
# [___CELL_SEPARATOR___]
