import numpy as np
import pandas as pd
import sympy as sp

import FormulaLab as fl
# [___CELL_SEPARATOR___]
data_list = ['f=m*a','a=v/t']
data_dict = {'1':'f=m*a','2':'a=v/t'}
data_dict_2 = {'ID':[1, 2], 'Formula':['f=m*a','a=v/t']}
data_tuple = ('f=m*a','a=v/t')
data_set = {'f=m*a','a=v/t'}

data_list
# [___CELL_SEPARATOR___]
df = pd.read_csv('Quick Database.csv')
df
# [___CELL_SEPARATOR___]
phyfos = fl.FormulaSearch(data=data_list) 
phyfos.data
# The new "Args" column is automatically generated 
# to help speed the search algorithm.  
# [___CELL_SEPARATOR___]
phyfos = fl.FormulaSearch(data=data_dict) 
phyfos.data
# [___CELL_SEPARATOR___]
phyfos = fl.FormulaSearch(data=df, formula_col='Formula', id_col='ID') 
#formula_col and id_col values should mathch the formulas database
phyfos.data
# [___CELL_SEPARATOR___]
d = phyfos.find('d')  #Searching is case sensitivity
d
# [___CELL_SEPARATOR___]
v = phyfos.find('v')
v
# [___CELL_SEPARATOR___]
v_as_a_function_of_a = phyfos.find('v', 'a')
v_as_a_function_of_a
# [___CELL_SEPARATOR___]
a_as_a_function_of_v = phyfos.find('a', 'v')
a_as_a_function_of_v
# [___CELL_SEPARATOR___]
v_as_a_function_of_t_d = phyfos.find('v', ['t','d'])
v_as_a_function_of_t_d
# [___CELL_SEPARATOR___]
f = phyfos.find('f', id=3)
f
# [___CELL_SEPARATOR___]
# Say you want "m" to be the function, you do not have to rewrite your formula again!
m = phyfos.find('m', id=3)
m
# [___CELL_SEPARATOR___]
# Also for 'a'. This is very helpful when there is a mistake 
# in the formula! You only change it once in your database.
a = phyfos.find('a', id=3)
a
# You will see how to convert this to a python function in step 4 
# [___CELL_SEPARATOR___]
phyfos.data
# [___CELL_SEPARATOR___]
phyfos.find('d', 'a') # What if you want to know what is the d(a)??
#It is not in the database! So, find() is not helpful here, derive() is!
# [___CELL_SEPARATOR___]
d = phyfos.derive('d', 'a', shortest_path=True) 
# shortest_path=True is faster and the default.
d
# [___CELL_SEPARATOR___]
# You can also see all of your traces:
phyfos.traces
# [___CELL_SEPARATOR___]
d = phyfos.derive('d', 'a', shortest_path=False) 
d
# Sometimes you get more solutions when you turn off shortest_path, 
# because derive() tries with all possible paths, with no shortcuts!
# [___CELL_SEPARATOR___]
# You can also see the all of your traces:
phyfos.traces
# The extra path has a repetitive solution
# [___CELL_SEPARATOR___]
# You can pretty print your solutions
# Latex print
d[1]
# [___CELL_SEPARATOR___]
sp.pretty_print(d[1])
# [___CELL_SEPARATOR___]
phyfos.data
# [___CELL_SEPARATOR___]
f = phyfos.find('f', function=True)
f(m=10, a=2)
# [___CELL_SEPARATOR___]
a = phyfos.find('a',id=3, function=True)
a(f=20, m=10)
# [___CELL_SEPARATOR___]
# You can also convert symbolic expression to python function
d = phyfos.derive('d', 'a')[0]
d
# [___CELL_SEPARATOR___]
d_func = phyfos.function(d)
d_func(t=2, a=1)
# [___CELL_SEPARATOR___]
d
# [___CELL_SEPARATOR___]
sp.var('a x')
d = d.subs(a,sp.sin(x))
d
# [___CELL_SEPARATOR___]
d.series(x)
# [___CELL_SEPARATOR___]
d.diff(x) # take the derivative of d with respect to x
# [___CELL_SEPARATOR___]
#Find formula as string, by its id number
str_fo = phyfos.find_raw_formula(1) 
str_fo
# [___CELL_SEPARATOR___]
# Convert str expr to formula and solve for a variable
phyfos.solve_for(expr=str_fo, var='v')
# [___CELL_SEPARATOR___]
# Tels you where to find certain variable in your database
phyfos.get_formula_ids('v')
# [___CELL_SEPARATOR___]
phyfos.get_formula_ids(('v','a')) # --> 'v' and 'a' can be found in id = 2
# [___CELL_SEPARATOR___]
# What if you want to know how your formulas are connected!
phyfos.trace([5,1,2])
# [___CELL_SEPARATOR___]
# Once you are done, you can see all your derived formulas stored in
phyfos.all_derived_formulas