import pandas as pd
import numpy as np
import cv2
from skimage import color
from skimage import io

from scipy import misc
# [___CELL_SEPARATOR___]
TEST = pd.read_csv("Principal: Processed Images/TESTmod.csv", index_col=0)
TRAIN = pd.read_csv("Principal: Processed Images/TRAINmod.csv", index_col=0)
# [___CELL_SEPARATOR___]
TRAIN.shape

# [___CELL_SEPARATOR___]
TRAIN = TRAIN[TRAIN.origin=="ISIC2018_Task3_Training_Input/"]
TRAIN.sum()
# [___CELL_SEPARATOR___]
# Grey world color correction algorithm
#from https://gist.github.com/shunsukeaihara/4603234

def grey_world(nimg):
    nimg = nimg.transpose(2, 0, 1).astype(np.uint32)
    mu_g = np.average(nimg[1])
    nimg[0] = np.minimum(nimg[0]*(mu_g/np.average(nimg[0])),255)
    nimg[2] = np.minimum(nimg[2]*(mu_g/np.average(nimg[2])),255)
    return nimg.transpose(1, 2, 0).astype(np.uint8)
# [___CELL_SEPARATOR___]
# "Principal: Processed Images/Data v1" function for TEST.csv
# Processes only HAM10000 images
import numpy as np

def process_image(name): # takes filename of the lesion sample
    img = io.imread("ISIC2018_Task3_Training_Input/"+name+".jpg")
    img = grey_world(img)
    img = img[22:22+405, 22:22+405, :]
    img = cv2.resize(img, dsize=(224, 224))#, interpolation=cv2.INTER_CUBIC)

    misc.imsave("Processed Images/TEST/"+ name+".jpg", img)
# [___CELL_SEPARATOR___]
import time
from tqdm import tqdm_notebook
start = time.time()
for lesion in tqdm_notebook(TEST.index):
    process_image(lesion)
    
end = time.time()
print("Run time for "+ str(len(TEST.index)) + " images: " + str((end - start)/60)+" minutes")    
# [___CELL_SEPARATOR___]
from glob import glob
filelist = glob("Processed Images/TEST/ISIC_*.jpg")
len(filelist)
# [___CELL_SEPARATOR___]
# Find out where each image is

MSK1 = glob("ISIC Archival Images/MSK-1/ISIC_*.jpg")
MSK2 = glob("ISIC Archival Images/MSK-2/ISIC_*.jpg")
MSK3 = glob("ISIC Archival Images/MSK-3/ISIC_*.jpg")
MSK4 = glob("ISIC Archival Images/MSK-4/ISIC_*.jpg")
MSK5 = glob("ISIC Archival Images/MSK-5/ISIC_*.jpg")
SONIC = glob("ISIC Archival Images/SONIC/ISIC_*.jpg")
UDA1 = glob("ISIC Archival Images/UDA-1/ISIC_*.jpg")
UDA2 = glob("ISIC Archival Images/UDA-2/ISIC_*.jpg")

allsets = [MSK1, MSK2, MSK3, MSK4, MSK5, SONIC, UDA1, UDA2]
for dataset in allsets:
    for i in range(len(dataset)):
        dataset[i] = dataset[i][27:-4]
HAM = glob("ISIC2018_Task3_Training_Input/ISIC_*.jpg")
for i in range(len(HAM)):
    HAM[i] = HAM[i][30:-4]

# [___CELL_SEPARATOR___]
def process_steps(img, name): # performs same steps as process_image but saves img in TRAIN
    img = grey_world(img)
    img = cv2.resize(img, dsize=(450, 600))#, interpolation=cv2.INTER_CUBIC)
    xrand = np.random.randint(0,45)
    yrand = np.random.randint(0,45)
    img = img[xrand:xrand+405, yrand:yrand+405, :]
    img = cv2.resize(img, dsize=(256, 256))#, interpolation=cv2.INTER_CUBIC)

    
    misc.imsave("Processed Images/TRAIN/"+ name+".jpg", img)
# [___CELL_SEPARATOR___]
# "Processed Images/Data" function for TRAIN.csv
# Processes images for each directory

def process_images_all(name):
    img = io.imread(TRAIN.loc[name]["origin"]+name+".jpg")
    process_steps(img, name)
    
# [___CELL_SEPARATOR___]
import time
from tqdm import tqdm_notebook

start = time.time()
for lesion in tqdm_notebook(TRAIN.index):
    process_images_all(lesion)
     
end = time.time()
print("Run time for "+ str(len(TRAIN.index)) + " images: " + str(round((end - start)/60, 3))+" minutes")    

# [___CELL_SEPARATOR___]
filelist = glob("Principal: Processed Images/TRAIN/ISIC_*.jpg")
len(filelist)
# [___CELL_SEPARATOR___]
