import pandas as pd
import math
import numpy as np
from scipy.stats import norm
# [___CELL_SEPARATOR___]
# Control group
control_df = pd.read_csv('ab_control.csv')
control_df.head()
# [___CELL_SEPARATOR___]
# Experiment group
experiment_df = pd.read_csv('ab_experiment.csv')
experiment_df.head()
# [___CELL_SEPARATOR___]
control_df.describe()
# [___CELL_SEPARATOR___]
experiment_df.describe()
# [___CELL_SEPARATOR___]
baseline = {'Cookies': 40000, 'Clicks': 3200, 'Enrollments': 660, 'CTP': 0.08,
           'GConversion': 0.20625, 'Retention': 0.53, 'NConversion': 0.109313}
# [___CELL_SEPARATOR___]
sample_baseline = baseline.copy()

sample_baseline['Cookies'] = 5000  # assume sample size is 5000
sample_baseline['Clicks'] = baseline['Clicks'] * 5000/baseline['Cookies']
sample_baseline['Enrollments'] = baseline['Enrollments'] * 5000/baseline['Cookies']

sample_baseline
# [___CELL_SEPARATOR___]
def get_binomial_std(p_hat, n):
    """
    p_hat: baseline probability of the event to occur
    n: sample size
    return: the standard deviation
    """
    std = round(math.sqrt(p_hat*(1-p_hat)/n),4)
    
    return std
# [___CELL_SEPARATOR___]
gross_conversion = {}

gross_conversion['d_min'] = 0.01
gross_conversion['p_hat'] = sample_baseline['GConversion']
gross_conversion['n'] = sample_baseline['Clicks']
gross_conversion['std'] = get_binomial_std(gross_conversion['p_hat'],
                                          gross_conversion['n'])

gross_conversion
# [___CELL_SEPARATOR___]
retention = {}

retention['d_min'] = 0.01
retention['p_hat'] = sample_baseline['Retention']
retention['n'] = sample_baseline['Enrollments']
retention['std'] = get_binomial_std(retention['p_hat'],
                                   retention['n'])

retention
# [___CELL_SEPARATOR___]
net_conversion = {}

net_conversion['d_min'] = 0.0075
net_conversion['p_hat'] = sample_baseline['NConversion']
net_conversion['n'] = sample_baseline['Clicks']
net_conversion['std'] = get_binomial_std(net_conversion['p_hat'],
                                        net_conversion['n'])

net_conversion
# [___CELL_SEPARATOR___]
def get_z_score(alpha):
    return norm.ppf(alpha)


def get_stds(p, d):
    std1 = math.sqrt(2*p*(1-p))
    std2 = math.sqrt(p*(1-p) + (p+d)*(1-(p+d)))
    
    std_lst = [std1, std2]
    return std_lst
    
    
def get_sample_size(std_lst, alpha, beta, d):
    n = pow(get_z_score(1-alpha/2)*std_lst[0] + get_z_score(1-beta)*std_lst[1], 2)/pow(d,2)
    return n
# [___CELL_SEPARATOR___]
alpha = 0.05
beta = 0.2
# [___CELL_SEPARATOR___]
gross_conversion['sample_size'] = round(get_sample_size(get_stds(gross_conversion['p_hat'],
                                                          gross_conversion['d_min']), alpha, beta,
                                                 gross_conversion['d_min']))
gross_conversion['page_views'] = 2*round(gross_conversion['sample_size']/(gross_conversion['n']/5000))

gross_conversion
# [___CELL_SEPARATOR___]
retention['sample_size'] = round(get_sample_size(get_stds(retention['p_hat'],
                                                          retention['d_min']), alpha, beta,
                                                 retention['d_min']))
retention['page_views'] = 2*round(retention['sample_size']/(retention['n']/5000))
retention
# [___CELL_SEPARATOR___]
net_conversion['sample_size'] = round(get_sample_size(get_stds(net_conversion['p_hat'],
                                                         net_conversion['d_min']), alpha, beta,
                                                         net_conversion['d_min']))
net_conversion['page_views'] = 2*round(net_conversion['sample_size']/(net_conversion['n']/5000))

net_conversion
# [___CELL_SEPARATOR___]
control_df.head()
# [___CELL_SEPARATOR___]
experiment_df.head()
# [___CELL_SEPARATOR___]
p=0.5
alpha=0.05
# [___CELL_SEPARATOR___]
def get_std(p, total_size):
    std = math.sqrt(p*(1-p)/total_size)
    return std

def get_marginOferror(std, alpha):
    me = round(get_z_score(1-alpha/2)*std, 4)
    return me
# [___CELL_SEPARATOR___]
control_pageviews = control_df['Pageviews'].sum()
experiment_pageviews = experiment_df['Pageviews'].sum()

print(control_pageviews, experiment_pageviews)
# [___CELL_SEPARATOR___]
total_pageviews = control_pageviews + experiment_pageviews
p_hat = control_pageviews/(total_pageviews)
std = get_std(p, total_pageviews)
me = get_marginOferror(std, alpha)

print('If ' + str(p) +' is within [' + str(round(p_hat - me, 4)) + ', ' + str(round(p_hat + me, 4)) + '], then the difference is expected.')
# [___CELL_SEPARATOR___]
control_clicks = control_df['Clicks'].sum()
experiment_clicks = experiment_df['Clicks'].sum()

print(control_clicks, experiment_clicks)
# [___CELL_SEPARATOR___]
total_clicks = control_clicks + experiment_clicks
p_hat = control_clicks/(total_clicks)
std = get_std(p, total_clicks)
me = get_marginOferror(std, alpha)

print('If ' + str(p) +' is within [' + str(round(p_hat - me, 4)) + ', ' + str(round(p_hat + me, 4)) + '], then the difference is expected.')
# [___CELL_SEPARATOR___]
control_ctp = control_clicks/control_pageviews
experiment_ctp = experiment_clicks/experiment_pageviews
p_pool = (control_clicks + experiment_clicks)/(control_pageviews + experiment_pageviews)
std_pool = math.sqrt(p_pool*(1-p_pool)*(1/experiment_pageviews + 1/control_pageviews))
me = get_marginOferror(std_pool, alpha)

diff = round(experiment_ctp - control_ctp, 4)

print('If ' + str(diff) +' is within [' + str(round(0 - me, 4)) + ', ' + str(round(0 + me, 4)) + '], then the difference is expected.')
# [___CELL_SEPARATOR___]
print(control_df.isnull().sum())
print()
print(experiment_df.isnull().sum())
# [___CELL_SEPARATOR___]
control_clicks = control_df['Clicks'].loc[control_df['Enrollments'].notnull()].sum()
experiment_clicks = experiment_df['Clicks'].loc[experiment_df['Enrollments'].notnull()].sum()
print('Clicks', control_clicks, experiment_clicks)

control_enrolls = control_df['Enrollments'].sum()
experiment_enrolls = experiment_df['Enrollments'].sum()
print('Enrollments', control_enrolls, experiment_enrolls)

control_GC = control_enrolls/control_clicks
experiment_GC = experiment_enrolls/experiment_clicks
print('Gross Conversion', control_GC, experiment_GC)
# [___CELL_SEPARATOR___]
p_pool = (control_enrolls + experiment_enrolls)/(control_clicks + experiment_clicks)
std_pool = math.sqrt(p_pool*(1-p_pool)*(1/control_clicks + 1/experiment_clicks))
me = get_marginOferror(std_pool, alpha)

print(p_pool, std_pool, me)
# [___CELL_SEPARATOR___]
# Statistical significance
GC_diff = round(experiment_GC - control_GC, 4)

print('If ' + str(GC_diff) +' is within [' + str(round(0 - me, 4)) + ', ' + str(round(0 + me, 4)) + '], then the difference is expected, and the change is not significant.')
# [___CELL_SEPARATOR___]
# Practically significance
d_min = gross_conversion['d_min']

print('If ' + str(GC_diff) +' is within [' + str(round(d_min - me, 4)) + ', ' + str(round(d_min + me, 4)) + '], then the change is not practically significant.')
# [___CELL_SEPARATOR___]
control_clicks = control_df['Clicks'].loc[control_df['Payments'].notnull()].sum()
experiment_clicks = experiment_df['Clicks'].loc[experiment_df['Payments'].notnull()].sum()
print('Clicks', control_clicks, experiment_clicks)

control_paid = control_df['Payments'].sum()
experiment_paid = experiment_df['Payments'].sum()
print('Payments', control_paid, experiment_paid)

control_NC = control_paid/control_clicks
experiment_NC = experiment_paid/experiment_clicks
print('Net Conversion', control_NC, experiment_NC)
# [___CELL_SEPARATOR___]
p_pool = (control_paid + experiment_paid)/(control_clicks + experiment_clicks)
std_pool = math.sqrt(p_pool*(1-p_pool)*(1/control_clicks + 1/experiment_clicks))
me = get_marginOferror(std_pool, alpha)

print(p_pool, std_pool, me)
# [___CELL_SEPARATOR___]
# Statistical significance
NC_diff = round(experiment_NC - control_NC, 4)

print('If ' + str(NC_diff) +' is within [' + str(round(0 - me, 4)) + ', ' + str(round(0 + me, 4)) + '], then the difference is expected, and the change is not significant.')
# [___CELL_SEPARATOR___]
# Practically significance
d_min = net_conversion['d_min']

print('If ' + str(NC_diff) +' is within [' + str(round(d_min - me, 4)) + ', ' + str(round(d_min + me, 4)) + '], then the change is not practically significant.')
# [___CELL_SEPARATOR___]
control_experiment_df = control_df.join(experiment_df, lsuffix='_control', rsuffix='_experiment')
print(control_experiment_df.shape)
control_experiment_df.head()
# [___CELL_SEPARATOR___]
control_experiment_df.isnull().sum()
# [___CELL_SEPARATOR___]
control_experiment_df.dropna(inplace=True)
print(control_experiment_df.shape)
control_experiment_df.isnull().sum()
# [___CELL_SEPARATOR___]
# If it's "success", assign 1, otherwise 0

control_experiment_df['GC_increase'] = np.where(
    control_experiment_df['Enrollments_experiment']/control_experiment_df['Clicks_experiment'] \
    > control_experiment_df['Enrollments_control']/control_experiment_df['Clicks_control'], 1, 0)

control_experiment_df['NC_increase'] = np.where(
    control_experiment_df['Payments_experiment']/control_experiment_df['Clicks_experiment'] \
    > control_experiment_df['Payments_control']/control_experiment_df['Clicks_control'], 1, 0)

control_experiment_df[['GC_increase', 'NC_increase']].head()
# [___CELL_SEPARATOR___]
print(control_experiment_df['GC_increase'].value_counts())
print(control_experiment_df['NC_increase'].value_counts())
# [___CELL_SEPARATOR___]
GC_success_ct = control_experiment_df['GC_increase'].value_counts()[1]
NC_success_ct = control_experiment_df['NC_increase'].value_counts()[1]

print(GC_success_ct, NC_success_ct)
# [___CELL_SEPARATOR___]
p = 0.5
alpha = 0.05
n = control_experiment_df.shape[0]

print(n)
# [___CELL_SEPARATOR___]
def get_probability(x, n):
    prob = round(math.factorial(n)/(math.factorial(x)*math.factorial(n-x))*pow(p,x)*pow(1-p, n-x), 4)
    return prob

def get_p_value(x, n):
    p_value = 0
    
    for i in range(0, x+1):
        p_value += get_probability(i, n)
        
    return round(p_value*2, 4)  # 2 side p_value
# [___CELL_SEPARATOR___]
print ("GC Change is significant if", get_p_value(GC_success_ct,n), "is smaller than", alpha)
print ("NC Change is significant if", get_p_value(NC_success_ct,n), "is smaller than", alpha)