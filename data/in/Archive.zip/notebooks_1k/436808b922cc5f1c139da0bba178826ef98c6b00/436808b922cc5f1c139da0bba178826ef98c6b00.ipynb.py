import pandas as pd

import matplotlib.pyplot as plt
%matplotlib inline
# [___CELL_SEPARATOR___]
df = pd.read_csv('time_data/walmart_stock.csv',
                 index_col = 'Date')
df.index = pd.to_datetime(df.index)
# [___CELL_SEPARATOR___]
df.head()
# [___CELL_SEPARATOR___]
df.tail()
# [___CELL_SEPARATOR___]
df.shift(1).head()
# [___CELL_SEPARATOR___]
# You will lose that last piece of data that no longer has an index!
df.shift(1).tail()
# [___CELL_SEPARATOR___]
df.shift(-1).head()
# [___CELL_SEPARATOR___]
df.shift(-1).tail()
# [___CELL_SEPARATOR___]
# Shift everything forward one month
df.tshift(periods = 1,
          freq = 'M').head()