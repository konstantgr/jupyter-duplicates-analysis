from landlab.io import read_esri_ascii
# [___CELL_SEPARATOR___]
# read_esri_ascii?
# [___CELL_SEPARATOR___]
(mg, z) = read_esri_ascii("west_bijou_gully.asc", name="topographic__elevation")
# [___CELL_SEPARATOR___]
from landlab.plot.imshow import imshow_grid
# [___CELL_SEPARATOR___]
%matplotlib inline
imshow_grid(mg, "topographic__elevation")
# [___CELL_SEPARATOR___]
import numpy as np

min_z = np.min(z[np.where(z > 0)])
max_z = np.max(z[np.where(z > 0)])
#help(imshow_grid)
imshow_grid(mg, 'topographic__elevation', limits=(min_z, max_z))
# [___CELL_SEPARATOR___]
mg.number_of_node_rows
# [___CELL_SEPARATOR___]
mg.number_of_node_columns
# [___CELL_SEPARATOR___]
mg.set_watershed_boundary_condition(z, 0)
imshow_grid(mg, mg.status_at_node, color_for_closed="blue")
# [___CELL_SEPARATOR___]
from landlab.io import read_asc_header
fop = open('synthetic_landscape.asc', 'r')
hdr = read_asc_header(fop)
hdr
# [___CELL_SEPARATOR___]
(mg1, z1) = read_esri_ascii('synthetic_landscape.asc', name='topographic__elevation')
imshow_grid(mg1, z1)
# [___CELL_SEPARATOR___]
mg1.set_closed_boundaries_at_grid_edges(True, True, True, False)
imshow_grid(mg1, mg1.status_at_node, color_for_closed='blue')
# [___CELL_SEPARATOR___]
(mg2, z2) = read_esri_ascii('synthetic_landscape.asc', name='topographic__elevation', halo=1)
imshow_grid(mg2, z2)
# [___CELL_SEPARATOR___]
mg2.set_nodata_nodes_to_closed(z2, -9.0)

mg2.status_at_node[15] = mg2.BC_NODE_IS_FIXED_VALUE
mg2.status_at_node[19] = mg2.BC_NODE_IS_FIXED_VALUE
imshow_grid(mg2, mg2.status_at_node, color_for_closed="blue")