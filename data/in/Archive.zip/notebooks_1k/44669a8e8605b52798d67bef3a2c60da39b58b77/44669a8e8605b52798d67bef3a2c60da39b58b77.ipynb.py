print("Hello, World!")
# [___CELL_SEPARATOR___]
print("\N{WAVING HAND SIGN}, \N{EARTH GLOBE ASIA-AUSTRALIA}!")
# [___CELL_SEPARATOR___]
print("First this line is printed,")
print("and then this one.")
# [___CELL_SEPARATOR___]
print("This line is missing something."
# [___CELL_SEPARATOR___]
# Examples of expressions:

#addition
print(2 + 2)

#string concatenation 
print('me' + ' and I')

#you can print a number with a string if you cast it 
print("me" + str(2))

#exponents
print(12 ** 2)

# [___CELL_SEPARATOR___]
a = 4
b = 10/5
# [___CELL_SEPARATOR___]
# Notice that 'a' retains its value.
print(a)
a + b
# [___CELL_SEPARATOR___]
# Fill in the missing lines to complete the expressions.
x = ...
...
...
print(...)
# [___CELL_SEPARATOR___]
# an empty list
lst = []
print(lst)

# reassigning our empty list to a new list
lst = [1, 3, 6, 'lists', 'are' 'fun', 4]
print(lst)
# [___CELL_SEPARATOR___]
# Elements are selected like this:
example = lst[2]

# The above line selects the 3rd element of lst (list indices are 0-offset) and sets it to a variable named example.
print(example)
# [___CELL_SEPARATOR___]
a = [1,2,3] #original list
b = a #b now points to list a 
b[0] = 4 
print(a[0]) #return 4 since we modified the first element of the list pointed to by a and b 
# [___CELL_SEPARATOR___]
### This line will store the first (inclusive) through fourth (exclusive) elements of lst as a new list called lst_2:
lst_2 = lst[1:4]

lst_2
# [___CELL_SEPARATOR___]
### Fill in the ellipses to complete the question.
my_list = ...

my_list_sliced = my_list[...]

last_of_sliced = ...

print(...)
# [___CELL_SEPARATOR___]
# A list containing six integers.
a_list = [1, 6, 4, 8, 13, 2]

# Another list containing six integers.
b_list = [4, 5, 2, 14, 9, 11]

print('Max of a_list:', max(a_list))
print('Min of b_list:', min(a_list))

# Concatenate a_list and b_list:
c_list = a_list + b_list
print('Concatenated:', c_list)
# [___CELL_SEPARATOR___]
import numpy as np
# [___CELL_SEPARATOR___]
# Initialize an array of integers 0 through 9.
example_array = np.array([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])

# This can also be accomplished using np.arange
example_array_2 = np.arange(10)
print('Undoubled Array:')
print(example_array_2)

# Double the values in example_array and print the new array.
double_array = example_array*2
print('Doubled Array:')
print(double_array)
# [___CELL_SEPARATOR___]
example_list = [1, 2, 3, 4, 5, 6, 7, 8, 9]
example_list * 2
# [___CELL_SEPARATOR___]
new_list = []

for element in example_array:
    new_element = element + 5
    new_list.append(new_element)

new_list
# [___CELL_SEPARATOR___]
newer_list = []

for completely_arbitrary_name in example_array:
    newer_element = completely_arbitrary_name + 5
    newer_list.append(newer_element)
    
newer_list
# [___CELL_SEPARATOR___]
for i in range(len(example_array)):
    example_array[i] = example_array[i] + 5

example_array
# [___CELL_SEPARATOR___]
while_array = np.arange(10)        # Generate our array of values

print('Before:', while_array)

while(max(while_array) < 50):      # Set our conditional
    while_array[4] += 1            # Add 1 to the fifth element if the conditional is satisfied 
    
print('After:', while_array)
# [___CELL_SEPARATOR___]
# Make use of iterators, range, length, while loops, and indices to complete this question.
question_3 = np.array([12, 31, 50, 0, 22, 28, 19, 105, 44, 12, 77])

for i in range(len(...)):
    while(...):
        question_3[i] = ...
        
for element in question_3:
    print(...)
# [___CELL_SEPARATOR___]
answer = np.array([15, 35, 50, 0, 25, 30, 20, 105, 45, 15, 80])
question_3 == answer
# [___CELL_SEPARATOR___]
# An adder function that adds 2 to the given n.
def add_two(n):
    return n + 2
# [___CELL_SEPARATOR___]
add_two(5)
# [___CELL_SEPARATOR___]
def is_multiple(m, n):
    if (m % n == 0):
        return True
    else:
        return False
# [___CELL_SEPARATOR___]
is_multiple(12, 4)
# [___CELL_SEPARATOR___]
is_multiple(12, 7)
# [___CELL_SEPARATOR___]
# Change possible_prime to any integer to test its primality
# NOTE: If you happen to stumble across a large (> 8 digits) prime number, the cell could take a very, very long time
# to run and will likely crash your kernel. Just click kernel>interrupt if it looks like it's caught.

possible_prime = 9999991

for i in range(2, possible_prime):
    if (is_multiple(possible_prime, i)):
        print(possible_prime, 'is not prime')   
        break
    if (i >= possible_prime/2):
        print(possible_prime, 'is prime')
        break
# [___CELL_SEPARATOR___]
from datascience import *
# [___CELL_SEPARATOR___]
Table.read_table('../data/incident/36828-0004-Data.tsv', delimiter='\t')
# [___CELL_SEPARATOR___]
fruit_names = make_array("Apple", "Orange", "Banana")
fruit_prices = make_array(1, 0.75, 0.5)
fruit_table = Table().with_columns("Fruit", fruit_names,
                                  "Price ($)", fruit_prices)
fruit_table
# [___CELL_SEPARATOR___]
empty_table = Table()
empty_table
# [___CELL_SEPARATOR___]
# YOUR CODE HERE

incidents = Table.read_table("../data/incident/36828-0004-Data.tsv", delimiter='\t')
incidents
# [___CELL_SEPARATOR___]
incidents.take([1, 3, 5]) # Takes rows with indices 1, 3, and 5 (the 2nd, 4th, and 6th rows)
# [___CELL_SEPARATOR___]
incidents.take(7) # Takes the row with index 7 (8th row)
# [___CELL_SEPARATOR___]
incidents.take(np.arange(7)) # Takes the row with indices 0, 1, ... 6
# [___CELL_SEPARATOR___]
incidents.select(["V4065", "IDPER"]) # Selects only "V4065" and "IDPER" columns
# [___CELL_SEPARATOR___]
incidents.drop([0, 1]) # Drops the columns with indices 0 and 1
# [___CELL_SEPARATOR___]
incidents.select([1, 68]).take([1, 2, 3, 5]) # Select only columns with indices 1 and 68, 
                                               # then only the rows with indices 1, 2, 3, 5
# [___CELL_SEPARATOR___]
# YOUR CODE HERE
# [___CELL_SEPARATOR___]
incidents.where("V4526AA", are.equal_to(1)) 
# [___CELL_SEPARATOR___]
incidents.where("V4364", are.between_or_equal_to(10000, 99996))
# [___CELL_SEPARATOR___]
num_incidents = incidents.num_rows
print("Number of rows: ", num_incidents)
num_attributes = incidents.num_columns
print("Numbers of columns: ", num_attributes)
# [___CELL_SEPARATOR___]
monetary_loss = incidents.where("V4364", are.between_or_equal_to(1, 99996)).select(2, 3, 'V4364') 
monetary_loss.sort('V4364') # Sort table by value of property taken in ascending order
# [___CELL_SEPARATOR___]
monetary_loss.sort('V4364').sort(2, descending=True) # Sort table by value of property taken in descending order (highest at top)