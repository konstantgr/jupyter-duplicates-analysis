import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
%matplotlib notebook

import george
import emcee
import scipy.stats
import corner
import h5py
# [___CELL_SEPARATOR___]
# 
# [___CELL_SEPARATOR___]
h5py_files = list()
obs_files = list()

import glob, os

for file in glob.glob("../data/paper_plots/ztf_lightcurves/*.hdf5"):
    h5py_files.append(file)
    
for file in glob.glob("../data/paper_plots/ztf_lightcurves/*.txt"):
    obs_files.append(file)

#obs_files
# [___CELL_SEPARATOR___]
obs_files[7]
# [___CELL_SEPARATOR___]
data  = pd.read_csv("../data/old_simulation_results_2/3200/3200_lc_49627_to_49787.txt", delimiter=" ", header=None)

time= data[0]
flux = data[1]
# [___CELL_SEPARATOR___]
time, flux, flux_err = run_gp.read_data(obs_files[11], whitespace=True)
# [___CELL_SEPARATOR___]
plt.plot(time, flux, '.')
# [___CELL_SEPARATOR___]
#guess the preliminary kernel numbers 
"""Calculates initial gp parameter values based on data."""
k1 = np.mean(flux) * george.kernels.ExpSquaredKernel(metric=10**2)
k2 = 0.5 * george.kernels.ExpSine2Kernel(gamma=7, log_period=np.log(3/24.))

kernel = k1+k2

gp = george.GP(kernel, mean=np.mean(flux), fit_mean=True)

gp.compute(time, flux_err)
pred, pred_var = gp.predict(flux, np.arange(time[0], time[len(time)-1], 1/24.), return_var=True)
ln_likelihood = gp.log_likelihood(flux)
# [___CELL_SEPARATOR___]
plt.figure(figsize=(5, 4))
plt.plot(time, flux, 'o', alpha=0.5, label="Observations")

#plot the kernel-fitted guess
plt.fill_between(np.arange(time[0], time[len(time)-1], 1/24.), pred - np.sqrt(pred_var), pred + np.sqrt(pred_var), color="green", alpha=0.4)
plt.plot(np.arange(time[0], time[len(time)-1], 1/24.), pred, 'g', lw=1.5, alpha=0.7, label="Fit")

plt.legend()
# [___CELL_SEPARATOR___]
from scipy.optimize import minimize

def neg_ln_like(p):
    gp.set_parameter_vector(p)
    try:
        negloglike =  -gp.log_likelihood(flux)
        return negloglike
    except scipy.linalg.LinAlgError:
        return np.inf
#print(neg_ln_like)

def grad_neg_ln_like(p):
    gp.set_parameter_vector(p)
    try:
        grad_loglike =  -gp.grad_log_likelihood(flux)
        return grad_loglike
    except scipy.linalg.LinAlgError:
        return np.inf
    #return -gp.grad_log_likelihood(y)
# [___CELL_SEPARATOR___]
gp.get_parameter_names()
# [___CELL_SEPARATOR___]
result = minimize(neg_ln_like, gp.get_parameter_vector(), jac=grad_neg_ln_like) #, method='L-BFGS-B')
gp.set_parameter_vector(result.x)


ln_likelihood_opt = gp.log_likelihood(flux)
#if (print_results == True):
print(ln_likelihood, result, ln_likelihood_opt)

#return gp, ln_likelihood_opt, result.fun
# [___CELL_SEPARATOR___]
plt.figure(figsize=(10, 8))
plt.plot(time, flux, 'o', alpha=0.5, label="Original")
#plt.plot(x,y, 'ko', ms = 3, alpha=0.5, label="Sample")

#plot the kernel-fitted guess
plt.fill_between(np.arange(time[0], time[len(time)-1], 1/24.), pred - np.sqrt(pred_var), pred + np.sqrt(pred_var), color="green", alpha=0.4)
plt.plot(np.arange(time[0], time[len(time)-1], 1/24.), pred, 'g', lw=1.5, alpha=0.7, label="Fit")

#all the x-values visually present we want to map onto
#x_short = np.linspace(time[0], time[len(time)-1], 1000)

#optimize the fit
#gp2, ln_like2, result = cgp.optimize(y,gp,gp.lnlikelihood, print_results=True)
#pred, pred_var = gp.predict(flux, x_short, return_var=True)

#print the optimized fit
#plt.fill_between(x_short, pred - np.sqrt(pred_var), pred + np.sqrt(pred_var), color="red", alpha=0.4)
#plt.plot(x_short, pred, "red", lw=1.5, alpha=0.5, label="Optimized")
#plt.xlim([pre_x[0], pre_x[cap]])
plt.legend()
# [___CELL_SEPARATOR___]
kernel.get_parameter_names()
# [___CELL_SEPARATOR___]
nwalkers=100
# [___CELL_SEPARATOR___]
# Calculates initial gp parameter values based on data

mean_flux = np.mean(flux)

# k1
log_amp_k1 = np.log(flux.max()-flux.min())
metric = 5**2

# k2
log_amp_k2 = np.log(0.5)
gamma = 10
log_period = np.log(6/24.)

parameters = {"mean": mean_flux, "log_amp_k1": log_amp_k1, "metric": metric, "log_amp_k2": log_amp_k2, "gamma": gamma,"log_period": log_period}
params = parameters
# [___CELL_SEPARATOR___]
# Creates a matrix of starting parameters for every walker.
p_start = np.array(list(params.values()))
cov_matrix = np.sqrt(np.diag(p_start)**2)
p0 = np.random.multivariate_normal(mean=p_start, cov=cov_matrix, size=(nwalkers))

# equally distributed starting period values for
p0[:,-1] = np.random.normal(size=nwalkers)*0.5 + np.log(4/24.)

walker_params = p0
# [___CELL_SEPARATOR___]
walker_params
# [___CELL_SEPARATOR___]
def prior(params):

    """
    Calculated the log of the prior values, given parameter values.

    Parameters
    ----------
    params : list
        List of all kernel parameters

    'mean:value',

    'kernel:k1:k1:log_constant',

    'kernel:k1:k2:metric:log_M_0_0',

    'kernel:k2:k1:log_constant',

    'kernel:k2:k2:gamma',

    'kernel:k2:k2:log_period')

    Returns
    -------
    sum_log_prior : int
        sum of all log priors (-inf if a parameter is out of range)

    """

    p_mean = scipy.stats.norm(np.mean(flux), 0.5).logpdf(params[0])
    p_log_amp_k1 = scipy.stats.norm(np.log(2), np.log(10)).logpdf(params[1])
    p_log_metric = scipy.stats.norm(np.log(100), np.log(10)).logpdf(np.log(params[2]))
    
    p_log_amp_k2 = scipy.stats.norm(np.log(2), np.log(2)).logpdf(params[3])
    p_log_gamma = scipy.stats.norm(np.log(10), np.log(2)).logpdf(np.log(params[4]))
    p_log_period = scipy.stats.norm(np.log(4./24.), (12./24.)).logpdf(params[5])


    sum_log_prior =  p_mean + p_log_amp_k1 + p_log_metric + p_log_amp_k2 + p_log_gamma + p_log_period

    if np.isnan(sum_log_prior) == True:
        return -np.inf

    return sum_log_prior


def logl(params, gp, tsample, fsample, flux_err):
     # compute lnlikelihood based on given parameters
    gp.set_parameter_vector(params)


    try:
        gp.compute(tsample, flux_err)
        lnlike = gp.lnlikelihood(fsample)
    except np.linalg.LinAlgError:
        lnlike = -1e25

    return lnlike


def post_lnlikelihood(params, gp, tsample, fsample, flux_err):

    """
    Calculates the posterior likelihood from the log prior and
    log likelihood.

    Parameters
    ----------
    params : list
        List of all kernel parameters

    Returns
    -------
    ln_likelihood : float
        The posterior, unless the posterior is infinite, in which case,
        -1e25 will be returned instead.

    """

    # calculate the log_prior
    log_prior = prior(params)

    # return -inf if parameters are outside the priors
    if np.isneginf(log_prior) == True:
        return -np.inf

    try:
        lnlike = logl(params, gp, tsample, fsample, flux_err)
        ln_likelihood = lnlike+log_prior

    except np.linalg.linalg.LinAlgError:
        ln_likelihood = -1e25

    return ln_likelihood if np.isfinite(ln_likelihood) else -1e25

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
ndim = 6
threads = 1
iterations = 1000
#burn_in=100

sampler = emcee.EnsembleSampler(nwalkers, ndim, post_lnlikelihood, args=[gp, time, flux, flux_err])

#run steps for a burn-in
#state = sampler.run_mcmc(walker_params, burn_in)
#sampler.reset()
#print(state[0])
data = sampler.run_mcmc(walker_params, iterations)
# [___CELL_SEPARATOR___]
sampler.flatchain
# [___CELL_SEPARATOR___]
labels = list(gp.get_parameter_names())

figure = corner.corner(sampler.flatchain, labels=labels, title_kwargs={"fontsize": 8})
# [___CELL_SEPARATOR___]
burn_in = 0
# [___CELL_SEPARATOR___]
"""
    Write the sampler results as an HDF5 file,
    with all the other info you might want.
    """

with h5py.File("testing"+".hdf5", "w") as f:
    f.create_dataset("chain", data=sampler.chain)

    f.attrs['true_period'] = 0

    f.attrs['walkers'] = nwalkers
    f.attrs['iterations'] = iterations
    f.attrs['data_pts'] = len(flux)
    f.attrs['acceptance_fraction'] = sampler.acceptance_fraction
    f.attrs['burn_in'] = burn_in
    f.create_dataset("time", data= time)
    f.create_dataset("flux", data = flux)
    f.create_dataset("flux_err", data = flux_err)
# [___CELL_SEPARATOR___]
sampler.chain.shape()
# [___CELL_SEPARATOR___]
colours = None
if colours is None:
    colours = ["black"]

dims = list(gp.get_parameter_names())

fig, ax = plt.subplots(3, 2, figsize=(10,9))
fig.subplots_adjust(wspace=0.5, hspace=0.3)
axs = [ax[0,0], ax[0,1], ax[1,0], ax[1,1]]

x = np.arange(iterations)

for i in range(sampler.chain.shape[2]):
    axs[i].set_xlabel('Step Number')
    axs[i].set_ylabel('{}'.format(dims[i]))

    for j in range(sampler.chain.shape[0]):
        param = sampler.chain[j,:,i]
        axs[i].plot(x, param, color=colours[0], alpha=0.3)

# [___CELL_SEPARATOR___]
run_plotting.make_summary_plots("testing.hdf5", true_lightcurve=None, true_period=None)
# [___CELL_SEPARATOR___]
data.shape()
# [___CELL_SEPARATOR___]
