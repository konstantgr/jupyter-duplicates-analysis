from openpyxl import load_workbook

from bs4 import BeautifulSoup
from selenium import webdriver
from time import sleep
import csv
from random import randint
import json, io

from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select
from selenium.webdriver.support.ui import WebDriverWait
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException
from selenium.common.exceptions import NoAlertPresentException
from selenium.webdriver.common.action_chains import ActionChains

import urllib
import urllib3
import requests
import json, io
from bs4 import BeautifulSoup
urllib3.disable_warnings()
header = {'User-Agent':'Mozilla/5.0'}


chrome_options = webdriver.ChromeOptions()
chrome_options.add_argument('--user-agent="Mozilla/5.0')
chrome_options.add_argument("user-data-dir=selenium")
driver = webdriver.Chrome(chrome_options=chrome_options, executable_path=r'/Users/Name/Downloads/Compressed/chromedrives/chromedriver.exe')


cookies = json.load(open('cookiesdict.txt'))
for cookie in cookies:
    driver.add_cookie(cookie)
    
# [___CELL_SEPARATOR___]
detamegaset=[]
# [___CELL_SEPARATOR___]
bfg_flex=driver.find_elements_by_class_name('bfg-flex')
for i in range(len(bfg_flex)):
    bfg_flex=driver.find_elements_by_class_name('bfg-flex')
    letter_link=bfg_flex[i+1].find_elements_by_class_name('bfg-roster-letter-link')
    for o in range(len(letter_link)):
        bfg_flex=driver.find_elements_by_class_name('bfg-flex')
        letter_link=bfg_flex[i+1].find_elements_by_class_name('bfg-roster-letter-link')
        print letter_link[o].text
        letter_link[o].click()
        sleep(5)
        
        no_of_agents=driver.find_elements_by_link_text('My Profile')
        for t in range(0,len(no_of_agents)):
            no_of_agents=driver.find_elements_by_link_text('My Profile')
            no_of_agents[t].click()
            sleep(5)
            soup=BeautifulSoup(driver.page_source, 'lxml')
            dataset=[]
            name=soup.find_all(class_="bfg-profile-name")[0].text
            dataset.append(name)
            company_name=soup.find_all(class_="bfg-profile-company-name")[0].text
            dataset.append(company_name)
            profile_title=soup.find_all(class_="bfg-profile-title")[0].text
            dataset.append(profile_title)
            profile_social_links=soup.find_all(class_="bfg-profile-social-links")[0].text
            dataset.append(profile_social_links)
            profile_tagline=soup.find_all(class_="bfg-profile-tagline")[0].text
            dataset.append(profile_tagline)
            profile_details=soup.find_all(class_="bfg-profile-details")
            for p in range(len(profile_details)-1):
                alinks=profile_details[p].find_all('a')
                for y in range(len(alinks)):
                    print alinks[y].text
                    dataset.append(alinks[y].text)

            address1=soup.find_all(class_="bfg-profile-address")[0].text
            dataset.append(address1)
            address2=soup.find_all(class_="bfg-profile-address2")[0].text
            dataset.append(address2)
            print dataset
            detamegaset.append(dataset)


            driver.get('https://sunflowerrealtors.com/find-an-agent/')
            sleep(5)
            bfg_flex=driver.find_elements_by_class_name('bfg-flex')
            letter_link=bfg_flex[i+1].find_elements_by_class_name('bfg-roster-letter-link')
            print letter_link[o].text
            letter_link[o].click()
            sleep(5)
        
       
    
# [___CELL_SEPARATOR___]
no_of_agents=driver.find_elements_by_link_text('My Profile')
print len(no_of_agents)
for t in range(0,len(no_of_agents)):
    no_of_agents=driver.find_elements_by_link_text('My Profile')
    no_of_agents[t].click()
    sleep(5)
    soup=BeautifulSoup(driver.page_source, 'lxml')
    dataset=[]
    name=soup.find_all(class_="bfg-profile-name")[0].text
    dataset.append(name)
    company_name=soup.find_all(class_="bfg-profile-company-name")[0].text
    dataset.append(company_name)
    profile_title=soup.find_all(class_="bfg-profile-title")[0].text
    dataset.append(profile_title)
    profile_social_links=soup.find_all(class_="bfg-profile-social-links")[0].text
    dataset.append(profile_social_links)
    profile_tagline=soup.find_all(class_="bfg-profile-tagline")[0].text
    dataset.append(profile_tagline)
    profile_details=soup.find_all(class_="bfg-profile-details")
    for p in range(len(profile_details)-1):
        alinks=profile_details[p].find_all('a')
        for y in range(len(alinks)):
            print alinks[y].text
            dataset.append(alinks[y].text)

    address1=soup.find_all(class_="bfg-profile-address")[0].text
    dataset.append(address1)
    address2=soup.find_all(class_="bfg-profile-address2")[0].text
    dataset.append(address2)
    print dataset
    detamegaset.append(dataset)


    driver.get('https://sunflowerrealtors.com/find-an-agent/')
    sleep(5)
    bfg_flex=driver.find_elements_by_class_name('bfg-flex')
    letter_link=bfg_flex[i].find_elements_by_class_name('bfg-roster-letter-link')
    print letter_link[12].text
    letter_link[12].click()
    sleep(5)
# [___CELL_SEPARATOR___]
bfg_flex=driver.find_elements_by_class_name('bfg-flex')
letter_link=bfg_flex[0].find_elements_by_class_name('bfg-roster-letter-link')
print letter_link[11].text
# [___CELL_SEPARATOR___]
no_of_agents=driver.find_elements_by_link_text('My Profile')
# [___CELL_SEPARATOR___]
len(no_of_agents)
# [___CELL_SEPARATOR___]
import warnings
from openpyxl import Workbook

wb = Workbook(write_only=True)
ws = wb.create_sheet()

# now we'll fill it with 100 rows x 200 columns
for irow in detamegaset:
    ws.append(irow)
# save the file
wb.save('start1.xlsx')
# [___CELL_SEPARATOR___]
bfg_flex=driver.find_elements_by_class_name('bfg-flex')
letter_link=bfg_flex[i].find_elements_by_class_name('bfg-roster-letter-link')
print letter_link[4].text
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
driver.get('https://sunflowerrealtors.com/find-an-agent/')
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
# driver.find_elements_by_link_text('« Back to Roster')[0].click()
# [___CELL_SEPARATOR___]
