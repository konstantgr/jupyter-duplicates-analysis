import numpy as np
import imageio
from skimage import transform
import matplotlib.pyplot as plt
from math import sqrt
import glob
import subprocess

import h5py
from tqdm import tqdm
import knn_cnn_features
import sound_similarity_inference
%matplotlib inline
# [___CELL_SEPARATOR___]
p = subprocess.Popen("ffmpeg -i data/videos/animals/2.mp4 -f wav -vn data/tmp/animals_0.wav", \
                     stdout=subprocess.PIPE, shell=True)
(output, err) = p.communicate()
p_status = p.wait()
# [___CELL_SEPARATOR___]
p = subprocess.Popen("ffprobe -i data/videos/animals/0.mp4 -show_streams -select_streams a -loglevel error"\
                     , stdout=subprocess.PIPE, shell=True)
(output, err) = p.communicate()
p_status = p.wait()
# [___CELL_SEPARATOR___]
"No audio channel" if output.decode()=='' else "Audio channels present:"+output.decode()
# [___CELL_SEPARATOR___]
!ffprobe -i data/videos/animals/0.mp4 -show_streams -select_streams a -loglevel error
# [___CELL_SEPARATOR___]
p = subprocess.Popen("ffprobe -i /home/hemant/Videos/Titans\ -\ Season\ 1.mp4 -show_streams -select_streams a -loglevel error", \
                     stdout=subprocess.PIPE, shell=True)
(output, err) = p.communicate()
p_status = p.wait()
# [___CELL_SEPARATOR___]
"No audio channel" if output.decode()=='' else "Audio channels present:"+output.decode()
# [___CELL_SEPARATOR___]
p = subprocess.Popen("ffmpeg -i /home/hemant/Videos/Titans\ -\ Season\ 1.mp4 -f wav -vn data/tmp/animals_0.wav", \
                     stdout=subprocess.PIPE, shell=True)
(output, err) = p.communicate()
p_status = p.wait()
# [___CELL_SEPARATOR___]
# The file is huge. Taking a small chunk of it and delete the larger chunk
!ffmpeg -t 30 -i data/tmp/animals_0.wav data/tmp/mini_0.wav -loglevel error && rm animals_0.wav
# [___CELL_SEPARATOR___]
# sample script to create a log_mel_spectrogram
from scipy.io import wavfile
from scipy import signal

sample_rate=16000
window_size=20
step_size=10
eps=1e-10
rate, data = wavfile.read('data/tmp/mini_0.wav')
if data.ndim > 1 : # ignore  channels 2+
    data = data[:, 0]
nperseg = int(round(window_size * sample_rate / 1e3))
noverlap = int(round(step_size * sample_rate / 1e3))
freqs, times, spec = signal.spectrogram(data,fs=sample_rate,window='hann',nperseg=nperseg,noverlap=noverlap)
log_specgram = np.log(spec.T.astype(np.float32) + eps)
# [___CELL_SEPARATOR___]
print(log_specgram.shape)
# [___CELL_SEPARATOR___]
import sys
sys.path.append("audioset/")
# [___CELL_SEPARATOR___]
import vggish_input
features_tensor = vggish_input.wavfile_to_examples(wav_file='data/tmp/mini_0.wav')
# [___CELL_SEPARATOR___]
features_tensor.shape
# [___CELL_SEPARATOR___]
import vggish_inference
embedding_batch, postprocessed_batch = vggish_inference.main(wav_file='data/tmp/mini_0.wav')
# [___CELL_SEPARATOR___]
embedding_batch.shape
# [___CELL_SEPARATOR___]
import tensorflow as tf
import numpy as np
import glob 
tf.enable_eager_execution()

files = sorted(glob.glob('audioset/data/audioset_v1_embeddings/bal_train/*'))
# [___CELL_SEPARATOR___]
def readTfRecords(tfrecords_filename, verbose = False, std_frames=10):
    multiple_audio_embedding = []
    labels = []

    record_iterator = tf.python_io.tf_record_iterator(path=tfrecords_filename)
    for string_record in record_iterator:
        example = tf.train.SequenceExample.FromString(string_record)
        label = np.array(example.context.feature['labels'].int64_list.value)
        n_frames = len(example.feature_lists.feature_list['audio_embedding'].feature)
        audio_embedding = []
        for i in range(n_frames):
            audio_embedding.append(tf.cast(tf.decode_raw(example.feature_lists.feature_list['audio_embedding']\
                        .feature[i].bytes_list.value[0],tf.uint8),tf.float32).numpy())
        audio_embedding = np.array(audio_embedding)
        
        if n_frames==std_frames:
            labels.append(label)
            multiple_audio_embedding.append(audio_embedding)
        if verbose:
            print('labels: ' + str(label))
            print(audio_embedding.shape)
    return np.array(multiple_audio_embedding), labels
# [___CELL_SEPARATOR___]
%time multiple_audio_embedding, labels = readTfRecords(files[1])
# [___CELL_SEPARATOR___]
multiple_audio_embedding.shape, len(labels)
# [___CELL_SEPARATOR___]
len(files)
# [___CELL_SEPARATOR___]
from tqdm import tqdm
import h5py
# [___CELL_SEPARATOR___]
all_audio_embedding = np.zeros((22176,10,128))
all_labels = []
pos = 0
for file in tqdm(files):
    multiple_audio_embedding, labels = readTfRecords(file)
    length = len(labels)
    if multiple_audio_embedding.shape!=(0,):
        try:
            all_audio_embedding[pos:(pos+length),] = np.array(multiple_audio_embedding)
            all_labels = all_labels + labels
            pos+=length
        except:
            print(multiple_audio_embedding.shape,file, length)
            break
# [___CELL_SEPARATOR___]
all_audio_embedding = all_audio_embedding[:pos,]
# [___CELL_SEPARATOR___]
all_audio_embedding.shape, len(all_labels)
# [___CELL_SEPARATOR___]
audioset_h5f = h5py.File('audioset_balanced_features_vggish.h5', 'w')
audioset_h5f.create_dataset('audio_embeddings', data=all_audio_embedding)
audioset_h5f.close()
# [___CELL_SEPARATOR___]
np.save('audioset_balanced_labels.npy', all_labels)
# [___CELL_SEPARATOR___]
flat_labels = [item for sublist in all_labels for item in sublist]
# from collections import Counter
# Counter(flat_labels)
# [___CELL_SEPARATOR___]
audioset_h5f = h5py.File('audioset_balanced_features_vggish.h5', 'r')
audio_embeddings = np.array(audioset_h5f['audio_embeddings'],dtype='float32')
audioset_h5f.close()
# [___CELL_SEPARATOR___]
feature_labels = np.load('audioset_balanced_labels.npy')
feature_labels = np.array([flab[0] for flab in feature_labels])
# [___CELL_SEPARATOR___]
audio_embeddings.shape
# [___CELL_SEPARATOR___]
reshaped_audio_embeddings = audio_embeddings.reshape(audio_embeddings.shape[:-2] + (-1,))
reshaped_audio_embeddings.shape
# [___CELL_SEPARATOR___]
%time feature_indices = knn_cnn_features.run_knn_features(reshaped_audio_embeddings,k=3)
# [___CELL_SEPARATOR___]
similar_videos = feature_labels[feature_indices]
# [___CELL_SEPARATOR___]
def get_cls_accuracy(similar_videos, feature_labels, k=3):
    accuracy = 0
    for i, sim_vids in enumerate(similar_videos):
        true_label = feature_labels[i]
        for sim_vid in sim_vids:
            pred_label = sim_vid
            accuracy += np.sum(pred_label==true_label)/k
    return accuracy/len(feature_labels)
# [___CELL_SEPARATOR___]
print("Accuracy:",get_cls_accuracy(similar_videos,feature_labels))
# [___CELL_SEPARATOR___]
len(set(feature_labels))
# [___CELL_SEPARATOR___]
# total number of labels (if considering all - not just first)
len(set([item for sublist in feature_labels for item in sublist]))
# [___CELL_SEPARATOR___]
%time feature_indices = knn_cnn_features.run_knn_features(reshaped_audio_embeddings,\
                                                    test_vectors=reshaped_audio_embeddings[:10],k=3)
# [___CELL_SEPARATOR___]
import sound_similarity_inference
# [___CELL_SEPARATOR___]
%time audio_embedding = sound_similarity_inference.embedding_from_audio('data/audio/v_ApplyEyeMakeup_g01_c01.wav')
# [___CELL_SEPARATOR___]
audio_embeddings, audio_labels, true_indices = sound_similarity_inference.load_sound_data()
# [___CELL_SEPARATOR___]
%time similar_indices = sound_similarity_inference.similar_sound_embedding(audio_embeddings[:1],k=10)
# [___CELL_SEPARATOR___]
output = sound_similarity_inference.label_from_index(similar_indices[0], true_indices[0])
# [___CELL_SEPARATOR___]
print(output[0],"\n",output[1])
# [___CELL_SEPARATOR___]
audioset_h5f = h5py.File('audioset_balanced_features_vggish.h5', 'r')
audio_embeddings = np.array(audioset_h5f['audio_embeddings'],dtype='float32')
audioset_h5f.close()
    
feature_labels = np.load('audioset_balanced_labels.npy')
feature_labels = np.array([flab[0] for flab in feature_labels])
# [___CELL_SEPARATOR___]
merged_audio_embeddings = audio_embeddings.reshape(audio_embeddings.shape[:-3] + (-1,128))
embedding_labels = np.array([i for i in feature_labels for _ in range(10)])
# [___CELL_SEPARATOR___]
merged_audio_embeddings.shape, len(embedding_labels)
# [___CELL_SEPARATOR___]
%time feature_indices = knn_cnn_features.run_knn_features(merged_audio_embeddings,k=3)
# [___CELL_SEPARATOR___]
similar_videos = embedding_labels[feature_indices]
print("Accuracy:",get_cls_accuracy(similar_videos,embedding_labels))
# [___CELL_SEPARATOR___]
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(merged_audio_embeddings, embedding_labels, \
                                        test_size=0.3, random_state=42)
# [___CELL_SEPARATOR___]
%time feature_indices = knn_cnn_features.run_knn_features(X_train,test_vectors=X_test,k=3)
# [___CELL_SEPARATOR___]
similar_videos = y_train[feature_indices]
print("Accuracy:",get_cls_accuracy(similar_videos,y_test))
# [___CELL_SEPARATOR___]
def get_ordered_unique(listed):
    seen = set()
    seen_add = seen.add
    return [x for x in listed if not (x in seen or seen_add(x))]
# [___CELL_SEPARATOR___]
get_ordered_unique(similar_videos[0])
# [___CELL_SEPARATOR___]
%timeit feature_indices = knn_cnn_features.run_knn_features(merged_audio_embeddings,\
                                                        test_vectors=X_test[:1],k=3)
# [___CELL_SEPARATOR___]
videos = sorted(glob.glob("data/UCF101/*"))
ucf_classes = [vid.split('/')[-1].split('_')[1] for vid in videos]
ucf_classes = sorted(list(set(ucf_classes)))
# [___CELL_SEPARATOR___]
def audio_emb_from_vid(vid_path, vid_name):
    sound_similarity_inference.extract_audio_from_video(vid_path)
    audio_embedding = sound_similarity_inference.embedding_from_audio("data/audio/"+vid_name+".wav")
    return audio_embedding
# [___CELL_SEPARATOR___]
for vid_path in tqdm(videos):
    vid_name = vid_path.split('/')[-1].split('.')[0]
    try:
        audio_embedding = audio_emb_from_vid(vid_path, vid_name)
        np.save('data/audio/'+vid_name+'.npy', audio_embedding)
    except:
        continue
# [___CELL_SEPARATOR___]
videos = sorted(glob.glob("data/audio/*.npy"))
# [___CELL_SEPARATOR___]
print("%0.2f" % (len(videos)*100/13320),"% of the videos in the UCF dataset have an audio channel")
# [___CELL_SEPARATOR___]
feature_vectors = None
audio_labels = []
for vid in tqdm(videos):
    if type(feature_vectors) is not np.ndarray:
        aud_emb = np.load(vid).astype('float32')
        audio_labels = audio_labels + [vid]*aud_emb.shape[0]
        feature_vectors = aud_emb
    else:
        aud_emb = np.load(vid).astype('float32')
        audio_labels = audio_labels + [vid]*aud_emb.shape[0]
        feature_vectors = np.vstack((feature_vectors, aud_emb))
# [___CELL_SEPARATOR___]
h5f = h5py.File('audio_sec_UCF_vggish.h5', 'w')
h5f.create_dataset('feature_vectors', data=feature_vectors)
h5f.create_dataset('feature_labels', data=np.array(audio_labels, dtype='S'))
h5f.close()
# [___CELL_SEPARATOR___]
feature_file = h5py.File('audio_sec_UCF_vggish.h5', 'r')
feature_labels = np.array([fl.decode() for fl in feature_file['feature_labels']])
feature_vectors = np.array(feature_file['feature_vectors'])
feature_file.close()
# [___CELL_SEPARATOR___]
%timeit feature_indices = knn_cnn_features.run_knn_features(feature_vectors,k=3)
# [___CELL_SEPARATOR___]
def get_cls_accuracy_ucf(similar_videos, feature_labels, k=3):
    accuracy = 0
    for i, sim_vids in enumerate(similar_videos):
        true_label = feature_labels[i].split('_')[1]
        for sim_vid in sim_vids:
            pred_label = sim_vid.split('_')[1]
            accuracy += np.sum(pred_label==true_label)/k
    return accuracy/len(feature_labels)
# [___CELL_SEPARATOR___]
similar_videos = feature_labels[feature_indices]
print("Accuracy:",get_cls_accuracy_ucf(similar_videos,feature_labels))
# [___CELL_SEPARATOR___]
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(feature_vectors, feature_labels, \
                                        test_size=0.3, random_state=42)
# [___CELL_SEPARATOR___]
%timeit feature_indices = knn_cnn_features.run_knn_features(X_train,test_vectors=X_test,k=3)
# [___CELL_SEPARATOR___]
feature_indices = knn_cnn_features.run_knn_features(X_train,test_vectors=X_test,k=3)
# [___CELL_SEPARATOR___]
similar_videos = y_train[feature_indices]
print("Accuracy:",get_cls_accuracy_ucf(similar_videos,y_test))
# [___CELL_SEPARATOR___]
similar_videos_flat = [item.split('_')[1] for sublist in similar_videos for item in sublist]
y_test_flat = [item.split('_')[1] for item in y_test for i in range(3)]
# [___CELL_SEPARATOR___]
from sklearn.metrics import confusion_matrix
cnf_matrix = confusion_matrix(y_test_flat, similar_videos_flat)
cnf_matrix = cnf_matrix.astype('float') / cnf_matrix.sum(axis=1)[:, np.newaxis]

import seaborn as sn
import pandas as pd
import matplotlib.pyplot as plt

df_cm = pd.DataFrame(cnf_matrix, range(51),
                  range(51))
plt.figure(figsize = (20,14))
sn.set(font_scale=0.1)#for label size
sn.heatmap(df_cm, annot=False)# font size ,annot_kws={"size": 16}
# [___CELL_SEPARATOR___]
notsogood = []
for i, row in enumerate(cnf_matrix):
    for j, colj in enumerate(row):
        if colj > 0.1 and i!=j:
            print(cnf_matrix[i,j])
            notsogood.append([i,j])
for nsgi in notsogood:
    print(ucf_classes[nsgi[1]],"->",ucf_classes[nsgi[0]])