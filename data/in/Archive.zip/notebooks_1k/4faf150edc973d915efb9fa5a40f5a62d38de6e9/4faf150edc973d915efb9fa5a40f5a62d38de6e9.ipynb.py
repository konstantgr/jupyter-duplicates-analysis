import numpy as np
import matplotlib.pyplot as plt
import gym
%matplotlib inline 
# [___CELL_SEPARATOR___]

from gym.envs.registration import register
register(id='FrozenLakeNotSlippery-v0',
    entry_point='gym.envs.toy_text:FrozenLakeEnv',
    kwargs={'map_name' : '4x4', 'is_slippery': False},
    max_episode_steps=100,
    reward_threshold=0.8196, # optimum = .8196
)
# [___CELL_SEPARATOR___]
from gym.envs.registration import register
register(
    id='FrozenLake8x8NotSlippery-v0',
    entry_point='gym.envs.toy_text:FrozenLakeEnv',
    kwargs={'map_name' : '8x8', 'is_slippery': False},
    max_episode_steps=100,
    reward_threshold=0.8196, # optimum = .8196
)
# [___CELL_SEPARATOR___]
#Change environment to FrozenLake8x8 to see grid.
env = gym.make('FrozenLake-v0')
# env = gym.make('FrozenLake8x8NotSlippery-v0')

print(env.observation_space.n)

#Both the grids look like as follows.
'''
    "4x4": [
        "SFFF",
        "FHFH",
        "FFFH",
        "HFFG"
    ],
    "8x8": [
        "SFFFFFFF",
        "FFFFFFFF",
        "FFFHFFFF",
        "FFFFFHFF",
        "FFFHFFFF",
        "FHHFFFHF",
        "FHFFHFHF",
        "FFFHFFFG"
    ]'''

#env.render() prints the frozenlake with an indicator showing where the agent is. You can use it for debugging.
env.render()
# [___CELL_SEPARATOR___]
print(env.observation_space.n)
print(env.action_space.n)
# [___CELL_SEPARATOR___]
Q = np.zeros([env.observation_space.n,env.action_space.n])

def choose_action(state):
    action=0
    if np.random.uniform(0, 1) < epsilon:
        action = env.action_space.sample()
    else:
        action = np.argmax(Q[state, :])
    return action

def learn(s, s1, r, a):
    predict = Q[s, a]
    target = r + gamma * np.max(Q[s1, :])
    Q[s, a] = Q[s, a] + lr_rate * (target - predict)
# [___CELL_SEPARATOR___]
# Set learning parameters
################

num_episodes = 10000
epsilon = 0.6
max_steps = 12
lr_rate = 0.7
gamma = 0.95

#num_episodes = 10
max_iter_per_episode = 20
li_sum_rewards = []
for i in range(num_episodes):
    iter = 0
            
    #Reset environment and get an initial state - should be done at start of each episode.
    s = env.reset()
    d = False
    j = 0
    sum_rewards = 0 # listed as G in the book
    while iter < max_iter_per_episode:
        iter+=1
        #Choose an action
        a = choose_action(s)
        # env.step() gives you next state, reward, done(whether the episode is over)
        # s1 - new state, r-reward, d-whether you are done or not
        s1,r,d,_ = env.step(a)
        sum_rewards += r
        
        #print('State : ',s, ' Action : ', a, ' State 1 : ', s1, ' Reward : ',r, 'Done : ', d)
        
        learn(s, s1, r, a)
        
        #if abs(r) > 0:
        #    print("r:", r)
            #assert False
        if iter > max_steps:
            d = True
            
        if d:
            li_sum_rewards.append(sum_rewards)
            #print('Episode Over')
            #if r != 1:
            #    print('Fell into hole with reward ', r)            
            break
        s = s1
plt.figure(figsize=(15,1))
plt.plot(li_sum_rewards)
plt.show()
# [___CELL_SEPARATOR___]
