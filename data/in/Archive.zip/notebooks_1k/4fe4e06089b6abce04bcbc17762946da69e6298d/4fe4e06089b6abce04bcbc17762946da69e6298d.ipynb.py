"""
Shopping List Calculator I
"""

# Create five variables,
# set them to strings that represent 5 common shopping list items


item_name_1 = None
item_name_2 = None
item_name_3 = None
item_name_4 = None
item_name_5 = None

# Create five more variables,
# set them to floats that represent the prices of each of the items above

item_price_1 = None
item_price_2 = None
item_price_3 = None
item_price_4 = None
item_price_5 = None

# Create five more variables,
# set them to ints that represent the quantity of each of the items above
item_quant_1 = None
item_quant_2 = None
item_quant_3 = None
item_quant_4 = None
item_quant_5 = None

# Print to the console the name and price of each item defined above as follows:
# 1 Coco Puffs = $8.95.
# where:
# 1 would be item_quant_1
# Coco Puffs would be item_name_1
# 8.95 would be item_name_2
