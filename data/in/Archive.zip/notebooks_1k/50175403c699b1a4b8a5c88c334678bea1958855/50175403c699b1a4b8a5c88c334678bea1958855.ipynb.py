import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier
from sklearn.metrics import mean_squared_error, accuracy_score, f1_score, r2_score, explained_variance_score, roc_auc_score
from sklearn.preprocessing import MinMaxScaler, OneHotEncoder, LabelBinarizer
from sklearn.neural_network import MLPClassifier, MLPRegressor
from sklearn.linear_model import Lasso

import torch
from torch import nn
import torch.nn.functional as F

torch.manual_seed(0)
np.random.seed(0)
# [___CELL_SEPARATOR___]
names = ['age', 'workclass', 'fnlwgt', 'education', 'education-num', 'marital-status', 'occupation', 'relationship', 'race', 'sex', 'capital-gain', 'capital-loss', 'hours-per-week', 'native-country', 'salary']
train = pd.read_csv('adult.data', names=names)
test = pd.read_csv('adult.test', names=names)

df = pd.concat([train, test])

print('raw original',df.shape)

datatypes_all = [
    ('age', 'positive int'),
    ('fnlwgt', 'positive int'),
    ('workclass', 'categorical'),
    ('education', 'categorical'),
    ('education-num', 'categorical'),
    ('marital-status', 'categorical'),
    ('occupation', 'categorical'),
    ('relationship', 'categorical'),
    ('race', 'categorical'),
    ('sex', 'categorical binary'),
    ('capital-gain', 'positive float'),
    ('capital-loss', 'positive float'),
    ('hours-per-week', 'positive int'),
    ('native-country', 'categorical'),
    ('salary', 'categorical binary'),
]
# [___CELL_SEPARATOR___]
class Processor:
    def __init__(self, datatypes):
        self.datatypes = datatypes
        
    def fit(self, matrix):
        preprocessors, cutoffs = [], []
        for i, (column, datatype) in enumerate(self.datatypes):
            preprocessed_col = matrix[:,i].reshape(-1, 1)

            if 'categorical' in datatype:
                preprocessor = LabelBinarizer()
            else:
                preprocessor = MinMaxScaler()

            preprocessed_col = preprocessor.fit_transform(preprocessed_col)
            cutoffs.append(preprocessed_col.shape[1])
            preprocessors.append(preprocessor)
        
        self.cutoffs = cutoffs
        self.preprocessors = preprocessors
    
    def transform(self, matrix):
        preprocessed_cols = []
        
        for i, (column, datatype) in enumerate(self.datatypes):
            preprocessed_col = matrix[:,i].reshape(-1, 1)
            preprocessed_col = self.preprocessors[i].transform(preprocessed_col)
            preprocessed_cols.append(preprocessed_col)

        return np.concatenate(preprocessed_cols, axis=1)

        
    def fit_transform(self, matrix):
        self.fit(matrix)
        return self.transform(matrix)
            
    def inverse_transform(self, matrix):
        postprocessed_cols = []

        j = 0
        for i, (column, datatype) in enumerate(self.datatypes):
            postprocessed_col = self.preprocessors[i].inverse_transform(matrix[:,j:j+self.cutoffs[i]])

            if 'categorical' in datatype:
                postprocessed_col = postprocessed_col.reshape(-1, 1)
            else:
                if 'positive' in datatype:
                    postprocessed_col = postprocessed_col.clip(min=0)

                if 'int' in datatype:
                    postprocessed_col = postprocessed_col.round()

            postprocessed_cols.append(postprocessed_col)
            
            j += self.cutoffs[i]
        
        return np.concatenate(postprocessed_cols, axis=1)
# [___CELL_SEPARATOR___]
datatypes_ori = [
    ('age', 'positive int'),
    ('workclass', 'categorical'),
    ('education-num', 'categorical'),
    ('marital-status', 'categorical'),
    ('occupation', 'categorical'),
    ('relationship', 'categorical'),
    ('race', 'categorical'),
    ('sex', 'categorical binary'),
    ('capital-gain', 'positive float'),
    ('capital-loss', 'positive float'),
    ('hours-per-week', 'positive int'),
    ('native-country', 'categorical'),
    ('salary', 'categorical binary'),
]
ori_df = df.drop(columns=['education', 'fnlwgt'])
print('after dropping',ori_df.shape)
map_back_ori = {}
map_forward_ori = {}
for column, datatype in datatypes_ori:
    if 'categorical' in datatype:
        series = ori_df[column].astype('category')
        ori_df[column] = series.cat.codes
        map_back_ori[column] = dict(enumerate(series.cat.categories)) # e.g. 9 --> 'USA'
        map_forward_ori[column] = dict(map(reversed, map_back_ori[column].items())) #e.g. 'USA' --> 9
ori_df=(ori_df.reset_index()).drop(columns='index')
map_forward_ori
# [___CELL_SEPARATOR___]
#TESTING MY HYPOTHESIS ABOUT Anderson's random forest
SELECTEDFEATURES = ['workclass','education','marital-status','occupation',
                    'relationship','race','sex','native-country','salary']  # ['workclass','education','marital-status','occupation','relationship','race','sex','native-country']

SIZE_DATASET = 4000 #also tried with 8000 and 48842. The score comes out similar, actually
ori_df_cut = df[SELECTEDFEATURES][:SIZE_DATASET]
for column, datatype in datatypes_all:
    if (column in ori_df_cut.columns) and ('categorical' in datatype):
        ori_df_cut[column] = ori_df_cut[column].astype('category').cat.codes
datatypes_anderson = [(col,datatype) for (col,datatype) in datatypes_all if col in ori_df_cut.columns]
ori_df_cut
#ori_scores,real_scores = get_scores(ori_df_cut,ori_df_cut,datatypes_anderson,return_original=True,anderson=True)
# [___CELL_SEPARATOR___]
#size 4000 was found in the original implementation of the work by Anderson, so we tried it as well. 
#With 4000 instead of 32561, it increases the accuracy (overfit?), but we report the lower accuracy score from 32561. 
def get_random_forest_score(df_input,df_test,SIZE_DATASET=4000,compute_f1=False,shuffle=True):
    if shuffle: 
        df = df_input.sample(frac=1).reset_index(drop=True)
    else:
        df = df_input
        
    X_train_encoded = df[:SIZE_DATASET].values
    X_test_encoded = df_test[:SIZE_DATASET].values

    clf = RandomForestClassifier(n_estimators=800, random_state=0)
    clf.fit(X_train_encoded[:,:-1], X_train_encoded[:,-1])
    prediction = clf.predict(X_test_encoded[:,:-1])
    score = accuracy_score(X_test_encoded[:,-1], prediction)
    print('accuracy score by random forest method is:',score)
    if compute_f1: 
        print('f_1 score is:',f1_score(X_test_encoded[:,-1], prediction))
        
    return score
    
get_random_forest_score(ori_df[:32561],ori_df[-16281:])
get_random_forest_score(ori_df_cut[:32561],ori_df_cut[-16281:])
# [___CELL_SEPARATOR___]
p = Processor(datatypes_ori)
p.fit(ori_df.values)

for path in ['synthetic_ae_0_2_gan_0_3.csv','synthetic_ae_0_4_gan_0_4.csv','synthetic_ae_0_7_gan_0_7.csv']:
    X_synthetic_encoded = pd.read_csv(path, index_col='Unnamed: 0')
    X_synthetic_real = p.inverse_transform(X_synthetic_encoded.to_numpy())
    synthetic_data = pd.DataFrame(X_synthetic_real, columns=ori_df.columns) #13 columns
    our_columns_for_random_forest = [col if col != 'education' else 'education-num' for col in ori_df_cut.columns]
    synthetic_data = synthetic_data[our_columns_for_random_forest]#.drop(columns='education-num')
    SIZE_DATASET=4000
    print('with training size',SIZE_DATASET,get_random_forest_score(synthetic_data, ori_df_cut[-16281:],SIZE_DATASET=SIZE_DATASET))
    SIZE_DATASET=32561
    print('with training size',SIZE_DATASET,get_random_forest_score(synthetic_data, ori_df_cut[-16281:],SIZE_DATASET=SIZE_DATASET))
# [___CELL_SEPARATOR___]
p = Processor(datatypes_ori)
p.fit(ori_df.values)

for path in ['synthetic_ae_0_2_gan_0_3.csv','synthetic_ae_0_4_gan_0_4.csv','synthetic_ae_0_7_gan_0_7.csv']:
    X_synthetic_encoded = pd.read_csv(path, index_col='Unnamed: 0')
    X_synthetic_real = p.inverse_transform(X_synthetic_encoded.to_numpy())
    synthetic_data = pd.DataFrame(X_synthetic_real, columns=ori_df.columns) #13 columns
    SIZE_DATASET=4000
    print('with training size',SIZE_DATASET,get_random_forest_score(synthetic_data, ori_df[-16281:],SIZE_DATASET=SIZE_DATASET))
    SIZE_DATASET=32561
    print('with training size',SIZE_DATASET,get_random_forest_score(synthetic_data, ori_df[-16281:],SIZE_DATASET=SIZE_DATASET))
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
