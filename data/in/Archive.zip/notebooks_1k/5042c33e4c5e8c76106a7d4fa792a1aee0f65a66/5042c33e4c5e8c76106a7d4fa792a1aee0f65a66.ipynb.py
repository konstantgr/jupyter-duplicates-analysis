import numpy as np
import matplotlib.pyplot as plt

x = np.linspace(-4,np.pi,100)
sin_x = np.sin(x)
plt.plot(x,sin_x)
d_x = np.cos(0.67)
plt.plot(x,d_x*x+d_x-0.67,'r')
plt.axvline(0.67,color="gray")
# [___CELL_SEPARATOR___]
import numpy as np
import matplotlib.pyplot as plt

def d_f_x_finite_difference(x_array,f_x,at_x):
    # Your code here
    ix = np.argwhere(x>=at_x)[0]
    return (f_x[ix+1]-f_x[ix]) / (x_array[ix+1]-x_array[ix]), ix

# create your input array
x = np.linspace(-4, 4, 1000)

# fill it with values from sin(x) and graph them
f_x = np.sin(x)
plt.plot(x, f_x);

# choose a value along x to compute the derivative
at_x = -2

# compute the derivative with d_f_x_finite_difference
dx, ix = d_f_x_finite_difference(x, f_x, at_x)

# graph the derivative as a line of the form y = mx+b
# getting `b` right is tricky, but the mx part is easy
m = dx
b = f_x[ix] - (dx * x[ix])
y = m * x + b

plt.plot(x, y);
plt.show()
