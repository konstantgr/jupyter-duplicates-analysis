Randomized Search with scikit-learn
# [___CELL_SEPARATOR___]
from sklearn import datasets

iris = datasets.load_iris()
X = iris.data[:,2:]
y = iris.target

from sklearn.model_selection import train_test_split, cross_val_score
X_train, X_test, y_train, y_test = train_test_split(X, y, stratify = y,random_state = 7)
# [___CELL_SEPARATOR___]
from sklearn.neighbors import KNeighborsClassifier

knn_clf = KNeighborsClassifier()
param_dist = {'n_neighbors': list(range(3,9,1))}
# [___CELL_SEPARATOR___]
from sklearn.model_selection import RandomizedSearchCV
rs = RandomizedSearchCV(knn_clf,param_dist,cv=10,n_iter=6)
rs.fit(X_train, y_train)
# [___CELL_SEPARATOR___]
rs.best_params_
# [___CELL_SEPARATOR___]
zip(rs.cv_results_['params'],rs.cv_results_['mean_test_score'])
# [___CELL_SEPARATOR___]
param_dist = {'n_neighbors': list(range(3,50,1))}
rs = RandomizedSearchCV(knn_clf,param_dist,cv=10,n_iter=15)
rs.fit(X_train,y_train)
rs.best_params_
# [___CELL_SEPARATOR___]
%timeit rs.fit(X_train,y_train)
# [___CELL_SEPARATOR___]
from sklearn.model_selection import GridSearchCV
param_grid = {'n_neighbors': list(range(3,50,1))}
gs = GridSearchCV(knn_clf,param_grid,cv=10)
%timeit gs.fit(X_train,y_train)
# [___CELL_SEPARATOR___]
gs.best_params_ 
# [___CELL_SEPARATOR___]
zip(gs.cv_results_['params'],gs.cv_results_['mean_test_score'])