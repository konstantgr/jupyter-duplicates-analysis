import math 
import numpy as np
import pandas as pd

import rdkit
from rdkit import Chem
from rdkit.Chem import AllChem
#from rdkit.Chem.AllChem import GenerateDepictionMatching3DStructure as Struct_3D
from rdkit.ForceField.rdForceField import MMFFMolProperties as properties
import rdkit.Chem.Draw as draw

from itertools import zip_longest
# from mpl_toolkits.mplot3d import Axes3D

# [___CELL_SEPARATOR___]
df = pd.read_csv('temp_cleaned_data.tsv',sep='\t')
# df = df.set_index('#')
df.head(3)
# [___CELL_SEPARATOR___]
num_atoms = []
for indexi, rowi in df.iterrows():
    smiles = df.name_smiles[indexi]
    molecule = Chem.MolFromSmiles(smiles)
    num_atoms.append(molecule.GetNumAtoms())
df['num_atoms'] = num_atoms
df = df.set_index('#')
df.head(3)
# [___CELL_SEPARATOR___]
# Defining the SMILES string from df
# benz_smiles = 'C1=CC2=C3C(=C(C=C2S(=O)(=O)[O-])S(=O)(=O)[O-])C=CC4=C(C=C(C1=C43)O)S(=O)(=O)[O-].[Na+].[Na+].[Na+]'
benz_smiles = '[CH-]1C=CC=C1.[CH-]1C=CC=C1.[Fe+2]'
# Building the benzene molecule
benz = Chem.MolFromSmiles(benz_smiles)
benz.GetNumAtoms()
# [___CELL_SEPARATOR___]
# Defining the SMILES string from df
#benz_smiles = df.name_smiles[1]
# Building the benzene molecule and ADDING HYDROGENS
benz = Chem.AddHs(Chem.MolFromSmiles(benz_smiles))
# 'Embedding' the molecule to assign coordinates to nuclei
AllChem.EmbedMolecule(benz)
# Optimising the molecule
AllChem.MMFFOptimizeMolecule(benz)
# Generating universal force field model
ff1 = AllChem.UFFGetMoleculeForceField(benz)
# Getting the positions of nuclei; returned as a tuple of the form (x1, y1, z1, x2, y2, z2, x3, ...)
pos1 = ff1.Positions()
# Drawing the molecule
draw.MolToImage(benz, kekulize=False) # can also use .MolToFile to save to a file
# [___CELL_SEPARATOR___]
benz_type = benz_H.GetAtoms()
# [___CELL_SEPARATOR___]
benz_H.GetNumAtoms()
# [___CELL_SEPARATOR___]
benz_type = []
for atom in benz_H.GetAtoms():
    benz_type.append(atom.GetAtomicNum())
#     print(atom.GetAtomicNum())
benz_type
# [___CELL_SEPARATOR___]
def grouper(n, iterable, fillvalue=None):
    "grouper(3, 'ABCDEFG', 'x') --> ABC DEF Gxx"
    args = [iter(iterable)] * n
    return zip_longest(fillvalue=fillvalue, *args)
# [___CELL_SEPARATOR___]
import matplotlib.pyplot as plt
x = []
y = []
z = []

# fig = plt.figure()
# ax = fig.add_subplot(111, projection='3d')
for item1, item2, item3 in grouper(3, pos2):
    x.append(item1)
    y.append(item2)
    z.append(item3)
#     ax.scatter(item1, item2, item3)
# [___CELL_SEPARATOR___]
benz_df = pd.DataFrame()
benz_df['charge'] = benz_type
benz_df['x'] = x
benz_df['y'] = y
benz_df['z'] = z
# benz_df.index += 1

benz_df
# [___CELL_SEPARATOR___]
def get_coulomb_matrix(molecule_df)
    num_atoms = len(molecule_df)
    coulomb = np.zeros(shape=(num_atoms,num_atoms))
    for indexi, rowi in benz_df.iterrows():
        for indexj, rowj in benz_df.iterrows():
            Zi = rowi.charge
            xi = rowi.x
            yi = rowi.y
            zi = rowi.z
            Zj = rowj.charge
            xj = rowj.x
            yj = rowj.y
            zj = rowj.z
            if indexi == indexj:
                element = 0.5 * math.pow(Zi, 2.4)
            else:
                norm_diff = math.sqrt(math.pow((xi-xj),2) + math.pow((yi-yj),2) + math.pow((zi-zj),2))
                element = Zi * Zj / norm_diff
            coulomb[indexi][indexj] = element
            
    return coulomb
# [___CELL_SEPARATOR___]
import utilities
from spDescriptors import spDescriptors as spD
# [___CELL_SEPARATOR___]
benzene = spD(df.name_smiles[0])
# [___CELL_SEPARATOR___]
benz_coulomb = benzene.get_coulomb_matrix()
# [___CELL_SEPARATOR___]
