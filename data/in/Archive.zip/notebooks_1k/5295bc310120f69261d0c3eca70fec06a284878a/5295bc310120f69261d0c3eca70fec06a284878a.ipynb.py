import pickle
import pprint
import matplotlib.pyplot as plt
import matplotlib.style as style
import numpy as np
import pandas as pd
from imblearn.over_sampling import SMOTE
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier, AdaBoostClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, roc_curve, classification_report, confusion_matrix,  _score, \
    recall_score
from sklearn.model_selection import train_test_split, GridSearchCV, cross_val_predict, KFold
from sklearn.naive_bayes import GaussianNB
from sklearn.pipeline import Pipeline
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import LinearSVC
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier

# [___CELL_SEPARATOR___]
import warnings
warnings.filterwarnings("ignore")

style.use('seaborn-whitegrid')
% matplotlib inline
# [___CELL_SEPARATOR___]
# # Change format of charts to .svg
%config InlineBackend.figure_format = 'svg'
# [___CELL_SEPARATOR___]
%xmode Plain
# [___CELL_SEPARATOR___]
df = pd.read_csv('data/clean_data_encoded_for_regression.csv')

X = df[['gender', 'senior', 'partner', 'dependents', 'tenure', 'phone_service',
       'multiple_lines', 'online_security', 'online_backup',
       'device_protection', 'tech_support', 'streaming_tv', 'streaming_movies',
       'paperless_billing', 'monthly_charges', 'total_charges',
       'avg_monthly_charges', 'internet_service-fiber_optic',
       'internet_service-no', 'contract-one_year', 'contract-two_year',
       'payment_method-credit_card_auto', 'payment_method-electronic_check',
       'payment_method-mailed_check']]

y = df['churn']

# Stratify our train-test-split so that we have a balanced split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=40, stratify=y)
# [___CELL_SEPARATOR___]
sm = SMOTE(random_state=42, ratio=1.0)
X_train_res, y_train_res = sm.fit_sample(X_train, y_train)
print(y_train.value_counts(), np.bincount(y_train_res)) 
# [___CELL_SEPARATOR___]
X_train_2, X_test_2, y_train_2, y_test_2 = train_test_split(X_train_res, y_train_res, test_size=0.33, random_state=20)
# [___CELL_SEPARATOR___]
def quick_test(model, X, y):
    xtrain, xtest, ytrain, ytest = train_test_split(X, y, test_size=0.3)
    model.fit(xtrain, ytrain)
    return model.score(xtrain, ytrain), model.score(xtest, ytest)


def quick_test_a_few_times(model, X, y, n=10):
    return (pd.DataFrame([quick_test(model, X, y) for j in range(n)],
                         columns=['Train Acc', 'Test Acc'])).mean()

new_model = make_pipeline(StandardScaler(), LinearSVC(max_iter=10000))
# pred = new_model.predict(X_test)
# Do the test 10 times with a LinearSVC and get the average score
print(quick_test_a_few_times(new_model, X_train_2, y_train_2))

# [___CELL_SEPARATOR___]
def get_scores(model):
    mod = model
    mod = mod.fit(X_train_2, y_train_2)
    predictions = mod.predict(X_test_2)
    # quick_test_a_few_times(decisiontree, X_train, y_train)

    print(f'**Model: {mod}**')
    print(f'Train accuracy: {mod.score(X_train_2, y_train_2)}')
    print(f'Test accuracy: {mod.score(X_test_2, y_test_2)}')
    print(f'Precision: {precision_score(y_test_2, predictions)}')
    print(f'Recall: {recall_score(y_test_2, predictions)}')
    print()
    print(classification_report(y_test_2, predictions))
    print()
# [___CELL_SEPARATOR___]
def evaluate_models(model_types: list):
    for model in model_types:
        m = model_types[model]
        quick_test_a_few_times(X_train_2, y_train_2)
        get_scores(m)


models = [
    {
        'label': 'Logistic Regression',
        'model': LogisticRegression(),
    },
    {
        'label': 'Gradient Boosting',
        'model': GradientBoostingClassifier(),
    },
    {
        'label': 'Random Forest',
        'model': RandomForestClassifier(),
    },
    {
        'label': 'AdaBoost Classifier',
        'model': AdaBoostClassifier(),
    },
    {
        'label': 'Support Vector Classifier',
        'model': SVC(probability=True),
    }
]

# evaluate_models(models)

decision_tree = DecisionTreeClassifier()
quick_test_a_few_times(decision_tree, X_train_2, y_train_2)
get_scores(decision_tree)
# [___CELL_SEPARATOR___]
random_forest = RandomForestClassifier()
quick_test_a_few_times(random_forest, X_train_2, y_train_2)
get_scores(random_forest)
# [___CELL_SEPARATOR___]
grad_boost = GradientBoostingClassifier()
quick_test_a_few_times(grad_boost, X_train_2, y_train_2)
get_scores(grad_boost)
# [___CELL_SEPARATOR___]
ada_boost = AdaBoostClassifier()
quick_test_a_few_times(ada_boost, X_train_2, y_train_2)
get_scores(ada_boost)
# [___CELL_SEPARATOR___]
logreg = LogisticRegression()
quick_test_a_few_times(logreg, X_train_2, y_train_2)
get_scores(logreg)
# [___CELL_SEPARATOR___]
linearsvc = LinearSVC()
quick_test_a_few_times(linearsvc, X_train_2, y_train_2)
# [___CELL_SEPARATOR___]
svc_rbf = SVC(kernel='rbf')
quick_test_a_few_times(svc_rbf, X_train_2, y_train_2)
# [___CELL_SEPARATOR___]
svc_poly = SVC(kernel='poly')
quick_test_a_few_times(svc_poly, X_train_2, y_train_2)
# [___CELL_SEPARATOR___]
gaussian_naive_bayes = GaussianNB()
quick_test_a_few_times(gaussian_naive_bayes, X_train_2, y_train_2)
# [___CELL_SEPARATOR___]
model = make_pipeline(StandardScaler(), SVC())
model.fit(X_train_2, y_train_2)
pred = model.predict(X_test_2)

quick_test_a_few_times(model, X_train_2, y_train_2)
# [___CELL_SEPARATOR___]
model = make_pipeline(StandardScaler(), SVC(kernel='rbf'))
model.fit(X_train_2, y_train_2)
pred = model.predict(X_test_2)

quick_test_a_few_times(model, X_train_2, y_train_2)
# [___CELL_SEPARATOR___]
decisiontree = DecisionTreeClassifier()
decisiontree.fit(X_train_2, y_train_2)
coeffs = decisiontree.feature_importances_ # it's a percentage

list_of_coeffs = list(sorted(zip(coeffs, X.columns)))
# [___CELL_SEPARATOR___]
import pprint
pprint.pprint(list_of_coeffs)
# [___CELL_SEPARATOR___]
list_of_coeffs = list(sorted(zip(coeffs, X.columns)))
pprint.pprint(list_of_coeffs)
# [___CELL_SEPARATOR___]
grad_boost = GradientBoostingClassifier()
grad_boost.fit(X_train_2, y_train_2)
grad_boost.feature_importances_ # values are between 0 and 1, not normalized
grad_boost.train_score_.mean()
# [___CELL_SEPARATOR___]
s2 = LinearSVC()
s2.fit(X_train, y_train)
s2.coef_ # the absolute value dictates importance
# [___CELL_SEPARATOR___]
log_reg = LogisticRegression()
log_reg.fit(X_train, y_train)
log_reg.coef_ # the abosulute value dictates importance
# [___CELL_SEPARATOR___]
plt.figure(figsize=(8, 8))

# Iterate through the list of models
for m in models:
    model = m['model']  # select the model
    model.fit(X_train_res, y_train_res)  # train the model
    y_pred = model.predict(X_test)  # predict the test data
    # Compute False postive rate, and True positive rate
    fpr, tpr, thresholds = roc_curve(y_test, model.predict_proba(X_test)[:, 1])
    # Calculate Area under the curve to display on the plot
    auc = roc_auc_score(y_test, model.predict(X_test))
    # Now, plot the computed values
    plt.plot(fpr, tpr, label='%s ROC (area = %0.2f)' % (m['label'], auc))
# Custom settings for the plot 
# plt.plot([0, 1], [0, 1],'r--')
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel('Specificity(False Positive Rate)', fontsize=12, labelpad=10)
plt.ylabel('Sensitivity(True Positive Rate)', fontsize=12, labelpad=10)
plt.title('Receiver Operating Characteristic (ROC) Curve', fontsize=12)
plt.legend(loc="lower right")
plt.show()
plt.savefig('visualizations/ROC_curve.jpg', dpi=300)

# [___CELL_SEPARATOR___]
plt.figure(figsize=(8,8))

# Add the models to the list that you want to view on the ROC plot
models = [
{
    'label': 'Logistic Regression',
    'model': make_pipeline(StandardScaler(), LogisticRegression())
},
{
    'label': 'Gradient Boosting',
    'model': GradientBoostingClassifier(),
},
{
    'label': 'Random Forest',
    'model': RandomForestClassifier(),
},
{
    'label': 'AdaBoost Classifier',
    'model': AdaBoostClassifier(),
},
{
    'label': 'Support Vector Classifier',
    'model': SVC(probability=True),
},
{
    'label': 'Naive Bayes',
    'model': GaussianNB(),
}
]

# Below for loop iterates through your models list
for m in models:
    model = m['model'] # select the model
    model.fit(X_train_2, y_train_2) # train the model
    y_pred=model.predict(X_test_2) # predict the test data
# Compute False postive rate, and True positive rate
    fpr, tpr, thresholds = roc_curve(y_test_2, model.predict_proba(X_test_2)[:,1])
# Calculate Area under the curve to display on the plot
    auc = roc_auc_score(y_test_2,model.predict(X_test_2))
# Now, plot the computed values
    plt.plot(fpr, tpr, label='%s ROC (area = %0.2f)' % (m['label'], auc))
# Custom settings for the plot 
plt.plot([0, 1], [0, 1],'r--')
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel('1-Specificity(False Positive Rate)')
plt.ylabel('Sensitivity(True Positive Rate)')
plt.title('Receiver Operating Characteristic (ROC) Curve')
plt.legend(loc="lower right")
plt.show()
# plt.savefig('visualizations/ROC_curve.svg')
# [___CELL_SEPARATOR___]
param_grid = {'C': [0.1, 10.]}

clf = make_pipeline(StandardScaler(), 
                    GridSearchCV(LogisticRegression(),
                                 param_grid=param_grid,
                                 cv=2,
                                 refit=True))

clf.fit(X_train, y_train)
pred = clf.predict(X_test)
# [___CELL_SEPARATOR___]
y_test
# [___CELL_SEPARATOR___]
LogisticRegression().get_params().keys()
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
print(classification_report(y_test, pred))
# [___CELL_SEPARATOR___]
df['churn'].value_counts()
# [___CELL_SEPARATOR___]
1869/(5163+1869)
# [___CELL_SEPARATOR___]
clf = make_pipeline(StandardScaler(), 
                    GridSearchCV(LogisticRegression(),
                                 param_grid={'C': [0.1, 1.0, 10.]},
                                 cv=3,
                                 refit=True))
# [___CELL_SEPARATOR___]
clf.fit(X_train, y_train)
# [___CELL_SEPARATOR___]
new_x = pd.DataFrame(X_train)
# [___CELL_SEPARATOR___]
new_x.shape
# [___CELL_SEPARATOR___]
clf.fit(X_train, y_train)
# [___CELL_SEPARATOR___]
new = clf.predict(new_x)
# [___CELL_SEPARATOR___]
print(classification_report(y_test, new))
# [___CELL_SEPARATOR___]
pipe = Pipeline([('scaler', StandardScaler()), ('clf', LogisticRegression())])
param_grid = [{'clf__C': [0.8, 1, 1.1, 1.2, 1.3, 1.5, 1.6], 'clf__class_weight': [None, 'balanced'],
               'clf__solver': ['liblinear', 'sag', 'saga']}]
gs = GridSearchCV(pipe, param_grid, cv=5, scoring='recall')
gs.fit(X_train_res, y_train_res)

# [___CELL_SEPARATOR___]
gs.best_params_
# [___CELL_SEPARATOR___]
pred = gs.predict(X_test)
# [___CELL_SEPARATOR___]
print(classification_report(y_test, pred))
# [___CELL_SEPARATOR___]
print(confusion_matrix(y_test, pred))
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
np.median(gs.cv_results_['mean_test_score'])
# [___CELL_SEPARATOR___]
pred = gs.predict(X_train)
# [___CELL_SEPARATOR___]
print(classification_report(y_train, pred))
print(confusion_matrix(y_train, pred))
# [___CELL_SEPARATOR___]
pred.shape
# [___CELL_SEPARATOR___]
logistic_gain_2 = []
i_vals = []
cost = []
savings = []
i = .01

pred = gs.predict(X_train)

for i in np.linspace(0, 1, 101):
    folds = KFold(n_splits=5, shuffle=True)
    probs = cross_val_predict(gs.best_estimator_, X_train, y_train, cv=folds, method='predict_proba', n_jobs=-1)
    probs = pd.DataFrame(probs)
    new_pred = probs[1].apply(lambda x: 1 if x > i else 0)
    conf = confusion_matrix(y_train, new_pred)

    total_cost = (conf[0][1] * 100) + (conf[1][1] * 100) + (conf[1][0] * 500)
    total_savings = conf[1][1] * 500

    net_gain = total_savings - total_cost
    logistic_gain_2.append(net_gain)
    i_vals.append(i)
    cost.append(total_cost)
    savings.append(total_savings)

print(f'Max net gain = {max(logistic_gain_2)}')

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
pipe = Pipeline([('scaler', StandardScaler()), ('clf', LogisticRegression(random_state=11))])
param_grid = [{'clf__C': [0.001, 0.1, 1.0], 'clf__solver': ['newton-cg', 'lbfgs', 'liblinear', 'sag', 'saga']}]
gs = GridSearchCV(pipe, param_grid, cv=5, n_jobs=-1, scoring='recall')
gs.fit(X_train_res, y_train_res)

# [___CELL_SEPARATOR___]
gs.best_params_
# [___CELL_SEPARATOR___]
np.median(gs.cv_results_['mean_train_score'])
# [___CELL_SEPARATOR___]
pred = gs.predict(X_train)
# [___CELL_SEPARATOR___]
print(classification_report(y_train, pred))
print(confusion_matrix(y_train, pred))
# [___CELL_SEPARATOR___]
np.linspace(0, 1, 101)
# [___CELL_SEPARATOR___]
logistic_gain = []
i_vals = []
cost = []
savings = []
i = .01

pred = gs.predict(X_train)

for i in np.linspace(0, 1, 101):
    folds = KFold(n_splits=5, shuffle=True)
    probs = cross_val_predict(gs.best_estimator_, X_train, y_train, cv=folds, method='predict_proba', n_jobs=-1)
    probs = pd.DataFrame(probs)
    new_pred = probs[1].apply(lambda x: 1 if x > i else 0)
    conf = confusion_matrix(y_train, new_pred)

    total_cost = (conf[0][1] * 100) + (conf[1][1] * 100) + (conf[1][0] * 500)
    total_savings = conf[1][1] * 500

    net_gain = total_savings - total_cost
    logistic_gain.append(net_gain)
    i_vals.append(i)
    cost.append(total_cost)
    savings.append(total_savings)

print(f'Max net gain = {max(logistic_gain)}')

# [___CELL_SEPARATOR___]
for i, v in enumerate(logistic_gain):
    if v == 272200:
        print(i)
# [___CELL_SEPARATOR___]
probs = pd.DataFrame(gs.predict_proba(X_train))
new_pred = probs[1].apply(lambda x: 1 if x > 0.22 else 0)
conf = confusion_matrix(y_train, new_pred)
print(conf)
# [___CELL_SEPARATOR___]
fig, ax = plt.subplots(figsize=(8,6))
plt.plot(i_vals, logistic_gain, label='Net Gain')
plt.plot(i_vals, cost, label='Cost')
plt.plot(i_vals,savings, label='Savings')
plt.legend(loc=0)
# [___CELL_SEPARATOR___]
fig, ax = plt.subplots(figsize=(8,6))
plt.plot(i_vals, logistic_gain, label='Net Gain')
plt.plot(i_vals, cost, label='Cost')
plt.plot(i_vals,savings, label='Savings')
plt.legend(loc=0)
# [___CELL_SEPARATOR___]
conf = confusion_matrix(y_train, pred)
# [___CELL_SEPARATOR___]
total_cost = (conf[0][1] * 100) + (conf[1][1] * 100)
total_savings = conf[1][1] * 500
# [___CELL_SEPARATOR___]
net_gain = total_savings - total_cost
print(net_gain)
# [___CELL_SEPARATOR___]
gs.score(X_train, y_train)
# [___CELL_SEPARATOR___]
coeffs = gs.best_estimator_.named_steps['clf'].coef_[0]
list_of_coeffs = list(sorted(zip(coeffs * 10, X.columns)))

# [___CELL_SEPARATOR___]
pipe = Pipeline([('scaler', StandardScaler()), ('clf', GradientBoostingClassifier())])
param_grid = [{'clf__learning_rate': [0.01, 0.1, 0.5, 1], 'clf__loss': ['deviance', 'exponential'],
               'clf__n_estimators': [50, 100, 150], 'clf__max_depth': [2, 3, 4]}]
gs = GridSearchCV(pipe, param_grid, cv=5, n_jobs=-1, scoring='recall')
gs.fit(X_train_res, y_train_res)

# [___CELL_SEPARATOR___]
gs.best_params_
# [___CELL_SEPARATOR___]
gs.best_score_
# [___CELL_SEPARATOR___]
np.median(gs.cv_results_['mean_test_score'])
# [___CELL_SEPARATOR___]
pred2 = gs.predict(X_train)
print(classification_report(y_train, pred2))
# [___CELL_SEPARATOR___]
pred2 = gs.predict(X_train)
print(classification_report
# [___CELL_SEPARATOR___]
fig, ax = plt.subplots(figsize=(8, 6))
plt.plot(i_vals, gradboost_gain, label='Net Gain')
plt.plot(i_vals, cost, label='Cost')
plt.plot(i_vals, savings, label='Savings')
plt.legend(loc=0)
# plt.savefig('gradientboost_triple.svg')

# [___CELL_SEPARATOR___]
pipe = Pipeline([('scaler', StandardScaler()), ('clf', AdaBoostClassifier())])
param_grid = [{'clf__learning_rate': [0.01, 0.1, 1], 'clf__algorithm': ['SAMME'], 'clf__n_estimators': [25, 50, 100]}]
gs = GridSearchCV(pipe, param_grid, cv=5, n_jobs=-1, scoring='recall')
gs.fit(X_train_res, y_train_res)

# [___CELL_SEPARATOR___]
gs.best_params_
# [___CELL_SEPARATOR___]
np.median(gs.cv_results_['mean_test_score'])
# [___CELL_SEPARATOR___]
pred = gs.predict(X_train)
print(classification_report(y_train, pred))
# [___CELL_SEPARATOR___]
np.median(gs.cv_results_['mean_test_score'])
# [___CELL_SEPARATOR___]
pred = gs.predict(X_train)
print(classification_report(y_train, pred))
# [___CELL_SEPARATOR___]
np.median(gs.cv_results_['mean_test_score'])
# [___CELL_SEPARATOR___]
adaboost_gain = []
i_vals = []
cost = []
savings = []

pred = gs.predict(X_train)

for i in np.linspace(0.0, 1.0, 101):
    folds = KFold(n_splits=5, shuffle=True)
    probs = cross_val_predict(gs.best_estimator_, X=X_train, y=y_train, cv=folds, method='predict_proba', n_jobs=-1)
    probs = pd.DataFrame(probs)
    #     probs = pd.DataFrame(gs.predict_proba(X_train))
    new_pred = probs[1].apply(lambda x: 1 if x > i else 0)
    conf = confusion_matrix(y_train, new_pred)

    total_cost = (conf[0][1] * 100) + (conf[1][1] * 100) + conf[1][0] * 500
    total_savings = conf[1][1] * 500

    net_gain = total_savings - total_cost
    adaboost_gain.append(net_gain)
    i_vals.append(i)
    cost.append(total_cost)
    savings.append(total_savings)

print(f'Max net gain = {max(adaboost_gain)}')

# [___CELL_SEPARATOR___]
fig, ax = plt.subplots(figsize=(8,6))
plt.plot(i_vals, adaboost_gain, label='Net Gain')
plt.plot(i_vals, cost, label='Cost')
plt.plot(i_vals,savings, label='Savings')
plt.legend(loc=0)
# [___CELL_SEPARATOR___]
pipe = Pipeline([('scaler', StandardScaler()), ('clf', RandomForestClassifier())])
param_grid = [{'clf__max_depth': [4, 5, 6], 'clf__max_features': [5, 10, 15, 20], 'clf__n_estimators': [50, 100, 150]}]
gs = GridSearchCV(pipe, param_grid, cv=5, n_jobs=-1, scoring='recall')
gs.fit(X_train_res, y_train_res)

# [___CELL_SEPARATOR___]
gs.best_params_
# [___CELL_SEPARATOR___]
np.median(gs.cv_results_['mean_test_score'])
# [___CELL_SEPARATOR___]
pred = gs.predict(X_train)
print(classification_report(y_train, pred))
# [___CELL_SEPARATOR___]
# Test against our test set
gs.score(X_test, y_test)
# [___CELL_SEPARATOR___]
randforest_gain = []
i_vals = []
cost = []
savings = []

pred = gs.predict(X_train)

for i in np.linspace(0.0, 1.0, 101):
    folds = KFold(n_splits=5, shuffle=True)
    probs = cross_val_predict(gs.best_estimator_, X_train, y_train, cv=folds, method='predict_proba', n_jobs=-1)
    probs = pd.DataFrame(probs)
    #     probs = pd.DataFrame(gs.predict_proba(X_train))
    new_pred = probs[1].apply(lambda x: 1 if x > i else 0)
    conf = confusion_matrix(y_train, new_pred)

    total_cost = (conf[0][1] * 100) + (conf[1][1] * 100) + conf[1][0] * 500
    total_savings = conf[1][1] * 500

    net_gain = total_savings - total_cost
    randforest_gain.append(net_gain)
    i_vals.append(i)
    cost.append(total_cost)
    savings.append(total_savings)

print(f'Max net gain = {max(randforest_gain)}')

# [___CELL_SEPARATOR___]
def make_backups():
    with open('backups/randforest.pkl', 'wb') as f:
        pickle.dump(randforest_gain, f)
        
    with open('backups/logistic.pkl', 'wb') as f:
        pickle.dump(logistic_gain, f)
        
    with open('backups/gradboost.pkl', 'wb') as f:
        pickle.dump(gradboost_gain, f)
        
# make_backups()
# [___CELL_SEPARATOR___]
y_train.shape
# [___CELL_SEPARATOR___]
new_pred_ones = np.ones(shape=(4922,))

conf = confusion_matrix(y_train, new_pred_ones)

total_cost = (conf[0][1] * 100) + (conf[1][1] * 100) + conf[1][0] * 500
total_savings = conf[1][1] * 500

net_gain = total_savings - total_cost
print(net_gain)

# [___CELL_SEPARATOR___]
new_pred_zeros = np.zeros(shape=(4922,))

conf = confusion_matrix(y_train, new_pred_zeros)

total_cost = (conf[0][1] * 100) + (conf[1][1] * 100) + conf[1][0] * 500
total_savings = conf[1][1] * 500

net_gain = total_savings - total_cost
print(net_gain)

# [___CELL_SEPARATOR___]
conf
# [___CELL_SEPARATOR___]
net_gain
# [___CELL_SEPARATOR___]
# 1308 customers will churn, at an average cost to replace of $500 each
# $654,000 loss, which is why our predictions bottom out at that number on the following chart (good to confirm that it does!)
1308 * 500
# [___CELL_SEPARATOR___]
fig, ax = plt.subplots(figsize=(8, 6))
plt.plot(i_vals, logistic_gain, label='Logistic Regression', color='green', lw=2)
ax.axhline(y=0, color='black')
ax.set_xlabel('Probability Threshold', fontsize=16, labelpad=10)
ax.set_ylabel('$ Saved', rotation=90, fontsize=16, labelpad=10)
ax.set_yticklabels(['-100k', '0', '100k', '200k', '300k'], fontsize=12)
ax.set_xticklabels(['0', '0.1', '0.2', '0.3', '0.4', '0.5'], fontsize=12)
ax.set_yticks([-100000, 0, 100000, 200000, 300000])
ax.set_xbound(lower=0, upper=0.5)
ax.set_ybound(lower=-100000, upper=300000)
# plt.savefig('visualizations/net_cost_8.jpg', dpi=300)

# [___CELL_SEPARATOR___]
fig, ax = plt.subplots(figsize=(8, 6))
plt.plot(i_vals, logistic_gain, label='Logistic Regression', lw=2)
plt.plot(i_vals, randforest_gain, label='Random Forests', lw=2)
plt.plot(i_vals, gradboost_gain, label='Gradient Boost', lw=2)
plt.legend(loc=0)
ax.set_xlabel('Probability Threshold', fontsize=16, labelpad=10)
ax.set_ylabel('$ Saved', rotation=90, fontsize=16, labelpad=10)
ax.set_xbound(lower=0, upper=1)
# plt.savefig('visualizations/net_cost_9.jpg', dpi=300)

# [___CELL_SEPARATOR___]
def makecost(obs,prob,falsepos_cost,falseneg_cost):
    def cost(cutoff):
        pred = np.array(prob > cutoff)
        fpos = pred * (1 - obs)
        fneg = (1 - pred) * obs
        return np.sum(fpos * falsepos_cost + fneg * falseneg_cost)
    return np.vectorize(cost)
# [___CELL_SEPARATOR___]
cut = np.linspace(0, 1, 100)
cost = np.zeros_like(cut)
from sklearn.model_selection import KFold, cross_val_predict

obs = y_train

K = 20
for j in range(K):
    folds = KFold(n_splits=5, shuffle=True)
    prob = cross_val_predict(gs.best_estimator_, X_train, obs, cv=folds, method='predict_proba', n_jobs=5)[:, 1]
    getcost = makecost(obs, prob, falsepos_cost=100, falseneg_cost=500)
    currentcost = getcost(cut) / X.shape[0]
    cost += currentcost
    plt.plot(cut, currentcost, c='C0', alpha=0.05)
cost /= K
plt.plot(cut, cost, c='C0')
plt.xlabel('cutoff')
plt.ylabel('Expected cost per data point');

# [___CELL_SEPARATOR___]
bestcut = cut[np.argmin(cost)]
bestcut
# [___CELL_SEPARATOR___]
categories = ['Logistic Regression', 'AdaBoost', 'Random Forests', 'Gradient Boosting']
recall_pct = [0.81, 0.74, 0.72, 0.68]
net_gain = [272000, 257200, 262800, 263600]
# [___CELL_SEPARATOR___]
categories = ['Do nothing', 'Assume everyone will churn', 'Our model']
gain = [-654000, 162000, 272000]

fig, ax = plt.subplots(figsize=(8,8))
barlist = ax.bar(categories, gain, edgecolor='black')
ax.axhline(y=0, color='black')
ax.set_xticklabels(['Do\nnothing', 'Retain\neveryone', 'Our\nmodel'], fontsize=20)
ax.set_yticklabels(['-$600k', '-$400k', '-$200k', '$0', '200k','400k'], fontsize=20)
ax.set_yticks([-600000, -400000, -200000, 0, 200000, 400000])
ax.set_ybound(lower=-700000, upper=400000)
barlist[2].set_edgecolor('black')
plt.grid(axis='x')
# plt.savefig('visualizations/our_model.jpg', dpi=300)
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
categories = ['Do nothing', 'Assume everyone will churn', 'Build a model']
gain = [-654000, 162000, 0]

fig, ax = plt.subplots(figsize=(8,8))
barlist = ax.bar(categories, gain, edgecolor='black')
ax.axhline(y=0, color='black')
ax.set_xticklabels(['Do\nnothing', 'Retain\neveryone', 'Build a\nmodel'], fontsize=20)
ax.set_yticklabels(['-$600k', '-$400k', '-$200k', '$0', '200k','400k'], fontsize=20)
ax.set_yticks([-600000, -400000, -200000, 0, 200000, 400000])
ax.set_ybound(lower=-700000, upper=400000)
plt.grid(axis='x')
# plt.savefig('visualizations/model_comparison.jpg', dpi=300)
# [___CELL_SEPARATOR___]
