# Headers 

import random
import seaborn as sns
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

from copy import copy
from collections import Counter
from dataset import Dataset as dataset
from imblearn.under_sampling import RandomUnderSampler
from imblearn.over_sampling import RandomOverSampler, SMOTE
from imblearn.under_sampling import NearMiss
from scipy.stats import kruskal
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedShuffleSplit
from sklearn.model_selection import cross_val_score, StratifiedKFold
from sklearn.metrics import accuracy_score, f1_score, recall_score, matthews_corrcoef
from sklearn.pipeline import Pipeline
from sklearn.utils import resample
from tqdm import tqdm_notebook
from typing import List


# This line is important if you want your results to be reproducible
np.random.seed(666)
# [___CELL_SEPARATOR___]
URL = 'http://archive.ics.uci.edu/ml/machine-learning-databases/cmc/cmc.data'
df = dataset(URL, header=None)
df.to_int()
df.set_target('x9')

df = df.to_categorical(['x1', 'x2', 'x4', 'x5', 'x6', 'x7', 'x8'])
df.discretize('x0', [(15, 20), (20, 25), (25, 30),
                     (30, 35), (35, 40), (40, 50)])
df.discretize('x3', [(0, 2), (2, 4), (4, 6), (6, 8), (8, 10), (10, 20)])
df.onehot_encode(df.names('features'))
# [___CELL_SEPARATOR___]
df_unbalanced = copy(df)
df_unbalanced.target.value_counts()
# [___CELL_SEPARATOR___]
df_unbalanced.drop_samples(df_unbalanced.samples_matching(3))
df_unbalanced.target.value_counts()
# [___CELL_SEPARATOR___]
df_unbalanced.drop_samples(random.sample(df_unbalanced.samples_matching(2), k=300))
df_unbalanced.target.value_counts()
# [___CELL_SEPARATOR___]
def init_dataset():
    URL = 'http://archive.ics.uci.edu/ml/machine-learning-databases/cmc/cmc.data'
    df = dataset(URL, header=None)
    df.to_int()
    df.set_target('x9')

    # Binomial
    df.drop_samples(df.samples_matching(3))

    df = df.to_categorical(['x1', 'x2', 'x4', 'x5', 'x6', 'x7', 'x8'])
    df.discretize('x0', [(15, 20), (20, 25), (25, 30),
                         (30, 35), (35, 40), (40, 50)])
    df.discretize('x3', [(0, 2), (2, 4), (4, 6), (6, 8), (8, 10), (10, 20)])
    df.onehot_encode(df.names('features'));

    return df
# [___CELL_SEPARATOR___]
X, y = df_unbalanced.split(test_size=0.2)

clf_baseline = LogisticRegression().fit(X.train, y.train)
pred_baseline = clf_baseline.predict(X.test)

print('Accuracy: ', accuracy_score(y.test, pred_baseline).round(3))
# [___CELL_SEPARATOR___]
print(np.unique(pred_baseline))
# [___CELL_SEPARATOR___]
print('F1:', f1_score(y.test, pred_baseline))
print('Recall:', recall_score(y.test, pred_baseline))
print('MCC:', matthews_corrcoef(y.test, pred_baseline))
# [___CELL_SEPARATOR___]
def evaluate_LogReg(X_train, y_train, X_test, y_test, 
                    return_score='F1',
                    printout=False):
    """
    Fits a logistic regression with the training set, and evaluates it with 
    the test set, using Accuracy, F1, Recall or MCC metrics

    """
    lr = LogisticRegression().fit(X_train, y_train)
    y_hat = lr.predict(X_test)

    accuracy = accuracy_score(y_test, y_hat)
    F1 = f1_score(y_test, y_hat)
    recall = recall_score(y_test, y_hat)
    MCC = matthews_corrcoef(y_test, y_hat)
    
    if printout is True:
        print('Accuracy:', accuracy)
        print('F1:', F1)
        print('Recall:', recall)
        print('MCC:', MCC)
    
    return eval(return_score)
# [___CELL_SEPARATOR___]
X_test = X.test
y_test = y.test
X = pd.concat([X.train, y.train], axis=1)

class_1 = X[X.x9 == 1]
class_2 = X[X.x9 == 2]

oversampled = resample(class_2, replace=True, n_samples=len(class_1),
                       random_state=666)

oversampled = pd.concat([class_1, oversampled])
oversampled.x9.value_counts()
# [___CELL_SEPARATOR___]
y_train = oversampled.x9
X_train = oversampled.drop('x9', axis=1)

random_oversample = evaluate_LogReg(X_train, y_train, X_test, y_test, printout=True)
# [___CELL_SEPARATOR___]
X, y = df_unbalanced.split(test_size=0.2)
X_train, y_train = SMOTE().fit_resample(X.train.values, y.train.values)

unique, counts = np.unique(y_train, return_counts=True)
print('Oversample count\n', np.asarray((unique, counts)).T, '\n')

smote_oversample = evaluate_LogReg(X_train, y_train, X_test, y_test, printout=True)
# [___CELL_SEPARATOR___]
X, y = df_unbalanced.split(test_size=0.2)
X_test = X.test
y_test = y.test

X = pd.concat([X.train, y.train], axis=1)

class_1 = X[X.x9 == 1]
class_2 = X[X.x9 == 2]

undersampled = resample(class_1, replace=True,
                        n_samples=len(class_2), random_state=666)

undersampled = pd.concat([undersampled, class_2])
undersampled.x9.value_counts()
# [___CELL_SEPARATOR___]
y_train = undersampled.x9
X_train = undersampled.drop('x9', axis=1)

random_undersample = evaluate_LogReg(X_train, y_train, X_test, y_test, printout=True)
# [___CELL_SEPARATOR___]
X, y = df_unbalanced.split(test_size=0.2)

undersampled = RandomUnderSampler(random_state=666)
X_train, y_train = undersampled.fit_resample(X.train.values, y.train.values)

unique, counts = np.unique(y_train, return_counts=True)
print('Undersample count\n', np.asarray((unique, counts)).T, '\n')

random_undersample = evaluate_LogReg(X_train, y_train, X_test, y_test, printout=True)
# [___CELL_SEPARATOR___]
X, y = df_unbalanced.split(test_size=0.2)
X_train, y_train = NearMiss().fit_resample(X.train.values, y.train.values)

unique, counts = np.unique(y_train, return_counts=True)
print('Undersample count\n', np.asarray((unique, counts)).T, '\n')

tomek_undersample = evaluate_LogReg(X_train, y_train, X_test, y_test, printout=True);
# [___CELL_SEPARATOR___]
plt.title('Summary of results')
plt.bar(range(4), [random_oversample, smote_oversample, random_undersample, tomek_undersample])
plt.xticks(range(4), ('R.Oversample','SMOTE','R.Undersample','Tomek Links'))
plt.show()
# [___CELL_SEPARATOR___]
df = init_dataset()
X, y = df.split()
# [___CELL_SEPARATOR___]
lr = LogisticRegression().fit(X.train, y.train)
y_hat = lr.predict(X.test)
y_probs = lr.predict_proba(X.test)

counts = y.test.x9.value_counts()
print('{} samples in test set, {} from class_1, and {} from class_2'.format(
    y.test.shape[0], counts.iloc[0], counts.iloc[1]))
# [___CELL_SEPARATOR___]
y_probs[:5]
# [___CELL_SEPARATOR___]
test_set = pd.concat([X.test, y.test], axis=1)
null_model = test_set.apply(
    lambda row: -0.6152 if row['x9'] == 1 else -1.5264, axis=1).sum()

print('Log likelihood of the null model:', null_model.round(2))
# [___CELL_SEPARATOR___]
mr = pd.DataFrame({'x9': y.test.values.ravel(), 'prob': y_probs[:, 0]})
mr.head()
# [___CELL_SEPARATOR___]
lr_model = mr.apply(
    lambda row: np.log(row['prob']) if row['x9'] == 1 else 1.0 - np.log(row['prob']), axis=1).sum()

print('Log likelihood of our model:', lr_model.round(2))
# [___CELL_SEPARATOR___]
df = init_dataset()
# [___CELL_SEPARATOR___]
X, y = df.split()
# [___CELL_SEPARATOR___]
my_model = LogisticRegression()
cv_scores = cross_val_score(my_model, X.train, y.train, scoring='f1', cv=20)

print("F1: %0.4f (+/- %0.2f)" % (np.median(cv_scores), np.std(cv_scores)))
# [___CELL_SEPARATOR___]
def plot_scores(scores, labels):
    """
    Receives scores (one or several arrays) and plots a scatter to the left with
    the values of the first one, and a boxplot with all of them to the right.
    
    Arguments
        scores: single list of scores, or list of lists of scores.
        labels: single label or list of labels identifying the scores passed
    """
    plt.figure(figsize=(10, 5))
    
    plt.subplot(1, 2, 1)
    plt.title('Scores from {}.'.format(labels[0]))
    plt.scatter(range(len(scores[0])), scores[0])
    
    plt.subplot(1, 2, 2)
    plt.title('{} scores stdev={:.4f}'.format(labels[0], np.std(scores[0])))
    for i in range(len(scores)):
        plt.axhline(np.median(scores[i]), color='orange', 
                    linestyle='--', linewidth=0.5)
    plt.boxplot(scores, labels=labels)
    plt.ylim(bottom=0.6, top=1.0)
    
    plt.show()
# [___CELL_SEPARATOR___]
plot_scores([cv_scores], ['CV'])
# [___CELL_SEPARATOR___]
lr = my_model.fit(X.train, y.train)
y_hat = my_model.predict(X.test)

print('F1 in production: {:.4f}'.format(f1_score(y.test, y_hat)))
# [___CELL_SEPARATOR___]
# Measure the CV score over the unbalanced dataset.
X, y = df_unbalanced.split()
cv_unbalanced_scores = cross_val_score(LogisticRegression(), X.train, y.train, 
                                       scoring='f1', cv=20)
# [___CELL_SEPARATOR___]
# Now, do the same, but applying SMOTE oversampling to each fold.
cv = StratifiedShuffleSplit(n_splits=20)
cv_smote_scores = []
for train_idx, test_idx, in cv.split(X.train.values, y.train.values):
    # Take the samples from the fold made by the CV method
    X_train, y_train = X.train.values[train_idx], y.train.values[train_idx]
    X_test, y_test = X.train.values[test_idx], y.train.values[test_idx]
    
    # Apply SMOTE to the training subset
    X_train, y_train = SMOTE().fit_resample(X_train, y_train)
    
    # Evaluate the model and store it in the array.
    f1 = evaluate_LogReg(X_train, y_train, X_test, y_test)    
    cv_smote_scores.append(f1)
# [___CELL_SEPARATOR___]
plot_scores([cv_smote_scores, cv_unbalanced_scores], 
            ['CV+SMOTE', 'CV Unbalanced'])
# [___CELL_SEPARATOR___]
# Measure the CV score over the unbalanced dataset.
X, y = df_unbalanced.split()
X_train, y_train = SMOTE().fit_resample(X.train.values, y.train.values)

wrong_scores = cross_val_score(LogisticRegression(), 
                               X_train, y_train, scoring='f1', cv=20)
# [___CELL_SEPARATOR___]
plot_scores([wrong_scores, cv_smote_scores], ['WRONG Overs.+CV', 'Correct'])
# [___CELL_SEPARATOR___]
df = init_dataset()
X, y = df.split()
# [___CELL_SEPARATOR___]
def bootstrap_split(X, y, seed, training_size=0.8):
    train_num_samples = X.shape[0]
    X_train, y_train = resample(X, y, replace=True, 
                                n_samples=int(train_num_samples * 0.8),
                                random_state=seed)

    # Take the indices present in the training samples
    indices_in_training = X_train.index.to_list()

    # Those, NOT in training are, go to the test set.
    X_test = X[~X.index.isin(indices_in_training)]
    y_test = y[~y.index.isin(indices_in_training)]

    return X_train, y_train, X_test, y_test
# [___CELL_SEPARATOR___]
bs_scores = []
for i in range(20):
    X_train, y_train, X_test, y_test = bootstrap_split(X.train, y.train, 
                                                       seed=i*23)
    bs_scores.append(evaluate_LogReg(X_train, y_train, X_test, y_test))

print("F1 (bootstrapping): %0.4f (+/- %0.2f)" % (np.median(bs_scores), np.std(bs_scores)))
# [___CELL_SEPARATOR___]
plot_scores([bs_scores, cv_scores], ['Bootstrapping', 'CV'])
# [___CELL_SEPARATOR___]
X, y = df_unbalanced.split()

# Now, do the same, but applying SMOTE oversampling to each fold.
bs_smote_scores = []
for i in range(20):
    # Take the samples from the fold made by the Bootstrapping method
    X_train, y_train, X_test, y_test = bootstrap_split(X.train,  y.train, 
                                                       seed=i*23)
    # Apply SMOTE to the training subset
    X_train, y_train = SMOTE().fit_resample(X_train.values, y_train.values)
    f1 = evaluate_LogReg(X_train, y_train, X_test, y_test)
    bs_smote_scores.append(f1)
# [___CELL_SEPARATOR___]
plot_scores([bs_smote_scores, cv_smote_scores, cv_unbalanced_scores], 
            ['BS+SMOTE', 'CV+SMOTE', 'CV Unbalanced'])
# [___CELL_SEPARATOR___]
def bs_med_score():
    bootstrap_scores = []
    for i in range(10):
        X_train, y_train, X_test, y_test = bootstrap_split(X.train,  y.train,
                                                           seed=i*23)
        # Apply SMOTE to the training subset
        X_train, y_train = SMOTE().fit_resample(X_train.values, y_train.values)
        bootstrap_scores.append(evaluate_LogReg(
            X_train, y_train, X_test, y_test))

    return np.median(bootstrap_scores)


def cv_med_score():
    cv = StratifiedShuffleSplit(
        n_splits=10, random_state=random.randint(1, 100))
    cv_scores = []
    for train_idx, test_idx, in cv.split(X.train.values, y.train.values):
        # Take the samples from the fold made by the CV method
        X_train, y_train = X.train.values[train_idx], y.train.values[train_idx]
        X_test, y_test = X.train.values[test_idx], y.train.values[test_idx]

        # Apply SMOTE to the training subset, train the LR and obtain F1
        X_train, y_train = SMOTE().fit_resample(X_train, y_train)
        cv_scores.append(evaluate_LogReg(X_train, y_train, X_test, y_test))

    return np.median(cv_scores)
# [___CELL_SEPARATOR___]
bs_smote_med_scores = [bs_med_score() for _ in tqdm_notebook(range(100))]
# [___CELL_SEPARATOR___]
cv_smote_med_scores = [cv_med_score() for _ in tqdm_notebook(range(100))]
# [___CELL_SEPARATOR___]
# Boxplot 
plt.title('Median of score (CV & BS) after 100 iterations')
plt.boxplot([cv_smote_med_scores, bs_smote_med_scores], 
            labels=['100 CV+SMOTE', '100 BS+SMOTE'])
plt.show()
# [___CELL_SEPARATOR___]
X, y = df_unbalanced.split()

# Train a LR with the oversampled portion of the split
X_train, y_train = SMOTE().fit_resample(X.train.values, y.train.values)
lr = my_model.fit(X_train, y_train)
y_hat = my_model.predict(X.test)

# Compute the metrics
f1 = f1_score(y.test, y_hat)
f1_cv = np.median(cv_smote_med_scores)
f1_bs = np.median(bs_smote_med_scores)

print('F1 with unseen data: {:.4f}'.format(f1))
print('F1 estimated by CV: {:.4f} ({:.2f}%)'.format(
    f1_cv, ((f1_cv-f1)/f1)*100.))
print('F1 estimated by Bootstrapping: {:.4f} ({:.2f}%)'.format(
    f1_bs, ((f1_bs-f1)/f1)*100.))
# [___CELL_SEPARATOR___]
def repeat_validation(n_times=100):
    f1s = []
    for _ in tqdm_notebook(range(n_times)):
        X, y = df_unbalanced.split(seed=random.randint(1, 100))
        X_train, y_train = SMOTE().fit_resample(X.train.values, y.train.values)
        lr = my_model.fit(X_train, y_train)
        y_hat = my_model.predict(X.test)
        f1s.append(f1_score(y.test, y_hat))

    return f1s
# [___CELL_SEPARATOR___]
f1s = repeat_validation(100)
m_f1 = np.median(f1s)
print('Median of F1 with unseen data, after 100 iterations: {:.4f}'.format(
    np.median(m_f1)))
print('F1 estimated by CV: {:.4f} ({:.2f}%)'.format(
    f1_cv, ((f1_cv-m_f1)/m_f1)*100.))
print('F1 estimated by Bootstrapping: {:.4f} ({:.2f}%)'.format(
    f1_bs, ((f1_bs-m_f1)/m_f1)*100.))
# [___CELL_SEPARATOR___]
def kw_test(data1, data2):
    stat, p = kruskal(data1, data2)
    print('Statistics={:.2f}, p={:.4f}'.format(stat, p))
    alpha = 0.05
    if p > alpha:
        print('Same distributions (fail to reject H0)')
        return True
    else:
        print('Different distributions (reject H0)')
        return False
# [___CELL_SEPARATOR___]
kw_test(f1s, cv_smote_med_scores)
# [___CELL_SEPARATOR___]
kw_test(f1s, bs_smote_med_scores)
# [___CELL_SEPARATOR___]
kw_test(cv_smote_med_scores, bs_smote_med_scores)