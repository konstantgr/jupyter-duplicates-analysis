# !wget http://groups.di.unipi.it/~gulli/newsspace200.xml.bz
# !bzip2 -d newsspace200.xml.bz
# [___CELL_SEPARATOR___]
# !wget http://lil.nlp.cornell.edu/resources/newsroom/r8625bda324/newsroom-release.tar
# !gzip -d release/train.jsonl.gz
# !gzip -d release/test.jsonl.gz
# !gzip -d release/dev.jsonl.gz
# [___CELL_SEPARATOR___]
from glob import glob

files = glob('release/*.jsonl')
files
# [___CELL_SEPARATOR___]
with open('release/dev.jsonl') as fopen:
    data = fopen.read().split('\n')
    
len(data)
# [___CELL_SEPARATOR___]
import json

d = json.loads(data[2])
d
# [___CELL_SEPARATOR___]
# !python3 -m spacy download en_core_web_sm
# import spacy
# nlp = spacy.load('en_core_web_sm')
# [___CELL_SEPARATOR___]
import re
from unidecode import unidecode

alphabets = '([A-Za-z])'
prefixes = (
    '(Mr|St|Mrs|Ms|Dr|Prof|Capt|Cpt|Lt|Mt|Puan|puan|Tuan|tuan|sir|Sir)[.]'
)
suffixes = '(Inc|Ltd|Jr|Sr|Co|Mo)'
starters = '(Mr|Mrs|Ms|Dr|He\s|She\s|It\s|They\s|Their\s|Our\s|We\s|But\s|However\s|That\s|This\s|Wherever|Dia|Mereka|Tetapi|Kita|Itu|Ini|Dan|Kami|Beliau|Seri|Datuk|Dato|Datin|Tuan|Puan)'
acronyms = '([A-Z][.][A-Z][.](?:[A-Z][.])?)'
websites = '[.](com|net|org|io|gov|me|edu|my)'
another_websites = '(www|http|https)[.]'
digits = '([0-9])'
before_digits = '([Nn]o|[Nn]ombor|[Nn]umber)'
month = '([Jj]an(?:uari)?|[Ff]eb(?:ruari)?|[Mm]a(?:c)?|[Aa]pr(?:il)?|Mei|[Jj]u(?:n)?|[Jj]ula(?:i)?|[Aa]ug(?:ust)?|[Ss]ept?(?:ember)?|[Oo]kt(?:ober)?|[Nn]ov(?:ember)?|[Dd]is(?:ember)?)'


def split_into_sentences(text, minimum_length = 10):
    text = text.replace('\x97', '\n')
    text = '. '.join([s for s in text.split('\n') if len(s)])
    text = text + '.'
    text = unidecode(text)
    text = ' ' + text + '  '
    text = text.replace('\n', ' ')
    text = re.sub(prefixes, '\\1<prd>', text)
    text = re.sub(websites, '<prd>\\1', text)
    text = re.sub(another_websites, '\\1<prd>', text)
    text = re.sub('[,][.]+', '<prd>', text)
    if '...' in text:
        text = text.replace('...', '<prd><prd><prd>')
    if 'Ph.D' in text:
        text = text.replace('Ph.D.', 'Ph<prd>D<prd>')
    text = re.sub('[.]\s*[,]', '<prd>,', text)
    text = re.sub(before_digits + '[.]\s*' + digits, '\\1<prd>\\2', text)
    text = re.sub(month + '[.]\s*' + digits, '\\1<prd>\\2', text)
    text = re.sub('\s' + alphabets + '[.][ ]+', ' \\1<prd> ', text)
    text = re.sub(acronyms + ' ' + starters, '\\1<stop> \\2', text)
    text = re.sub(
        alphabets + '[.]' + alphabets + '[.]' + alphabets + '[.]',
        '\\1<prd>\\2<prd>\\3<prd>',
        text,
    )
    text = re.sub(
        alphabets + '[.]' + alphabets + '[.]', '\\1<prd>\\2<prd>', text
    )
    text = re.sub(' ' + suffixes + '[.][ ]+' + starters, ' \\1<stop> \\2', text)
    text = re.sub(' ' + suffixes + '[.]', ' \\1<prd>', text)
    text = re.sub(' ' + alphabets + '[.]', ' \\1<prd>', text)
    text = re.sub(digits + '[.]' + digits, '\\1<prd>\\2', text)
    if '”' in text:
        text = text.replace('.”', '”.')
    if '"' in text:
        text = text.replace('."', '".')
    if '!' in text:
        text = text.replace('!"', '"!')
    if '?' in text:
        text = text.replace('?"', '"?')
    text = text.replace('.', '.<stop>')
    text = text.replace('?', '?<stop>')
    text = text.replace('!', '!<stop>')
    text = text.replace('<prd>', '.')
    sentences = text.split('<stop>')
    sentences = sentences[:-1]
    sentences = [s.strip() for s in sentences if len(s) > minimum_length]
    return sentences
# [___CELL_SEPARATOR___]
def split(story, highlights, cap = 1000):
    a, s_ = [], ''
    for s in story:
        if len(s_ + ' ' + s) >= cap:
            a.append(s_.strip())
            s_ = ''
        else:
            s_ = s_ + ' ' + s
    if len(s_):
        a.append(s_.strip())
    a.append('[SUMMARY]: ' + highlights)
    return a
# [___CELL_SEPARATOR___]
%%time
d = json.loads(data[7])
r = split(split_into_sentences(d['text']), d['summary'])
# [___CELL_SEPARATOR___]
r, len(r[0].split())
# [___CELL_SEPARATOR___]
from tqdm import tqdm

x = []

for file in files:
    with open(file) as fopen:
        data = fopen.read().split('\n')
        
    for i in tqdm(range(len(data))):
        try:
            d = json.loads(data[i])
            r = split(split_into_sentences(d['text']), d['summary'])
            x.append(r)
        except:
            pass
# [___CELL_SEPARATOR___]
with open('newsroom.json', 'w') as fopen:
    json.dump(x, fopen)
# [___CELL_SEPARATOR___]
x[-1]
# [___CELL_SEPARATOR___]
texts, index = [], 0
while len(texts) < 1500000:
    texts.extend(x[index][:-1])
    index += 1
# [___CELL_SEPARATOR___]
batch_size = 100000

for i in range(0, len(texts), batch_size):
    b = texts[i: i + batch_size]
    with open(f'dataset-{i}.json', 'w') as fopen:
        json.dump(b, fopen)