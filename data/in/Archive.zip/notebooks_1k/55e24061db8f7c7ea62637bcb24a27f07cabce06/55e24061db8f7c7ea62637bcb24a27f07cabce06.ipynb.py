import pandas as pd
import numpy as np
from matplotlib import pyplot as plt
%matplotlib inline
from collections import Counter
import seaborn as sns
# [___CELL_SEPARATOR___]
work = pd.read_csv('../manuallists/manual_title_subset.tsv', sep = '\t', index_col = 'docid', low_memory=False)
work.head()
# [___CELL_SEPARATOR___]
work.columns
# [___CELL_SEPARATOR___]
allgenres = Counter()
for index, row in work.iterrows():
    if pd.isnull(row.genres):
        continue
    g = set(row.genres.split('|'))
    for genre in g:
        allgenres[genre] += 1
print(allgenres.most_common(25))
# [___CELL_SEPARATOR___]
alltitles = Counter()
fictiontitles = Counter()
ficclues = {'Fiction', 'Novel', 'Short stories', 'Domestic fiction', 'Love stories', 
            'Historical fiction', 'Psychological fiction', "Detective and mystery stories",
           "Mystery fiction"}
fictiondefinition = {'longfiction', 'shortfiction', 'juvenile'}

for index, row in work.iterrows():
    if not row.category in fictiondefinition:
        continue
    date = int(row.latestcomp)
    alltitles[date] += 1
    
    if pd.isnull(row.genres):
        continue
    g = set(row.genres.split('|'))
    fiction = False
    for genre in g:
        if genre in ficclues:
            fiction = True
            break
    if fiction:
        fictiontitles[date] += 1

        
# [___CELL_SEPARATOR___]
x = []
y = []
for i in range(1800, 2008):
    fiction5yr = 0
    all5yr = 0
    for j in range(i - 2, i + 3):
        if j in alltitles and alltitles[j] > 0:
            fiction5yr += fictiontitles[j]
            all5yr += alltitles[j]
            
    if all5yr > 0:
        ratio = fiction5yr / all5yr
    else:
        ratio = 0
        
    x.append(i)
    y.append(ratio)
plt.plot(x, y)
# [___CELL_SEPARATOR___]
sns.set_style("darkgrid")
fig, ax = plt.subplots(figsize = (8, 5))
ax = plt.plot(x, y)
plt.xlim(1800, 2010)
plt.ylim(0,1)
plt.savefig('percentlabeledfic.png', dpi = 400, bbox_inches = 'tight')
plt.show()
# [___CELL_SEPARATOR___]
thesum = 0
for k, v in alltitles.items():
    thesum += v
thesum
# [___CELL_SEPARATOR___]
