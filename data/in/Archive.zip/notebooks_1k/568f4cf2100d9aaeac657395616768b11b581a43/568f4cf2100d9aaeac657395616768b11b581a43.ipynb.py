from pelops.datasets.veri import VeriDataset
from pelops.analysis.unsorted.recompute.extract_feats_from_chips import extract_feats_from_chips
import pelops.utils as utils

# [___CELL_SEPARATOR___]
veri = VeriDataset('/local_data/dgrossman/newVeRi',set_type=utils.SetType.TRAIN.value)
extract_feats_from_chips(veri, '/local_data/dgrossman/image_NEW_TRAIN')
# [___CELL_SEPARATOR___]
veri = VeriDataset('/local_data/dgrossman/newVeRi',set_type=utils.SetType.TEST.value)
extract_feats_from_chips(veri, '/local_data/dgrossman/image_NEW_TEST')
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
veri = VeriDataset('/local_data/dgrossman/tinyVeRi',set_type=utils.SetType.TRAIN.value)
extract_feats_from_chips(veri, '/local_data/dgrossman/image_NEW_TINY_TRAIN')
# [___CELL_SEPARATOR___]
veri = VeriDataset('/local_data/dgrossman/tinyVeRi',set_type=utils.SetType.TEST.value)
extract_feats_from_chips(veri, '/local_data/dgrossman/image_NEW_TINY_TEST')
# [___CELL_SEPARATOR___]
