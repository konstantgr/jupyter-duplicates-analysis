import seaborn as sns
import numpy as np
tips = sns.load_dataset('tips')
# [___CELL_SEPARATOR___]
size = tips["size"]
size.loc[:15] = np.nan
size.head(20)
# [___CELL_SEPARATOR___]
size.shape
# [___CELL_SEPARATOR___]
size.isnull().sum()
# [___CELL_SEPARATOR___]
mean = size.mean()
mean = round(mean)
print(mean)
# [___CELL_SEPARATOR___]
size.fillna(mean, inplace=True)
size.head(20)
# [___CELL_SEPARATOR___]
import matplotlib.pyplot as plt
plt.hist(size)
plt.show()
# [___CELL_SEPARATOR___]
min_val = size.mean() - (3 * size.std())
min_val
# [___CELL_SEPARATOR___]
max_val = size.mean() + (3 * size.std())
max_val
# [___CELL_SEPARATOR___]
outliers = size[size > max_val]
outliers.count()
# [___CELL_SEPARATOR___]
outliers
# [___CELL_SEPARATOR___]
size = size[size <= max_val]
size.shape
# [___CELL_SEPARATOR___]
from sklearn.preprocessing import LabelEncoder
import pandas as pd
# [___CELL_SEPARATOR___]
enc = LabelEncoder()
tips["sex"] = enc.fit_transform(tips['sex'].astype('str'))
tips["smoker"] = enc.fit_transform(tips['smoker'].astype('str'))
tips["day"] = enc.fit_transform(tips['day'].astype('str'))
tips["time"] = enc.fit_transform(tips['time'].astype('str'))
# [___CELL_SEPARATOR___]
tips.head()
# [___CELL_SEPARATOR___]
tips_normalized = (tips - tips.min())/(tips.max()-tips.min())
tips_normalized.head(10)
# [___CELL_SEPARATOR___]
tips_standardized = (tips - tips.mean())/tips.std()
tips_standardized.head(10)