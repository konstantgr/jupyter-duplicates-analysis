import numpy as np
import pandas as pd
import scipy.io as sio
import os
# [___CELL_SEPARATOR___]
!wget http://csegroups.case.edu/sites/default/files/bearingdatacenter/files/Datafiles/97.mat
!wget http://csegroups.case.edu/sites/default/files/bearingdatacenter/files/Datafiles/98.mat
!wget http://csegroups.case.edu/sites/default/files/bearingdatacenter/files/Datafiles/99.mat
!wget http://csegroups.case.edu/sites/default/files/bearingdatacenter/files/Datafiles/100.mat
# [___CELL_SEPARATOR___]
!mkdir  cwr_healthy
# [___CELL_SEPARATOR___]
!mv *.mat cwr_healthy/
# [___CELL_SEPARATOR___]
def read_folder(folder):
    data = 'dummy'
    skip = False
    for file in os.listdir(folder):
        file_id = file[:-4]
        mat_file_dict = sio.loadmat(folder+file)
        del data
        for key, value in mat_file_dict.items():
            if 'DE_time' in key or 'FE_time' in key:
                a = np.array(mat_file_dict[key])
                try:
                    data
                except NameError:
                    data = a
                else:
                    if (data.shape[0] != a.shape[0]):
                        print('skipping ' + file_id)
                        skip = True
                        continue
                    data = np.hstack((data,a))
        if skip:
            skip=False
            continue
        id = np.repeat(file_id,data.shape[0])
        id.shape = (id.shape[0],1)
        data = np.hstack((id,data))
        if data.shape[1] == 2:
            zeros = np.repeat(float(0),data.shape[0])
            zeros.shape =(data.shape[0],1)
            data = np.hstack((data,zeros))
        try:
            result
        except NameError:
            result = data
        else:
            result = np.vstack((result,data))
    return result
# [___CELL_SEPARATOR___]
result_healthy = read_folder('./cwr_healthy/')
# [___CELL_SEPARATOR___]
pdf = pd.DataFrame(result_healthy)
# [___CELL_SEPARATOR___]
pdf.to_csv('result_healthy_pandas.csv', header=False, index=True)
# [___CELL_SEPARATOR___]
#!for url in `curl -s csegroups.case.edu/bearingdatacenter/pages/12k-drive-end-bearing-fault-data |grep mat |grep http |awk -F'href="' '{print $2}' |awk -F'">' '{print $1}'`; do wget $url; done
#!for url in `curl -s csegroups.case.edu/bearingdatacenter/pages/48k-drive-end-bearing-fault-data |grep mat |grep http |awk -F'href="' '{print $2}' |awk -F'">' '{print $1}'`; do wget $url; done
#!for url in `curl -s csegroups.case.edu/bearingdatacenter/pages/12k-fan-end-bearing-fault-data |grep mat |grep http |awk -F'href="' '{print $2}' |awk -F'">' '{print $1}'`; do wget $url; done
#!mkdir cwr_faulty
#!mv *.mat cwr_faulty/
# [___CELL_SEPARATOR___]
!wget http://csegroups.case.edu/sites/default/files/bearingdatacenter/files/Datafiles/105.mat
!wget http://csegroups.case.edu/sites/default/files/bearingdatacenter/files/Datafiles/106.mat
!wget http://csegroups.case.edu/sites/default/files/bearingdatacenter/files/Datafiles/107.mat
!wget http://csegroups.case.edu/sites/default/files/bearingdatacenter/files/Datafiles/108.mat
# [___CELL_SEPARATOR___]
!mkdir cwr_faulty
!mv *.mat cwr_faulty/
# [___CELL_SEPARATOR___]
!ls cwr_faulty/
# [___CELL_SEPARATOR___]
result_faulty = read_folder('./cwr_faulty/')
# [___CELL_SEPARATOR___]
pdf = pd.DataFrame(result_faulty)
# [___CELL_SEPARATOR___]
pdf.to_csv('result_faulty_pandas.csv', header=False, index=True)
# [___CELL_SEPARATOR___]
!pwd
# [___CELL_SEPARATOR___]
