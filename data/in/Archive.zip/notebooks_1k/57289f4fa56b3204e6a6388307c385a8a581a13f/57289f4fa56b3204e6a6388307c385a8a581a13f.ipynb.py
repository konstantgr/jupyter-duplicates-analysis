#
#                ______  e-   ______
#                ||||||   ^   ||||||        
# driving laser  ||||||   |   ||||||        
# -------------> ||||||   |   ||||||        
#                ||||||   |   ||||||   
#                ||||||   |   ||||||        
#                ------       ------
#                design       design
#                region       region
#
# [___CELL_SEPARATOR___]
import numpy as np
import matplotlib.pylab as plt
import scipy.sparse as sp
import sys
sys.path.append('..')

from angler import Optimization, Simulation
from angler.structures import accelerator_multi

%load_ext autoreload
%autoreload 2
%matplotlib inline
# [___CELL_SEPARATOR___]
# fundamental constants and simulation parameters
c0 = 3e8                     # speed of light in vacuum (m/s)
lambda_m = 2e-6              # waveength in meters
omega = 2*np.pi*c0/lambda_m  # angular frequency (2pi/s)
dl = 0.1e-1                  # grid size (microns)
NPML = [15, 0]               # number of pml grid points on x and y borders
pol = 'Hz'                   # polarization (either 'Hz' or 'Ez')
num_cells = 10                # number of cells to tile in plots
# [___CELL_SEPARATOR___]
# material constants
n_index = np.sqrt(2)               # refractive index
eps_m = n_index**2           # relative permittivity
# [___CELL_SEPARATOR___]
# geometric parameters
beta = 0.5                  # electron speed / speed of light
gap = 0.4                   # gap size (microns)
lambda0 = lambda_m*1e6      # free space wavelength (microns)
L = 2                      # width of design region (microns)
num_channels = 3        
spc = 2                     # space between PML -> Src. & Src -> Design region
# [___CELL_SEPARATOR___]
# define permittivity of three port system
eps_r, design_region = accelerator_multi(beta, gap, lambda0, L, spc, num_channels, dl, NPML, eps_m)
(Nx, Ny) = eps_r.shape
nx, ny = int(Nx/2), int(Ny/2)

# make a new simulation
simulation = Simulation(omega,eps_r,dl,NPML,pol)

print("Computed a domain with {} grids in x and {} grids in y".format(Nx,Ny))
print("The simulation has {} grids per free space wavelength".format(int(lambda0/dl)))

simulation.plt_eps(tiled_y=num_cells)
plt.show()
# [___CELL_SEPARATOR___]
# set the plane wave source
simulation = Simulation(omega, eps_r, dl, NPML, 'Hz')
simulation.src = np.zeros((Nx, Ny))
# simulation.src[NPML[0] + int(spc/dl), :] = 1
simulation.src[Nx-NPML[0] - int(spc/dl), :] = 1

# [___CELL_SEPARATOR___]
# make an empty space simulation for normalization of fields
eps_normalize, _ = accelerator_multi(beta, gap, lambda0, L, spc, num_channels, dl, NPML, 1)
sim_normalize = Simulation(omega,eps_normalize,dl,NPML,pol)
sim_normalize.src = np.zeros((Nx, Ny))
sim_normalize.src[NPML[0] + int(spc/dl), :] = 1
sim_normalize.src[Nx-NPML[0] - int(spc/dl), :] = 1

(_,Ey,Hz) = sim_normalize.solve_fields()
sim_normalize.plt_re(tiled_y=num_cells, outline=False)
plt.show()
E0 = np.mean(np.abs(Ey[nx, :]))
print('E0 = {}'.format(E0))
# [___CELL_SEPARATOR___]
# initalize the design region randomly
simulation.init_design_region(design_region, eps_m, style='halfway')
simulation.plt_eps(tiled_y=num_cells, outline=False)
plt.show()
# [___CELL_SEPARATOR___]
# define objective function  (equal power transmission to bottom and top)
from angler.objective import Objective, obj_arg
arg1 = obj_arg('ex', component='Ex', nl=False)
arg2 = obj_arg('ey', component='Ey', nl=False)

import autograd.numpy as npa
def J(ex, ey):
    eta = npa.zeros((Nx, Ny), dtype=npa.complex128)    
    centers = [i * (gap + L) for i in range(num_channels//2+1)]
    for center in centers:
        eta[nx - int(center/dl), :] = 1/Ny*npa.exp(1j*2*npa.pi*dl*npa.linspace(0, Ny-1, Ny)/beta/lambda0)
        eta[nx + int(center/dl), :] = 1/Ny*npa.exp(1j*2*npa.pi*dl*npa.linspace(0, Ny-1, Ny)/beta/lambda0)    
    return npa.sum(npa.real(ey*eta)) / npa.sqrt(npa.square(npa.max(npa.abs(ex))) + npa.square(npa.max(npa.abs(ey)))) / num_channels

objective = Objective(J, arg_list=[arg1, arg2])
# [___CELL_SEPARATOR___]
# make optimization object and check derivatives
R = None
beta_proj = 1e-9
eta= 0.5
optimization = Optimization(objective=objective, simulation=simulation, design_region=design_region, eps_m=eps_m, R=R, beta=beta_proj, eta=eta)
# [___CELL_SEPARATOR___]
# check the derivatives (note, full derivatives are checked, linear and nonlinear no longer separate)
(grad_avm, grad_num) = optimization.check_deriv(Npts=5, d_rho=1e-4)
print('adjoint gradient   = {}\nnumerical gradient = {}'.format(grad_avm, grad_num))
# [___CELL_SEPARATOR___]
# run the optimization
optimization.run(method='LBFGS', Nsteps=2)
# [___CELL_SEPARATOR___]
# plot optimization results
f, (ax1, ax2) = plt.subplots(1, 2, figsize=(22,3))

simulation.plt_eps(ax=ax1, tiled_y=num_cells, outline=False)
ax1.set_title('final permittivity distribution')

optimization.plt_objs(ax=ax2)
ax2.set_yscale('linear')
plt.show()
# [___CELL_SEPARATOR___]
# setup subplots
f, (ax) = plt.subplots(1,1, figsize=(20,5))

# linear fields
(Hx,Hy,Ez) = simulation.solve_fields()
simulation.plt_re(ax=ax, tiled_y=num_cells)
ax1.set_title('linear field')

plt.show()
# [___CELL_SEPARATOR___]
