# importing the necessary dependencies
import geoplotlib
# [___CELL_SEPARATOR___]
# displaying the map with the default tile provider
geoplotlib.show()
# [___CELL_SEPARATOR___]
# using map tiles from the dark matter tile provider
geoplotlib.tiles_provider('darkmatter')
geoplotlib.show()
# [___CELL_SEPARATOR___]
# using custom object to set up tile provider
geoplotlib.tiles_provider({
    'url': lambda zoom, xtile, ytile: 'http://a.tile.openstreetmap.fr/hot/%d/%d/%d.png' % (zoom, xtile, ytile),
    'tiles_dir': 'custom_tiles',
    'attribution': 'Custom Tiles Provider - Humanitarian map style | Packt Courseware'
})
geoplotlib.show()