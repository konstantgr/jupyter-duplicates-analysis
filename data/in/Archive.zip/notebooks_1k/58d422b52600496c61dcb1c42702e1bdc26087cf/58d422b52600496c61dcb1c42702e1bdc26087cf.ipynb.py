import sys
sys.path.append("..")
import splitwavepy as s

import scipy
import numpy as np
import matplotlib.pyplot as plt
# [___CELL_SEPARATOR___]

fast = 30
lag = 0

M = s.eigval.grideigval(s.split(s.synth(noise=0.001),fast,lag))

fig, ax = plt.subplots(nrows=1, ncols=3, figsize=(20, 6))
ax[0].contourf(M.lags,M.degs,M.lam1,cmap='viridis')
ax[1].contourf(M.lags,M.degs,M.lam2,cmap='viridis')
ax[2].contourf(M.lags,M.degs,M.lam1/M.lam2,cmap='viridis')
ax[0].set_title('Lambda 1')
ax[1].set_title('Lambda 2')
ax[2].set_title('Lambda 1 / Lambda 2')
ax[0].set_xlabel('Lag')
ax[1].set_xlabel('Lag')
ax[2].set_xlabel('Lag')
ax[0].set_ylabel('Fast')
ax[1].set_ylabel('Fast')
ax[2].set_ylabel('Fast')
# plt.colorbar(ax)
plt.show()
# [___CELL_SEPARATOR___]
# splitting parameters
fast = 30
lag = 10
# sigma noise amplitude
noise = 0.001

M = s.eigval.grideigval(s.split(s.synth(noise=noise),fast,lag))

squashfast = np.sum(M.lam1/M.lam2, axis=0)
squashlag = np.sum(M.lam1/M.lam2, axis=1)
sfl1 = np.sum(M.lam1, axis=0)
sll1 = np.sum(M.lam1, axis=1)
sfl2 = np.sum(M.lam2, axis=0)
sll2 = np.sum(M.lam2, axis=1)

fig, ax = plt.subplots(nrows=3,ncols=2)

ax[0][0].plot(M.degs[0,:],squashfast)
ax[0][0].set_title('L1/L2 Fast')
ax[0][1].plot(M.lags[:,0],squashlag)
ax[0][1].set_title('L1/L2 Lag')

ax[1][0].plot(M.degs[0,:],sfl1)
ax[1][0].set_title('L1 Fast')
ax[1][1].plot(M.lags[:,0],sll1)
ax[1][1].set_title('L1 Lag')

ax[2][0].plot(M.degs[0,:],sfl2)
ax[2][0].set_title('L2 Fast')
ax[2][1].plot(M.lags[:,0],sll2)
ax[2][1].set_title('L2 Lag')

fastidx = np.where(M.degs[0,:]==fast)[0]
lagidx = np.where(M.lags[:,0]==lag)[0]

ax[0][0].plot([fast,fast],[np.min(squashfast),np.max(squashfast)])
ax[0][1].plot([lag,lag],[np.min(squashlag),np.max(squashlag)])

plt.show()

print('Lam1/Lam2: fast, lag:',M.degs[0,np.argmax(squashfast)],M.lags[np.argmax(squashlag),0])
print('Lam1: fast, lag:',M.degs[0,np.argmax(sfl1)],M.lags[np.argmax(sll1),0])
print('Lam2: fast, lag:',M.degs[0,np.argmin(sfl2)],M.lags[np.argmin(sll2),0])

M.plot()

print('SNR',M.snr)
print('Lam1/Lam2 max: fast, lag:',M.fast,M.lag)
# [___CELL_SEPARATOR___]
from scipy.interpolate import interp1d

def val_at_alpha(data,alpha):
    """
    Find value of function at the alpha level
    """
    idx = np.argsort(data)
    cum = np.cumsum(data[idx])
    tot = np.max(cum)
    get_x_at_cum = interp1d(cum, np.arange(cum.size))
    get_val_at_x = interp1d(np.arange(data.size), data[idx])
    xval = get_x_at_cum(tot*alpha)
    return get_val_at_x(xval)

# alpha = 0.318 corresponds to one sigma error bar assuming Gaussian distribution
v_fast = val_at_alpha(squashfast,.318)
v_lag = val_at_alpha(squashlag,.318)

fig, ax = plt.subplots(nrows=1, ncols=2)
ax[0].plot(squashfast)
ax[0].plot([0,squashfast.size],[v_fast,v_fast])
ax[0].set_title('Fast')
ax[1].plot(squashlag)
ax[1].plot([0,squashlag.size],[v_lag,v_lag])
ax[1].set_title('Lag')

plt.show()
# [___CELL_SEPARATOR___]
# Associated error bars

# [___CELL_SEPARATOR___]
# Test on a well known function (Gaussian)

from scipy import signal
a = signal.gaussian(101,10)
y = val_at_alpha(a,0.318)

plt.plot(a)
plt.plot([0,a.size],[y,y])
plt.show()
# [___CELL_SEPARATOR___]
lag = 30
fast = 30
M = s.eigval.grideigval(s.split(s.synth(noise=1),fast,lag))

squashfast = np.sum(M.lam1/M.lam2, axis=0)
squashlag = np.sum(M.lam1/M.lam2, axis=1)
sfl1 = np.sum(M.lam1, axis=0)
sll1 = np.sum(M.lam1, axis=1)
sfl2 = np.sum(M.lam2, axis=0)
sll2 = np.sum(M.lam2, axis=1)
diff = squashfast - np.roll(squashfast,45)
mult = squashfast * np.roll(squashfast,45)

fig, ax = plt.subplots(nrows=1,ncols=2)
ax[0].plot(M.degs[0,:],squashfast)
ax[0].plot(M.degs[0,:],np.roll(squashfast,45))
ax[0].plot(M.degs[0,:],diff,'--')
ax[1].plot(M.degs[0,:],diff**2)
ax[1].plot(M.degs[0,:],mult)
# ax[1].plot(M.degs[0,:],diff**2/mult)
# ax1.plot(M.degs[0,:],mult,'--')
plt.show()

sumdiff = np.sum(np.abs(diff))
sumdiffsq = np.sum(diff**2)
summult = np.sum(mult)
print('sumdiff = ',sumdiff)
print('sumdiffsq = ', sumdiffsq)
print('summult = ',summult)
print('ratio diff2_mult = ',sumdiffsq/summult)
print('ratio mult_diff2 = ',summult/sumdiffsq)

def NI(M):
    squashfast = np.sum(M.lam1/M.lam2, axis=0)
    squashlag = np.sum(M.lam1/M.lam2, axis=1)
    diff = squashfast - np.roll(squashfast,45)
    mult = squashfast * np.roll(squashfast,45)
    sumdiffsq = np.sum(diff**2)
    summult = np.sum(mult)
    return sumdiffsq/summult

M.plot()
print('NI = ',NI(M))
print('SNR = ',M.snr)
# [___CELL_SEPARATOR___]
lag = 0
fast = 45
M = s.eigval.grideigval(s.split(s.synth(noise=.01),fast,lag))

rads = np.deg2rad(np.column_stack((M.degs,M.degs+180,M.degs[:,0]+360)))
lags = np.column_stack((M.lags,M.lags,M.lags[:,0]))
lam1 = np.column_stack((M.lam1,M.lam1,M.lam1[:,0]))
lam2 = np.column_stack((M.lam2,M.lam2,M.lam2[:,0]))                  


fig, ax = plt.subplots(subplot_kw=dict(projection='polar'),nrows=1,ncols=3,figsize=(20,8))
ax[0].contourf(rads,lags,lam1,50,cmap='magma')
ax[0].set_title('Lam1')
ax[1].contourf(rads,lags,lam2,50,cmap='magma')
ax[1].set_title('Lam2')
ax[2].contourf(rads,lags,lam1/lam2,50,cmap='viridis')
ax[2].set_title('Lam1/Lam2')
plt.show()
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
M.degs.shape[1]+/2%1
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
