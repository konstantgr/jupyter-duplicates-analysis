from threading import Thread

class InputReader(Thread):
    def run(self):
        self.line_of_text = input()
# [___CELL_SEPARATOR___]
print("Enter any text and press enter: ")
thread = InputReader()
thread.start()

count = result = 1
while thread.is_alive():
    result = count * count 
    count += 1

print("calculated squares up to {0} * {0} = {1}".format(
    count, result))
print("while you typed '{}'".format(thread.line_of_text))
# [___CELL_SEPARATOR___]
import json 
from urllib.request import urlopen 
import time 
import requests
import pyowm

CITIES = ['Edmonton', 'Victoria', 'Winnipeg', 'Fredericton',
          'Halifax', 'Toronto', 'Charlottetown',
          'Quebec', 'Regina']

class TempGetter(Thread):
    def __init__(self, city):
        super().__init__()
        self.city = city
        self.owm = pyowm.OWM('be06b12aa45e1ca05a8f972f81376c6d')
    def run(self):
        city = self.owm.weather_at_place(self.city)
        weather = city.get_weather()
        self.temperature = weather.get_temperature('fahrenheit')['temp']
        
threads = [TempGetter(c) for c in CITIES]
start = time.time()
for thread in threads:
    thread.start()
for thread in threads:
    thread.join()
for thread in threads:
    print("it is {0.temperature:.0f}°C in {0.city}".format(thread))
print(
   "Got {} temps in {} seconds".format(
   len(threads), time.time() - start))
# [___CELL_SEPARATOR___]
owm = pyowm.OWM('be06b12aa45e1ca05a8f972f81376c6d')
start = time.time()
for city in CITIES:
    cityobj = owm.weather_at_place(city)
    weather = cityobj.get_weather()
    temperature = weather.get_temperature('fahrenheit')['temp']
    print("it is {0}°C in {1}".format(temperature, city))
print(
   "Got {} temps in {} seconds".format(
   len(threads), time.time() - start))
# [___CELL_SEPARATOR___]
from multiprocessing import Process, cpu_count

print("My computer has {} available processes/cpu's to run on.".format(cpu_count()))
# [___CELL_SEPARATOR___]
import time 
import os 

class MuchCPU(Process):
    def run(self):
        print(os.getpid())
        for i in range(200000000):
            pass
        
procs = [MuchCPU() for f in range(cpu_count())]
t = time.time()
for p in procs:
    p.start()
for p in procs: 
    p.join()
print("work took {} seconds".format(time.time()-t))
# [___CELL_SEPARATOR___]
class MuchCPU(Thread):
    def run(self):
        print(os.getpid())
        for i in range(200000000):
            pass
        
procs = [MuchCPU() for f in range(cpu_count())]
t = time.time()
for p in procs:
    p.start()
for p in procs: 
    p.join()
print("work took {} seconds".format(time.time()-t))
# [___CELL_SEPARATOR___]
import random 
import time
import multiprocessing

data = (
    ['a', '2'], ['b', '4'], ['c', '6'], ['d', '8'],
    ['e', '1'], ['f', '3'], ['g', '5'], ['h', '7']
)

def mp_worker(input1):
    inputs = input1[0]
    the_time = input1[1]
    print(" Processs {}\tWaiting {} seconds".format(inputs, the_time))
    time.sleep(int(the_time))
    print(" Process {}\tDONE".format(inputs))

def mp_handler():
    p = multiprocessing.Pool(2)
    p.map(mp_worker, data)

mp_handler()
# [___CELL_SEPARATOR___]
from multiprocessing import Process, Queue
import time
import sys 

def reader_proc(queue):
    # Read from the queue. spawned as seperate process 
    while True:
        msg = queue.get() # just read from queue 
        if (msg == "DONE"):
            break
            
def writer(count, queue):
    # Write to our queue
    for ii in range(0, count):
        queue.put(ii)
    queue.put('DONE')
        
pqueue = Queue()
for count in [10**4, 10**5, 10**6]:
    # reader_proc() reads pqueue as sperate process
    reader_p = Process(target=reader_proc, args=((pqueue),))
    reader_p.daemon = True
    reader_p.start()
    
    _start = time.time()
    writer(count, pqueue) # writer adds numbers to queue
    reader_p.join() # join is what starts the communication
    print("Sending {0} numbers to Queue() took {1} seconds".format(count,(time.time()-_start)))
# [___CELL_SEPARATOR___]
from concurrent.futures import ThreadPoolExecutor
from concurrent.futures import as_completed
import urllib.request
# [___CELL_SEPARATOR___]
def downloader(url):
    req = urllib.request.urlopen(url)
    filename = os.path.basename(url)
    ext = os.path.splitext(url)[1]
    if not ext: 
        raise RuntimeError("URL does not contain an extension")
    
    with open(filename, 'wb') as file_handle:
        while True:
            chunk = req.read(1024)
            if not chunk:
                break
            file_handle.write(chunk)
    msg = 'Finished downloading {filename}'.format(filename=filename)
    return msg

def main(urls):
    with ThreadPoolExecutor(max_workers=5) as executor:
        futures = [executor.submit(downloader, url) for url in urls]
        for future in as_completed(futures):
            print(future.result())
# [___CELL_SEPARATOR___]
urls = ["http://www.irs.gov/pub/irs-pdf/f1040.pdf",
            "http://www.irs.gov/pub/irs-pdf/f1040a.pdf",
            "http://www.irs.gov/pub/irs-pdf/f1040ez.pdf",
            "http://www.irs.gov/pub/irs-pdf/f1040es.pdf",
            "http://www.irs.gov/pub/irs-pdf/f1040sb.pdf"]
main(urls)
# [___CELL_SEPARATOR___]
def minimize():
    current = yield
    while True:
        value = yield current
        current = min(value, current)

it = minimize()
next(it)            # Prime the generator
print(it.send(10))
print(it.send(4))
print(it.send(22))
print(it.send(-1))
# [___CELL_SEPARATOR___]
import asyncio
import random

async def coroutine_1():
    print('coroutine_1 is active on the event loop')
    print('coroutine_1 yielding control. Going to be blocked for 4 seconds')
    await asyncio.sleep(4)
    print('coroutine_1 resumed. coroutine_1 exiting')
    
async def coroutine_2():
    print('coroutine_2 is active on the event loop')
    print('coroutine_2 yielding control. Going to be blocked for 5 seconds')
    await asyncio.sleep(5)
    print('coroutine_2 resumed. coroutine_2 exiting')
# [___CELL_SEPARATOR___]
# create the event loop 
loop = asyncio.get_event_loop()

#schedule both coroutines to run on the event loop 
loop.run_until_complete(asyncio.gather(coroutine_1(), coroutine_2()))
# [___CELL_SEPARATOR___]
import asyncio
import random

@asyncio.coroutine
def random_sleep(counter):
    delay = random.random() * 5
    print("{} sleeps for {:.2f} seconds".format(counter, delay))
    yield from asyncio.sleep(delay)
    print("{} awakens".format(counter))
    
@asyncio.coroutine
def five_sleepers(): 
    print("Creating five tasks") 
    tasks = [asyncio.ensure_future(random_sleep(i)) for i in range(5)]
    print("Sleeping after starting five tasks")
    yield from asyncio.sleep(2)
    print("Waking and waiting for five tasks")
    yield from asyncio.wait(tasks)
    
asyncio.get_event_loop().run_until_complete(five_sleepers())
print("Done five tasks")
# [___CELL_SEPARATOR___]
async def myCoroutine():
    print("Simple Coroutine Example")
    
def main():
    """
    main function to define event loop and run loop until done
    """
    loop = asyncio.get_event_loop()
    loop.run_until_complete(myCoroutine())
    loop.close()
main()
# [___CELL_SEPARATOR___]
# alternate method for defining coroutines (not as common)
@asyncio.coroutine
def myCoroutine2():
    print("My Coroutine")
# [___CELL_SEPARATOR___]
async def myCoroutine(id):
    process_time = random.randint(1,5)
    await asyncio.sleep(process_time)
    print("Coroutine {}, has succesfully completed after {} seconds".format(id, process_time))
    
    
async def main():
    """
    main function to define event loop and run loop until done
    """
    tasks = []
    for i in range(10):
        tasks.append(asyncio.ensure_future(myCoroutine(i)))
    await asyncio.gather(*tasks)
# [___CELL_SEPARATOR___]
start = time.time()
loop = asyncio.new_event_loop()
loop.run_until_complete(main())
loop.close()
print("Total time: {} seconds.".format(time.time()-start))
# [___CELL_SEPARATOR___]
def run_without_asyncio():
    for i in range(10):
        process_time = random.randint(1,5)
        time.sleep(process_time)
        print("Process {} finished in {} seconds.".format(i, process_time))
start = time.time()      
run_without_asyncio()
print("Total time: {} seconds.".format(time.time()-start))