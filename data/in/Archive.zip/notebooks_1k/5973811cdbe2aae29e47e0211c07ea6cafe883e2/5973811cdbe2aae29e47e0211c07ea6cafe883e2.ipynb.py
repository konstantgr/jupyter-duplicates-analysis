import ipywidgets
import traitlets
import pandas as pd
import bqplot
# [___CELL_SEPARATOR___]
buildings = pd.read_csv("/home/shared/sp18-is590dv/data/IL_Building_Inventory.csv",
                        na_values = {
                            'Year Acquired': 0,
                            'Year Constructed': 0
                        })
# [___CELL_SEPARATOR___]
x_sc = bqplot.LinearScale()
y_sc = bqplot.LinearScale()
# [___CELL_SEPARATOR___]
x_ax = bqplot.Axis(scale = x_sc, label = 'Year Constructed')
y_ax = bqplot.Axis(scale = y_sc, label = 'Year Acquired',
                   orientation = 'vertical')
# [___CELL_SEPARATOR___]
scatter = bqplot.Scatter(x = buildings['Year Constructed'],
                         y = buildings['Year Acquired'],
                        scales = {
                            'x': x_sc,
                            'y': y_sc
                        }, sizes = 0.5)
# [___CELL_SEPARATOR___]
fig = bqplot.Figure(marks = [scatter],
                    axes = [x_ax, y_ax],
)
# [___CELL_SEPARATOR___]
fig
# [___CELL_SEPARATOR___]
pz = bqplot.PanZoom(scales = {'x': [x_sc], 'y': [y_sc]})
# [___CELL_SEPARATOR___]
fig.interaction = pz
# [___CELL_SEPARATOR___]
x_sc.min, x_sc.max
# [___CELL_SEPARATOR___]
tooltip = bqplot.Tooltip(fields = ["x"])

scatter = bqplot.Scatter(x = buildings['Year Constructed'],
                         y = buildings['Year Acquired'],
                        scales = {
                            'x': x_sc,
                            'y': y_sc
                        }, sizes = 0.5,
                        tooltip = tooltip,

                         interactions = {'click': ''})
# [___CELL_SEPARATOR___]
lasso_selector = bqplot.interacts.LassoSelector(
                    marks = [scatter]
)
fig = bqplot.Figure(marks = [scatter],
                    axes = [x_ax, y_ax],
                    interaction = lasso_selector
)
# [___CELL_SEPARATOR___]
fig
# [___CELL_SEPARATOR___]
x_sc2 = bqplot.LinearScale()
y_sc2 = bqplot.LinearScale()
x_ax2 = bqplot.Axis(scale = x_sc2)
y_ax2 = bqplot.Axis(scale = y_sc2, orientation='vertical')

hist = bqplot.Hist(sample=buildings["Square Footage"],
                   scales = {'sample': x_sc2,
                             'count': y_sc2},
                   select_bars = True,
                   opacities = [0.1],
                  )

hist2 = bqplot.Hist(sample = buildings["Square Footage"],
                   scales = {'sample': x_sc2,
                            'count': y_sc2})

fig2 = bqplot.Figure(marks = [hist, hist2], axes = [x_ax2, y_ax2])
fig2
# [___CELL_SEPARATOR___]
selector = bqplot.interacts.LassoSelector
# [___CELL_SEPARATOR___]
hist.selected
# [___CELL_SEPARATOR___]
import numpy as np
# [___CELL_SEPARATOR___]
def update_histogram(event):
    indices = []
    for lasso in event['new']:
        indices.append(lasso['indices'])
    indices = np.concatenate(indices)
    ind = np.unique(indices)
    hist2.sample = buildings["Square Footage"].iloc[ind]

scatter.unobserve("selected")    
scatter.observe(update_histogram, "selected")
# [___CELL_SEPARATOR___]
scatter = bqplot.Scatter(x = buildings['Year Constructed'],
                         y = buildings['Year Acquired'],
                        scales = {
                            'x': x_sc,
                            'y': y_sc
                        })
brush = bqplot.interacts.BrushSelector(marks = [scatter],
                                       x_scale = x_sc,
                                       y_scale = y_sc,
                                       color = 'red')
fig = bqplot.Figure(marks = [scatter],
                    axes = [x_ax, y_ax],
                    interaction = brush
)
# [___CELL_SEPARATOR___]
fig
# [___CELL_SEPARATOR___]
brush.traits()
# [___CELL_SEPARATOR___]
