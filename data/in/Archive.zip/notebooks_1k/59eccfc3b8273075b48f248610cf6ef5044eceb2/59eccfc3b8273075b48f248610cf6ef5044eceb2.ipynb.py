import tensorflow as tf
import tensorflow_hub as hub
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
# [___CELL_SEPARATOR___]
module_url = "https://tfhub.dev/google/universal-sentence-encoder-large/3"
# Import the Universal Sentence Encoder's TF Hub module
embed = hub.Module(module_url)
# [___CELL_SEPARATOR___]
text_data_path_1 = 'text_data_1.csv'
text_data_path_2 = 'text_data_2.data'
# [___CELL_SEPARATOR___]
df_1 = pd.read_csv(text_data_path_1)
print('number of dataset: {}'.format(df_1.shape[0]))
print('emotion types: {} types\n{}'.format(df_1['sentiment'].nunique(),df_1['sentiment'].unique()))
df_1.head()
# [___CELL_SEPARATOR___]
df_2 = pd.read_csv(text_data_path_2)
print('number of dataset: {}'.format(df_2.shape[0]))
print('emotion types: {} types\n{}'.format(df_2['emotions'].nunique(),df_2['emotions'].unique()))
df_2.head()
# [___CELL_SEPARATOR___]
df_1_col_tokeep = ['sentiment','content']
df_1_sentiment_filter = ['worry','sadness','love','surprise','fun','hate','anger']
df_1 = df_1[df_1_col_tokeep]
df_1 = df_1[df_1['sentiment'].isin(df_1_sentiment_filter)]
df_1 = df_1.rename(columns = {"sentiment": "emotions","content":"text"}) 

emotion_rename = {'worry':'fear','fun':'joy','hate':'anger'}
df_1 = df_1.replace({'emotions':emotion_rename})
# [___CELL_SEPARATOR___]
def text_preprocessing(text):
    new_text = ' '.join(x for x in text.strip().lower().split() if not x.startswith('@'))
    new_text = ' '.join('website' if x.startswith('http://') else x for x in new_text.split())
    
    return new_text         
# [___CELL_SEPARATOR___]
df_1['text'] = df_1['text'].apply(text_preprocessing)
df_2['text'] = df_2['text'].apply(text_preprocessing)
df_2 = df_2[['emotions','text']]
# [___CELL_SEPARATOR___]
df = pd.concat([df_1,df_2])
df = df.reset_index(drop=True)
# [___CELL_SEPARATOR___]
df['emotions'].value_counts().plot.bar()
# [___CELL_SEPARATOR___]
df_joy_temp = df[df['emotions']=='joy']
df_sadness_temp = df[df['emotions']=='sadness']
df_anger_temp = df[df['emotions']=='anger']
df_fear_temp = df[df['emotions']=='fear']
df_love_temp = df[df['emotions']=='love']
from sklearn.utils import shuffle

df_joy_temp = shuffle(df_joy_temp)#.sample(frac=1).reset_index(drop=True)
df_sadness_temp = shuffle(df_sadness_temp)#.sample(frac=1).reset_index(drop=True)
df_anger_temp = shuffle(df_anger_temp)#.sample(frac=1).reset_index(drop=True)
df_fear_temp = shuffle(df_fear_temp)#.sample(frac=1).reset_index(drop=True)
df_love_temp = shuffle(df_love_temp)#.sample(frac=1).reset_index(drop=True)
# [___CELL_SEPARATOR___]
df_joy_temp = df_joy_temp[1:int(np.ceil(len(df_joy_temp)/7))]
df_sadness_temp = df_sadness_temp[1:int(np.ceil(len(df_sadness_temp)/6))]
df_anger_temp = df_anger_temp[1:int(np.ceil(len(df_anger_temp)/3))]
df_fear_temp = df_fear_temp[1:int(np.ceil(len(df_fear_temp)/3))] 
df_love_temp = df_love_temp[1:int(np.ceil(len(df_love_temp)/2))] 
# [___CELL_SEPARATOR___]
df_rest_temp = df[df['emotions']=='surprise']
# [___CELL_SEPARATOR___]
df = pd.concat([df_joy_temp,df_sadness_temp,df_anger_temp,df_fear_temp,df_love_temp,df_rest_temp])
# [___CELL_SEPARATOR___]
df = shuffle(df)#.sample(frac=1).reset_index(drop=True)
# [___CELL_SEPARATOR___]
df['emotions'].value_counts().plot.bar()
# [___CELL_SEPARATOR___]
len(df)
# [___CELL_SEPARATOR___]
df = df.reset_index()
# [___CELL_SEPARATOR___]
df.head()
# [___CELL_SEPARATOR___]
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split


le = LabelEncoder()
  
# Creating train and dev dataframes according to BERT
df_bert = pd.DataFrame({'user_id':df['index'],
            'label':le.fit_transform(df['emotions']),
            'alpha':['a']*df.shape[0],
            'text':df['text'].replace(r'\n',' ',regex=True)})
 
df_bert_train, df_bert_dev = train_test_split(df_bert, test_size=0.01)
 
# # Creating test dataframe according to BERT
# df_test = pd.read_csv("data/test.csv")
# df_bert_test = pd.DataFrame({'User_ID':df_test['User_ID'],
#                  'text':df_test['Description'].replace(r'\n',' ',regex=True)})

# [___CELL_SEPARATOR___]
# Saving dataframes to .tsv format as required by BERT
df_bert_train.to_csv('data/train.tsv', sep='\t', index=False, header=False)
df_bert_dev.to_csv('data/dev.tsv', sep='\t', index=False, header=False)
# df_bert_test.to_csv('data/test.tsv', sep='\t', index=False, header=True)
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
df.head()
X = df['text'].tolist()
y = df['emotions'].tolist()
emotion_type = np.unique(y)
# [___CELL_SEPARATOR___]
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
# [___CELL_SEPARATOR___]
X = np.asarray(X)
y = np.asarray(pd.get_dummies(y),dtype=np.int8)
# [___CELL_SEPARATOR___]
X_train,X_valid_test,y_train,y_valid_test = train_test_split(X,y,test_size=0.05,random_state=0,stratify=y)
X_valid,X_test,y_valid,y_test = train_test_split(X_valid_test,y_valid_test,test_size=0.5,random_state=0,stratify=y_valid_test)
print('X_train shape: {}'.format(len(X_train)))
print('y_train shape: {}'.format(len(y_train)))
print('X_valid shape: {}'.format(len(X_valid)))
print('y_valid shape: {}'.format(len(y_valid)))
print('X_test shape: {}'.format(len(X_test)))
print('y_test shape: {}'.format(len(y_test)))
# [___CELL_SEPARATOR___]
from tensorflow.keras.layers import Input,Lambda,Dense
from tensorflow.keras.models import Model
import keras.backend as K
# [___CELL_SEPARATOR___]
def USE(x): #universal sentence encoding
    return embed(tf.squeeze(tf.cast(x, tf.string)))
# [___CELL_SEPARATOR___]
input_text = Input(shape=(1,), dtype=tf.string)
embedding = Lambda(USE,output_shape=(512,))(input_text)
dense = Dense(256, activation='relu')(embedding)
pred = Dense(df['emotions'].nunique(),activation='softmax')(dense)
model = Model(inputs=[input_text],outputs=pred)
model.compile(loss='categorical_crossentropy',optimizer='adam', metrics=['accuracy'])
# [___CELL_SEPARATOR___]
model.summary()
# [___CELL_SEPARATOR___]
type(y_train)
# [___CELL_SEPARATOR___]
with tf.Session() as session:
    K.set_session(session)
    session.run(tf.global_variables_initializer())
    session.run(tf.tables_initializer())
    history = model.fit(X_train,y_train,
              validation_data=(X_valid,y_valid),
              epochs=1,
              batch_size=64)
#     model.save_weights('./model.h5')
# [___CELL_SEPARATOR___]
