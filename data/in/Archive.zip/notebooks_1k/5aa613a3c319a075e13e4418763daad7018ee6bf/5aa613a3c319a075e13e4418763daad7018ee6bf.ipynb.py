%matplotlib inline
from parcels import FieldSet, ParticleSet, JITParticle, AdvectionRK4, ParticleFile, plotTrajectoriesFile
import numpy as np
from datetime import timedelta as delta
from os import path
# [___CELL_SEPARATOR___]
filenames = path.join('SWASH_data', 'field_*.nc')
variables = {'U': 'cross-shore velocity',
             'V': 'along-shore velocity',
             'depth_u': 'time varying depth_u'}
# [___CELL_SEPARATOR___]
dimensions = {'U': {'lon': 'x', 'lat': 'y', 'depth': 'not_yet_set', 'time': 't'},
              'V': {'lon': 'x', 'lat': 'y', 'depth': 'not_yet_set', 'time': 't'},
              'depth_u': {'lon': 'x', 'lat': 'y', 'depth': 'not_yet_set', 'time': 't'}}
# [___CELL_SEPARATOR___]
fieldset = FieldSet.from_netcdf(filenames, variables, dimensions, mesh='flat', allow_time_extrapolation=True)
fieldset.U.set_depth_from_field(fieldset.depth_u)
fieldset.V.set_depth_from_field(fieldset.depth_u)
# [___CELL_SEPARATOR___]
pset = ParticleSet(fieldset, JITParticle, lon=9.5, lat=12.5, depth=-0.1)
pfile = pset.ParticleFile("SwashParticles", outputdt=delta(seconds=0.05))
pset.execute(AdvectionRK4, dt=delta(seconds=0.005), output_file=pfile)

pfile.export()  # export the trajectory data to a netcdf file
plotTrajectoriesFile('SwashParticles.nc');