images_dir = "2019-05_ManualSegmentationsa"
# [___CELL_SEPARATOR___]
from local_vars import root_folder

from keras.layers import Input
from keras.layers import BatchNormalization, Activation, Embedding, ZeroPadding2D

from keras.layers.convolutional import UpSampling2D, Conv2D, Conv2DTranspose
from keras.models import  Model
from keras.optimizers import Adam, rmsprop
from keras import losses
from keras.layers import concatenate, Add
from keras.utils import to_categorical
import keras.backend as K

import matplotlib.pyplot as plt
import cv2

import numpy as np

import os
import shutil

patch_size = 128

category = True

import keras.utils

import numpy as np
import keras

import scipy


def nvidia_unet(patch_size=128):
    input_ = Input((patch_size, patch_size, 1))
    skips = []
    output = input_
    for shape, filters in zip([5, 3, 3, 3, 3, 3, 3], [16, 32, 64, 64, 64, 64, 64]):
        skips.append(output)
        print(output.shape)
        output= Conv2D(filters, (shape, shape), strides=2, padding="same", activation="relu")(output)
        #output = BatchNormalization()(output)
        #if shape != 7:
        #   output = BatchNormalization()(output)
    for shape, filters in zip([4, 4, 4, 4, 4, 4, 4, 4], [64, 64, 64, 64,32, 16, 2]):
        output = keras.layers.UpSampling2D()(output)
        
        skip_output = skips.pop()
        output = concatenate([output, skip_output], axis=3)
        
        if filters != 2:
            activation = "relu"
        else:
            activation = "softmax"
        output = Conv2D(filters if filters != 2 else 2, (shape, shape), activation=activation, padding="same")(output)
        
        
            
        if filters != 2:
            output = BatchNormalization(momentum=.9)(output)
    assert len(skips) == 0
    return Model([input_], [output])
models = [nvidia_unet() for _ in range(2)]
[model.compile(optimizer=keras.optimizers.adam(), loss= "binary_crossentropy", metrics=["accuracy"]) for model in models]
loss = [[] for _ in range(2)]
models[1].summary()
# [___CELL_SEPARATOR___]
data = np.array( np.load(os.path.join(root_folder, images_dir, "ultrasound.npy" )), np.float)
classes = np.array(np.load(os.path.join(root_folder, images_dir, "segmentation.npy")), np.float)
#classes = np.concatenate([classes, 1 - classes], -1)
tdata = np.array( np.load(os.path.join(root_folder, images_dir, "ultrasound-test.npy" )), np.float)
tclasses = np.array(np.load(os.path.join(root_folder, images_dir, "segmentation-test.npy")), np.float)
#tclasses = np.concatenate([tclasses, 1 - tclasses], -1)
# [___CELL_SEPARATOR___]
def dialateStack(array, iterations):
    return np.array([scipy.ndimage.binary_dilation(y_e, iterations=iterations) for y_e in array])

width = 1
test_y_dialated = dialateStack(tclasses[:, :, :, 0], width)
t_final_x = []
t_final_y = []
for i in range(len(tdata)):

    
    t_final_x.append(cv2.resize(tdata[i], (128, 128)))
    t_final_y.append(cv2.resize(test_y_dialated[i] + 0.0, (128, 128)))
tdata =  np.expand_dims(t_final_x, -1)
test_y_dialated = np.array(t_final_y)

test_y_dialated = np.expand_dims(test_y_dialated, -1)
tclasses_dialated = np.concatenate([test_y_dialated, 1-test_y_dialated], -1)

# [___CELL_SEPARATOR___]
i = np.random.randint(10)
plt.imshow(tclasses_dialated[i, :, :, 0])
plt.colorbar()
plt.show()
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
from multiprocessing import Queue, Process

from augmentor import prepare_batches

prepared_batches = Queue(maxsize=7)
 
width = 1
y_edge = np.array([scipy.ndimage.binary_dilation(y_e, iterations=width) for y_e in classes])[:, :] * 1.0
threads = []
for _ in range(6):
    p = Process(target=prepare_batches, args=(y_edge, data, prepared_batches))
    
    p.start()
    
    threads = threads + [p]

# [___CELL_SEPARATOR___]
while True:
    batchx, batchy = prepared_batches.get(block=True, timeout=15)
    print("qsize", prepared_batches.qsize())
    for i in range(1):
        l = models[i].fit(batchx, batchy, validation_data=(tdata, tclasses_dialated), batch_size=len(batchx) // 12)
        loss[i].append(l)
# [___CELL_SEPARATOR___]
for t in threads:
    t.terminate()
    t.join()
    print("blammo")
# [___CELL_SEPARATOR___]
result = models[0].predict(batchx)
result[:, 0, 0, 0]=1
# [___CELL_SEPARATOR___]
j = np.random.randint(120)
plt.imshow(batchx[j, :, :, 0])
plt.show()
plt.imshow(result[j, :, :, 0])
plt.show()

plt.imshow(batchy[j,:, :, 0])
plt.show()
# [___CELL_SEPARATOR___]
for _ in range(13):
    result = models[0].predict(tdata)

    j = np.random.randint(70)
    plt.imshow(tdata[j, :, :, 0])
    plt.show()
    plt.imshow((result[j, :, :, 0] > .3) * 1)
    plt.colorbar()
    plt.show()

    plt.imshow(tclasses_dialated[j,:, :, 0])
    plt.show()
# [___CELL_SEPARATOR___]
#models[0].save("5_14_19_model_no_pretrain.h5")
models[0].save("5_14_19_model_no_pretrain_binary_crossentropy.h5")
# [___CELL_SEPARATOR___]
plt.plot([l.history['loss'] for l in loss[0][:]])
plt.plot([l.history['val_loss'] for l in loss[0][:]])
plt.show()
plt.plot([l.history['acc'] for l in loss[0][:]])
plt.plot([l.history['val_acc'] for l in loss[0][:]])
plt.show()
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
models[0].evaluate(tdata, tclasses_dialated)
# [___CELL_SEPARATOR___]
np.sum(((models[0].predict(tdata) > .5) * 1.0) == tclasses_dialated)
# [___CELL_SEPARATOR___]
np.sum(((models[0].predict(tdata) > .5) * 1.0) == tclasses_dialated) /tclasses_dialated.size
# [___CELL_SEPARATOR___]
