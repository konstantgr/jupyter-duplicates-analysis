import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import torch.distributions as D
import torchvision
import torchvision.transforms as transforms
import pyblaze.nn as xnn
import pyblaze.nn.functional as X
import matplotlib.pyplot as plt

%matplotlib inline
plt.style.use('seaborn-notebook')
plt.rcParams['figure.dpi'] = 150
# [___CELL_SEPARATOR___]
train_dataset = torchvision.datasets.MNIST(
    root="~/Downloads/", train=True, download=True, transform=transforms.ToTensor()
)
# [___CELL_SEPARATOR___]
noise_dataset = xnn.NoiseDataset(D.Normal(torch.zeros(2), torch.ones(2)))
# [___CELL_SEPARATOR___]
critic_iterations = 3
# [___CELL_SEPARATOR___]
train_loader = train_dataset.loader(batch_size=1024, num_workers=4, drop_last=True, shuffle=True)
noise_loader = noise_dataset.loader(batch_size=1024)
zip_loader = xnn.ZipDataLoader(noise_loader, train_loader, critic_iterations+1, critic_iterations)
# [___CELL_SEPARATOR___]
plt.figure()

images = [train_dataset[i] for i in np.random.choice(len(train_dataset), 10)]
for i, (image, _) in enumerate(images):
    plt.subplot(1, 10, i+1)
    plt.imshow(image[0], cmap='binary')
    plt.axis('off')

plt.show()
# [___CELL_SEPARATOR___]
class Generator(nn.Module):
    
    def __init__(self):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Linear(2, 128),
            nn.ReLU(),
            nn.BatchNorm1d(128),
            nn.Linear(128, 6272),
            nn.ReLU(),
            xnn.View(-1, 128, 7, 7),
            nn.ReLU(),
            nn.BatchNorm2d(128),
            nn.ConvTranspose2d(128, 64, kernel_size=4, stride=2, padding=1),
            nn.ReLU(),
            nn.BatchNorm2d(64),
            nn.ConvTranspose2d(64, 32, kernel_size=4, stride=2, padding=1),
            nn.ReLU(),
            nn.BatchNorm2d(32),
            nn.Conv2d(32, 1, kernel_size=3, stride=1, padding=1),
            nn.Sigmoid()
        )

    def forward(self, noise):
        return self.conv(noise)

class Critic(nn.Module):
    
    def __init__(self):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(1, 64, kernel_size=4, stride=2, padding=1),
            nn.ReLU(),
            nn.Conv2d(64, 128, kernel_size=4, stride=2, padding=1),
            nn.ReLU(),
            nn.Conv2d(128, 256, kernel_size=5, stride=2, padding=1),
            nn.Flatten(),
            nn.Linear(2304, 1)
        )
        
    def forward(self, x):
        return self.conv(x)


class WGAN(nn.Module):

    def __init__(self):
        super().__init__()
        self.generator = Generator()
        self.critic = Critic()

    def forward(self, noise):
        fake = self.generator(noise)
        return self.critic(fake)
# [___CELL_SEPARATOR___]
model = WGAN()

print(f'Total parameters:     {sum(p.numel() for p in model.parameters()):6,}')
print(f'Generator parameters: {sum(p.numel() for p in model.generator.parameters()):6,}')
print(f'Critic parameters:    {sum(p.numel() for p in model.critic.parameters()):6,}')
# [___CELL_SEPARATOR___]
generator_optimizer = optim.Adam(model.generator.parameters(), lr=3e-4)
critic_optimizer = optim.Adam(model.critic.parameters(), lr=3e-4)
generator_loss = xnn.WassersteinLossGenerator()
gp = xnn.GradientPenalty(model.critic, lipschitz=True)
critic_loss = xnn.WassersteinLossCritic(gp)
# [___CELL_SEPARATOR___]
engine = xnn.WGANEngine(model, expects_data_target=True)
# [___CELL_SEPARATOR___]
class PlottingCallback(xnn.TrainingCallback):
    
    def __init__(self, generator, noise_data):
        self.generator = generator
        self.noise_iter = iter(noise_data.loader(batch_size=10))
        self.epoch = None
        
    def before_epoch(self, epoch, iterations):
        self.epoch = epoch
    
    def after_epoch(self, metrics):
        if self.epoch % 10 == 0:
            device = next(self.generator.parameters()).device
            noise = next(self.noise_iter).to(device)
            with torch.no_grad():
                out = self.generator(noise).cpu().numpy()
            self._plot(out)
            
    def _plot(self, out):
        plt.figure()
        for i in range(10):
            plt.subplot(1, 10, i+1)
            plt.imshow(out[i].reshape(28, 28), cmap='binary')
            plt.axis('off')
        plt.show()
# [___CELL_SEPARATOR___]
history = engine.train(
    zip_loader,
    epochs=150,
    generator_optimizer=generator_optimizer,
    critic_optimizer=critic_optimizer,
    generator_loss=generator_loss,
    critic_loss=critic_loss,
    critic_iterations=critic_iterations,
    callbacks=[
        xnn.BatchProgressLogger(),
        PlottingCallback(model.generator, noise_dataset)
    ]
)
# [___CELL_SEPARATOR___]
all_losses = history.batch_em_distance
plt.figure()
plt.plot(range(len(all_losses)), all_losses, linewidth=1)
plt.show()
# [___CELL_SEPARATOR___]
eval_noise = iter(noise_dataset.loader(batch_size=10))
# [___CELL_SEPARATOR___]
out = engine.predict(
    eval_noise,
    iterations=1
)
# [___CELL_SEPARATOR___]
plt.figure(dpi=150)
for i in range(10):
    plt.subplot(1, 10, i+1)
    plt.imshow(out[i].reshape(28, 28), cmap='binary')
    plt.axis('off')
plt.show()