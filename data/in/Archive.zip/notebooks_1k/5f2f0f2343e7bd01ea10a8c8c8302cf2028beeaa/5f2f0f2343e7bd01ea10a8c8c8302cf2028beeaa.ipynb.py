# #uncomment only if you're running from google colab
# !git clone https://github.com/Datatouille/rl-workshop
# !mv rl-workshop/* .
# !ls

# #gym
# !pip install gym #For full installations, see https://github.com/openai/gym#installation

# #displays
# !pip install pyvirtualdisplay
# !sudo apt-get install xvfb

# #torch and numpy
# !pip install numpy 
# !pip install torch torchvision
# import torch
# torch.__version__
# [___CELL_SEPARATOR___]
%matplotlib inline

#environments
import gym
gym.logger.set_level(40)

#torch
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import optim
#use cuda 0 if available; assuming 1 gpu
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

#misc
import numpy as np
import matplotlib.pyplot as plt
from tqdm import tqdm_notebook
from datetime import datetime
from collections import Counter, deque

#solutions
from solutions.memory import VanillaMemory
from solutions.agents import DDPGAgent

#shut up warnings
import warnings
warnings.filterwarnings("ignore")

MODEL_PATH = 'models/'
# [___CELL_SEPARATOR___]
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.animation
from IPython.display import HTML
from pyvirtualdisplay import Display

#display
display = Display(visible=0, size=(512, 512))
display.start()
import os
os.environ["DISPLAY"] = ":" + str(display.display) + "." + str(display.screen)
# [___CELL_SEPARATOR___]
env = gym.make('Pendulum-v0')
state = env.reset()
score = 0
t=0
frames = []

while True:
    action = 4 * np.random.rand(1) - 1
    state, reward, done, info = env.step(action)
    t+=1
    score+=reward
    
    frames.append(env.render(mode = 'rgb_array'))
    if done: break
print(f'Done in {t} timsteps with score {score}.')
# [___CELL_SEPARATOR___]
#animate frames
patch = plt.imshow(frames[0])
animate = lambda i: patch.set_data(frames[i])
ani = matplotlib.animation.FuncAnimation(plt.gcf(), animate, frames=len(frames), interval = 1)
HTML(ani.to_jshtml())
# [___CELL_SEPARATOR___]
#create environment
env = gym.make('Pendulum-v0')
env.reset()

'''
Write your code here
'''

# [___CELL_SEPARATOR___]
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import optim
from torch.autograd.variable import Variable

class ActorNetwork(nn.Module):
    def __init__(self, state_size, action_size, hidden_size, seed=1412):
        super(ActorNetwork, self).__init__()
        self.seed = torch.manual_seed(seed)
        self.fc1 = nn.Linear(state_size, hidden_size)
        self.fc2 = nn.Linear(hidden_size, hidden_size)
        self.head = nn.Linear(hidden_size, action_size)
        
    def forward(self, state):
        '''
        Write your code here
        '''
# [___CELL_SEPARATOR___]
class CriticNetwork(nn.Module):
    def __init__(self, state_size, action_size, hidden_size, seed=1412):
        super(CriticNetwork, self).__init__()
        self.seed = torch.manual_seed(seed)
        '''
        Write your code here
        '''
        
    def forward(self, state, action):
        '''
        Write your code here
        '''
# [___CELL_SEPARATOR___]
class DDPGAgent():        
    def __init__(self, 
        state_size, action_size, nb_hidden, replay_memory, action_bounds = [-2,2], random_seed=0, 
        bs = 128, gamma=0.99, tau=1e-3, lr_actor=1e-4, lr_critic=1e-4, wd_actor=0, wd_critic=0,
        clip_actor = None, clip_critic=None, update_interval = 20, update_times = 10): 

        self.state_size = state_size
        self.action_size = action_size
        self.action_lower = action_bounds[0]
        self.action_upper = action_bounds[1]
        self.seed = random.seed(random_seed)
        self.bs = bs
        self.update_interval = update_interval
        self.update_times = update_times
        self.timestep = 0

        self.gamma = gamma
        self.tau = tau
        self.lr_actor = lr_actor
        self.lr_critic = lr_critic
        self.wd_critic = wd_critic
        self.wd_actor = wd_actor
        self.clip_critic=clip_critic
        self.clip_actor = clip_actor
        self.actor_losses = []
        self.critic_losses = []

        #actor
        self.actor_local = ActorNetwork(state_size, action_size, nb_hidden, random_seed).to(device)
        self.actor_target = ActorNetwork(state_size, action_size, nb_hidden, random_seed).to(device)
        self.actor_optimizer = optim.Adam(self.actor_local.parameters(), lr=self.lr_actor,weight_decay=self.wd_actor)

        #critic
        self.critic_local = CriticNetwork(state_size, action_size, nb_hidden, random_seed).to(device)
        self.critic_target = CriticNetwork(state_size, action_size, nb_hidden, random_seed).to(device)
        self.critic_optimizer = optim.Adam(self.critic_local.parameters(), lr=self.lr_critic,weight_decay=self.wd_critic)

        #noise
        self.noise = OUNoise(action_size, random_seed)

        #replay memory
        self.memory = replay_memory
    
    def step(self, state, action, reward, next_state, done):
        #increment timestep
        self.timestep+=1
        self.memory.add(state, action, reward, next_state, done)

        # Learn, if enough samples are available in memory  
        if self.timestep % self.update_interval == 0:
            for i in range(self.update_times):
                if len(self.memory) > self.bs:
                    transitions = self.memory.sample(self.bs)
                    self.learn(transitions)

    def act(self, state, add_noise=True):
        state = torch.from_numpy(state).float().to(device)
        self.actor_local.eval()
        with torch.no_grad():
            action = self.actor_local(state).cpu().data.numpy()
        self.actor_local.train()        
        if add_noise:
            action += self.noise.sample()
        return np.clip(action, self.action_lower, self.action_upper)

    def reset_noise(self):
        self.noise.reset()

    def learn(self, transitions):
        states, actions, rewards, next_states, dones = transitions

        # ---------------------------- update critic ---------------------------- #
        # Get predicted next-state actions and Q values from target models
        actions_next = self.actor_target(next_states)
        Q_targets_next = self.critic_target(next_states, actions_next)
        # Compute Q targets for current states (y_i)
        Q_targets = rewards + (self.gamma * Q_targets_next * (1 - dones))
        # Compute critic loss
        Q_expected = self.critic_local(states, actions)
        critic_loss = F.mse_loss(Q_expected, Q_targets)
        # Minimize the loss
        self.critic_optimizer.zero_grad()
        critic_loss.backward()
        if self.clip_critic: torch.nn.utils.clip_grad_norm(self.critic_local.parameters(), self.clip_critic)
        self.critic_optimizer.step()

        # ---------------------------- update actor ---------------------------- #
        # Compute actor loss
        actions_pred = self.actor_local(states)
        actor_loss = -self.critic_local(states, actions_pred).mean()
        # Minimize the loss
        self.actor_optimizer.zero_grad()
        actor_loss.backward()
        if self.clip_actor: torch.nn.utils.clip_grad_norm(self.actor_local.parameters(), self.clip_actor)
        self.actor_optimizer.step()

        # ----------------------- update target networks ----------------------- #
        self.soft_update(self.critic_local, self.critic_target)
        self.soft_update(self.actor_local, self.actor_target)   
           
        self.actor_losses.append(actor_loss.cpu().data.numpy())
        self.critic_losses.append(critic_loss.cpu().data.numpy())        

    def soft_update(self, local_model, target_model):
        """Soft update model parameters.
        θ_target = τ*θ_local + (1 - τ)*θ_target
        """
        for target_param, local_param in zip(target_model.parameters(), local_model.parameters()):
            target_param.data.copy_(self.tau*local_param.data + (1.0-self.tau)*target_param.data)
# [___CELL_SEPARATOR___]
import random
import copy
import numpy as np

class OUNoise:
    """Ornstein-Uhlenbeck process."""

    def __init__(self, size, seed=1412, mu=0., theta=0.15, sigma=0.3):
        """Initialize parameters and noise process."""
        self.size = size        
        self.mu = mu * np.ones(size)
        self.theta = theta
        self.sigma = sigma        
        self.seed = random.seed(seed)
        self.reset()

    def reset(self):
        """Reset the internal state (= noise) to mean (mu)."""
        self.state = copy.copy(self.mu)

    def sample(self):
        """Update internal state and return it as a noise sample."""
        x = self.state        
        dx = self.theta * (self.mu - x) + self.sigma * np.random.standard_normal(self.size)
        self.state = x + dx
        return(self.state)
# [___CELL_SEPARATOR___]
noise = OUNoise(size=1,seed=1412,mu=0.,theta=0.15,sigma=0.3)
# [___CELL_SEPARATOR___]
'''
Write your code here
'''
noises = []

plt.plot(noises)
# [___CELL_SEPARATOR___]
env = gym.make('Pendulum-v0')
'''
Write your code here:
1. Create a replay memory with any chosen capacity
2. Create a DDPG agent with hyperparameters of your choice; refer to solutions/agents.py
'''
# [___CELL_SEPARATOR___]
scores = []
moving_scores = []
scores_avg = deque(maxlen=100)
n_episodes = 200
solved = -400

for episode in tqdm_notebook(range(n_episodes)):
    #get initial states         
    state = env.reset()
    score = 0
    agent.reset_noise()                                             
    
    while True:
        #agent action
        action = agent.act(state)
        next_state,reward,done,info = env.step(action)        
        agent.step(state, action, reward, next_state, done) 
        score += reward                                         
        state = next_state 
        if done: break
            
    #book keeping
    scores.append(score)
    scores_avg.append(score)
    moving_scores.append(np.mean(scores_avg))

    #print scores intermittenly
    if episode % 10 ==0: print(f'Episode: {episode} Score: {score} Average Score: {np.mean(scores_avg)}')

    #break if done
    if (np.mean(scores_avg) > solved):
        print(f'Environment solved in {episode} episodes! Average Score: {np.mean(scores_avg)}')
        break
# [___CELL_SEPARATOR___]
plt.plot(scores)
plt.plot(moving_scores)
# [___CELL_SEPARATOR___]
plt.plot(agent.actor_losses)
# [___CELL_SEPARATOR___]
plt.plot(agent.critic_losses)
# [___CELL_SEPARATOR___]
#somehow you need to do the animation import it again otherwise it wouldn't work
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.animation
from IPython.display import HTML
from pyvirtualdisplay import Display

#display
display = Display(visible=0, size=(512, 512))
display.start()
import os
os.environ["DISPLAY"] = ":" + str(display.display) + "." + str(display.screen)
# [___CELL_SEPARATOR___]
env = gym.make('Pendulum-v0')
state = env.reset()
score = 0
t=0
frames = []
while True:
    #only infer action; no training
    action = a(torch.FloatTensor(state)).detach().numpy()
    
    #env step
    state, reward, done, info = env.step(action)
    
    #book keeping
    t+=1
    score+=reward
    
    #break if done
    if done: break
    
    #append frame
    frames.append(env.render(mode = 'rgb_array'))
print(f'Done in {t} timsteps with score {score}.')
# [___CELL_SEPARATOR___]
#animate frames
patch = plt.imshow(frames[0])
animate = lambda i: patch.set_data(frames[i])
ani = matplotlib.animation.FuncAnimation(plt.gcf(), animate, frames=len(frames), interval = 1)
HTML(ani.to_jshtml())
# [___CELL_SEPARATOR___]
env = gym.make('Pendulum-v0')
mem = VanillaMemory(int(1e6), seed = 0)
agent = DDPGAgent(state_size=3, action_size=1, nb_hidden=64, 
                  replay_memory=mem, random_seed=0, bs = 512,
                  gamma=0.99, tau=1e-2, lr_actor=1e-3, lr_critic=1e-3, wd_actor=0, wd_critic=0,
                  clip_actor = None, clip_critic= None, update_interval = 1, update_times = 1)
# [___CELL_SEPARATOR___]
scores = []
moving_scores = []
scores_avg = deque(maxlen=100)
n_episodes = 200
solved = -400

for episode in tqdm_notebook(range(n_episodes)):
    #get initial states         
    state = env.reset()
    score = 0
    agent.reset_noise()                                             
    
    while True:
        #agent action
        action = agent.act(state)
        next_state,reward,done,info = env.step(action)        
        agent.step(state, action, reward, next_state, done) 
        score += reward                                         
        state = next_state 
        if done: break
            
    #book keeping
    scores.append(score)
    scores_avg.append(score)
    moving_scores.append(np.mean(scores_avg))

    #print scores intermittenly
    if episode % 10 ==0: print(f'Episode: {episode} Score: {score} Average Score: {np.mean(scores_avg)}')

    #break if done
    if (np.mean(scores_avg) > solved):
        print(f'Environment solved in {episode} episodes! Average Score: {np.mean(scores_avg)}')
        break
# [___CELL_SEPARATOR___]
plt.plot(scores)
plt.plot(moving_scores)
# [___CELL_SEPARATOR___]
plt.plot(agent.actor_losses)
# [___CELL_SEPARATOR___]
plt.plot(agent.critic_losses)
# [___CELL_SEPARATOR___]
#save network of solved agent
# torch.save(agent.actor_local.state_dict(),f'models/ddpg.pth')
agent.actor_local.load_state_dict(torch.load(f'models/ddpg.pth'))
a = agent.actor_local
# [___CELL_SEPARATOR___]
#somehow you need to do the animation import it again otherwise it wouldn't work
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.animation
from IPython.display import HTML
from pyvirtualdisplay import Display

#display
display = Display(visible=0, size=(512, 512))
display.start()
import os
os.environ["DISPLAY"] = ":" + str(display.display) + "." + str(display.screen)
# [___CELL_SEPARATOR___]
env = gym.make('Pendulum-v0')
state = env.reset()
score = 0
t=0
frames = []
while True:
    #only infer action; no training
    action = a(torch.FloatTensor(state)).detach().numpy()
    
    #env step
    state, reward, done, info = env.step(action)
    
    #book keeping
    t+=1
    score+=reward
    
    #break if done
    if done: break
    
    #append frame
    frames.append(env.render(mode = 'rgb_array'))
print(f'Done in {t} timsteps with score {score}.')
# [___CELL_SEPARATOR___]
#animate frames
patch = plt.imshow(frames[0])
animate = lambda i: patch.set_data(frames[i])
ani = matplotlib.animation.FuncAnimation(plt.gcf(), animate, frames=len(frames), interval = 1)
HTML(ani.to_jshtml())
# [___CELL_SEPARATOR___]
