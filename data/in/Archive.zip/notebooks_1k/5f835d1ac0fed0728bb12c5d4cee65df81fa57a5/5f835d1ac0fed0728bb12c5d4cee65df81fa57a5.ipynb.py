# Seaborn distplots
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import seaborn as sns
# sns.set()

# Build data
MAX = 100
STEP = 10
np.random.seed(0) # set random number seed (in order to make the run repeatable)

li_0 = [round(x + MAX*np.random.rand(),2) for x in range(0, MAX)]
li_1 = [round(x + MAX*np.random.rand(),2) for x in range(0, MAX)]
di = {'col_0': li_0, 'col_1': li_1}
df = pd.DataFrame.from_dict(di)
print("li_0[:10]:", li_0[:10])
print("---")
print("li_1[:10]:", li_1[:10])

di = {'col_0': li_0, 'col_1': li_1}
df = pd.DataFrame.from_dict(di)
print("---")
print(df.describe())
# [___CELL_SEPARATOR___]
fig = plt.figure(figsize=(12, 9))
plt.suptitle('Seaborn distplots example', color='m')

BINS = 12

ax1 = fig.add_subplot(211)
ax2 = fig.add_subplot(212)
g1 = sns.distplot(df.iloc[:, 0].dropna(), bins=BINS, kde=False, ax=ax1)
g2 = sns.distplot(df.iloc[:, 1].dropna(), bins=BINS, kde=False, ax=ax2)

y_title_margin = 1.02
ax1.set_title('Distribution of first column', y = y_title_margin, color='m')
ax2.set_title('Distribution of second column', y = y_title_margin, color='m')
ax1.set(xlabel='', ylabel='Counts')
ax2.set(xlabel='Values', ylabel='Counts')
ax1.grid(True)
ax2.grid(True)

g1.set(xlim=(0, 200), ylim=(0, 20))
g2.set(xlim=(0, 200), ylim=(0, 20))

plt.show()