%matplotlib inline
import matplotlib
import seaborn as sns
matplotlib.rcParams['savefig.dpi'] = 144
# [___CELL_SEPARATOR___]
import expectexception
# [___CELL_SEPARATOR___]
# to access NumPy, we have to import it
import numpy as np
# [___CELL_SEPARATOR___]
list_of_lists = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
print(list_of_lists)
# [___CELL_SEPARATOR___]
an_array = np.array(list_of_lists)
print(an_array)
# [___CELL_SEPARATOR___]
non_rectangular = [[1, 2], [3, 4, 5], [6, 7, 8, 9]]
print(non_rectangular)
# [___CELL_SEPARATOR___]
non_rectangular_array = np.array(non_rectangular)
print(non_rectangular_array)
# [___CELL_SEPARATOR___]
print(an_array.shape, an_array.dtype)
print(non_rectangular_array.shape, non_rectangular_array.dtype)
# [___CELL_SEPARATOR___]
np.linspace(2, 10, 3)
# [___CELL_SEPARATOR___]
    np.arange(1, 10, 4)
# [___CELL_SEPARATOR___]
np.logspace(2, 10, 2)
# [___CELL_SEPARATOR___]
np.zeros(3)
# [___CELL_SEPARATOR___]
np.diag([1,2,3,4])
# [___CELL_SEPARATOR___]
np.eye(5)
# [___CELL_SEPARATOR___]
print(np.logspace(1, 10, 10).dtype)
print(np.logspace(1, 10, 10).astype(int).dtype)
# [___CELL_SEPARATOR___]
print(sum([sum(inner_list) for inner_list in list_of_lists]))
print(an_array.sum())
# [___CELL_SEPARATOR___]
# what happens here?
print(non_rectangular_array)
print(non_rectangular_array.sum())
# [___CELL_SEPARATOR___]
# concatenate three lists
print([1, 2] + [3, 4, 5] + [6, 7, 8, 9])
# [___CELL_SEPARATOR___]
print(an_array)
print('Array row sums: ', an_array.sum(axis=1))
print('Array column sums: ', an_array.sum(axis=0))
# [___CELL_SEPARATOR___]
print('List of list row sums: ', [sum(inner_list) for inner_list in list_of_lists])

def column_sum(list_of_lists):
    running_sums = [0] * len(list_of_lists[0])
    for inner_list in list_of_lists:
        for i, number in enumerate(inner_list):
            running_sums[i] += number
            
    return running_sums

print('List of list column sums: ', column_sum(list_of_lists))
# [___CELL_SEPARATOR___]
a = np.array([1, 2, 3, 4, 5])
print(a + 5) # add a scalar
print(a * 5) # multiply by a scalar
print(a / 5) # divide by a scalar (note the float!)
# [___CELL_SEPARATOR___]
b = a + 1
print(a + b) # add together two arrays
print(a * b) # multiply two arrays (element-wise)
print(a / b.astype(float)) # divide two arrays (element-wise)
# [___CELL_SEPARATOR___]
print(a, b)
print(np.dot(a, b)) # inner product of two arrays
print(np.outer(a, b)) # outer product of two arrays
# [___CELL_SEPARATOR___]
time_list = [np.random.random() for _ in range(100000)]
time_arr = np.array(time_list)
# [___CELL_SEPARATOR___]
%%timeit 
sum(time_list)
# [___CELL_SEPARATOR___]
%%timeit
np.sum(time_arr)
# [___CELL_SEPARATOR___]
mat = np.random.rand(20, 10)
# [___CELL_SEPARATOR___]
mat.reshape(40, 5).shape
# [___CELL_SEPARATOR___]
%%expect_exception ValueError

mat.reshape(30, 5)
# [___CELL_SEPARATOR___]
mat.ravel().shape
# [___CELL_SEPARATOR___]
mat.transpose().shape
# [___CELL_SEPARATOR___]
print(a)
print(b)
# [___CELL_SEPARATOR___]
np.hstack((a, b))
# [___CELL_SEPARATOR___]
np.vstack((a, b))
# [___CELL_SEPARATOR___]
np.dstack((a, b))
# [___CELL_SEPARATOR___]
np.random.seed(42)
jan_coffee_sales = np.random.randint(25, 200, size=(4, 7))
print(jan_coffee_sales)
# [___CELL_SEPARATOR___]
# mean sales
print('Mean coffees sold per day in January: %d' % jan_coffee_sales.mean())
# [___CELL_SEPARATOR___]
# mean sales for Monday
print('Mean coffees sold on Monday in January: %d' % jan_coffee_sales[:, 1].mean())
# [___CELL_SEPARATOR___]
# day with most sales
# remember we count dates from 1, not 0!
print('Day with highest sales was January %d' % (jan_coffee_sales.argmax() + 1))
# [___CELL_SEPARATOR___]
# is there a weekly periodicity?
from fractions import Fraction

normalized_sales = (jan_coffee_sales - jan_coffee_sales.mean()) / abs(jan_coffee_sales - jan_coffee_sales.mean()).max()
frequencies = [Fraction.from_float(f).limit_denominator() for f in np.fft.fftfreq(normalized_sales.size)]
power = np.abs(np.fft.fft(normalized_sales.ravel()))**2
list(zip(frequencies, power))[:len(power) // 2]
# [___CELL_SEPARATOR___]
import matplotlib.pyplot as plt
# [___CELL_SEPARATOR___]
def gen_stock_price(days, initial_price):
    # stock price grows or shrinks linearly
    # not exceeding 10% per year (heuristic)
    trend = initial_price * (np.arange(days) * .1 / 365 * np.random.rand() * np.random.choice([1, -1]) + 1)
    # noise will be about 2%
    noise = .02 * np.random.randn(len(trend)) * trend
    return trend + noise

days = 365
initial_prices = [80, 70, 65]
for price in initial_prices:
    plt.plot(np.arange(-days, 0), gen_stock_price(days, price))
plt.title('Stock price history for last %d days' % days)
plt.xlabel('Time (days)')
plt.ylabel('Price (USD)')
plt.legend(['Company A', 'Company B', 'Company C'])
# [___CELL_SEPARATOR___]
from scipy.stats import linregress

def gen_football_team(n_players, mean_shoe, mean_jersey):
    shoe_sizes = np.random.normal(size=n_players, loc=mean_shoe, scale=.15 * mean_shoe)
    jersey_sizes = mean_jersey / mean_shoe * shoe_sizes + np.random.normal(size=n_players, scale=.05 * mean_jersey)

    return shoe_sizes, jersey_sizes

shoes, jerseys = gen_football_team(16, 11, 100)

fig = plt.figure(figsize=(12, 6))
fig.suptitle('Football team equipment profile')

ax1 = plt.subplot(221)
ax1.hist(shoes)
ax1.set_xlabel('Shoe size')
ax1.set_ylabel('Counts')

ax2 = plt.subplot(223)
ax2.hist(jerseys)
ax2.set_xlabel('Chest size (cm)')
ax2.set_ylabel('Counts')

ax3 = plt.subplot(122)
ax3.scatter(shoes, jerseys, label='Data')
ax3.set_xlabel('Shoe size')
ax3.set_ylabel('Chest size (cm)')

fit_line = linregress(shoes, jerseys)
ax3.plot(shoes, fit_line[1] + fit_line[0] * shoes, 'r', label='Line of best fit')

handles, labels = ax3.get_legend_handles_labels()
ax3.legend(handles[::-1], labels[::-1])
# [___CELL_SEPARATOR___]
def gen_hourly_temps(days):
    ndays = len(days)
    seasonality = (-15 * np.cos((np.array(days) - 30) * 2.0 * np.pi / 365)).repeat(24) + 10
    solar = -3 * np.cos(np.arange(24 * ndays) * 2.0 * np.pi / 24)
    weather = np.interp(range(len(days) * 24), range(0, 24 * len(days), 24 * 2), 3 * np.random.randn(np.ceil(float(len(days)) / 2).astype(int)))
    noise = .5 * np.random.randn(24 * len(days))

    return seasonality + solar + weather + noise

days = np.arange(365)
hours = np.arange(days[0] * 24, (days[-1] + 1) * 24)
plt.plot(hours, gen_hourly_temps(days))
plt.title('Hourly temperatures')
plt.xlabel('Time (hours since Jan. 1)')
plt.ylabel('Temperature (C)')
# [___CELL_SEPARATOR___]
import pandas as pd

players = ['Ronaldinho', 'Pele', 'Lionel Messi', 'Zinedine Zidane', 'Didier Drogba', 'Ronaldo', 'Yaya Toure', 
           'Frank Rijkaard', 'Diego Maradona', 'Mohamed Aboutrika', "Samuel Eto'o", 'George Best', 'George Weah', 
           'Roberto Donadoni']
shoes, jerseys = gen_football_team(len(players), 10, 100)

df = pd.DataFrame({'shoe_size': shoes, 'jersey_size': jerseys}, index = players)

df
# [___CELL_SEPARATOR___]
# we can also make a dataframe using zip

df = pd.DataFrame(list(zip(shoes, jerseys)), columns = ['shoe_size', 'jersey_size'], index = players)

df
# [___CELL_SEPARATOR___]
print(df['shoe_size'])
# [___CELL_SEPARATOR___]
print(np.log(df))
# [___CELL_SEPARATOR___]
df.mean()
# [___CELL_SEPARATOR___]
print(df.loc['Ronaldo'])
# [___CELL_SEPARATOR___]
print(df.loc[['Ronaldo', 'George Best'], 'shoe_size'])
# [___CELL_SEPARATOR___]
# can also select position-based slices of data
print(df.loc['Ronaldo':'George Best', 'shoe_size'])
# [___CELL_SEPARATOR___]
# for position-based indexing, we will typically use iloc
print(df.iloc[:5])
# [___CELL_SEPARATOR___]
print(df.iloc[2:4, 0])
# [___CELL_SEPARATOR___]
# to see just the top of the DataFrame, use head
df.head()
# [___CELL_SEPARATOR___]
# of for the bottom use tail
df.tail()
# [___CELL_SEPARATOR___]
# adding a new column
df['position'] = np.random.choice(['goaltender', 'defense', 'midfield', 'attack'], size=len(df))
df.head()
# [___CELL_SEPARATOR___]
# adding a new row
df.loc['Dylan'] = {'jersey_size': 91, 'shoe_size': 9, 'position': 'midfield'}
df.loc['Dylan']
# [___CELL_SEPARATOR___]
df.drop('Dylan')
# [___CELL_SEPARATOR___]
df.drop('position', axis=1)
# [___CELL_SEPARATOR___]
df = df.drop('Dylan')
print(df)
# [___CELL_SEPARATOR___]
df.drop('position', axis=1, inplace=True)
print(df)