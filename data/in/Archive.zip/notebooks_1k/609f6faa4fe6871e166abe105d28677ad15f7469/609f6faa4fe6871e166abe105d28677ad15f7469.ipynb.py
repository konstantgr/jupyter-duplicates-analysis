sessionInfo()
# [___CELL_SEPARATOR___]
