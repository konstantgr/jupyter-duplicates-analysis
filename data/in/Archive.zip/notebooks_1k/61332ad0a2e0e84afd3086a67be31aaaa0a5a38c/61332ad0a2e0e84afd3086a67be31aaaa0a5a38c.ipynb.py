! pip install -U pip
! pip install twine
# [___CELL_SEPARATOR___]
%%file foo.py
"""
When this file is imported with `import foo`,
only `useful_func1()` and `useful_func()` are loaded, 
and the test code `assert ...` is ignored. However,
when we run foo.py as a script `python foo.py`, then
the two assert statements are run.
Most commonly, the code under `if __naem__ == '__main__':`
consists of simple examples or test cases for the functions
defined in the moule.
"""

def useful_func1():
    pass

def useful_fucn2():
    pass

if __name__ == '__main__':
    assert(useful_func1() is None)
    assert(useful_fucn2() is None)
# [___CELL_SEPARATOR___]
import pkg.foo as foo
# [___CELL_SEPARATOR___]
foo.f1()
# [___CELL_SEPARATOR___]
import pkg
# [___CELL_SEPARATOR___]
pkg.foo.f1()
# [___CELL_SEPARATOR___]
! cat pkg/sub1/more_sub1_stuff.py
# [___CELL_SEPARATOR___]
from pkg.sub1.more_sub1_stuff import g3

g3()
# [___CELL_SEPARATOR___]
! cat pkg/sub2/sub2_stuff.py
# [___CELL_SEPARATOR___]
from pkg.sub2.sub2_stuff import h2

h2()
# [___CELL_SEPARATOR___]
! ls -R sta663
# [___CELL_SEPARATOR___]
! cat sta663/run_sta663.py
# [___CELL_SEPARATOR___]
%%file sta663/setup.py
from setuptools import setup

setup(name = "sta663-cliburn",
      version = "1.0",
      author='Cliburn Chan',
      author_email='cliburn.chan@duke.edu',
      url='http://people.duke.edu/~ccc14/sta-663-2018/',
      py_modules = ['sta663'],
      packages=setuptools.find_packages(),
      scripts = ['run_sta663.py'],
      python_requires='>=3',
      )
# [___CELL_SEPARATOR___]
%%bash

cd sta663
python setup.py sdist
cd -
# [___CELL_SEPARATOR___]
! ls -R sta663
# [___CELL_SEPARATOR___]
%%bash

cp sta663/dist/sta663_cliburn-1.0-py3.6.egg /tmp
cd /tmp
tar xzf sta663_cliburn-1.0-py3.6.egg 
cd sta663-1.0
python setup.py install
# [___CELL_SEPARATOR___]
! cat sta663/__init__.py
# [___CELL_SEPARATOR___]
! cat sta663/pkg/__init__.py
# [___CELL_SEPARATOR___]
! cat sta663/pkg/sub1/__init__.py
# [___CELL_SEPARATOR___]
! cat sta663/pkg/sub2/__init__.py
# [___CELL_SEPARATOR___]
import sta663
# [___CELL_SEPARATOR___]
[x for x in dir(sta663) if not x.startswith('__')]
# [___CELL_SEPARATOR___]
sta663.g1()
# [___CELL_SEPARATOR___]
from sta663 import pkg
# [___CELL_SEPARATOR___]
[x for x in dir(pkg) if not x.startswith('__')]
# [___CELL_SEPARATOR___]
from sta663.pkg import sub1, sub2
# [___CELL_SEPARATOR___]
[x for x in dir(sub1) if not x.startswith('__')]
# [___CELL_SEPARATOR___]
[x for x in dir(sub2) if not x.startswith('__')]
# [___CELL_SEPARATOR___]
sub1.g1(), sub1.g2(), sub1.g3()
# [___CELL_SEPARATOR___]
sub2.h1(), sub2.h2()
# [___CELL_SEPARATOR___]
sta663.pkg.sub2.sub2_stuff.h1()
# [___CELL_SEPARATOR___]
sta663.pkg.sub2.sub2_stuff.h2()
# [___CELL_SEPARATOR___]
%%bash

export TWINE_USERNAME='cliburn' 
export TWINE_PASSWORD=''
twine upload --repository-url https://test.pypi.org/legacy/ sta663/dist/*
# [___CELL_SEPARATOR___]
%%bash

pip install --index-url https://test.pypi.org/simple/ sta663
# [___CELL_SEPARATOR___]
