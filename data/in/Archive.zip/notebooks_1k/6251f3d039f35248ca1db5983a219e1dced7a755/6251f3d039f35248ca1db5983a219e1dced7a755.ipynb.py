######    0123456789012345678901234567890123456789012345678901234567890'
record = '....................100          .......513.25     ..........'
cost = int(record[20:32]) * float(record[40:48])
print(cost)
# [___CELL_SEPARATOR___]
SHARES = slice(20,32)
PRICE  = slice(40,48)
cost = int(record[SHARES]) * float(record[PRICE])
print(cost)
# [___CELL_SEPARATOR___]
a = slice(10, 50, 2)
print(a.start)
print(a.stop)
print(a.step)
# [___CELL_SEPARATOR___]
s = 'HelloWorld'
a = slice(5, 10, 2)
a.indices(len(s))
# [___CELL_SEPARATOR___]
for i in range(*a.indices(len(s))):
    print(s[i])