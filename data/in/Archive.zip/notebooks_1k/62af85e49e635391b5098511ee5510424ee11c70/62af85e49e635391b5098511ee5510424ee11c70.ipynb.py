import pandas as pd
from matplotlib import pyplot as plt
import seaborn as sns
import numpy as np

%matplotlib inline
# [___CELL_SEPARATOR___]
df = pd.read_json("/Users/Ben/Downloads/BRAZIL_SOY_2.2/BRAZIL_SOY_2.2.json")
# [___CELL_SEPARATOR___]
df.head()
# [___CELL_SEPARATOR___]
print(f"{len(df):,g}")
# [___CELL_SEPARATOR___]
df_atal = df[df["MUNICIPALITY"] == "Atalaia"]
# [___CELL_SEPARATOR___]
df_atal_china = df_atal[df_atal['COUNTRY'] == 'China']
# [___CELL_SEPARATOR___]
df_atal_china_bung = df_atal_china[df_atal_china["EXPORTER"] == "Bunge"]
# [___CELL_SEPARATOR___]
land_use = []
soy_volume = []
years = []
for year in df_atal_china_bung["YEAR"].unique():
    tmp = df_atal_china_bung[df_atal_china_bung["YEAR"] == year]
    land_use.append(tmp['LAND_USE'].sum())
    soy_volume.append(tmp['SOY_EQUIVALENT_TONS'].sum())
    years.append(year)
# [___CELL_SEPARATOR___]
plt.bar(years,land_use)
plt.title("Atalaia Soy production land use for Chinease exports (absolute area)")
plt.ylabel("Ha")
plt.show()
# [___CELL_SEPARATOR___]
region_area = 53200

plt.bar(years, (np.array(land_use)/region_area) * 100)
plt.title("Atalaia Soy production land use for Chinease exports (relative area)")
plt.ylabel("% area of region")
plt.show()
# [___CELL_SEPARATOR___]
# Possibly a good vizulisation for region (rather than single destinations)

plt.bar(years, np.array(soy_volume)/np.array(land_use))
plt.title("Atalaia Soy productivity for Chinease exports")
plt.ylabel("t/ha")
plt.show()
# [___CELL_SEPARATOR___]
amazonia = df[df["BIOME"] == "AMAZONIA"]
# [___CELL_SEPARATOR___]
max_deforest = []
years=[]
for year in amazonia["YEAR"].unique():
    print(year)
    tmp = amazonia[amazonia["YEAR"] == year]
    max_deforest.append(tmp["MAX_SOY_DEFORESTATION"].sum())
    years.append(year)
# [___CELL_SEPARATOR___]
plt.bar(years,max_deforest)
plt.title('Amazonia max deforestation over time')
plt.ylabel("ha")
# [___CELL_SEPARATOR___]

def prop_by_max_deforestation(df, prop='EXPORTER'):
    d = {}
    for exporter in sorted(df[prop].unique()):
        exprt_tmp = df[df[prop] == exporter]
        d[exporter] = exprt_tmp["MAX_SOY_DEFORESTATION"].sum()
    s = [(k, d[k]) for k in sorted(d, key=d.get, reverse=True)]
    return s

def key_prop_max_deforestation(df, key_props, prop='EXPORTER'):
    d = {}
    for key in key_props:
        exprt_tmp = df[df[prop] == key]
        d[key] = exprt_tmp["MAX_SOY_DEFORESTATION"].sum()
    s = [(k, d[k]) for k in sorted(d, key=d.get, reverse=True)]
    return s
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
s = prop_by_max_deforestation(amazonia, prop='EXPORTER')

labels = []
volumes = []

for item in s:
    labels.append('')
    volumes.append(item[1])
# [___CELL_SEPARATOR___]
# Looks like the top 6 Exporters are responsible for the vast majority of deforestation - we should use 6 categories + other
plt.plot(volumes[0:40])
# [___CELL_SEPARATOR___]
# Identify the top exporters responsible for deforestation by name

top_exporters = []
for item in s[0:6]:
    top_exporters.append(item[0])
top_exporters
# [___CELL_SEPARATOR___]
for key in top_exporters:
    print(key)
# [___CELL_SEPARATOR___]
max_deforest = []
years=[]
quantity_by_company = {}
for year in amazonia["YEAR"].unique():
    print(year)
    years.append(year)
    tmp = amazonia[amazonia["YEAR"] == year]
    tmp_s = key_prop_max_deforestation(tmp, top_exporters, prop="EXPORTER")  # find the quantity attributed to each of the key exporters
    tmp_d = {}
    for item in tmp_s:
        tmp_d[item[0]] =item[1]
    tmp_d['Total'] = tmp["MAX_SOY_DEFORESTATION"].sum()
    quantity_by_company[year] = tmp_d
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
plt.figure(figsize=(10,5))
menMeans = (20, 35, 30, 35, 27)
womenMeans = (25, 32, 34, 20, 25)
menStd = (2, 3, 4, 1, 2)
womenStd = (3, 5, 2, 3, 3)
width = 0.35       # the width of the bars: can also be len(x) sequence

tmp = []
for year in quantity_by_company.keys():
    tmp.append(quantity_by_company[year]['Total'])   
plt.bar(years, tmp, width, label='Other')

years = list(quantity_by_company.keys())
expcount = 0
for exporter in top_exporters:
    tmp = []
    for year in quantity_by_company.keys():
        tmp.append(quantity_by_company[year][exporter])
    if expcount == 0:
        plt.bar(years, tmp, width, label=exporter)
        past_values = np.array(tmp)
    else:
        plt.bar(years, tmp, width, bottom=past_values, label=exporter)
        past_values = np.array(tmp) + past_values
        pass
    expcount += 1

plt.ylabel('max deforestation (ha)')
plt.title('Max deforestation by exporter')
plt.legend()

plt.show()
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
s = prop_by_max_deforestation(amazonia, prop='COUNTRY')

labels = []
volumes = []

for item in s:
    labels.append('')
    volumes.append(item[1])

plt.plot(volumes[0:40])
# [___CELL_SEPARATOR___]
# Identify the top countries responsible for deforestation by name

top_countries = []
for item in s[0:6]:
    top_countries.append(item[0])
top_countries
# [___CELL_SEPARATOR___]
max_deforest = []
years=[]
quantity_by_country = {}
for year in amazonia["YEAR"].unique():
    print(year)
    years.append(year)
    tmp = amazonia[amazonia["YEAR"] == year]
    tmp_s = key_prop_max_deforestation(tmp, top_countries, prop="COUNTRY")  # find the quantity attributed to each of the key exporters
    tmp_d = {}
    for item in tmp_s:
        tmp_d[item[0]] =item[1]
    tmp_d['Total'] = tmp["MAX_SOY_DEFORESTATION"].sum()
    quantity_by_country[year] = tmp_d
# [___CELL_SEPARATOR___]
tmp_s
# [___CELL_SEPARATOR___]
plt.figure(figsize=(10,5))
menMeans = (20, 35, 30, 35, 27)
womenMeans = (25, 32, 34, 20, 25)
menStd = (2, 3, 4, 1, 2)
womenStd = (3, 5, 2, 3, 3)
width = 0.35       # the width of the bars: can also be len(x) sequence

years = list(quantity_by_country.keys())

tmp = []
for year in quantity_by_country.keys():
    tmp.append(quantity_by_country[year]['Total'])   
plt.bar(years, tmp, width, label='Other')

expcount = 0
for country in top_countries:
    tmp = []
    for year in quantity_by_company.keys():
        try:
            tmp.append(quantity_by_country[year][country])
        except:
            print(f'error for {year} {country}')
            tmp.append(0)            
    if expcount == 0:
        plt.bar(years, tmp, width, label=country)
        past_values = np.array(tmp)
    else:
        plt.bar(years, tmp, width, bottom=past_values, label=country)
        past_values = np.array(tmp) + past_values
        pass
    expcount += 1

plt.ylabel('max deforestation (ha)')
plt.title('Max deforestation by country')
plt.legend()

plt.show()
# [___CELL_SEPARATOR___]
top_countries
# [___CELL_SEPARATOR___]
max_deforest = []
all_quantity_by_company = {}
tmp_s = key_prop_max_deforestation(amazonia, top_countries, prop="COUNTRY") # find the quantity attributed to each of the key exporters
tmp_d = {}
for item in tmp_s:
    tmp_d[item[0]] =item[1]
tmp_d['Total'] = amazonia["MAX_SOY_DEFORESTATION"].sum()
quantity_by_company[year] = tmp_d
# [___CELL_SEPARATOR___]
tmp_d
# [___CELL_SEPARATOR___]
countries = list(tmp_d.keys())
countries.remove("Total")
countries.append("Other")
# [___CELL_SEPARATOR___]
list(tmp_d.values())
# [___CELL_SEPARATOR___]
total = 0
not_total = 0

plot_values = []

for k in tmp_d:
    if k == 'Total':
        total = tmp_d[k]
    else:
        plot_values.append(tmp_d[k])

other = total - np.sum(plot_values)

plot_values.append(other)
# [___CELL_SEPARATOR___]
# Pie chart, where the slices will be ordered and plotted counter-clockwise:
labels = countries
sizes = plot_values

fig1, ax1 = plt.subplots()
ax1.pie(sizes, labels=labels, autopct='%1.1f%%',
        shadow=False, startangle=90)
ax1.axis('equal')
plt.title("Countries primarily responsible for max deforestation from soy")
plt.show()
# [___CELL_SEPARATOR___]
df = pd.read_json("/Users/ikersanchez/Vizzuality/PROIEKTUAK/TRASE/work/data/ARGENTINA_BEEF/ARGENTINA_BEEF.json")
df.head()
# [___CELL_SEPARATOR___]
fob_usd = []
beef_volume= []
years = []
for year in df["YEAR"].unique():
    tmp = df[df["YEAR"] == year]
    fob_usd.append(tmp['FOB_USD'].sum())
    beef_volume.append(tmp['BEEF_EQUIVALENT_TONS'].sum())
    years.append(year)
# [___CELL_SEPARATOR___]
plt.bar(years,fob_usd)
plt.ylabel("usd")
plt.xticks(years)
plt.title("Financial flow per year")
plt.show()
# [___CELL_SEPARATOR___]
plt.bar(years, np.array(fob_usd)/np.array(beef_volume))
plt.title("Beef price per year")
plt.ylabel("usd/t")
plt.xticks(years)
plt.show()
# [___CELL_SEPARATOR___]
def  prop_fob_usd(df, prop='COUNTRY'):
    d = {}
    for country in sorted(df[prop].unique()):
        tmp = df[df[prop] == country]
        d[country] = tmp["FOB_USD"].sum()
    s = [(k, d[k]) for k in sorted(d, key=d.get, reverse=True)]
    return s

def key_prop_fob_usd(df, key_props, prop='COUNTRY'):
    d = {}
    for key in key_props:
        exprt_tmp = df[df[prop] == key]
        d[key] = exprt_tmp["FOB_USD"].sum()
    s = [(k, d[k]) for k in sorted(d, key=d.get, reverse=True)]
    return s
# [___CELL_SEPARATOR___]
s = prop_fob_usd(df, prop='COUNTRY')

labels = []
amount = []

for item in s:
    labels.append(item[0])
    amount.append(item[1])
# [___CELL_SEPARATOR___]
# Top 9 Countries are responsible for the vast majority of the financial flow
plt.plot(amount[0:40])
# [___CELL_SEPARATOR___]
# Top 9 exporters
top_countries = labels[0:9]
top_countries
# [___CELL_SEPARATOR___]
years=[]
quantity_by_country = {}
for year in df["YEAR"].unique():
    years.append(year)
    tmp = df[df["YEAR"] == year]
    tmp_s = key_prop_fob_usd(tmp, top_countries, prop="COUNTRY") 
    tmp_d = {}
    for item in tmp_s:
        tmp_d[item[0]] =item[1]
    tmp_d['Total'] = tmp["FOB_USD"].sum()
    quantity_by_country[year] = tmp_d
# [___CELL_SEPARATOR___]
plt.figure(figsize=(10,5))
width = 0.35    # the width of the bars: can also be len(x) sequence

tmp = []
for year in quantity_by_country.keys():
    tmp.append(quantity_by_country[year]['Total'])   
plt.bar(years, tmp, width, label='Other')

years = list(quantity_by_country.keys())
expcount = 0
for country in top_countries:
    tmp = []
    for year in quantity_by_country.keys():
        tmp.append(quantity_by_country[year][country])
    if expcount == 0:
        plt.bar(years, tmp, width, label=country)
        past_values = np.array(tmp)
    else:
        plt.bar(years, tmp, width, bottom=past_values, label=country)
        past_values = np.array(tmp) + past_values
        pass
    expcount += 1

plt.ylabel('Total usd')
plt.title('Financial flow by country')
plt.legend()
plt.xticks(years)

plt.show()
# [___CELL_SEPARATOR___]
df_country = pd.DataFrame(quantity_by_country)
countries = df_country.index
plt.figure(figsize=(10,5))

for i in range(len(df_country)-1):
    plt.plot(df_country.iloc[i], label=countries[i])

plt.ylabel('Total usd')
plt.title('Financial flow by country')
plt.legend(loc=1)
plt.xticks(years)

plt.show()
# [___CELL_SEPARATOR___]
tmp_d = quantity_by_country[2015]
tmp_d
# [___CELL_SEPARATOR___]
total = 0
values = []

for k in tmp_d:
    if k == 'Total':
        total = tmp_d[k]
    else:
        values.append(tmp_d[k])

other = total - np.sum(values)

values.append(other)
# [___CELL_SEPARATOR___]
labels = list(tmp_d.keys())
labels.remove("Total")
labels.append("Other")

fig, ax = plt.subplots()
ax.pie(values, labels=labels, autopct='%1.1f%%',
        shadow=False, startangle=90)
ax.axis('equal')
plt.title("Countries primarily responsible for financial flow of beef in 2015");
# [___CELL_SEPARATOR___]
def key_prop_price(df, key_props, prop='COUNTRY'):
    d = {}
    for key in key_props:
        exprt_tmp = df[df[prop] == key]
        d[key] = np.array(tmp["FOB_USD"].sum())/np.array(tmp["BEEF_EQUIVALENT_TONS"].sum())
    s = [(k, d[k]) for k in sorted(d, key=d.get, reverse=True)]
    return s
# [___CELL_SEPARATOR___]
years=[]
quantity_by_country = {}
for year in df["YEAR"].unique():
    print(year)
    years.append(year)
    tmp = df[df["YEAR"] == year]
    tmp_s = key_prop_price(tmp, top_countries, prop="COUNTRY") 
    tmp_d = {}
    for item in tmp_s:
        tmp_d[item[0]] =item[1]
    tmp_d['Total'] = np.array(tmp["FOB_USD"].sum())/np.array(tmp["BEEF_EQUIVALENT_TONS"].sum())
    quantity_by_country[year] = tmp_d
# [___CELL_SEPARATOR___]
plt.figure(figsize=(10,5))
width = 0.35    # the width of the bars: can also be len(x) sequence

tmp = []
for year in quantity_by_country.keys():
    tmp.append(quantity_by_country[year]['Total'])   
plt.bar(years, tmp, width, label='Other')

years = list(quantity_by_country.keys())
expcount = 0
for country in top_countries:
    tmp = []
    for year in quantity_by_country.keys():
        tmp.append(quantity_by_country[year][country])
    if expcount == 0:
        plt.bar(years, tmp, width, label=country)
        past_values = np.array(tmp)
    else:
        plt.bar(years, tmp, width, bottom=past_values, label=country)
        past_values = np.array(tmp) + past_values
        pass
    expcount += 1

plt.ylabel('usd/t')
plt.title('Beef price by country')
plt.legend()
plt.xticks(years)

plt.show()
# [___CELL_SEPARATOR___]
