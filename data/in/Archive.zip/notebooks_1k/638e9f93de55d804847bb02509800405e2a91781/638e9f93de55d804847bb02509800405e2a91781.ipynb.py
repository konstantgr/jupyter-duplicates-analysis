from scipy.stats import norm
from scipy.optimize import minimize
import matplotlib.pyplot as plt
%matplotlib inline
import numpy as np
# [___CELL_SEPARATOR___]
def p_distribution_pdf(x, **kwargs):
    """This is the target distribution. It only uses x, but is equipped with kwargs
    to simplify interface -- now p_distribution and q_distribution (defined below) are exchangeable """
    w = 0.1
    mean1 = 1
    stddev1 = .5
    mean2 = 10
    stddev2 = 3
    
    return w * norm.pdf(x, loc=mean1, scale=stddev1) + (1-w) * norm.pdf(x, loc=mean2, scale=stddev2)
# [___CELL_SEPARATOR___]
x_values = np.arange(-5, +25, .1)
plt.figure(figsize=(18, 10), dpi= 80, facecolor='w', edgecolor='k')
plt.plot(x_values, p_distribution_pdf(x_values), 'b-')
plt.xlim([np.min(x_values), np.max(x_values)])
plt.ylim([0, plt.ylim()[1]])
plt.grid()
plt.show()
# [___CELL_SEPARATOR___]
def q_distribution_pdf(x, **kwargs):
    """This is the pdf of approximate distribution.
    We assume that to be Normal, and send in loc and scale through the kwargs"""
    loc = kwargs.get('loc')
    scale = kwargs.get('scale')
    return np.maximum(1e-6, norm.pdf(x=x, loc=loc, scale=scale))
# [___CELL_SEPARATOR___]
def optimize_parameters(f, g, eps):
    """
    The work-horse for the optimization. Takes two functions f and g as input.
    One of these is the p-function above, the other is the q-function.
    This method does not care which is which.
    (Implementation trick: Note that while both the p-func and the q-func accept loc and scale as input through
    **kwargs, only the q-function actually uses that input. This, however, ensures that we in this function can
    consider p and q as "exchangeable").
    The function  calculates KL(f||g) through (naive) numerical integration, and returns the mu-sigma-pair that
    minimizes the KL.
    :param f: An executable function that accepts inputs x, loc, shape which returns a vector of the same shape as x
    :param g: An executable function that accepts inputs x, loc, shape which returns a vector of the same shape as x
    :param eps: Step-size for the numerical integration
    :return: Parameters - a vector of [mu, sigma]
    """

    def calculate_KL_for_given_parameters(parameters):
        """
        Calculate the KL(f||g) using the given parameters. 
        Both f and g are already set (in the surrounding scope); 
        one is p_distribution the other is q_distribuiton. eps is also set in the outer scope. 
        This is important beause the interface to scipy's minimize requires you send in a function 
        that *only* takes a list containing the parameters we try to optimize as input.
        
        Do the calculation using numeric integration: 
        At several equally-distanced points along the x-axis, (called x_i, =0, 1, ...) we calculate 
        f(x_i) * log(f(x_i) / g(x_i))
        Then sum all these values, and multiply by the length between x_i and x_(i+1). 
        Here np.sum() is helpful: It takes the elements of a list/vecotr and sums the contributions.
        np.log(y) will calculate the log of y.
        
        :param params: Parameter vector: [mu, sigma]
        :return: KL(f||g) 
        """
        mu = parameters[0]
        sigma = parameters[1]

        x_val = np.arange(-25, +25, eps)
        total = eps * np.sum(f(x_val, loc=mu, scale=sigma) *
                                    (np.log(f(x_val, loc=mu, scale=sigma))
                                     - np.log(g(x_val, loc=mu, scale=sigma))))
        return total
    
    """
    Find (approximate) optimal value using numerical optimization. 
    The minimize function from scipy will do this for us. 
    The call to minimize takes the following parameters:
        * a function to be minimized
        * bounds for the solution, a touple with one element per parameter, with lower and uper bounds.
               Here loc can be whatever, but for numerical stability it can be clever to ensure that 
               scale must be >= 1E-2 or something like that.
        * x0: The startingpoint for the optimization. Almost any value should work here, but it is useful
               to supply "something" to ensure that the startingpoint is legal (i.e., variance > 0)
    """
    optimum = minimize(calculate_KL_for_given_parameters, 
                       bounds=((None, None), (1E-2, None)), 
                       x0=[0, 5])
    
    # We only need the optimum, not all the extra info (like the minimal KL value), 
    # hence we only return the "x-slot", optimum['x']
    return optimum['x']
# [___CELL_SEPARATOR___]
def generate_moment_projection(eps=1E-2):
    """
    Generate the "Moment projection" (M-projection; K&F Def 8.4).
    This minimizes KL(p||q) wrt. q. Also known as the "expectation propagation loss".
    :param eps: The step-size for the numerical integration
    :param starting_point: Starting point for the optimization. Anything reasonable will work.
    :return: Parameters - a vector of [mu, sigma]
    """

    return optimize_parameters(f=p_distribution_pdf,
                               g=q_distribution_pdf,
                               eps=eps)
# [___CELL_SEPARATOR___]
def generate_information_projection(eps=1E-2):
    """
    Generate the "Information projection" (I-projection; K&F Def 8.4).
    This minimizes KL(q||p) wrt. q. Also known as "variational inference".
    :param eps: The step-size for the numerical integration
    :param starting_point: Starting point for the optimization.
    Anything reasonable will work.
    :return: Parameters - a vector of [mu, sigma]
    """
    return optimize_parameters(f=q_distribution_pdf,
                               g=p_distribution_pdf,
                               eps=eps)
# [___CELL_SEPARATOR___]
# Find moment estimate
moment_estimate = generate_moment_projection()
print("M-projection: mu = {:5.3f}, sigma = {:5.3f}".format(
    moment_estimate[0], moment_estimate[1]))

# Find information estimate
information_estimate = generate_information_projection()
print("I-projection: mu = {:5.3f}, sigma = {:5.3f}".format(
    information_estimate[0], information_estimate[1]))
# [___CELL_SEPARATOR___]
x_values = np.arange(-5, +25, .01)
plt.figure(figsize=(18, 10), dpi= 80, facecolor='w', edgecolor='k')
plt.plot(x_values, p_distribution_pdf(x_values), 'b-', label='$p(x)$')
plt.plot(x_values, q_distribution_pdf(x_values, loc=moment_estimate[0], scale=moment_estimate[1]),
         'r--', label='M-proj: $\\arg\\min_q KL(p||q)$')
plt.plot(x_values, q_distribution_pdf(x_values, loc=information_estimate[0], scale=information_estimate[1]),
         'g--', label='I-proj: $\\arg\\min_q KL(q||p)$')
plt.legend(loc='upper right')
plt.gca().axes.yaxis.set_ticklabels([])
plt.gca().axes.xaxis.set_ticklabels([])
plt.xlim([np.min(x_values), np.max(x_values)])
plt.ylim([0, plt.ylim()[1]])
plt.show()
# [___CELL_SEPARATOR___]
