import networkx as nx
import matplotlib.pyplot as plt
import numpy as np
import warnings
warnings.filterwarnings('ignore')

%matplotlib inline
# [___CELL_SEPARATOR___]
# Create an empty graph object with no nodes and edges.
G = nx.Graph() # DiGraph, MultiGraph, MultiDiGraph
# [___CELL_SEPARATOR___]
## Add nodes to our graph object
# In NetworkX, nodes can be any hashable object e.g. a text string, an image,
# an XML object, another Graph, a customized node object, etc.

G.add_node('1')
G.add_node(1)
G.add_node('second')

# G.add_node({'dictionary': 'will throw error'})
# G.add_node([1, 2])
# [___CELL_SEPARATOR___]
list_of_nodes = [1, 2, 3, 'node4']
G.add_nodes_from(list_of_nodes)
# [___CELL_SEPARATOR___]
# Access nodes in a Graph object
G.nodes()
# [___CELL_SEPARATOR___]
# NetworkX has a lot of graph generators path_graph is one of them.
H = nx.path_graph(7)
print(H.nodes())
# [___CELL_SEPARATOR___]
G.add_nodes_from(H)
print(G.nodes())
# [___CELL_SEPARATOR___]
G.add_node(H)
print(G.nodes())
# [___CELL_SEPARATOR___]
# Now let's talk about edges.
# Edge between two nodes means that they share some property/relationship
# G.add_node(H)
G.add_edge(0, 'second')
G.add_edge(2, 3)
G.add_edge('second', 'node4')

list_of_edges = [(2, 3), (4, 5), ('node4', 0)]
G.add_edges_from(list_of_edges)

# Check out edges
G.edges()
# [___CELL_SEPARATOR___]
# Number of nodes and edges.
print(G.number_of_nodes(), len(G), len(G.nodes()))
print(G.number_of_edges(), len(G.edges()))
# [___CELL_SEPARATOR___]
print(G.nodes())
G.remove_node(0)
print(G.nodes())
# [___CELL_SEPARATOR___]
print(G.edges())
G.remove_edge(4, 5)
print(G.edges())
# [___CELL_SEPARATOR___]
G.clear()
print(G.nodes(), G.edges())
# [___CELL_SEPARATOR___]
# One more graph generator. This will create
# a Erdos-Reyni Graph
G = nx.erdos_renyi_graph(10, 1.0, seed=1)

# Let's checkout nodes and edges
print(G.nodes())
print(G.edges())
nx.draw(G)
# [___CELL_SEPARATOR___]
matrix = nx.to_numpy_matrix(G)
# print matrix

fig = plt.figure()
ax = fig.add_subplot(1,1,1)
ax.set_aspect('equal')
plt.imshow(matrix, interpolation='nearest', cmap=plt.cm.gray)
plt.show()
# [___CELL_SEPARATOR___]
G.add_edge(1, 2, weight=4.7)

G.add_edges_from([(3, 4), (4, 5)], color='red')

G.add_edges_from([(1, 2, {'color': 'blue'}), (2, 3, {'weight': 8})])

G[1][2]['weight'] = 4.7
# [___CELL_SEPARATOR___]
G.add_node(1, time='13:00')
print(G.nodes())
print(G.nodes(data=True))
# [___CELL_SEPARATOR___]
# Accessing the graph dictionary
print('nodes: ', G.nodes())
print('edges: ', G.edges())

print(G[0])
print(G[1])
print(G[1][2])
# [___CELL_SEPARATOR___]
print(G[1])
print(G[1][2])
print(G[1][2]['color'])
# [___CELL_SEPARATOR___]
G = nx.Graph()
list_of_cities = [('Paris', 'Warsaw', 841), ('Warsaw', 'Berlin', 584), ('Berlin', 'London', 1101), ('Paris', 'Barcelona', 1038)]
G.add_weighted_edges_from(list_of_cities)

# print G.nodes()
print(G.edges(data=True))
# Iterate through the edges and find the highest weight.
# [___CELL_SEPARATOR___]
result = max([w['weight'] for u, v, w in G.edges(data=True)])
print(result)

# max(G.edges(data=True), key=lambda x:x[2])
# [___CELL_SEPARATOR___]
G = nx.erdos_renyi_graph(20, 0.15, seed=1)
# [___CELL_SEPARATOR___]
nx.draw(G, with_labels=True)
# [___CELL_SEPARATOR___]
# Let's find out the neighbors of node 12
list(G.neighbors(12))
# [___CELL_SEPARATOR___]
# nx.degree_centrality(G)
list(nx.degree_centrality(G).items())[0:5]
# [___CELL_SEPARATOR___]
import csv
authors_graph = nx.Graph()
with open('CA-GrQc.txt', 'r') as f:
    reader = csv.reader(f, delimiter='\t')
    for row in reader:
        authors_graph.add_edge(row[0], row[1])
# [___CELL_SEPARATOR___]
print(authors_graph.number_of_edges())
print(authors_graph.number_of_nodes())
# [___CELL_SEPARATOR___]
# Neighbors/ degree of node is one way of calculating the importance
# of the node. Influential nodes.
# print(list(authors_graph.neighbors('22504')))
print(len(list(authors_graph.neighbors('22504'))))
print(nx.degree(authors_graph,['22504']))
print(authors_graph.degree(['22504']))
# [___CELL_SEPARATOR___]
result = [(node, len(list(authors_graph.neighbors(node)))) for node in authors_graph.nodes()]
# [___CELL_SEPARATOR___]
max(result, key=lambda node:node[1])
# [___CELL_SEPARATOR___]
authors_graph.degree()['21012']
# returns a dictionary of degree keyed by node
# [___CELL_SEPARATOR___]
authors_graph.degree()
# [___CELL_SEPARATOR___]
nx.degree_centrality(authors_graph)
# [___CELL_SEPARATOR___]
plt.hist(list(nx.degree_centrality(authors_graph).values()))
plt.show()

G = nx.erdos_renyi_graph(1000, 0.9, seed=1)
plt.hist(list(nx.degree_centrality(G).values()))
plt.show()

H = nx.barabasi_albert_graph(1000, 30, 0.3)
K = nx.powerlaw_cluster_graph(1000, 30, 0.3)

plt.hist(list(nx.degree_centrality(H).values()))
plt.show()

plt.hist(list(nx.degree_centrality(K).values()))
plt.show()
# [___CELL_SEPARATOR___]
G = nx.erdos_renyi_graph(10, 0.15, seed=1)
nx.draw(G, with_labels=True)
# [___CELL_SEPARATOR___]
print([len(c) for c in sorted(nx.connected_components(authors_graph), key=len, reverse=True)])
# [___CELL_SEPARATOR___]
graphs = [c for c in sorted(nx.connected_component_subgraphs(authors_graph), key=len, reverse=True)]
# [___CELL_SEPARATOR___]
len(graphs[10])
# [___CELL_SEPARATOR___]
nx.draw(graphs[10])
# [___CELL_SEPARATOR___]
nx.draw(nx.erdos_renyi_graph(10, 0.2, seed=1), with_labels=True)
# [___CELL_SEPARATOR___]
print(nx.shortest_path(graphs[0], '22504', '23991'))
print(len(nx.shortest_path(graphs[0], '22504', '23991')))
print(nx.shortest_path_length(graphs[0], '22504', '23991'))
# [___CELL_SEPARATOR___]
# G = nx.fast_gnp_random_graph(10000, 0.1, seed=1)
# [___CELL_SEPARATOR___]
d = {}
for node in authors_graph.nodes():
    try:
        d[node] = nx.shortest_path_length(authors_graph, '22504', node)
    except:
        d[node] = -1
# [___CELL_SEPARATOR___]
plt.hist(list(d.values()))
plt.show()
# list(d.values())
# [___CELL_SEPARATOR___]
# print(sum([1 for _, val in d.items() if val == -1]))
# print(len(authors_graph.nodes()) - len(graphs[0]))
# print((sum(val for _, val in d.items() if val != -1))/len(graphs[0]))
# [___CELL_SEPARATOR___]
G = nx.DiGraph()
G.add_edge(1, 2)
print(G.edges())
# G[1][2]
# G.is_directed()
# type(G)
# [___CELL_SEPARATOR___]
G.add_edges_from([(1, 2), (3, 2), (4, 2), (5, 2), (6, 2), (7, 2)])
nx.draw(G, with_labels=True)
# [___CELL_SEPARATOR___]
G.in_degree()
# [___CELL_SEPARATOR___]
nx.pagerank(G)
# [___CELL_SEPARATOR___]
G.add_edge(5, 6)
nx.draw(G, with_labels=True)
# [___CELL_SEPARATOR___]
nx.pagerank(G)
# [___CELL_SEPARATOR___]
G.add_edge(2, 8)
nx.draw(G, with_labels=True)
# [___CELL_SEPARATOR___]
nx.pagerank(G)
# [___CELL_SEPARATOR___]
%%time
deg_centrality = nx.degree_centrality(authors_graph)
btw_centrality = nx.betweenness_centrality(authors_graph)

deg_cent_sorted = [i[1] for i in sorted(zip(deg_centrality.keys(), deg_centrality.values()))]
btw_cent_sorted = [i[1] for i in sorted(zip(btw_centrality.keys(), btw_centrality.values()))]

plt.scatter(deg_cent_sorted, btw_cent_sorted)
plt.xlabel('degree')
plt.ylabel('betweeness')
plt.title('centrality scatterplot')
# [___CELL_SEPARATOR___]
