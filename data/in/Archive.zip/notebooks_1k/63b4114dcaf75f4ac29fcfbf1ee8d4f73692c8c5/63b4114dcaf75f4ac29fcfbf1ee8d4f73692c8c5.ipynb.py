%matplotlib inline
from google.colab import files
# [___CELL_SEPARATOR___]
import matplotlib.pyplot as plt
import math
import numpy as np
np.random.seed(5)
# [___CELL_SEPARATOR___]
import scipy.stats as stats
import random
import math
import pandas as pd

# [___CELL_SEPARATOR___]
from sklearn import decomposition
from sklearn import datasets

# datasets
!pip install ggplot
from ggplot import mtcars
iris = datasets.load_iris()
# [___CELL_SEPARATOR___]
X = iris.data
A = X.T.dot(X)  # a square matrix
V = np.linalg.eig(A)


# check that A v = lambda v
print('lambda * v', A.dot(V[1][:, 0]) / V[1][:, 0])
print('lambda', V[0][0])
# [___CELL_SEPARATOR___]
# Get PCA with 2 components from Iris Data using sklearn
X = iris.data

pca = decomposition.PCA(n_components=2, svd_solver='full')
pca.fit(X)
C = pca.transform(X)
D = pca.components_.T

print('X shape is ', X.shape)
print('C shape is ', C.shape)
print('D shape is ', D.shape)
# [___CELL_SEPARATOR___]
# Do it manually by getting eigendecomposition of X^T X
Xm = X - X.mean(axis=0)
d = np.linalg.eig(Xm.T.dot(Xm))

# get top 2 eigenvalues
D1 = d[1][:, :2]

C1 = Xm.dot(D1)

print('Actual X[0]', X[0])
print('Sklearn reconstruction', C.dot(D.T)[0] + X.mean(axis=0))
print('Numpy reconstruction', C1.dot(D1.T)[0] + X.mean(axis=0))
# [___CELL_SEPARATOR___]
## Numerical Methods
[chapter4(dl book)]
(http://www.deeplearningbook.org/contents/numerical.html)

http://cs231n.github.io/optimization-1/

#### Directional Derivative 

### Convex Optimization

#### Newton's method

#### Simplex Algorithm - Linear Programming

#### Quadratic Programming


### Non-convex Optimization

#### Finite Differences
#### Gradient Descent
#### Conjugate Gradient
#### BFGS
#### Hessian
#### Genetic Algorithms
#### Differential Evolution
# [___CELL_SEPARATOR___]
# Compute covariance with numpy

X = iris.data

print(np.mean((X - np.mean(X, axis=0)) ** 2, axis=0))

print(np.std(X, axis=0) ** 2)
# [___CELL_SEPARATOR___]
def sigmoid(x):
  y = []
  for item in x:
    y.append(1/(1 + math.exp(-item)))
  return y

x = np.arange(-10, 10, 0.2)
y = sigmoid(x)
plt.plot(x, y)
plt.show()
# [___CELL_SEPARATOR___]
 def soft_plus(x):
    y = []
    for item in x:
      y.append(math.log(1 + math.exp(item)))
    return y
  
x = np.arange(-10, 10, 0.2)
y = soft_plus(x)
plt.plot(x, y)
plt.show()
# [___CELL_SEPARATOR___]
# change the index from numbers to the name of the car
mtcars.index = mtcars['name']
# [___CELL_SEPARATOR___]
# Mean:
mtcars.mean(axis=0) # mean of each column
mtcars.mean(axis=1) # mean of each row
mtcars.median(axis=0) # median of column
# [___CELL_SEPARATOR___]
# Defined as the 'five num' summary:

five_num = [mtcars["mpg"].quantile(0),   
            mtcars["mpg"].quantile(0.25),
            mtcars["mpg"].quantile(0.50),
            mtcars["mpg"].quantile(0.75),
            mtcars["mpg"].quantile(1)]

print(five_num)

# IQR(Interquartile range) is a measure of spread (upper quartile-lower quartile
# 4-quantiles are called quartiles):
mtcars["mpg"].quantile(0.75) - mtcars["mpg"].quantile(0.25)
# [___CELL_SEPARATOR___]
# A boxplot plots these quantities, i.e.
mtcars.boxplot(column='mpg', return_type='axes', figsize=(8,8))

plt.text(x=0.74, y=22.25, s="3rd Quartile")
plt.text(x=0.8, y=18.75, s="Median")
plt.text(x=0.75, y=15.5, s="1st Quartile")
plt.text(x=0.9, y=10, s="Min")
plt.text(x=0.9, y=32, s="Max")
plt.text(x=0.7, y=19.5, s="IQR", rotation=90, size=25)
plt.show()
# [___CELL_SEPARATOR___]
norm_data = np.random.normal(size=100000)
skewed_data = np.concatenate((np.random.normal(size=35000)+2, 
                             np.random.exponential(size=65000)), 
                             axis=0)
uniform_data = np.random.uniform(0,2, size=100000)
peaked_data = np.concatenate((np.random.exponential(size=50000),
                             np.random.exponential(size=50000)*(-1)),
                             axis=0)

data_df = pd.DataFrame({"norm":norm_data,
                       "skewed":skewed_data,
                       "uniform":uniform_data,
                       "peaked":peaked_data})


data_df.plot(kind="density",
            figsize=(10,10),
            xlim=(-5,5))
plt.show()
# [___CELL_SEPARATOR___]
print('skew of graphs')
print(data_df.skew())
print('\n')
print('kurtosis of graphs')
print(data_df.kurt())
# [___CELL_SEPARATOR___]
# Computes all pairwise correlation scores
mtcars.corr(method='pearson')
# [___CELL_SEPARATOR___]
mpg = mtcars['mpg']
cyl = mtcars['cyl']

cov_mc = np.mean((mpg - np.mean(mpg))* (cyl - np.mean(cyl)))
cov_mc/(np.std(mtcars['mpg']) * np.std(mtcars['cyl']))
# [___CELL_SEPARATOR___]
np.random.seed(3)

mu = 10
sigma = 3
sample_size = 8
population_size = 50000
population = np.random.normal(mu, sigma, size=population_size)
sample_means = []

for _ in range(10000):
  sample = population[np.random.randint(0, len(population), sample_size)]
  sample_means.append(np.mean(sample))
  

print('Mean of sample means is', np.mean(sample_means), 'and the true mean is', mu)
print('Standard deviation of sample means is ', np.std(sample_means))
print('Theoretical standard deviation of sample means is', np.sqrt(sigma**2 / sample_size))

# [___CELL_SEPARATOR___]
np.random.seed(3)

mu = 10
sigma = 3
sample_size = 15
population_size = 50000
population = np.random.normal(mu, sigma, size=population_size)
sample_stds = []
unbiased_sample_stds = []

for _ in range(10000):
  sample = population[np.random.randint(0, len(population), sample_size)]
  sample_stds.append(np.std(sample))
  unbiased_sample_stds.append(np.std(sample, ddof=1)**2)
  

print('Mean of sample stds is', np.mean(sample_stds), 'and the true std is', sigma)
print('Mean of unbiased sample stds is', np.sqrt(np.mean(unbiased_sample_stds)))

# [___CELL_SEPARATOR___]
#create population
population1 = stats.poisson.rvs(mu=35, size=50000)
population2 = stats.poisson.rvs(mu=35, size=100000)
population = np.concatenate((population1, population2))
print('actual population mean', population.mean())


np.random.seed(5)
sample_size = 500
sample_ages = np.random.choice(a=population, size=sample_size)
sample_mean = sample_ages.mean()
print('sample mean', sample_mean)

# 2 tailed distribution, so to get a 95% confidence interval, we need to use 97.5%

z = stats.norm.ppf(q=.975)
moe = z * (population.std() / math.sqrt(sample_size))
print('margin of error', moe)
print('95th% confidence interval:', (sample_mean - moe, sample_mean + moe))

# [___CELL_SEPARATOR___]
sample_size = 50
sample_ages = np.random.choice(a=population, size=sample_size)
sample_mean = sample_ages.mean()
# [___CELL_SEPARATOR___]
# actually, we are getting t for q = .975 and q = .025
# we are actually doing mu + moe(q=0.025) and mu + moe (q=0.975)
t = stats.t.ppf(q=.975, df=sample_size - 1)
sample_stdev = np.std(sample_ages, ddof=1)
moe_t = t * (sample_stdev / math.sqrt(sample_size))

print('margin of error with t value', moe_t)
print('confidence interval:', (sample_mean - moe_t, sample_mean + moe_t))
print('population mean', population.mean())
# [___CELL_SEPARATOR___]
# you want your confidence interval to be within .1 unit of the actual mean
moe = 0.1
# for 95% confidence interval:
z = stats.norm.ppf(q=.975)

# moe = z * (sigma/sqrt(n))
# so, n = (z * sigma / moe)^2
sigma = 1

print('The number of samples would be ', ((z * sigma) / moe) ** 2)
# [___CELL_SEPARATOR___]
# Let's show that this sample size gives us the correct confidence interval
mu = 2
sigma = 1
sample_size = 384
population = np.random.normal(mu, sigma, 5000)

sample_mean = []
for _ in range(10000):
  sample = population[np.random.randint(0, len(population), sample_size)]
  sample_mean.append(np.mean(sample))

print('Sampled 95% confidence interval', np.percentile(sample_mean, 2.5), np.percentile(sample_mean, 97.5))
print('Sample mean is: ', np.mean(sample_mean))
# [___CELL_SEPARATOR___]
# 1. Perform resampling:
sample_data = np.array([30,37,36,43,42,43,43,46,41,42])
x_bar = np.mean(sample_data)

# Let's perform 100 bootstrap samples
bootstrap_samples_n = 100
bootstrapped_x_bars = []
for n in range(bootstrap_samples_n):
  resample_idx = np.random.randint(0, len(sample_data), len(sample_data))
  bootstrapped_x_bars.append(np.mean(sample_data[resample_idx]))

bootstrapped_x_bars = np.sort(bootstrapped_x_bars)
delta_star = bootstrapped_x_bars - x_bar
# [___CELL_SEPARATOR___]
# 2. Now we can get the 80th percentile of delta_star distribution
lower_bound_int = delta_star[int(bootstrap_samples_n * .1) - 1]
upper_bound_int = delta_star[int(bootstrap_samples_n * .9) - 1]
print('confidence interval is: ', [x_bar + lower_bound_int, 
                                   x_bar + upper_bound_int])
# [___CELL_SEPARATOR___]
from collections import Counter
import numpy as np
# [___CELL_SEPARATOR___]
def reservoir_alg(res_capacity=10, stream_size=100):
  # For this example, let's say the reservoir is already filled to capacity
  reservoir = []
  for i in range(1, stream_size):
    if i <= res_capacity:
      reservoir.append(i)
    else:
      # Do reservoir sampling:
      j = np.random.randint(1, i + 1)
      if j <= res_capacity:
        # remove j element and replace with i
        reservoir[j - 1] = i
  return reservoir
# [___CELL_SEPARATOR___]
# Now let's run this 10,000 times and see if we get uniform distribution
# over the 100 items we see in total
counts = Counter()
num_sim = 10000
for i in range(num_sim):
  reservoir = reservoir_alg()
  counts.update(reservoir)

# We expect the counter to show that each number in stream_size
# has an equal probability of occuring:
probs = {x:counts[x] / num_sim for x in counts}
# [___CELL_SEPARATOR___]
# Indeed we see that each has a ~1/stream_size probability of occuring!
probs
# [___CELL_SEPARATOR___]
# Type-1 Error Example
null_mu = 10
null_std = 6
experiment_sample_size = 20
significance_level = 0.05
N = 40000
# Null Hypothesis is that our sampled mu = null_mu

false_positive = 0
for _ in range(N):
  # run 1000 experiments
  exp = np.random.normal(loc=null_mu, scale=null_std, size=20)
  exp_mu = np.mean(exp)
  
  # do a 1-Sample Z-test, we divide by std of the sample mean
  z = (exp_mu - null_mu) / (null_std / np.sqrt(experiment_sample_size))
  test_statistic = stats.norm.cdf(z)
  if test_statistic < (significance_level / 2)\
      or test_statistic > (1 - significance_level / 2):
    false_positive += 1

print('The Type-1 Error is: ', false_positive / N)
# [___CELL_SEPARATOR___]
from scipy.stats import norm
import scipy.stats as stats
# [___CELL_SEPARATOR___]
# Use a z test bc we have normal data and a known variance:
data = np.array([1, 2, 3, 6, 0])
N = len(data)
mean_open_rate = np.mean(data)
null_hypothesis_open_rate = 2
known_variance = 4
sigma = np.sqrt(known_variance)
sqrt_N = np.sqrt(N)

# calculate our Z statistic since our sample mean comes from a normal distribution
z = (mean_open_rate - null_hypothesis_open_rate) / (sigma / sqrt_N)
z
# [___CELL_SEPARATOR___]
# Find P(Z > z)
print('Probability that we get this mean open-rate if the Null Hypothesis is true')
print(1 - stats.norm.cdf(z))
# [___CELL_SEPARATOR___]
# Use a t test because we don't know mean or population variance:
data = np.array([1, 2, 0, 1, 0])
N = len(data)
mean_life = np.mean(data)
null_hypothesis_life = 2


sigma = np.std(data, ddof=1)
sqrt_N = np.sqrt(N)

# calculate our t statistic
t = (mean_life - null_hypothesis_life) / (sigma / sqrt_N)
t
# [___CELL_SEPARATOR___]
# p-value = P(|T| > |t|) = 1 - t_dist(t, df)
df = N - 1
p_value = 2 * (1 -  stats.t.cdf(abs(t), df))

print('The sample mean battery life is', mean_life)
print('The p-value is', p_value)

print('our p-value < .05 so we reject the null hypothesis. Good luck at your company')
# [___CELL_SEPARATOR___]

N1 = 800
N2 = 779
# let's sample from the two populations
button_one_obs = np.random.normal(3, 2.0, N1)
button_two_obs = np.random.normal(3.3, 2.0, N2)

mu1 = np.mean(button_one_obs)
mu2 = np.mean(button_two_obs)
std1 = np.std(button_one_obs, ddof=1)
std2 = np.std(button_two_obs, ddof=1)

# let's calculate the two-sample t-test manually
pooled_variance = ((N1 - 1) * std1**2 + (N2 - 1) * std2**2) / (N1 + N2 - 2)
pooled_variance *= ((1/N1) + (1/N2))
t = (mu1 - mu2) / np.sqrt(pooled_variance)

print('t', t)

df = N1 + N2 - 2
p_value = 2 * (1 -  stats.t.cdf(abs(t), df))


print('p', p_value)

# [___CELL_SEPARATOR___]
# we can also get the same result using stats.ttest_ind_from_stats
t, p = stats.ttest_ind_from_stats(mu1, std1, N1, mu2, std2, N2)

print('t', t)
print('p', p)
# [___CELL_SEPARATOR___]
# let's calculate the test-statistic manually
observed = [135, 170, 365, 328]
expected = [152.81, 152.19, 347.19, 345.81]
chi_sq_stat = sum([(e - o) ** 2 / e for o, e in zip(observed, expected)])
print(chi_sq_stat)
df = (2-1)*(2-1)
# [___CELL_SEPARATOR___]
# stats.chisquare is equivalent as the above calculation
stats.chisquare(observed, expected, ddof=df)
# [___CELL_SEPARATOR___]
# https://stackoverflow.com/questions/15204070/is-there-a-python-scipy-function-to-determine-parameters-needed-to-obtain-a-ta
from scipy.stats import norm, zscore

def sample_power_probtest(p1, p2, power=0.8, sig=0.05):
    z = norm.isf([sig/2]) #two-sided t test
    zp = -1 * norm.isf([power]) 
    d = (p1-p2)
    s = 2*((p1+p2) /2)*(1-((p1+p2) /2))
    n = s * ((zp + z)**2) / (d**2)
    return n[0]

def sample_power_difftest(d, s, power=0.8, sig=0.05):
    z = norm.isf([sig/2])
    zp = -1 * norm.isf([power])
    n = s * ((zp + z)**2) / (d**2)
    return int(round(n[0]))
# [___CELL_SEPARATOR___]
sample_power_probtest(0.5, 0.75, power=0.9)
# [___CELL_SEPARATOR___]
import statsmodels.stats.api as sms
es = sms.proportion_effectsize(0.5, 0.75)
# [___CELL_SEPARATOR___]
sms.NormalIndPower().solve_power(es, power=0.9, alpha=0.05, ratio=1)
# [___CELL_SEPARATOR___]
def _return_params_beta(mean, var):
  alpha = (((1 - mean) / var) - (1 / mean)) * mean**2
  beta = alpha * (1 / mean - 1)
  return alpha, beta
# [___CELL_SEPARATOR___]
_return_params_beta(.27, 0.00065482)
# [___CELL_SEPARATOR___]
a, b = 81, 219
# we can get sigma using scipy
sigma = stats.beta.stats(81, 219, moments='mvsk')[1]

# [___CELL_SEPARATOR___]
# Choose alpha and beta based on mean and sigma
a, b = 81, 219
beta_dist = stats.beta(a, b)
x = np.linspace(0, 1, 1002)[1:-1]
plt.plot(x, beta_dist.pdf(x))
plt.show()
# we see the mean is .27, and the beta distribution gives us a distribution around the sign-up rate
# [___CELL_SEPARATOR___]
a2, b2 = 81 + 100, 219 + 200
beta_dist2 = stats.beta(a2, b2)
x2 = np.linspace(0, 1, 1002)[1:-1]
plt.plot(x, beta_dist.pdf(x))
plt.plot(x2, beta_dist2.pdf(x2))
plt.show()
# [___CELL_SEPARATOR___]
%matplotlib inline
import numpy as np
from scipy import stats
from matplotlib import pyplot as plt
# [___CELL_SEPARATOR___]
alpha_0, beta_0 = _return_params_beta(mean=.15, var=.00015)
alpha_0, beta_0
# [___CELL_SEPARATOR___]

beta_dist = stats.beta(alpha_0, beta_0)
x = np.linspace(0, 1, 1002)[1:-1]
plt.plot(x, beta_dist.pdf(x))
plt.show()
# [___CELL_SEPARATOR___]
alpha_A, beta_A = alpha_0 + 100, beta_0 + 885
alpha_B, beta_B = alpha_0 + 78, beta_0 + 522

beta_distA = stats.beta(alpha_A, beta_A)
beta_distB = stats.beta(alpha_B, beta_B)
x2 = np.linspace(0, 0.5, 1002)[1:-1]

plt.plot(x, beta_dist.pdf(x),
         label=r'$\alpha_0=%.1f,\ \beta_0=%.1f$' % (alpha_0, beta_0))
plt.plot(x, beta_distA.pdf(x),
         label=r'$\alpha_A=%.1f,\ \beta_A=%.1f$' % (alpha_A, beta_A))
plt.plot(x, beta_distB.pdf(x2),
        label=r'$\alpha_B=%.1f,\ \beta_B=%.1f$' % (alpha_B, beta_B))
plt.legend(loc=0)
plt.show()
# [___CELL_SEPARATOR___]
print('average stats', 78/(522+78))
print('low', stats.beta.ppf(.025, alpha_B, beta_B))
print('high', stats.beta.ppf(.975, alpha_B, beta_B))
# [___CELL_SEPARATOR___]
alpha_A, beta_A = alpha_0 + 185, beta_0 + 785
alpha_B, beta_B = alpha_0 + 220, beta_0 + 850
print(alpha_0, beta_0)
print(alpha_A, beta_A)
print(alpha_B, beta_B)


beta_distA = stats.beta(alpha_A, beta_A)
beta_distB = stats.beta(alpha_B, beta_B)
x2 = np.linspace(0, 0.6, 1002)[1:-1]


plt.plot(x, beta_dist.pdf(x2),
         label=r'$\alpha_0=%.1f,\ \beta_0=%.1f$' % (alpha_0, beta_0))
plt.plot(x, beta_distA.pdf(x2),
         label=r'$\alpha_A=%.1f,\ \beta_A=%.1f$' % (alpha_A, beta_A))
plt.plot(x, beta_distB.pdf(x2),
        label=r'$\alpha_B=%.1f,\ \beta_B=%.1f$' % (alpha_B, beta_B))
plt.legend(loc=0)
plt.show()
# [___CELL_SEPARATOR___]

sim_size = 1000000
A_sim = stats.beta.rvs(alpha_A, beta_A, size=sim_size)
B_sim = stats.beta.rvs(alpha_B, beta_B, size=sim_size)

np.sum(B_sim > A_sim) / sim_size
# [___CELL_SEPARATOR___]
# use log beta because beta function can be less numerically stable

import math

def log_beta_func(a, b):
    beta = math.exp(math.lgamma(a) + math.lgamma(b) - math.lgamma(a+b))
    return beta

def exp_error(alpha_A, beta_A, alpha_B, beta_B):
  total_sum = 0
  for i in range(int(alpha_B - 1)):
    lnum = log_beta_func(alpha_A + i, beta_A + beta_B) 
    lden = math.log(beta_B + i) + log_beta_func(1 + i, beta_B) + \
        log_beta_func(alpha_A, beta_A)
    total_sum += math.exp(lnum - lden)
  return total_sum

1 - exp_error(alpha_A, beta_A, alpha_B, beta_B)
# [___CELL_SEPARATOR___]
def _return_mu_var(a, b):
  mu = a / (a + b)
  var = a * b / ((a + b) ** 2 * (a + b + 1))
  return mu, var

mu_A, var_A = _return_mu_var(alpha_A, beta_A)
mu_B, var_B = _return_mu_var(alpha_B, beta_B)

mu_diff = mu_B - mu_A
var_diff = var_A + var_B

posterior = stats.norm.cdf(0, mu_diff, var_diff)
low_estimate = stats.norm.ppf(.025, mu_diff, var_diff)
high_estimate = stats.norm.ppf(.975, mu_diff, var_diff)


print('posterior probability that B > A', 1 - posterior)
print('\n')

print('estimate', mu_diff)
print('credible interval for above estimate:')
print('lower bound', low_estimate)
print('higher bound', high_estimate)

# [___CELL_SEPARATOR___]
import numpy as np

document = "Some polar bears in the Arctic are shedding pounds during the time they should be beefing up, a new study shows. It’s the climate change diet and scientists say it’s not good. They blame global warming for the dwindling ice cover on the Arctic Ocean that bears need for hunting seals each spring."
sentence1 = document.split('.')[0]

doc_dict = {}
idx_num = 0
for sentence in document.split('.'):
  sentence_tknzd = sentence.split(' ')
  for word in sentence_tknzd:
    word.strip(',')
    if word not in doc_dict:
      doc_dict[word] = idx_num
    idx_num += 1

sentence1_tknzd = sentence1.split(' ')
# [___CELL_SEPARATOR___]
# Initialize weights matrix W, and W'
# let's give only 20 features for now:
vocab_size = len(doc_dict) + 1
num_features = 20

W = np.random.standard_normal(size=(vocab_size, num_features))

W_prime = np.random.standard_normal(size=(num_features, vocab_size))

# Set some hyperparameters of model:
learning_rate = 0.1
win_size = 3
# [___CELL_SEPARATOR___]
# Check distance between polar and bears
polar_vec = W[doc_dict['polar']]
bears_vec = W[doc_dict['bears']]
cosine_similarity(polar_vec.reshape(1, num_features), bears_vec.reshape(1, num_features))
# [___CELL_SEPARATOR___]
# Go through 10 epochs:
for x in range(10):
  for target_idx in range(0, len(sentence1_tknzd)):
    # Get all indices
    start_idx = max(target_idx - win_size, 0)
    end_idx = min(len(sentence1_tknzd) - 1, target_idx + win_size)
    target_word = sentence1_tknzd[target_idx]
    context = [sentence1_tknzd[idx] for idx in range(start_idx, target_idx)]
    context += [sentence1_tknzd[idx] for idx in range(target_idx + 1, end_idx + 1)]

    # Input vectors:
    inp = np.array([doc_dict[c] for c in context])
    input_layer = np.zeros((len(inp), vocab_size))
    input_layer[np.arange(len(inp)), inp] = 1

    # you can just use np.mean function?
    # Average input word vectors (context) to get hidden layer.
    h = (1 / len(context)) * np.sum([np.dot(W.T, x) for x in input_layer], axis=0)

    scores = np.array([np.dot(W_prime[:, i].T, h) for i in range(vocab_size)])

    # Apply softmax
    output_layer = np.exp(scores) / np.sum(np.exp(scores), axis=0)

    # compute error e
    t_j = np.zeros(vocab_size)
    t_j[target_idx] = 1
    e = output_layer - t_j

    # Update W'
    W_prime -= np.array([learning_rate * e[j] * h for j in range(vocab_size)]).T

    # Update W
    # Only updating input context vectors
    # EH [1, 20]
    EH = np.array([np.sum(W_prime[i, :] * e) for i in range(num_features)])
    EH_weighted = EH * learning_rate * (1 / vocab_size)
    W[a] -= EH_weighted


# [___CELL_SEPARATOR___]
polar_vec2 = W[doc_dict['polar']]
bears_vec2 = W[doc_dict['bears']]
cosine_similarity(polar_vec2.reshape(1, num_features), bears_vec2.reshape(1, num_features))