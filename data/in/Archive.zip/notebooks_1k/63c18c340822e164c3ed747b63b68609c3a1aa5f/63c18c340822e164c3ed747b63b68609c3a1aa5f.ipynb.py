!pwd
# [___CELL_SEPARATOR___]
!pip install --upgrade pip
# [___CELL_SEPARATOR___]
!pip install lxml
# [___CELL_SEPARATOR___]
!pip install py4j
# [___CELL_SEPARATOR___]
!pip install tushare
# [___CELL_SEPARATOR___]
