iplot(gen_rabi_elem(tau=500e-9, mw_amp=1.5, mw_freq=3e9))
# [___CELL_SEPARATOR___]
# Make sure pulseblock package location is on your path
import sys
sys.path.append('/home/tp/code/pulseblock')
# [___CELL_SEPARATOR___]
from pulseblock import pulse as po  # module containing all individual pulse classes
from pulseblock import pulse_block as pb  # module containing PulseBlock class
# [___CELL_SEPARATOR___]
dev_pb = pb.PulseBlock(name='dev_pb')
# [___CELL_SEPARATOR___]
dev_pb.insert(
    p_obj=po.PTrue(ch='aom', dur=1e-6)
)
# [___CELL_SEPARATOR___]
print(dev_pb)
# [___CELL_SEPARATOR___]
from pulseblock.pb_iplot import iplot

iplot(dev_pb)
# [___CELL_SEPARATOR___]
iplot(
    dev_pb.join(
        p_obj=po.PTrue(
            ch='cntr_gate', 
            dur=500e-9,
            t0=300e-9
        ),
        name='test_pb'
    )
)
# [___CELL_SEPARATOR___]
dev_pb.insert(
    p_obj=po.PTrue(ch='cntr_gate', dur=500e-9, t0=300e-9)
)
# [___CELL_SEPARATOR___]
iplot(dev_pb)
# [___CELL_SEPARATOR___]
t_buf = 400e-9
tau = 200e-9
# [___CELL_SEPARATOR___]
dev_pb.append(
    po.PSin(
        ch='mw', 
        dur=tau, 
        t0=t_buf,  # in append(), t0 specifies delay from the end of the block (t0 can be negative)
        amp=1.5, 
        freq=2.87e9
    )
)
# [___CELL_SEPARATOR___]
iplot(dev_pb)
# [___CELL_SEPARATOR___]
tmp_dur = dev_pb.dur

dev_pb.insert(
    p_obj=po.PTrue(
        ch='aom', 
        dur=1e-6, 
        t0=tmp_dur + t_buf)
)

dev_pb.insert(
    p_obj=po.PTrue(
        ch='cntr_gate', 
        dur=500e-9, 
        t0=tmp_dur + t_buf)
)
# [___CELL_SEPARATOR___]
iplot(dev_pb)
# [___CELL_SEPARATOR___]
dev_pb.insert(
    p_obj=po.PTrue(
        ch='trig', 
        dur=100e-9, 
        t0=-150e-9   
    )
)
# [___CELL_SEPARATOR___]
iplot(dev_pb)
# [___CELL_SEPARATOR___]
dev_pb.dflt_dict = {
    'aom': po.DFalse(),
    'cntr_gate': po.DFalse(),
    'mw': po.DConst(val=0.0),
    'trig': po.DFalse()
}
# [___CELL_SEPARATOR___]
print(dev_pb)
# [___CELL_SEPARATOR___]
iplot(dev_pb)
# [___CELL_SEPARATOR___]
def gen_rabi_elem(tau, mw_amp, mw_freq):
    
    # Technical parameters:
    aom_dur = 1e-6  # aom pulse
    t_buf=400e-9  # safety window
    cntr_dur=500e-9  # duration of counter norm/readout pulses
    cntr_t0=300e-9  # offset for counter normalization pulse
    
    p_block = pb.PulseBlock()
    
    # Inint AOM pulse
    p_block.insert(po.PTrue(ch='aom', dur=aom_dur))
    
    # Normalization counter
    p_block.insert(po.PTrue(ch='cntr_gate', dur=cntr_dur, t0=cntr_t0))
    
    # MW
    p_block.append(
        po.PSin(
            ch='mw', t0=t_buf, dur=tau, 
            amp=mw_amp, freq=mw_freq
        )
    )
    
    # Safe the position for the readout pulses
    tmp_t = p_block.dur + t_buf
    
    # Readout AOM
    p_block.insert(po.PTrue(ch='aom', t0=tmp_t, dur=aom_dur))
    
    # Readout counter
    p_block.insert(po.PTrue(ch='cntr_gate', t0=tmp_t, dur=cntr_dur))
    
    # Trigger
    p_block.insert(po.PTrue(ch='trig', t0=-150e-9, dur=100e-9))
    
    return p_block
# [___CELL_SEPARATOR___]
iplot(
    gen_rabi_elem(tau=3e-6, mw_amp=1.5, mw_freq=2.87e9)
)
# [___CELL_SEPARATOR___]
import numpy as np
# [___CELL_SEPARATOR___]
# Sweep parameters
mw_amp = 1.5e-3
mw_freq = 2.87e9
tau_start = 100e-9
tau_stop=5e-6
tau_n_steps = 101

# Array of tau
tau_ar = np.linspace(100e-9, 5e-6, num=tau_n_steps)

# Create empty PulseBlock
rabi_pb = pb.PulseBlock(name='RabiPb')

# Append elementary block for each tau
for tau in tau_ar:
    rabi_pb.append_pb(
        gen_rabi_elem(
            tau=tau, 
            mw_amp=mw_amp, 
            mw_freq=mw_freq
        )
    )
    
# Specify Default Pulse values
rabi_pb.dflt_dict['aom'] = po.DFalse()
rabi_pb.dflt_dict['cntr_gate'] = po.DFalse()
rabi_pb.dflt_dict['mw'] = po.DConst(val=0.0)
rabi_pb.dflt_dict['trig'] = po.DFalse()
# [___CELL_SEPARATOR___]
iplot(rabi_pb, use_gl=True)
# [___CELL_SEPARATOR___]
from pulseblock.pb_sample import pb_sample
# [___CELL_SEPARATOR___]
samp_dict, n_pts, add_pts, t_ar = pb_sample(pb_obj=rabi_pb, samp_rate=10e9, debug=True)
# [___CELL_SEPARATOR___]
samp_dict
# [___CELL_SEPARATOR___]
# Sweep parameters
mw_amp = 1
mw_freq = 10e6
tau_start = 100e-9
tau_stop=5e-6
tau_n_steps = 3

# Array of tau
tau_ar = np.linspace(100e-9, 300e-9, num=tau_n_steps)

# Assemble PulseBlock
rabi_pb = pb.PulseBlock(name='RabiPb')

for tau in tau_ar:
    rabi_pb.append_pb(
        gen_rabi_elem(
            tau=tau, 
            mw_amp=mw_amp, 
            mw_freq=mw_freq
        )
    )
    
# Default Pulse values
rabi_pb.dflt_dict['aom'] = po.DFalse()
rabi_pb.dflt_dict['cntr_gate'] = po.DFalse()
rabi_pb.dflt_dict['mw'] = po.DConst(val=0.0)
rabi_pb.dflt_dict['trig'] = po.DFalse()
# [___CELL_SEPARATOR___]
samp_dict, n_pts, add_pts, t_ar = pb_sample(pb_obj=rabi_pb, samp_rate=150e6, debug=True)
# [___CELL_SEPARATOR___]
import plotly.graph_objects as plt
# [___CELL_SEPARATOR___]
fig = plt.Figure()

fig.add_trace(plt.Scatter(x=t_ar, y=samp_dict['trig'].astype(float)+1))
fig.add_trace(plt.Scatter(x=t_ar, y=samp_dict['mw']))
fig.add_trace(plt.Scatter(x=t_ar, y=samp_dict['cntr_gate'].astype(float)-1))
fig.add_trace(plt.Scatter(x=t_ar, y=samp_dict['aom'].astype(float)-2))

fig.show()
# [___CELL_SEPARATOR___]
rabi_pb = gen_rabi_elem(tau=500e-9, mw_amp=1, mw_freq=1)
iplot(original_rabi_pb)
# [___CELL_SEPARATOR___]
rabi_pb.add_offset(
    offset_dict={'aom': -400e-9}
)
iplot(rabi_pb)
# [___CELL_SEPARATOR___]
