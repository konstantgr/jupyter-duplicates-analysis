import pandas as pd
import numpy as np
import glob
import re
from collections import defaultdict
# [___CELL_SEPARATOR___]
from html.parser import HTMLParser

class MLStripper(HTMLParser):
    def __init__(self):
        self.reset()
        self.strict = False
        self.convert_charrefs= True
        self.fed = []
    def handle_data(self, d):
        self.fed.append(d)
    def get_data(self):
        return ''.join(self.fed)

def strip_tags(html):
    s = MLStripper()
    s.feed(html)
    return s.get_data()
# [___CELL_SEPARATOR___]
df_data = defaultdict(list)
for filename in glob.iglob('Lyrics/ohhla.com/*/*/*/*.txt', recursive=True):
    with open(filename, 'r', encoding = "ISO-8859-1") as f:
        stripped_lyrics = strip_tags(f.read())
        
        artist = re.search('Artist:\s*(.*)\s*\n', stripped_lyrics)
        song = re.search('Song:\s*(.*)\s*\n', stripped_lyrics)
        lyrics = re.search('Typed by:\s*(.*)\s*\n([\s\S]*)', stripped_lyrics)

        if artist is not None and song is not None and lyrics is not None:
            df_data["filename"].append(filename)
            df_data["artist"].append(artist.group(1))
            df_data["song"].append(song.group(1))
            df_data["lyrics"].append(lyrics.group(2).lower())  # group(1) is the transcriber
# [___CELL_SEPARATOR___]
rap_data = pd.DataFrame(df_data)
rap_data.iloc[105:120]
# [___CELL_SEPARATOR___]
rap_data.shape
# [___CELL_SEPARATOR___]
for artist, song, lyrics in zip(df_data["artist"],
                                df_data["song"],
                                df_data["lyrics"]):
    if "python" in set(lyrics.split()):
        print(artist, " - ", song)
# [___CELL_SEPARATOR___]
for artist, song, lyrics in zip(df_data["artist"],
                                df_data["song"],
                                df_data["lyrics"]):
    if "anaconda" in set(lyrics.split()):
        print(artist, " - ", song)
# [___CELL_SEPARATOR___]
# The 1/3 million most frequent words, all lowercase, with counts. 
# http://norvig.com/ngrams/
ngrams=pd.read_csv("assets/count_1w.txt",sep="\t",names=["word","count"])
ngrams.tail(n=20)
# [___CELL_SEPARATOR___]
# The Tournament Word List (178,690 words) -- used by North American Scrabble players.
# http://norvig.com/ngrams/
twl_wordlist=pd.read_csv("assets/TWL06.txt",names=["word"])
twl_wordlist=pd.DataFrame(twl_wordlist["word"].str.lower())

twl_w_ngrams = pd.merge(twl_wordlist, ngrams)
# [___CELL_SEPARATOR___]
twl_w_ngrams.sort_values(by="count").head(n=20)
# [___CELL_SEPARATOR___]
np.sum(twl_w_ngrams["count"] < 400000)
# [___CELL_SEPARATOR___]
all_bigwords = twl_w_ngrams[twl_w_ngrams["count"] < 400000]["word"].values
all_big_bigwords = [word for word in all_bigwords if len(word) > 4]
bigset = set(all_big_bigwords)

print(all_big_bigwords[:100])
# [___CELL_SEPARATOR___]
df_data["matches"] = []
for lyrics in df_data["lyrics"]:
    found_words = set(lyrics.split()) & bigset
    df_data["matches"].append(found_words)
# [___CELL_SEPARATOR___]
rap_data = pd.DataFrame(df_data)
rap_data = rap_data[rap_data.matches != set()]
# [___CELL_SEPARATOR___]
rap_data.head(n=20)
# [___CELL_SEPARATOR___]
from collections import Counter
rap_onegrams = Counter()

for lyrics in df_data["lyrics"]:
    rap_onegrams.update(lyrics.split())
# [___CELL_SEPARATOR___]
rap_onegrams_df = pd.DataFrame.from_dict(rap_onegrams, orient='index').reset_index()
rap_onegrams_df.columns = ["word","count"]
# [___CELL_SEPARATOR___]
rap_onegrams_df.sort_values(by="count").tail(n=20)
# [___CELL_SEPARATOR___]
raptwl_df = pd.merge(twl_wordlist, rap_onegrams_df, on="word")
raptwl_df.head()

all_bigrapwords = set(raptwl_df[raptwl_df["count"] < 5]["word"].values)
len(all_bigrapwords)
# [___CELL_SEPARATOR___]
df_data["rap_matches"] = []
for lyrics in df_data["lyrics"]:
    found_words = set(lyrics.split()) & all_bigrapwords
    df_data["rap_matches"].append(found_words)
# [___CELL_SEPARATOR___]
rap_data = pd.DataFrame(df_data)
rap_data = rap_data[rap_data.rap_matches != set()]
rap_data
# [___CELL_SEPARATOR___]
#rap_data[rap_data["artist"].str.startswith("Kanye")]
#rap_data[rap_data["artist"].str.startswith("Wu-Tang") & rap_data["filename"].str.contains("enter")]
rap_data[rap_data["artist"].str.startswith("Nas") & rap_data["filename"].str.contains("illmatic")]
# [___CELL_SEPARATOR___]
# Search and replace 23375 to 1173 in the lyrics subset on Github!
print(rap_data.loc[23375]["matches"])
print(rap_data.loc[23375]["rap_matches"])
# [___CELL_SEPARATOR___]
word = "trifle"
# [___CELL_SEPARATOR___]
import spotipy
sp = spotipy.Spotify()
    
def test_track_search(sp, search_str):
    results = sp.search(q=search_str, type='track', limit=1)
    if len(results['tracks']['items']) > 0:
        print(results['tracks']['items'][0]['artists'][0]['name']," - ",
              results['tracks']['items'][0]['name'],
              results['tracks']['items'][0]['popularity'],)
    else:
        print("")

test_track_search(sp, 'Nas Memory Lane')
# [___CELL_SEPARATOR___]
# Activate Google Data API
DEVELOPER_KEY = ""

from apiclient.discovery import build
from datetime import datetime

def youtube_search(q):
  youtube = build("youtube", "v3", developerKey=DEVELOPER_KEY)

  search_response = youtube.search().list(
    q=q, type="video",
    part="id,snippet", maxResults=1
  ).execute()

  for search_result in  search_response.get("items", []):
      if search_result is not None:
          video_id = search_result["id"]["videoId"]
          date_posted = search_result["snippet"]["publishedAt"]
          results = youtube.videos().list(
                    part="statistics", id=video_id
                    ).execute()
  return (video_id,
          float(results["items"][0]["statistics"]["viewCount"]),
          float((datetime.now()-datetime.strptime(date_posted, "%Y-%m-%dT%H:%M:%S.000Z")).days))
# [___CELL_SEPARATOR___]
youtube_data = youtube_search("Nas Memory Lane")
print(youtube_data)
# [___CELL_SEPARATOR___]
from IPython.display import HTML
HTML('<iframe width="560" height="315" src="https://www.youtube.com/embed/JXBFG2vsyCM?rel=0&amp;controls=0&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')
# [___CELL_SEPARATOR___]
from wiktionaryparser import WiktionaryParser

def get_definition(word):
    parser = WiktionaryParser()
    worddef = parser.fetch(word)
    
    possible_defs = []
    for entymologies in worddef:
        for dd in entymologies["definitions"]:
            all_defs = re.sub(word+"\s*\u200e","",
                                  dd['text']).strip().split("\n")
            all_gdefs = [d for d in all_defs if re.match("^\(.*\)$",d) == None]
            possible_defs.append((dd['partOfSpeech'],
                                  all_gdefs))
    return possible_defs
# [___CELL_SEPARATOR___]
get_definition("racket")
# [___CELL_SEPARATOR___]
get_definition("trifle")
# [___CELL_SEPARATOR___]
lyrics = rap_data.loc[23375]["lyrics"]
rap_sentence = [line for line in lyrics.split("\n") if word in line][0]
print(rap_sentence)
# [___CELL_SEPARATOR___]
import nltk
split_sentence = nltk.word_tokenize(rap_sentence)
tagged_sentence = nltk.pos_tag(split_sentence,tagset="universal")
print(tagged_sentence)
# [___CELL_SEPARATOR___]
rap_sentence = "word to christ, a disciple of streets, I trifle on beats"
split_sentence = nltk.word_tokenize(rap_sentence)
tagged_sentence = nltk.pos_tag(split_sentence,tagset="universal")
print(tagged_sentence)
# [___CELL_SEPARATOR___]
def get_definition_with_sentence(word, rap_sentence):
    split_sentence = nltk.word_tokenize(rap_sentence)
    tagged_sentence = nltk.pos_tag(split_sentence,
                                      tagset="universal")
    
    index_of_word = split_sentence.index(word)
    pos_of_word = tagged_sentence[index_of_word][1].lower()
    
    parser = WiktionaryParser()
    worddef = parser.fetch(word)

    possible_defs = []
    for entymologies in worddef:
        for dd in entymologies["definitions"]:
            part_of_speech = dd['partOfSpeech']
            all_defs = re.sub(word+"\s*\u200e","",
                                  dd['text']).strip().split("\n")
            all_gdefs = [d for d in all_defs if re.match("^\(.*\)$",d) == None]
            
            # Take the first definition that matches part of speech
            if part_of_speech == pos_of_word:
                return (dd['partOfSpeech'], all_gdefs)

    return ("N/A","N/A")
# [___CELL_SEPARATOR___]
get_definition_with_sentence("trifle", rap_sentence)
# [___CELL_SEPARATOR___]
def get_definition_with_lyrics(word, lyrics):
    rap_sentence = [line for line in lyrics.split("\n") if word in line][0]
    return get_definition_with_sentence(word, rap_sentence)
# [___CELL_SEPARATOR___]
lyrics_split=["Twinkle, twinkle, little star",
"How I wonder what you are",
"Up above the world so high",
"Like a diamond in the sky"]
# [___CELL_SEPARATOR___]
def get_rhymegroup(target_word, lyrics_split):
    group_index_of_target = -1
    
    for groupid, line in enumerate(lyrics_split):
        if target_word in line:
            group_index_of_target = groupid

    if group_index_of_target > 0 and group_index_of_target < len(lyrics_split)-1:
        return lyrics_split[group_index_of_target-1:group_index_of_target+2]
    else:
        return "N/A"
# [___CELL_SEPARATOR___]
get_rhymegroup("high", lyrics_split)
# [___CELL_SEPARATOR___]
import pronouncing
# [___CELL_SEPARATOR___]
pronouncing.rhymes("star")[0:20]
# [___CELL_SEPARATOR___]
print(pronouncing.phones_for_word("high"))
print(pronouncing.phones_for_word("sky"))
# [___CELL_SEPARATOR___]
print(pronouncing.phones_for_word("orange"))
print(pronouncing.phones_for_word("hinge"))
# [___CELL_SEPARATOR___]
def rhymes_per_line(lyrics_split):
    rhymes = []
    for line in lyrics_split:
        words = line.strip().split()
        last_word = words[-1].strip('.,?!;:')
        last_word_p = pronouncing.phones_for_word(last_word)
        if len(last_word_p) > 0:
            rhymes.append((pronouncing.rhyming_part(last_word_p[0]),line))
    return rhymes
# [___CELL_SEPARATOR___]
rhymes_per_line(lyrics_split)
# [___CELL_SEPARATOR___]
lyrics_split = [line for line in df_data["lyrics"][23375].split("\n") if len(line) > 0]
print(lyrics_split[10:-30])
# [___CELL_SEPARATOR___]
target_word = "trifle"
# [___CELL_SEPARATOR___]
def get_rhymes(lyrics_split):
    lines_with_rhyming_parts = list()
    for line in lyrics_split:
        words = line.split()
        last_word = words[-1].strip('.,?!;:') # .strip() to remove any punctuation
        last_word_p = pronouncing.phones_for_word(last_word)
        
        if len(last_word_p) > 0:
            if len(last_word_p) > 1:
                last_word_p = [last_word_p[0],]
                
            for phones in last_word_p:
                rhyming_part = pronouncing.rhyming_part(phones)
                line_with_part = [rhyming_part[:2], line]
                #print(line_with_part)
                lines_with_rhyming_parts.append(line_with_part)
        else:
            line_with_part = ["N/A", line]
            lines_with_rhyming_parts.append(line_with_part)
            
    return lines_with_rhyming_parts
# [___CELL_SEPARATOR___]
rhyme_lines = get_rhymes(lyrics_split)
# [___CELL_SEPARATOR___]
rhyme_lines[40:60]
# [___CELL_SEPARATOR___]
import itertools
import operator

grouped_rhymes = []
for key,group in itertools.groupby(rhyme_lines, operator.itemgetter(0)):
    merged_group = [g[1] for g in group]
    grouped_rhymes.append(list(merged_group))
# [___CELL_SEPARATOR___]
grouped_rhymes[15:35]
# [___CELL_SEPARATOR___]
def rhymegroup(target_word, grouped_rhymes):
    group_index_of_target = -1
    
    for groupid, rhymes in enumerate(grouped_rhymes):
        #print(groupid, rhymes)
        for line in rhymes:
            if target_word in line:
                group_index_of_target = groupid
    
    if group_index_of_target != -1:
        return grouped_rhymes[group_index_of_target]
    else:
        return "N/A"
# [___CELL_SEPARATOR___]
rhymegroup("trifle", grouped_rhymes)
# [___CELL_SEPARATOR___]
def rhymegroup_from_word(word, lyrics):
    lyrics_split = [line for line in lyrics.split("\n") if len(line) > 0]
    grouped_rhymes = []
    for key,group in itertools.groupby(rhyme_lines, operator.itemgetter(0)):
        merged_group = [g[1] for g in group]
        grouped_rhymes.append(list(merged_group))
    return rhymegroup(word, grouped_rhymes)
# [___CELL_SEPARATOR___]
# Get API key, https://www.tumblr.com/docs/en/api/v2 and do OATHv1
tumblr_client = ''
tumblr_secret = ''
access_key    = ''
access_secret = ''

import pytumblr

user = pytumblr.TumblrRestClient(
    tumblr_client, tumblr_secret,
    access_key, access_secret)
# [___CELL_SEPARATOR___]
def post_template(word, part_of_speech, worddef, lyrics, artist, song, youtube=None):
    
    post = '''<p><a href="http://en.wiktionary.org/wiki/{}">{}</a> '''.format(word, word)
    post += '''- {} -\xa0 {}</p>'''.format(part_of_speech, worddef)

    post += "<p>"
    for line in lyrics:
        if word in line:
            post += line.replace(word,"<b>"+word+"</b>")+"<br />"
        else:
            post += line+"<br />"
    post += "</p>"
    
    if youtube is not None:
        post += '''<p>-{} on\xa0“'''.format(artist)
        post += '''<a href="https://www.youtube.com/watch?v={}">{}</a>”</p>'''.format(youtube,
                                                                                      song)
    else:
        post += '''<p>-{} on\xa0“{}”</p>'''.format(artist,song)        
    
    return post
# [___CELL_SEPARATOR___]
print(rap_data.loc[23375])
# [___CELL_SEPARATOR___]
word = "trifle"
artist = rap_data.loc[23375].artist
song = rap_data.loc[23375].song

part_of_speech, worddef = get_definition_with_lyrics(word,
                                                       rap_data.loc[23375].lyrics)
lyrics = rhymegroup_from_word(word, rap_data.loc[23375].lyrics)
youtube = youtube_search(artist + " " + song)[0]

slug = word+"-"+part_of_speech+"-"+artist

#print(word, part_of_speech, worddef[0], lyrics, artist, song, youtube)
# [___CELL_SEPARATOR___]
post_body = post_template(word, part_of_speech, worddef[0], lyrics, artist, song, youtube)
# [___CELL_SEPARATOR___]
user.create_text("rapwords",
                 format="html",
                 state="published",
                 slug=slug,
                 body=post_body,
                 tags=[part_of_speech],)