# Quick utility to embed the videos below
from IPython.display import YouTubeVideo
def embed_video(index, playlist='PLYCpMb24GpOC704uO9svUrihl-HY1tTJJ'):
    return YouTubeVideo('', index=index - 1, list=playlist, width=600, height=350)
# [___CELL_SEPARATOR___]
embed_video(1)
# [___CELL_SEPARATOR___]
embed_video(2)
# [___CELL_SEPARATOR___]
embed_video(3)
# [___CELL_SEPARATOR___]
embed_video(4)
# [___CELL_SEPARATOR___]
embed_video(5)
# [___CELL_SEPARATOR___]
embed_video(6)
# [___CELL_SEPARATOR___]
embed_video(7)
# [___CELL_SEPARATOR___]
embed_video(8)
# [___CELL_SEPARATOR___]
embed_video(9)
# [___CELL_SEPARATOR___]
embed_video(10)
# [___CELL_SEPARATOR___]
embed_video(11)