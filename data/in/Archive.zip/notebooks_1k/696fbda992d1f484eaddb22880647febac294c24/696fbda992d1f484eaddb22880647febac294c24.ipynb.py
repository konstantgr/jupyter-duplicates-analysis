%matplotlib inline
%reload_ext autoreload
%autoreload 2

import numpy as np
import pandas as pd
from pathlib import Path
import json
import matplotlib.pyplot as plt
import seaborn as sns
# from geopy.distance import distance
# [___CELL_SEPARATOR___]
PATH = Path('data')
list(PATH.iterdir())

from IPython.core.interactiveshell import InteractiveShell
InteractiveShell.ast_node_interactivity = "all"

# from mpl_toolkits.basemap import Basemap
import folium
from folium.plugins import MarkerCluster,FastMarkerCluster
# [___CELL_SEPARATOR___]
df = pd.read_feather(PATH/'houston_ready.feather')
# [___CELL_SEPARATOR___]
# # recalculate miles differences
# def haversine_array(lat1, lng1, lat2, lng2):
#     lat1, lng1, lat2, lng2 = map(np.radians, (lat1, lng1, lat2, lng2))
#     AVG_EARTH_RADIUS = 6371  # in km
#     lat = lat2 - lat1
#     lng = lng2 - lng1
#     d = np.sin(lat * 0.5) ** 2 + np.cos(lat1) * np.cos(lat2) * np.sin(lng * 0.5) ** 2
#     h = 2 * AVG_EARTH_RADIUS * np.arcsin(np.sqrt(d))
#     return h

# lat2 = df.latitude.values.tolist()
# long2 = df.longitude.values.tolist()

# lat1 = df.latitude.shift().values.tolist()
# lat1[0] = lat2[0]
# long1 = df.longitude.shift().values.tolist()
# long1[0] = long2[0]

# km_diff = haversine_array(lat1,long1,lat2,long2) 
# df['mile_diff'] = km_diff * 0.621371 # to miles
# [___CELL_SEPARATOR___]
# df[df.mile_diff>12].groupby(['year','month','day']).mile_diff.mean()

# df['plane'] = df.mile_diff>12

# # df.to_feather(PATH/'houston_ready.feather')

# df_ground = df[~df.plane].copy().reset_index(drop=True)
# [___CELL_SEPARATOR___]
from sklearn.cluster import MeanShift, estimate_bandwidth
rs=42
# [___CELL_SEPARATOR___]
bw = estimate_bandwidth(df[['latitude','longitude']],quantile=0.3,
                        n_samples=20000,
                        random_state=rs,n_jobs=-1)
# [___CELL_SEPARATOR___]
ms = MeanShift(bandwidth=bw, bin_seeding=True)
cluster = ms.fit_predict(df[['latitude','longitude']])
# [___CELL_SEPARATOR___]
df['cluster'] = cluster
# [___CELL_SEPARATOR___]
fig,ax = plt.subplots(figsize=(20,10))
_=ax.scatter(df.longitude,df.latitude,c=df.cluster,cmap='tab20',s=3,alpha=1)

_=ax.set_ylabel('latitude')
_=ax.set_xlabel('longitude')
# [___CELL_SEPARATOR___]
temp=df.groupby('cluster').size()
temp
# [___CELL_SEPARATOR___]
fig,ax = plt.subplots(figsize=(20,10))
_=ax.scatter(df[df.cluster==temp.idxmax()].longitude,
                 df[df.cluster==temp.idxmax()].latitude,cmap='tab10',s=3,alpha=0.7)
_=ax.set_ylabel('latitude')
_=ax.set_xlabel('longitude')
# [___CELL_SEPARATOR___]
df_h = df[(df.cluster==0)].reset_index(drop=True)
df_h.shape
# [___CELL_SEPARATOR___]
bw = estimate_bandwidth(df_h[['latitude','longitude']],quantile=0.1,
                        n_samples=30000,
                        random_state=rs,n_jobs=-1)
# [___CELL_SEPARATOR___]
ms = MeanShift(bandwidth=bw, bin_seeding=True)
df_h['cluster'] = ms.fit_predict(df_h[['latitude','longitude']])
# [___CELL_SEPARATOR___]
temp=df_h.groupby('cluster').size()
temp
# [___CELL_SEPARATOR___]
#0.1
fig,ax = plt.subplots(figsize=(20,10))
_=ax.scatter(df_h.longitude,df_h.latitude,c=df_h.cluster,cmap='tab20',s=1,alpha=1)

_=ax.set_ylabel('latitude')
_=ax.set_xlabel('longitude')
# [___CELL_SEPARATOR___]
temp = df_h.groupby('cluster').size()

temp.nlargest(n=6)

idx_maxes=temp.nlargest(n=6).index.values
# [___CELL_SEPARATOR___]
fig,ax = plt.subplots(figsize=(20,10))
for i,i_max in enumerate(idx_maxes):    
    _=ax.scatter(df_h[df_h.cluster==i_max].longitude,
                 df_h[df_h.cluster==i_max].latitude,cmap='tab20',s=3,alpha=0.7,label=f'{i+1}')
_=ax.set_ylabel('latitude')
_=ax.set_xlabel('longitude')
_=ax.legend(markerscale=5)
# [___CELL_SEPARATOR___]
df_lrg_cluster = df_h[df_h.cluster.isin(np.delete(idx_maxes,1))].copy().reset_index(drop=True)
df_lrg_cluster.shape
# [___CELL_SEPARATOR___]
# weekend
df_lrg_cluster['is_weekend'] = ~df_lrg_cluster.day_of_week.isin(np.arange(0,5))
# [___CELL_SEPARATOR___]
# weekday vs weekend

wd = df_lrg_cluster[~df_lrg_cluster.is_weekend]
we = df_lrg_cluster[df_lrg_cluster.is_weekend]
fig,axes = plt.subplots(ncols=2,figsize=(20,10),sharex=True,sharey=True)
_=axes[0].scatter(wd.longitude,
                 wd.latitude,c=wd.cluster,cmap='tab20',s=3,alpha=0.4,label='Weekday')
_=axes[1].scatter(we.longitude,
                 we.latitude,c=we.cluster,cmap='tab20',s=3,alpha=0.4,label='Weekend')
_=axes[0].set_ylabel('latitude')
_=axes[0].set_xlabel('longitude')
_=axes[0].legend()
_=axes[1].set_ylabel('latitude')
_=axes[1].set_xlabel('longitude')
_=axes[1].legend()
# [___CELL_SEPARATOR___]
# day-night
df_lrg_cluster['is_night'] = ~df_lrg_cluster.hour.isin(np.arange(9,20)) #day is from 9 am to 7:59 pm
# [___CELL_SEPARATOR___]
# weekday day vs night
wd_day = df_lrg_cluster[(~df_lrg_cluster.is_weekend) & (~df_lrg_cluster.is_night)]
wd_night = df_lrg_cluster[(~df_lrg_cluster.is_weekend) & (df_lrg_cluster.is_night)]

fig,axes = plt.subplots(ncols=2,figsize=(20,10),sharex=True,sharey=True)
_=axes[0].scatter(wd_day.longitude,
                 wd_day.latitude,c=wd_day.cluster,cmap='tab20',s=3,alpha=0.4,label='Weekday-Day')
_=axes[1].scatter(wd_night.longitude,
                 wd_night.latitude,c=wd_night.cluster,cmap='tab20',s=3,alpha=0.4,label='Weekday-Night')
_=axes[0].set_ylabel('latitude')
_=axes[0].set_xlabel('longitude')
_=axes[0].legend()
_=axes[1].set_ylabel('latitude')
_=axes[1].set_xlabel('longitude')
_=axes[1].legend()
# [___CELL_SEPARATOR___]
# weekend day vs night
we_day = df_lrg_cluster[(df_lrg_cluster.is_weekend) & (~df_lrg_cluster.is_night)]
we_night = df_lrg_cluster[(df_lrg_cluster.is_weekend) & (df_lrg_cluster.is_night)]

fig,axes = plt.subplots(ncols=2,figsize=(20,10),sharex=True,sharey=True)
_=axes[0].scatter(we_day.longitude,
                 we_day.latitude,c=we_day.cluster,cmap='tab20',s=3,alpha=0.4,label='Weekend-Day')
_=axes[1].scatter(we_night.longitude,
                 we_night.latitude,c=we_night.cluster,cmap='tab20',s=3,alpha=0.4,label='Weekend-Night')
_=axes[0].set_ylabel('latitude')
_=axes[0].set_xlabel('longitude')
_=axes[0].legend()
_=axes[1].set_ylabel('latitude')
_=axes[1].set_xlabel('longitude')
_=axes[1].legend()