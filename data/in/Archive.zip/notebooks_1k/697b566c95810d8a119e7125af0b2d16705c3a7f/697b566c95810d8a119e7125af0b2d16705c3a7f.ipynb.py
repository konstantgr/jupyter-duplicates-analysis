from IPython.display import Image
# [___CELL_SEPARATOR___]
from google.cloud import bigquery
%load_ext google.cloud.bigquery
# [___CELL_SEPARATOR___]
%%bigquery popularspots

#standardSql
SELECT
  group_trips / (single_trips + group_trips) AS percent_groups,
  single_trips + group_trips AS total_trips,
  q.end_station_id AS end_station_id,
  stations.name AS name,
  stations.latitude AS latitude,
  stations.longitude AS longitude
FROM (
  SELECT
    COUNTIF(group_size = 1) AS single_trips,
    COUNTIF(group_size != 1) AS group_trips,
    end_station_id
  FROM (
    SELECT
      ROUND(UNIX_SECONDS(starttime) / 120) AS start,
      -- round to nearest 2 minutes
      ROUND(UNIX_SECONDS(stoptime) / 120) AS stop,
      -- round to nearest 2 minutes
      start_station_id,
      end_station_id,
      COUNT(*) AS group_size
    FROM
      `bigquery-public-data.new_york.citibike_trips`
    GROUP BY
      start,
      stop,
      start_station_id,
      end_station_id )
  GROUP BY
    end_station_id ) q
LEFT JOIN
  `bigquery-public-data.new_york.citibike_stations` AS stations
ON
  q.end_station_id = stations.station_id
WHERE
  name is not NULL
ORDER BY
  percent_groups DESC
# [___CELL_SEPARATOR___]
import os
from urllib.parse import urlencode

def map_with_markers(center, markers):
    markers = [f"color:{marker['color']}|{marker['latitude']},{marker['longitude']}" for marker in markers]
    params = {
        'key': os.environ.get('GOOGLE_API_KEY'),
        'size': '1200x1200',
        'center': center,
        'zoom': 12,
        'markers': markers
    }
    base_url = 'https://maps.googleapis.com/maps/api/staticmap'
    url = f"{base_url}?{urlencode(params, doseq=True)}"
    return Image(url=url, format='jpg')

import colorsys

def color_for_magnitude(mag, hue):
    r, g, b = map(lambda x: int(x * 255), colorsys.hsv_to_rgb(hue, 1.0-mag, 1.0))
    return f'0x{r:02x}{g:02x}{b:02x}'
# [___CELL_SEPARATOR___]
top_15 = popularspots.to_dict('records')[:15]
markers = [
    {'latitude': location['latitude'] , 'longitude': location['longitude'], 'color': color_for_magnitude(rank/15, 0.6)}
    for rank, location in enumerate(top_15, 1)]

map_with_markers('', markers)
# [___CELL_SEPARATOR___]
bottom_15 = popularspots.to_dict('records')[-15:]
markers = [
    {'latitude': location['latitude'] , 'longitude': location['longitude'], 'color': color_for_magnitude(rank/15, 0.0)}
    for rank, location in enumerate(bottom_15, 1)]

map_with_markers('', markers)
# [___CELL_SEPARATOR___]
