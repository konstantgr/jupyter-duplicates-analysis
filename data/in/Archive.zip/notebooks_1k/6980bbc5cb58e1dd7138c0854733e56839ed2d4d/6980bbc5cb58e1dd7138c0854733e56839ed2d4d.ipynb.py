import datamine.io as dm
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib import style
style.use('fivethirtyeight')
%matplotlib inline
# [___CELL_SEPARATOR___]
#Establish an object to interact with CME Datamine.
#Supply Credentials per Documentation: http://www.cmegroup.com/market-data/datamine-api.html
myDatamine = dm.DatamineCon(username='', password='^', path='./data/')
# [___CELL_SEPARATOR___]
#Get the first 1,000 items for Crytocurrencies
myDatamine.get_catalog(dataset='CRYPTOCURRENCY', limit=1000)
# [___CELL_SEPARATOR___]
# Review one of the data catalog items as supplied in dict format.  
myDatamine.data_catalog.popitem()
# [___CELL_SEPARATOR___]
# We can view the data catalog easier in a Pandas Dataframe
dataCatalogDF = pd.DataFrame.from_dict(myDatamine.data_catalog,).T
dataCatalogDF.head()
# [___CELL_SEPARATOR___]
# We can see how many data products we can access
dataCatalogDF.dataset.value_counts()
# [___CELL_SEPARATOR___]
# Load the bitcoin data from datamine cloud and structure into dataframe of myDatamine.bitcoin_DF.  
# Will return 0 if successful
myDatamine.crypto_load()
# [___CELL_SEPARATOR___]
#look at the data frame
myDatamine.crypto_DF.head()
# [___CELL_SEPARATOR___]
#There are many values in the file; 
#We are intesested in every second value as 'BRTI' and one daily index that is daily as 'BRR'
myDatamine.crypto_DF.symbol.value_counts()
# [___CELL_SEPARATOR___]
indexValue = myDatamine.crypto_DF.loc[myDatamine.crypto_DF['symbol'] =='BRTI','mdEntryPx'].plot(figsize=[15,5]);
plt.title('Historical Bitcoin Intraday Reference Rate')
plt.xlabel('Date')
plt.ylabel('USD/BTC')
plt.style.use('fivethirtyeight')
plt.savefig('./images/BitcoinRTIndexValue.png')
plt.show()
# [___CELL_SEPARATOR___]
myDatamine.crypto_DF.loc[myDatamine.crypto_DF['symbol'] =='BRR','mdEntryPx'].plot(figsize=[15,5])
plt.title('Historical Bitcoin Daily Value')
plt.xlabel('Date')
plt.ylabel('USD/BTC')
plt.style.use('fivethirtyeight')
plt.savefig('./images/BitcoinEndofDayValue.png')
plt.show()
# [___CELL_SEPARATOR___]
#update my catalog with Tick Data
myDatamine.get_catalog(dataset='TICK', limit=10)
# [___CELL_SEPARATOR___]
#download and load my data
#Tick Data can be a lot of files and can take time to load into a Pandas Dataframe...
myDatamine.time_sales_load()
# [___CELL_SEPARATOR___]
ts = myDatamine.time_sales_DF
ts.head()
# [___CELL_SEPARATOR___]
#Review the Symbols we have loaded.  ED= Eurodollars
#See https://www.cmegroup.com/trading/products/#pageNumber=1&sortField=oi&sortAsc=false for product code and information
ts.ticker_symbol.value_counts()
# [___CELL_SEPARATOR___]
#Plot Histogram of lot size of a given trade for Euro Dollars Oil
ts.loc[ts.ticker_symbol =='ED','trade_quantity'].hist(bins=20).set_yscale('log')
# [___CELL_SEPARATOR___]
