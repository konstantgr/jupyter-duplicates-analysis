%matplotlib inline

from movielens import MovieLens
from hybridLinUCB import HybridLinUCB
import numpy as np
import matplotlib.pyplot as plt
# [___CELL_SEPARATOR___]
from matplotlib.pylab import rcParams
rcParams['figure.figsize'] = 7, 5
# [___CELL_SEPARATOR___]
ucb = HybridLinUCB(alpha=0.1, dataset=None, max_items=100, allow_selecting_known_arms=True)
# [___CELL_SEPARATOR___]
print('R:\n', ucb.dataset.R)
# [___CELL_SEPARATOR___]
avg_reward = ucb.run(num_epochs=50)
# [___CELL_SEPARATOR___]
plt.plot(range(len(avg_reward)), avg_reward)
plt.ylabel('average reward in epoch')
plt.ylim(0.2, 1)
plt.xlabel('epoch (1 epoch = recommended to all users)')
plt.title('HybridLinUCB: Fixed rewards')
# [___CELL_SEPARATOR___]
ucb_stochastic = HybridLinUCB(alpha=0.1, dataset=None, max_items=100, 
                        allow_selecting_known_arms=True, fixed_rewards=False, prob_reward_p=0.9)
# [___CELL_SEPARATOR___]
print('R:\n', ucb_stochastic.dataset.R)
# [___CELL_SEPARATOR___]
avg_reward_stochastic = ucb_stochastic.run(num_epochs=50)
# [___CELL_SEPARATOR___]
plt.plot(range(len(avg_reward_stochastic)), avg_reward_stochastic)
plt.ylabel('average reward in epoch')
plt.ylim(0.2, 1)
plt.xlabel('epoch (1 epoch = recommended to all users)')
plt.title('HybridLinUCB: Stochastic rewards with p=0.9')
# [___CELL_SEPARATOR___]
ucb_stochastic_100 = HybridLinUCB(alpha=0.1, dataset=None, max_items=100, 
                        allow_selecting_known_arms=True, fixed_rewards=False, prob_reward_p=0.9)
# [___CELL_SEPARATOR___]
avg_reward_stochastic_100 = ucb_stochastic_100.run(num_epochs=100)
# [___CELL_SEPARATOR___]
rcParams['figure.figsize'] = 14, 5
plt.plot(range(len(avg_reward_stochastic_100)), avg_reward_stochastic_100)
plt.ylabel('average reward in epoch')
plt.ylim(0.2, 1)
plt.xlabel('epoch (1 epoch = recommended to all users)')
plt.title('HybridLinUCB: Stochastic rewards with p=0.9')
# [___CELL_SEPARATOR___]
