from clx.workflow.splunk_alert_workflow import SplunkAlertWorkflow
# [___CELL_SEPARATOR___]
source = {
    "type": "kafka",
    "kafka_brokers": "kafka:9092",
    "group_id": "gtcdc2",
    "batch_size": 24,
    "consumer_kafka_topics": ["gtcdemo_raw"],
    "time_window": 5,
}
dest = {
    "type": "kafka",
    "kafka_brokers": "kafka:9092",
    "batch_size": 24,
    "publisher_kafka_topic": "gtcdemo_enriched",
    "output_delimiter": ",",
}
# [___CELL_SEPARATOR___]
workflow = SplunkAlertWorkflow(name="splunk_workflow", source=source, destination=dest,
                               threshold=2.0, raw_data_col_name="Raw")
workflow.run_workflow()
# [___CELL_SEPARATOR___]
