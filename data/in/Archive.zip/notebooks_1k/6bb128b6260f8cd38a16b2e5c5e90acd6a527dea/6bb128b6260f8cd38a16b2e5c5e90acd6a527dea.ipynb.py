# Import module support
import support

# Now you can call defined function that module as follows
support.print_func("drk")
# [___CELL_SEPARATOR___]
# Now import your Phone Package.
import Phone as p
# [___CELL_SEPARATOR___]
p.Pots()
# [___CELL_SEPARATOR___]
p.Isdn()
# [___CELL_SEPARATOR___]
p.G3()
# [___CELL_SEPARATOR___]
