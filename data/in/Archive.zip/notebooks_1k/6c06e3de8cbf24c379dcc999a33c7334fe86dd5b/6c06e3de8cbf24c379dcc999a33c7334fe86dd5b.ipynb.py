!pip3 install torch torchvision
# [___CELL_SEPARATOR___]
## The usual imports
import torch
import torch.nn as nn

## print out the pytorch version used
print(torch.__version__)
# [___CELL_SEPARATOR___]
## our data in tensor form
x = torch.tensor([[-1.0],  [0.0], [1.0], [2.0], [3.0], [4.0]], dtype=torch.float)
y = torch.tensor([[-3.0], [-1.0], [1.0], [3.0], [5.0], [7.0]], dtype=torch.float)
# [___CELL_SEPARATOR___]
## print size of the input tensor
x.size()
# [___CELL_SEPARATOR___]
## Neural network with 1 hidden layer
layer1 = nn.Linear(1,1, bias=False)
model = nn.Sequential(layer1)
# [___CELL_SEPARATOR___]
## loss function
criterion = nn.MSELoss()

## optimizer algorithm
optimizer = torch.optim.SGD(model.parameters(), lr=0.01)
# [___CELL_SEPARATOR___]
## training
for i in range(150):
    model = model.train()

    ## forward
    output = model(x)
    loss = criterion(output, y)
    optimizer.zero_grad()

    ## backward + update model params 
    loss.backward()
    optimizer.step()

    model.eval()
    print('Epoch: %d | Loss: %.4f' %(i, loss.detach().item()))
# [___CELL_SEPARATOR___]
## test the model
sample = torch.tensor([10.0], dtype=torch.float)
predicted = model(sample)
print(predicted.detach().item())