from biorefineries.lipidcane import system
from biorefineries.lipidcane import set_lipid_fraction
from biosteam.evaluation import Model, Metric
from biosteam.evaluation.evaluation_tools import triang # Creates triangular distribution at +-10%
from biosteam import find, PowerUtility

flowsheet = find.flowsheet['lipidcane']
biorefinery = find('lipidcane_sys')
tea = biorefinery.TEA
ethanol = flowsheet('ethanol')
lipid_cane = flowsheet('lipid_cane')
ethanol_density = 2.9866 # kg/gallon
gasoline_energy = 33.41 # kWhr/gallon
ethanol_per_GGE = 1.5

# %% Create metrics

get_MFSP = lambda: tea.solve_price(ethanol) * ethanol_density / ethanol_per_GGE # USD / GGE
get_GGE_flow = lambda: ethanol.massnet / ethanol_per_GGE # kg / hr
get_excess_power = lambda: sum([i._power_utility.rate for i in biorefinery.units
                                if i._has_power_utility]) # kW
get_excess_power_per_GGE = lambda: get_excess_power() / get_GGE_flow() # kWhr/GGE
get_feedstock_price = lambda: tea.solve_price(lipid_cane) # USD / kg

metrics = (Metric('MFSP', get_MFSP, 'USD/GGE'),
           Metric('Net electricity', get_excess_power_per_GGE, 'kWhr/GGE'),
           Metric('Feedstock price', get_feedstock_price, 'USD/kr'))

# %% Create model and add most sensitive parameters:
# Ethanol price, Lipid cane price, Electricity price, Fermentation efficiency, and Boiler efficiency

model = Model(biorefinery, metrics)
param = model.parameter

# Ethanol price
@param(element=ethanol, units='USD/kg',
       distribution=triang(ethanol.price))
def set_ethanol_price(price):
    ethanol.price = price
    
# Lipid cane price
@param(element=lipid_cane, units='USD/kg',
       distribution=triang(lipid_cane.price))
def set_lipid_cane_price(price):
    lipid_cane.price = price

# Electricity price
@param(element=PowerUtility, units='USD/kWhr',
       distribution=triang(PowerUtility.price))
def set_electricity_price(price):
    PowerUtility.price = price

# Fermentation efficiency
fermentation = flowsheet('R301')
@param(element=fermentation,
       distribution=triang(fermentation.efficiency))
def set_fermentation_efficiency(efficiency):
    fermentation.efficiency= efficiency
    
# Boiler efficiency
BT = flowsheet('BT')
@param(element=BT,
       distribution=triang(BT.boiler_efficiency))
def set_boiler_efficiency(boiler_efficiency):
    BT.boiler_efficiency = boiler_efficiency

# Load samples
N_samples = 1000
rule = 'L'
samples = model.sample(N_samples, rule)
model.load_samples(samples)
    
# Function that returns Monte Carlo results
def uncertainty_results_at_lipid_fraction(lipid_fraction):
    set_lipid_fraction(lipid_fraction)
    model.evaluate()
    return model.table.copy()

# [___CELL_SEPARATOR___]
table = uncertainty_results_at_lipid_fraction(0.02)
table
# [___CELL_SEPARATOR___]
model.spearman()
# [___CELL_SEPARATOR___]
def calculate_feedstock_price(IRR, ethanol_price_per_gallon):
    tea.IRR = IRR
    ethanol.price = ethanol_price_per_gallon * ethanol_density
    return tea.solve_price(ethanol) # USD/kg
# [___CELL_SEPARATOR___]
calculate_feedstock_price(0.15, 2.15)
# [___CELL_SEPARATOR___]
# %% Create model and all default parameters (plus a few more)

model_extended = Model(biorefinery, metrics)
param = model_extended.parameter
model_extended.load_default_parameters(lipid_cane) # THIS LOADS ALL 90 OR SO PARAMETERS

# Fermentation efficiency
fermentation = flowsheet('R301')
@param(element=fermentation,
       distribution=triang(fermentation.efficiency))
def set_fermentation_efficiency(efficiency):
    fermentation.efficiency= efficiency
    
# Boiler efficiency
BT = flowsheet('BT')
@param(element=BT,
       distribution=triang(BT.boiler_efficiency))
def set_boiler_efficiency(boiler_efficiency):
    BT.boiler_efficiency = boiler_efficiency

# Load samples
N_samples = 1000
rule = 'L'
samples = model_extended.sample(N_samples, rule)
model_extended.load_samples(samples)
    
# Function that returns Monte Carlo results
def uncertainty_results_at_lipid_fraction_extended(lipid_fraction):
    set_lipid_fraction(lipid_fraction)
    model_extended.evaluate()
    return model.table.copy()

# [___CELL_SEPARATOR___]
table = uncertainty_results_at_lipid_fraction_extended(0.02)
table