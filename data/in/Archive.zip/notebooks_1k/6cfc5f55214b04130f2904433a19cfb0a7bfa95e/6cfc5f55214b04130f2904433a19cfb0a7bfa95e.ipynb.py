from distutils.version import LooseVersion as Version
import sys

OK = '\x1b[42m[ OK ]\x1b[0m'
FAIL = "\x1b[41m[FAIL]\x1b[0m"

try:
    import importlib
except ImportError:
    print(FAIL, "Python version 3.5 is required,"
                " but %s is installed." % sys.version)

    
def import_version(pkg, min_ver, fail_msg=""):
    mod = None
    try:
        mod = importlib.import_module(pkg)
        ver = mod.__version__
        if Version(ver) < min_ver:
            print(FAIL, "%s version %s or higher required, but %s installed."
                  % (lib, min_ver, ver))
        else:
            print(OK, '%s version %s' % (pkg, ver))
    except ImportError:
        print(FAIL, '%s not installed. %s' % (pkg, fail_msg))
    return mod


# first check the python version
print('Using python in', sys.prefix)
print(sys.version)
pyversion = Version(sys.version)
if pyversion < "3.5":
    print(FAIL, "Python version 3.5 is required,"
                " but %s is installed." % sys.version)
print()
requirements = {'numpy': "1.6.1", 'scipy': "0.9", 'matplotlib': "2.0",
                'sklearn': "0.22.1", 'pandas': "0.18",
                "imblearn": "0.1"}

# now the dependencies
for lib, required_version in list(requirements.items()):
    import_version(lib, required_version)
# [___CELL_SEPARATOR___]
