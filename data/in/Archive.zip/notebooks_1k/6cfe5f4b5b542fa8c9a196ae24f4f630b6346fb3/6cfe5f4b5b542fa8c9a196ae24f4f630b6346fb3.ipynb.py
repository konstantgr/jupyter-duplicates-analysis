from nltk.classify import NaiveBayesClassifier
from nltk.corpus import movie_reviews
import pickle
import nltk.classify.util
import sys
%matplotlib notebook
import matplotlib.pyplot as plt
import numpy as np


def clean(words):
    return dict([(word, True) for word in words])


negative_ids = movie_reviews.fileids('neg')
positive_ids = movie_reviews.fileids('pos')


negative_features = [(clean(movie_reviews.words(fileids=[f])), 'negative') for f in negative_ids]
positive_features = [(clean(movie_reviews.words(fileids=[f])), 'positive') for f in positive_ids]


negative_cutoff = int(len(negative_features) * 95/100)
positive_cutoff = int(len(positive_features) * 90/100)

train_features = negative_features[:negative_cutoff] + positive_features[:positive_cutoff]
test_features = negative_features[negative_cutoff:] + positive_features[positive_cutoff:]

print('Training on %d data, testing on %d data' % (len(train_features), len(test_features)))
classifier = NaiveBayesClassifier.train(train_features)
print('Training complete')
print('accuracy:', nltk.classify.util.accuracy(classifier, test_features)*100,'%')
classifier.show_most_informative_features()


f = open('model', 'wb')
pickle.dump(classifier, f)
f.close()
# [___CELL_SEPARATOR___]
f = open('model', 'rb')
classifier = pickle.load(f)
f.close()



sentence="i don't love you "
features = clean(sentence)
print(classifier.classify(features))

sentence="i love you sweetheart "
features = clean(sentence)
print(classifier.classify(features))


sentence="i am not saying that i don't love you"
features = clean(sentence)
print(classifier.classify(features))

sentence="This size of laptop is very bad"
features = clean(sentence)
print(classifier.classify(features))


# [___CELL_SEPARATOR___]
opinion={}

f=open('export_chat.txt','r')
pos,neg=0,0
for line in f:
    try:
        chat=line.split('-')[1].split(':')[1]
        name=line.split('-')[1].split(':')[0]
        if opinion.get(name,None) is None:
            opinion[name]=[0,0]
        res=classifier.classify(clean(chat))
        print(name,res,chat)
        if res=='positive':
            pos+=1
            opinion[name][0]+=1
        else:
            neg+=1
            opinion[name][1]+=1
    except:
        pass
print("positive: {} \nNegative: {}".format(pos,neg))
# [___CELL_SEPARATOR___]
neg=abs(neg)
labels = ['positive','negative']
sizes = [pos,neg]
fig1, ax1 = plt.subplots()
ax1.pie(sizes ,labels=labels, autopct='%1.1f%%')
plt.title('Whatsapp Sentiment Analysis')
plt.show()

# [___CELL_SEPARATOR___]
names,positive,negative=[],[],[]
for name in opinion:
    names.append(name)
    positive.append(opinion[name][0])
    negative.append(opinion[name][1])
    
# [___CELL_SEPARATOR___]
def autolabel(rects):
    for rect in rects:
        h = rect.get_height()
        ax.text(rect.get_x()+rect.get_width()/2., 1.05*h, '%d'%int(h),
                ha='center', va='bottom')

# [___CELL_SEPARATOR___]
ind = np.arange(len(names))
width=0.3
max_x=max(max(positive),max(negative))+2

fig = plt.figure()
ax = fig.add_subplot()

yvals = positive
rects1 = ax.bar(ind, yvals, width, color='g')
zvals = negative
rects2 = ax.bar(ind+width, zvals, width, color='r')

ax.set_xlabel('Names')
ax.set_ylabel('Sentiment')

ax.set_xticks(ind+width)
ax.set_yticks(np.arange(0,max_x,1))
ax.set_xticklabels( names )
ax.legend( (rects1[0], rects2[0]), ('positive', 'negative') )
ax.set_title('Whatsapp Chat Sentiment Analysis')


autolabel(rects1)
autolabel(rects2)

plt.show()
# [___CELL_SEPARATOR___]
