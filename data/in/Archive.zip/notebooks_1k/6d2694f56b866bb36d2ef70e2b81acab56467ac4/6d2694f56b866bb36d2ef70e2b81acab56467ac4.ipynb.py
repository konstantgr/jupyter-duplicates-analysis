%%capture
!pip install pandas_read_xml

# restart runtime after this install to allow Google colab to use the updated packages.
# [___CELL_SEPARATOR___]
import pandas_read_xml as pdx
# [___CELL_SEPARATOR___]
test_zip_path = 'https://bulkdata.uspto.gov/data/trademark/dailyxml/applications/apc200219.zip'
root_key_list = ['trademark-applications-daily', 'application-information', 'file-segments', 'action-keys']

df = pdx.read_xml(test_zip_path, root_key_list)
# [___CELL_SEPARATOR___]
df
# [___CELL_SEPARATOR___]
from pandas_read_xml import auto_separate_tables

key_columns = ['action-key', 'case-file|serial-number']

data = df.pipe(auto_separate_tables, key_columns)
# [___CELL_SEPARATOR___]
data.keys()
# [___CELL_SEPARATOR___]
data['classifications']
# [___CELL_SEPARATOR___]
