import os

from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from pprint import pprint

url = 'https://google.com'
# [___CELL_SEPARATOR___]
try:
    driver = webdriver.Chrome('/home/afun/Downloads/chromedriver')
    driver.get(url)
    driver.maximize_window()
    driver.implicitly_wait(10)
    
    search_input  = driver.find_element(By.ID, 'lst-ib')
    search_input.send_keys(u'人工智慧')
    search_input.send_keys(Keys.ENTER)
    
    for i in range(2):
        print('='*87, 'Page {}'.format(i))

        links = driver.find_elements(By.XPATH, '//div[@class="r"]/a[@href]')

        for link in links:
            page_title = link.find_element(By.TAG_NAME, 'h3').text
            page_url = ''

            if link.get_attribute('href'):
                page_url = link.get_attribute('href')

            print('title: {}\nurl: {}\n---'.format(page_title, page_url))

        next_page = driver.find_element(By.XPATH, '//*[@id="pnnext"]/span[2]').click()

except Exception as e:
    print(e)
finally:
    driver.quit()