import pandas as pd
from sklearn.preprocessing import Binarizer, LabelEncoder, OneHotEncoder
import numpy as np
from sklearn.cross_validation import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score
from sklearn import tree
# [___CELL_SEPARATOR___]
data = pd.read_csv('sales_loss_win_data.csv')
# [___CELL_SEPARATOR___]
data.head()
# [___CELL_SEPARATOR___]
data = data.drop('Opportunity Number', axis =1 )
# [___CELL_SEPARATOR___]
data.head()
# [___CELL_SEPARATOR___]
le = LabelEncoder()
# [___CELL_SEPARATOR___]
class MultiColumnLabelEncoder:
    def __init__(self,columns = None):
        self.columns = columns # array of column names to encode

    def fit(self,X,y=None):
        return self # not relevant here

    def transform(self,X):
        '''
        Transforms columns of X specified in self.columns using
        LabelEncoder(). If no columns specified, transforms all
        columns in X.
        '''
        output = X.copy()
        if self.columns is not None:
            for col in self.columns:
                output[col] = LabelEncoder().fit_transform(output[col])
        else:
            for colname,col in output.iteritems():
                output[colname] = LabelEncoder().fit_transform(col)
        return output

    def fit_transform(self,X,y=None):
        return self.fit(X,y).transform(X)
# [___CELL_SEPARATOR___]
final_data = MultiColumnLabelEncoder(columns = ['Supplies Subgroup', 'Supplies Group', 'Region', 'Route To Market', 
                                  'Opportunity Result', 'Competitor Type']).fit_transform(data)
# [___CELL_SEPARATOR___]
final_data.head()
# [___CELL_SEPARATOR___]
yVar = final_data['Opportunity Result']
xVar = final_data.loc[:, final_data.columns != 'Opportunity Result']
# [___CELL_SEPARATOR___]
X_train, X_test, y_train, y_test = train_test_split(xVar, yVar, test_size=0.2)
print (X_train.shape, y_train.shape)
print (X_test.shape, y_test.shape)
# [___CELL_SEPARATOR___]
clf_gini = DecisionTreeClassifier(criterion = "gini", random_state = 100,
                               max_depth=3, min_samples_leaf=5)
clf_gini.fit(X_train, y_train)
# [___CELL_SEPARATOR___]
clf_entropy = DecisionTreeClassifier(criterion = "entropy", random_state = 100, 
                                     max_depth=3, min_samples_leaf=5)
clf_entropy.fit(X_train, y_train)
# [___CELL_SEPARATOR___]
y_pred_gini = clf_gini.predict(X_test)
y_pred_en = clf_entropy.predict(X_test)
# [___CELL_SEPARATOR___]
print ("Gini accuracy is ", accuracy_score(y_test,y_pred_gini)*100)
print ("Entropy accuracy is ", accuracy_score(y_test,y_pred_en)*100)