from pyspark.ml.feature import VectorAssembler
from pyspark.ml.pipeline import Pipeline, PipelineModel
from pyspark.ml.classification import RandomForestClassifier
from pyspark.ml.classification import DecisionTreeClassifier
from pyspark.ml.evaluation import MulticlassClassificationEvaluator
# [___CELL_SEPARATOR___]
df = (spark.read
      .option("inferSchema", True)
      .option("header", True)
      .csv("/data/creditcard-fraud.csv"))
# [___CELL_SEPARATOR___]
df.limit(10).toPandas()
# [___CELL_SEPARATOR___]
feature_columns = [col for col in df.columns if col.startswith("V")]
print(feature_columns)
# [___CELL_SEPARATOR___]
vectorizer = VectorAssembler(inputCols = feature_columns, outputCol="features")
vectorizer.transform(df).select("features", "Class").limit(5).toPandas()
# [___CELL_SEPARATOR___]
est = RandomForestClassifier()
est.setMaxDepth(5)
est.setLabelCol("Class")
# [___CELL_SEPARATOR___]
print(est.explainParams())
# [___CELL_SEPARATOR___]
df_train, df_test = df.randomSplit(weights=[0.7, 0.3], seed = 1)
# [___CELL_SEPARATOR___]
pipeline = Pipeline()
pipeline.setStages([vectorizer, est])
model = pipeline.fit(df_train)
# [___CELL_SEPARATOR___]
df_test_pred = model.transform(df_test)
# [___CELL_SEPARATOR___]
from pyspark.ml.evaluation import BinaryClassificationEvaluator
# [___CELL_SEPARATOR___]
evaluator = BinaryClassificationEvaluator()
evaluator.setLabelCol("Class")
# [___CELL_SEPARATOR___]
evaluator.evaluate(model.transform(df_test))
# [___CELL_SEPARATOR___]
from pyspark.sql.functions import *
# [___CELL_SEPARATOR___]
test_accuracy = (df_test_pred
.select("Class", "prediction")
.withColumn("isEqual", expr("Class == prediction"))
.select(avg(expr("cast(isEqual as float)")))
.first())
# [___CELL_SEPARATOR___]
test_accuracy
# [___CELL_SEPARATOR___]
treeEstimator = DecisionTreeClassifier()
treeEstimator.setImpurity("entropy")
treeEstimator.setLabelCol("Class")

pipeline = Pipeline()
pipeline.setStages([vectorizer, treeEstimator])
model = pipeline.fit(df_train)
evaluator.evaluate(model.transform(df_test))
# [___CELL_SEPARATOR___]
accuracy_evaluator = MulticlassClassificationEvaluator()
accuracy_evaluator.setLabelCol("Class")
accuracy_evaluator.setMetricName("accuracy")
accuracy_evaluator.evaluate(model.transform(df_test))
# [___CELL_SEPARATOR___]
f1_evaluator = MulticlassClassificationEvaluator()
f1_evaluator.setLabelCol("Class")
f1_evaluator.setMetricName("f1")
f1_evaluator.evaluate(model.transform(df_test))
# [___CELL_SEPARATOR___]
