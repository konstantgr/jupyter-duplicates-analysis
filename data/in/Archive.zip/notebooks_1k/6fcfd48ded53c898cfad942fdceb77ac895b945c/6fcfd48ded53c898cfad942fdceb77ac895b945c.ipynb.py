import json
import torch

import numpy as np

from functools import partial
from fastai2.basics import *
from fastai2.vision.all import *
# [___CELL_SEPARATOR___]
torch.cuda.set_device(2)
# [___CELL_SEPARATOR___]
# Chosen parameters
lr=2e-2
sqrmom=0.99
mom=0.95
beta=0.
eps=1e-4
bs=64 
sa=1

m = xresnet34
act_fn = Mish
pool = MaxPool

nc=20
# [___CELL_SEPARATOR___]
source = untar_data(URLs.IMAGEWANG_160)
len(get_image_files(source/'unsup')), len(get_image_files(source/'train')), len(get_image_files(source/'val'))
# [___CELL_SEPARATOR___]
# Use the Ranger optimizer
opt_func = partial(ranger, mom=mom, sqr_mom=sqrmom, eps=eps, beta=beta)
# [___CELL_SEPARATOR___]
m_part = partial(m, c_out=nc, act_cls=torch.nn.ReLU, sa=sa, pool=pool)
model_meta[m_part] = model_meta[xresnet34]
# [___CELL_SEPARATOR___]
save_name = 'imagewang_contrast_kornia_80ep_loweraug'
# [___CELL_SEPARATOR___]
#export
from pytorch_metric_learning import losses
class XentLoss(losses.NTXentLoss):
    def forward(self, output1, output2):
        stacked = torch.cat((output1, output2), dim=0)
        labels = torch.arange(output1.shape[0]).repeat(2)
        return super().forward(stacked, labels, None)
    
class ContrastCallback(Callback):
    run_before=Recorder
    def __init__(self, size=256, aug_targ=None, aug_pos=None, temperature=0.1):
        self.aug_targ = ifnone(aug_targ, get_aug_pipe(size))
        self.aug_pos = ifnone(aug_pos, get_aug_pipe(size))
        self.temperature = temperature
        
    def update_size(self, size):
        pipe_update_size(self.aug_targ, size)
        pipe_update_size(self.aug_pos, size)
        
    def begin_fit(self): 
        self.old_lf = self.learn.loss_func
        self.old_met = self.learn.metrics
        self.learn.metrics = []
        self.learn.loss_func = losses.NTXentLoss(self.temperature)
        
    def after_fit(self):
        self.learn.loss_fun = self.old_lf
        self.learn.metrics = self.old_met
        
    def begin_batch(self):
        xb, = self.learn.xb
        xb_targ = self.aug_targ(xb)
        xb_pos = self.aug_pos(xb)
        self.learn.xb = torch.cat((xb_targ, xb_pos), dim=0),
        self.learn.yb = torch.arange(xb_targ.shape[0]).repeat(2),
        
# [___CELL_SEPARATOR___]
#export
def pipe_update_size(pipe, size):
    for tf in pipe.fs:
        if isinstance(tf, RandomResizedCropGPU):
            tf.size = size
# [___CELL_SEPARATOR___]
def get_dbunch(size, bs, workers=8, dogs_only=False):
    path = URLs.IMAGEWANG_160 if size <= 160 else URLs.IMAGEWANG
    source = untar_data(path)
    
    folders = ['unsup', 'val'] if dogs_only else None
    files = get_image_files(source, folders=folders)
    
    tfms = [[PILImage.create, ToTensor, RandomResizedCrop(size, min_scale=0.9)], 
            [parent_label, Categorize()]]
    
#     dsets = Datasets(files, tfms=tfms, splits=GrandparentSplitter(train_name='unsup', valid_name='val')(files))
    dsets = Datasets(files, tfms=tfms, splits=RandomSplitter(valid_pct=0.1)(files))
    
#     batch_tfms = [IntToFloatTensor, *aug_transforms(p_lighting=1.0, max_lighting=0.9)]
    batch_tfms = [IntToFloatTensor]
    dls = dsets.dataloaders(bs=bs, num_workers=workers, after_batch=batch_tfms)
    dls.path = source
    return dls
# [___CELL_SEPARATOR___]
size = 128
bs = 256

dbunch = get_dbunch(160, bs)
len(dbunch.train.dataset)
# [___CELL_SEPARATOR___]
dbunch.show_batch()
# [___CELL_SEPARATOR___]
# # xb = TensorImage(torch.randn(1, 3,128,128))
# afn_tfm, lght_tfm = aug_transforms(p_lighting=1.0, max_lighting=0.8, p_affine=1.0)
# # lght_tfm.split_idx = None
# xb.allclose(afn_tfm(xb)), xb.allclose(lght_tfm(xb, split_idx=0))
# [___CELL_SEPARATOR___]
import kornia
# [___CELL_SEPARATOR___]
#export
def get_aug_pipe(size, stats=None, s=.6):
    stats = ifnone(stats, imagenet_stats)
    rrc = kornia.augmentation.RandomResizedCrop((size,size), scale=(0.2, 1.0), ratio=(3/4, 4/3))
    rhf = kornia.augmentation.RandomHorizontalFlip()
    rcj = kornia.augmentation.ColorJitter(0.8*s, 0.8*s, 0.8*s, 0.2*s)
    
    tfms = [rrc, rhf, rcj, Normalize.from_stats(*stats)]
    pipe = Pipeline(tfms)
    pipe.split_idx = 0
    return pipe
# [___CELL_SEPARATOR___]
aug = get_aug_pipe(size)
aug2 = get_aug_pipe(size)
cbs = ContrastCallback(size=size, aug_targ=aug, aug_pos=aug2, temperature=0.3)
# [___CELL_SEPARATOR___]
xb,yb = dbunch.one_batch()
nrm = Normalize.from_stats(*imagenet_stats)
xb_dec = nrm.decodes(aug(xb))
show_images([xb_dec[0], xb[0]])
# [___CELL_SEPARATOR___]
ch = nn.Sequential(nn.AdaptiveAvgPool2d(1), Flatten(), nn.Linear(512, 256), nn.ReLU(), nn.Linear(256, 128))
learn = cnn_learner(dbunch, m_part, opt_func=opt_func,
                    metrics=[], loss_func=CrossEntropyLossFlat(), cbs=cbs, pretrained=False,
                    config={'custom_head':ch}
                   ).to_fp16()
# [___CELL_SEPARATOR___]
learn.unfreeze()
learn.fit_flat_cos(80, 2e-2, wd=1e-2, pct_start=0.5)
# [___CELL_SEPARATOR___]
torch.save(learn.model[0].state_dict(), f'{save_name}.pth')
# [___CELL_SEPARATOR___]
# learn.save(save_name)
# [___CELL_SEPARATOR___]
def get_dbunch(size, bs, workers=8, dogs_only=False):
    path = URLs.IMAGEWANG_160 if size <= 160 else URLs.IMAGEWANG
    source = untar_data(path)
    
    if dogs_only:
        dog_categories = [f.name for f in (source/'val').ls()]
        dog_train = get_image_files(source/'train', folders=dog_categories)
        valid = get_image_files(source/'val')
        files = dog_train + valid
        splits = [range(len(dog_train)), range(len(dog_train), len(dog_train)+len(valid))]
    else:
        files = get_image_files(source)
        splits = GrandparentSplitter(valid_name='val')(files)
        
    
    item_aug = [RandomResizedCrop(size, min_scale=0.35), FlipItem(0.5)]
    tfms = [[PILImage.create, ToTensor, *item_aug], 
            [parent_label, Categorize()]]
    
    dsets = Datasets(files, tfms=tfms, splits=splits)
    
    batch_tfms = [IntToFloatTensor, Normalize.from_stats(*imagenet_stats)]
    dls = dsets.dataloaders(bs=bs, num_workers=workers, after_batch=batch_tfms)
    dls.path = source
    return dls
# [___CELL_SEPARATOR___]
def do_train(size=128, bs=64, lr=1e-2, epochs=5, runs=5, dogs_only=False, save_name=None):
    dbunch = get_dbunch(size, bs, dogs_only=dogs_only)
    for run in range(runs):
        print(f'Run: {run}')
        ch = nn.Sequential(nn.AdaptiveAvgPool2d(1), Flatten(), nn.Linear(512, 20))
        learn = cnn_learner(dbunch, m_part, opt_func=opt_func, normalize=False,
                metrics=[accuracy,top_k_accuracy], loss_func=LabelSmoothingCrossEntropy(),
#                 metrics=[accuracy,top_k_accuracy], loss_func=CrossEntropyLossFlat(),
                pretrained=False,
                config={'custom_head':ch})

        if save_name is not None:
            state_dict = torch.load(f'{save_name}.pth')
            learn.model[0].load_state_dict(state_dict)

#             state_dict = torch.load('imagewang_inpainting_15_epochs_nopretrain.pth')
#             learn.model[0].load_state_dict(state_dict)
        learn.unfreeze()
        learn.fit_flat_cos(epochs, lr, wd=1e-2)
# [___CELL_SEPARATOR___]
epochs = 5
runs = 1
# [___CELL_SEPARATOR___]
do_train(epochs=epochs, runs=runs, lr=2e-2, dogs_only=False, save_name=save_name)
# [___CELL_SEPARATOR___]
epochs = 20
runs = 1
# [___CELL_SEPARATOR___]
# LATEST
do_train(epochs=epochs, runs=runs, lr=2e-2, dogs_only=False, save_name=save_name)
# [___CELL_SEPARATOR___]
epochs = 80
runs = 1
# [___CELL_SEPARATOR___]
do_train(epochs=epochs, runs=runs, dogs_only=False, save_name=save_name)
# [___CELL_SEPARATOR___]
epochs = 200
runs = 1
# [___CELL_SEPARATOR___]
do_train(epochs=epochs, runs=runs, dogs_only=False, save_name=save_name)