import hatchet as ht
# [___CELL_SEPARATOR___]
# Copied from hatchet/hatchet/tests/conftest.py
def mock_graph_literal():
    graph_dict = [
        {
            "name": "foo",
            "metrics": {"time (inc)": 130.0, "time": 0.0},
            "children": [
                {
                    "name": "bar",
                    "metrics": {"time (inc)": 20.0, "time": 5.0},
                    "children": [
                        {"name": "baz", "metrics": {"time (inc)": 5.0, "time": 5.0}},
                        {
                            "name": "grault",
                            "metrics": {"time (inc)": 10.0, "time": 10.0},
                        },
                    ],
                },
                {
                    "name": "qux",
                    "metrics": {"time (inc)": 60.0, "time": 0.0},
                    "children": [
                        {
                            "name": "quux",
                            "metrics": {"time (inc)": 60.0, "time": 5.0},
                            "children": [
                                {
                                    "name": "corge",
                                    "metrics": {"time (inc)": 55.0, "time": 10.0},
                                    "children": [
                                        {
                                            "name": "bar",
                                            "metrics": {
                                                "time (inc)": 20.0,
                                                "time": 5.0,
                                            },
                                            "children": [
                                                {
                                                    "name": "baz",
                                                    "metrics": {
                                                        "time (inc)": 5.0,
                                                        "time": 5.0,
                                                    },
                                                },
                                                {
                                                    "name": "grault",
                                                    "metrics": {
                                                        "time (inc)": 10.0,
                                                        "time": 10.0,
                                                    },
                                                },
                                            ],
                                        },
                                        {
                                            "name": "grault",
                                            "metrics": {
                                                "time (inc)": 10.0,
                                                "time": 10.0,
                                            },
                                        },
                                        {
                                            "name": "garply",
                                            "metrics": {
                                                "time (inc)": 15.0,
                                                "time": 15.0,
                                            },
                                        },
                                    ],
                                }
                            ],
                        }
                    ],
                },
                {
                    "name": "waldo",
                    "metrics": {"time (inc)": 50.0, "time": 0.0},
                    "children": [
                        {
                            "name": "fred",
                            "metrics": {"time (inc)": 35.0, "time": 5.0},
                            "children": [
                                {
                                    "name": "plugh",
                                    "metrics": {"time (inc)": 5.0, "time": 5.0},
                                },
                                {
                                    "name": "xyzzy",
                                    "metrics": {"time (inc)": 25.0, "time": 5.0},
                                    "children": [
                                        {
                                            "name": "thud",
                                            "metrics": {
                                                "time (inc)": 25.0,
                                                "time": 5.0,
                                            },
                                            "children": [
                                                {
                                                    "name": "baz",
                                                    "metrics": {
                                                        "time (inc)": 5.0,
                                                        "time": 5.0,
                                                    },
                                                },
                                                {
                                                    "name": "garply",
                                                    "metrics": {
                                                        "time (inc)": 15.0,
                                                        "time": 15.0,
                                                    },
                                                },
                                            ],
                                        }
                                    ],
                                },
                            ],
                        },
                        {
                            "name": "garply",
                            "metrics": {"time (inc)": 15.0, "time": 15.0},
                        },
                    ],
                },
            ],
        },
        {
            "name": "waldo",
            "metrics": {"time (inc)": 30.0, "time": 10.0},
            "children": [
                {
                    "name": "bar",
                    "metrics": {"time (inc)": 20.0, "time": 5.0},
                    "children": [
                        {"name": "baz", "metrics": {"time (inc)": 5.0, "time": 5.0}},
                        {
                            "name": "grault",
                            "metrics": {"time (inc)": 10.0, "time": 10.0},
                        },
                    ],
                }
            ],
        },
    ]

    return graph_dict
# [___CELL_SEPARATOR___]
gf = ht.GraphFrame.from_literal(mock_graph_literal())
# [___CELL_SEPARATOR___]
print(gf.tree(color=True, metric="time (inc)"))
gf.dataframe
# [___CELL_SEPARATOR___]
query = [
    {"name": "qux"},
    ("*", {"time (inc)": "> 10"}),
    {"name": "gr[a-z]+", "time (inc)": "<= 10"}
]
# [___CELL_SEPARATOR___]
sgf = gf.filter(query, squash=True)
print(sgf.tree(color=True, metric="time (inc)"))
sgf.dataframe
# [___CELL_SEPARATOR___]
query = [
    {"name": "bar"},
    ("*", {"time (inc)": "> 50"}),
    {"name": "gr[a-z]+", "time (inc)": "<= 10"}
]
# [___CELL_SEPARATOR___]
sgf = gf.filter(query, squash=True)
print(sgf.tree(color=True, metric="time (inc)"))
sgf.dataframe
# [___CELL_SEPARATOR___]
query = [
    {"name": "waldo"},
    "+",
    {"time (inc)": ">= 20.0"},
    "+",
    {"time (inc)": 5.0, "time": 5.0}
]
# [___CELL_SEPARATOR___]
sgf = gf.filter(query, squash=True)
print(sgf.tree(color=True, metric="time (inc)"))
sgf.dataframe
# [___CELL_SEPARATOR___]
query = [
    {"name": "waldo"},
    "+",
    {"time (inc)": ">= 20.0"},
    "+",
    {"time (inc)": 7.5, "time": 7.5}
]
# [___CELL_SEPARATOR___]
sgf = gf.filter(query, squash=True)
print(sgf.tree(color=True, metric="time (inc)"))
sgf.dataframe
# [___CELL_SEPARATOR___]
gf = ht.GraphFrame.from_hpctoolkit("../hatchet-sc19-datasets/kripke-mpi/mvapich2.3/hpctoolkit-kripke-database-2589460")
# [___CELL_SEPARATOR___]
print(gf.tree(color=True, metric="time (inc)"))
gf.dataframe
# [___CELL_SEPARATOR___]
gf.drop_index_levels()
gf.dataframe
# [___CELL_SEPARATOR___]
isinstance(gf.dataframe.iloc[0]["name"], str)
# [___CELL_SEPARATOR___]
gf.dataframe[gf.dataframe["name"].str.startswith("MPI")]
# [___CELL_SEPARATOR___]
query = [
    "*",
    {"name": "MPI.*"},
    "*"
]
# [___CELL_SEPARATOR___]
sgf = gf.filter(query, squash=True)
print(sgf.tree(color=True, metric="time (inc)"))
sgf.dataframe
# [___CELL_SEPARATOR___]
