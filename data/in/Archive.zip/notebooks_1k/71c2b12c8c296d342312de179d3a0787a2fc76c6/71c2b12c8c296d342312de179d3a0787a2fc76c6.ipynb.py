from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences

train_data = [
  "আচ্ছা, ডেটা কিভাবে কথা বলে?",
  "পড়ছিলাম হান্স রোসলিং এর একটা বই, ফ্যাক্টফুলনেস।",
  "ধারণা থেকে নয়, বরং ডেটাকে কথা বলতে দিলে আমাদের সব বিপদ কাটবে।",
  "এই লোক পৃথিবীকে দেখিয়েছিলেন কিভাবে ২০০ বছরের ডেটা আমাদের বাঁচার সময় বাড়িয়েছে!"
]

test_data = [
  "এই অ্যানিমেশন আমরা করবো আমাদের পিসিতে।",
  "সরাসরি চালান নিচের লিংক থেকে, হচ্ছে তো?",
  "পাল্টান প্যারামিটার, চালান নিজের মতো করে।"
]
# [___CELL_SEPARATOR___]
num_words = 1000
oov_token = '<UNK>'
pad_type = 'post'
trunc_type = 'post'
# [___CELL_SEPARATOR___]
# আমাদের ট্রেনিং ডেটা টোকেনাইজ করি, বাংলায় স্টপওয়ার্ড হিসেবে দাড়ি '।'কে ফেলে দিতে হবে।
tokenizer = Tokenizer(num_words=num_words, filters='!"#$%&()*+,-./:;<=>?@[\\]^_`{|}~\t\n।', oov_token=oov_token)
tokenizer.fit_on_texts(train_data)
# [___CELL_SEPARATOR___]
# ট্রেনিং ডেটার ওয়ার্ড ইনডেক্স বের করি
word_index = tokenizer.word_index
# [___CELL_SEPARATOR___]
tokenizer.get_config()
# [___CELL_SEPARATOR___]
# টেনিং ডেটার বাক্যগুলোকে সিকোয়েন্স এ ফেলি
train_sequences = tokenizer.texts_to_sequences(train_data)
# [___CELL_SEPARATOR___]
# ট্রেনিং এর সর্বোচ্চ লেনথ বের করি
maxlen = max([len(x) for x in train_sequences])
# [___CELL_SEPARATOR___]
# ট্রেনিং এর সিকোয়েন্স এর প্যাডিং যোগ করি
train_padded = pad_sequences(train_sequences, padding=pad_type, truncating=trunc_type, maxlen=maxlen)
# [___CELL_SEPARATOR___]
# আমাদের কাজের আউটপুটগুলো দেখি ভিন্ন ভাবে, তবে বাংলায় স্টপওয়ার্ড হিসেবে '।'কে ফেলে দিয়েছি।
print("Word index:\n", word_index)
print("\nTraining sequences:\n", train_sequences)
print("\nPadded training sequences:\n", train_padded)
print("\nPadded training shape:", train_padded.shape)
print("Training sequences data type:", type(train_sequences))
print("Padded Training sequences data type:", type(train_padded))
# [___CELL_SEPARATOR___]
test_sequences = tokenizer.texts_to_sequences(test_data)
test_padded = pad_sequences(test_sequences, padding=pad_type, truncating=trunc_type, maxlen=maxlen)

print("Testing sequences:\n", test_sequences)
print("\nPadded testing sequences:\n", test_padded)
print("\nPadded testing shape:",test_padded.shape)
# [___CELL_SEPARATOR___]
for x, y in zip(test_data, test_padded):
  print('{} -> {}'.format(x, y))

print("\nWord index (for reference):", word_index)