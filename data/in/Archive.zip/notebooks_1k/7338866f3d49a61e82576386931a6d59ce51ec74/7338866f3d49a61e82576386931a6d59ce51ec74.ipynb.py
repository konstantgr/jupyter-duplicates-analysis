# Our standard packages for data science.
import os
import numpy as np
import pandas as pd 
import seaborn as sns
import matplotlib.pyplot as plt
import itertools
import time

# Our main packages for standard machine learning
from sklearn.linear_model import *
from sklearn.tree import *
from sklearn.svm import *
from sklearn.naive_bayes import *
from sklearn.ensemble import *
from sklearn.multiclass import *
from sklearn.neighbors import KNeighborsClassifier
from sklearn.feature_selection import SelectKBest
from sklearn.feature_selection import chi2
from sklearn.preprocessing import StandardScaler, RobustScaler
from scipy.stats import randint as sp_randint
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.model_selection import KFold
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import KFold, StratifiedKFold
from sklearn.metrics import accuracy_score, confusion_matrix
from sklearn.model_selection import LeaveOneGroupOut
from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import RandomizedSearchCV
from sklearn.metrics import *
from sklearn.model_selection import *
from sklearn import preprocessing
le = preprocessing.LabelEncoder()
from scipy import stats
from scipy.stats import norm
from matplotlib import rcParams
%matplotlib inline

import warnings
warnings.filterwarnings('ignore')
import gc
gc.enable()

print('Packages are ready!')
# [___CELL_SEPARATOR___]
winedata = pd.read_csv('Data\winedata.csv')

print('Data is ready!')
# [___CELL_SEPARATOR___]
ctarget = winedata['quality']
qtarget = winedata['color']
data = winedata.drop('quality', axis=1)
data = data.drop('color', axis=1)
print('Done!')
# [___CELL_SEPARATOR___]
print(winedata.shape)
print(data.shape)
print(qtarget.shape)
print(ctarget.shape)
# [___CELL_SEPARATOR___]
from sklearn.datasets import load_boston

boston = load_boston()
# [___CELL_SEPARATOR___]
boston.keys()
# [___CELL_SEPARATOR___]
boston.data.shape
# [___CELL_SEPARATOR___]
print(boston.feature_names)
# [___CELL_SEPARATOR___]
print(boston.DESCR)
# [___CELL_SEPARATOR___]
bos = pd.DataFrame(boston.data)
bos.head()
# [___CELL_SEPARATOR___]
bos.columns = boston.feature_names
bos.head()
# [___CELL_SEPARATOR___]
bos['PRICE'] = boston.target
bos.head()
# [___CELL_SEPARATOR___]
bos.describe()
# [___CELL_SEPARATOR___]
plt.scatter(bos.RM, bos.PRICE)
plt.xlabel("Average Rooms Per Dwelling (RM)")
plt.ylabel("Housing Price")
plt.title("Relationship between RM and Price")
# [___CELL_SEPARATOR___]
sns.regplot(y="PRICE", x="RM", data=bos, fit_reg = True)
# [___CELL_SEPARATOR___]
import statsmodels.api as sm
from statsmodels.formula.api import ols
# [___CELL_SEPARATOR___]
model = ols('PRICE ~ RM',bos).fit()
print(model.summary())
# [___CELL_SEPARATOR___]
model = ols('PRICE ~ CRIM',bos).fit()
print(model.summary())
# [___CELL_SEPARATOR___]
model = ols('PRICE ~ PTRATIO',bos).fit()
print(model.summary())
# [___CELL_SEPARATOR___]
model = ols('PRICE ~ RM+DIS+TAX+B+NOX+CRIM+ZN+INDUS+CHAS+AGE+RAD+PTRATIO+LSTAT',bos).fit()
model.fittedvalues.head()
print(model.summary())
# [___CELL_SEPARATOR___]
reduced = ols('PRICE ~ PTRATIO+RM+CRIM+LSTAT',bos).fit()
print(reduced.summary())
# [___CELL_SEPARATOR___]
plt.scatter(bos.PRICE, model.fittedvalues)
plt.xlabel("Actual Prices")
plt.ylabel("Predicted prices")
plt.title("Prices vs Predicted Prices")
# [___CELL_SEPARATOR___]
from sklearn.linear_model import LinearRegression
X = bos.drop('PRICE', axis = 1)

lm = LinearRegression()
lm.fit(X, bos.PRICE)
# [___CELL_SEPARATOR___]
print('Estimated intercept coefficient: {}'.format(lm.intercept_))
# [___CELL_SEPARATOR___]
pd.DataFrame({'features': X.columns, 'estimatedCoefficients': lm.coef_})[['features', 'estimatedCoefficients']]
# [___CELL_SEPARATOR___]
plt.hist(lm.predict(X))
plt.title('Predicted Housing Prices (fitted values)')
plt.xlabel('Price')
plt.ylabel('Frequency')
# [___CELL_SEPARATOR___]
lm = LinearRegression()
lm.fit(X[['PTRATIO']], bos.PRICE)
msePTRATIO = np.mean((bos.PRICE - lm.predict(X[['PTRATIO']])) ** 2)
print(msePTRATIO)
# [___CELL_SEPARATOR___]
lm = LinearRegression()
lm.fit(X[['CRIM']], bos.PRICE)
mseCRIM = np.mean((bos.PRICE - lm.predict(X[['CRIM']])) ** 2)
print(mseCRIM)
# [___CELL_SEPARATOR___]
lm = LinearRegression()
lm.fit(X[['RM']], bos.PRICE)
mseRM = np.mean((bos.PRICE - lm.predict(X[['RM']])) ** 2)
print(mseRM)
# [___CELL_SEPARATOR___]
lm = LinearRegression()
lm.fit(X[['LSTAT']], bos.PRICE)
mseLSTAT = np.mean((bos.PRICE - lm.predict(X[['LSTAT']])) ** 2)
print(mseLSTAT)
# [___CELL_SEPARATOR___]
x = data
y = qtarget
folds = StratifiedKFold(n_splits=5, shuffle=True, random_state=59)
measured= np.zeros((x.shape[0]))
score = 0

for times, (trn_idx, val_idx) in enumerate(folds.split(x.values,y.values)):
    model = LogisticRegression(n_jobs=-1)
    model.fit(x.iloc[trn_idx],y[trn_idx])
    measured[val_idx] = model.predict(x.iloc[val_idx])
    score += model.score(x.iloc[val_idx],y[val_idx])
    print("Fold: {} score: {}".format(times,model.score(x.iloc[val_idx],y[val_idx])))

    gc.collect()

print('Avg Accuracy RF', score / folds.n_splits)
# [___CELL_SEPARATOR___]
x = data
y = qtarget
folds = KFold(n_splits=5, shuffle=True, random_state=59)
measured= np.zeros((x.shape[0]))
score = 0

for times, (trn_idx, val_idx) in enumerate(folds.split(x.values,y.values)):
    model = Lasso()
    model.fit(x.iloc[trn_idx],y[trn_idx])
    measured[val_idx] = model.predict(x.iloc[val_idx])
    score += model.score(x.iloc[val_idx],y[val_idx])
    print("Fold: {} score: {}".format(times,model.score(x.iloc[val_idx],y[val_idx])))

    gc.collect()
    
print('Avg Accuracy RF', score / folds.n_splits)
# [___CELL_SEPARATOR___]
x = data
y = qtarget
folds = KFold(n_splits=5, shuffle=True, random_state=59)
measured= np.zeros((x.shape[0]))
score = 0

for times, (trn_idx, val_idx) in enumerate(folds.split(x.values,y.values)):
    model = DecisionTreeClassifier()
    model.fit(x.iloc[trn_idx],y[trn_idx])
    measured[val_idx] = model.predict(x.iloc[val_idx])
    score += model.score(x.iloc[val_idx],y[val_idx])
    print("Fold: {} score: {}".format(times,model.score(x.iloc[val_idx],y[val_idx])))

    gc.collect()
    
print('Avg Accuracy RF', score / folds.n_splits)
# [___CELL_SEPARATOR___]
x = data
y = qtarget
folds = KFold(n_splits=5, shuffle=True, random_state=59)
measured= np.zeros((x.shape[0]))
score = 0

for times, (trn_idx, val_idx) in enumerate(folds.split(x.values,y.values)):
    model = LinearSVC()
    model.fit(x.iloc[trn_idx],y[trn_idx])
    measured[val_idx] = model.predict(x.iloc[val_idx])
    score += model.score(x.iloc[val_idx],y[val_idx])
    print("Fold: {} score: {}".format(times,model.score(x.iloc[val_idx],y[val_idx])))

    gc.collect()
    
print('Avg Accuracy RF', score / folds.n_splits)
# [___CELL_SEPARATOR___]
x = data
y = qtarget
folds = KFold(n_splits=5, shuffle=True, random_state=59)
measured= np.zeros((x.shape[0]))
score = 0

for times, (trn_idx, val_idx) in enumerate(folds.split(x.values,y.values)):
    model = KNeighborsClassifier()
    model.fit(x.iloc[trn_idx],y[trn_idx])
    measured[val_idx] = model.predict(x.iloc[val_idx])
    score += model.score(x.iloc[val_idx],y[val_idx])
    print("Fold: {} score: {}".format(times,model.score(x.iloc[val_idx],y[val_idx])))

    gc.collect()
    
print('Avg Accuracy RF', score / folds.n_splits)
# [___CELL_SEPARATOR___]
x = data
y = qtarget
folds = KFold(n_splits=5, shuffle=True, random_state=59)
measured= np.zeros((x.shape[0]))
score = 0

for times, (trn_idx, val_idx) in enumerate(folds.split(x.values,y.values)):
    model = RandomForestClassifier()
    model.fit(x.iloc[trn_idx],y[trn_idx])
    measured[val_idx] = model.predict(x.iloc[val_idx])
    score += model.score(x.iloc[val_idx],y[val_idx])
    print("Fold: {} score: {}".format(times,model.score(x.iloc[val_idx],y[val_idx])))

    gc.collect()
    
print('Avg Accuracy RF', score / folds.n_splits)
# [___CELL_SEPARATOR___]
ccdata = pd.read_csv('https://query.data.world/s/44aoyjg7hb4h64bns6iqnzpa5pmv2c')
# [___CELL_SEPARATOR___]
ccdata
# [___CELL_SEPARATOR___]
ccdata.isna().sum().max()
# [___CELL_SEPARATOR___]
ccdata.describe()
# [___CELL_SEPARATOR___]
x = ccdata['Time']

plt.hist(x, bins=100)
plt.ylabel('# of times')
plt.xlabel('Dist of Time')
plt.show()

plt.show()
# [___CELL_SEPARATOR___]
x = ccdata[ccdata['Class']==1]['Time']

plt.hist(x, bins=50)
plt.ylabel('# of times')
plt.xlabel('Dist of Time')
plt.show()

plt.show()
# [___CELL_SEPARATOR___]
ccdata['scaled_amount'] = RobustScaler().fit_transform(ccdata['Amount'].values.reshape(-1,1))
ccdata['scaled_time'] = RobustScaler().fit_transform(ccdata['Time'].values.reshape(-1,1))

ccdata.drop(['Time','Amount'], axis=1, inplace=True)

scaled_amount = ccdata['scaled_amount']
scaled_time = ccdata['scaled_time']

ccdata.drop(['scaled_amount', 'scaled_time'], axis=1, inplace=True)
ccdata.insert(0, 'scaled_amount', scaled_amount)
ccdata.insert(1, 'scaled_time', scaled_time)

ccdata.head()
# [___CELL_SEPARATOR___]
del scaled_amount
del scaled_time
# [___CELL_SEPARATOR___]
#When you run this line, you'll need to restart Jupyter Lab.
!pip install --user imbalanced-learn
# [___CELL_SEPARATOR___]
from imblearn.over_sampling import SMOTE
from imblearn.ensemble import BalancedBaggingClassifier
from imblearn.ensemble import BalancedRandomForestClassifier
import imblearn

from sklearn.metrics import precision_score, recall_score, f1_score, roc_auc_score, accuracy_score, classification_report, confusion_matrix
# [___CELL_SEPARATOR___]
ccdata = ccdata.sample(frac=1, random_state=42)

fraud_ccdata = ccdata[ccdata['Class'] == 1]
non_fraud_ccdata = ccdata[ccdata['Class'] == 0][:492]

undersample_ccdata = pd.concat([fraud_ccdata, non_fraud_ccdata])

new_ccdata = undersample_ccdata.sample(frac=1, random_state=42)

new_ccdata
# [___CELL_SEPARATOR___]
new_cctarget = new_ccdata['Class']
cctarget = ccdata['Class']

new_ccdata = new_ccdata.drop('Class', axis=1)
ccdata = ccdata.drop('Class', axis=1)
print('Data Ready')
# [___CELL_SEPARATOR___]
new_ccdata.reset_index(drop=True, inplace=True)
new_cctarget.reset_index(drop=True, inplace=True)
# [___CELL_SEPARATOR___]
training_data, test_data, training_target, test_target = train_test_split(ccdata, cctarget, test_size = .1, random_state=42)
# [___CELL_SEPARATOR___]
x_train, x_val, y_train, y_val = train_test_split(training_data, training_target, test_size = .1, random_state=42)
# [___CELL_SEPARATOR___]
sm = SMOTE(sampling_strategy=.01, random_state=42)
cc_smote, cc_smote_target = sm.fit_sample(x_train, y_train)
# [___CELL_SEPARATOR___]
cc_smote_target.sum()
# [___CELL_SEPARATOR___]
model = LogisticRegression(n_jobs=-1)
model.fit(x_train, y_train)
y_pred = model.predict(test_data)
v_pred = model.predict(x_val)

print('Validation Results')
print('Accuracy: {}'.format(model.score(x_val, y_val)))
print('Recall: {}'.format(recall_score(y_val, model.predict(x_val))))
print('Precision: {}'.format(precision_score(y_val, v_pred, average='micro')))
print('f1: {}'.format(f1_score(y_val, v_pred, average='micro')))
print(confusion_matrix(y_val, v_pred))

print('\nTest Results')
print('Accuracy: {}'.format(model.score(test_data, test_target)))
print('Recall: {}'.format(recall_score(test_target, model.predict(test_data))))
print('Precision: {}'.format(precision_score(test_target, y_pred, average='micro')))
print('f1: {}'.format(f1_score(test_target, y_pred, average='micro')))
print(confusion_matrix(test_target, y_pred))
# [___CELL_SEPARATOR___]
model = LogisticRegression(n_jobs=-1)
model.fit(new_ccdata, new_cctarget)
y_pred = model.predict(test_data)
v_pred = model.predict(x_val)

print('Validation Results')
print('Accuracy: {}'.format(model.score(x_val, y_val)))
print('Recall: {}'.format(recall_score(y_val, model.predict(x_val))))
print('Precision: {}'.format(precision_score(y_val, v_pred, average='micro')))
print('f1: {}'.format(f1_score(y_val, v_pred, average='micro')))
print(confusion_matrix(y_val, v_pred))

print('\nTest Results')
print('Accuracy: {}'.format(model.score(test_data, test_target)))
print('Recall: {}'.format(recall_score(test_target, model.predict(test_data))))
print('Precision: {}'.format(precision_score(test_target, y_pred, average='micro')))
print('f1: {}'.format(f1_score(test_target, y_pred, average='micro')))
print(confusion_matrix(test_target, y_pred))
# [___CELL_SEPARATOR___]
model = LogisticRegression(n_jobs=-1)
model.fit(cc_smote, cc_smote_target)
y_pred = model.predict(test_data)
v_pred = model.predict(x_val)

print('Validation Results')
print('Accuracy: {}'.format(model.score(x_val, y_val)))
print('Recall: {}'.format(recall_score(y_val, model.predict(x_val))))
print('Precision: {}'.format(precision_score(y_val, v_pred, average='micro')))
print('f1: {}'.format(f1_score(y_val, v_pred, average='micro')))
print(confusion_matrix(y_val, v_pred))

print('\nTest Results')
print('Accuracy: {}'.format(model.score(test_data, test_target)))
print('Recall: {}'.format(recall_score(test_target, model.predict(test_data))))
print('Precision: {}'.format(precision_score(test_target, y_pred, average='micro')))
print('f1: {}'.format(f1_score(test_target, y_pred, average='micro')))
print(confusion_matrix(test_target, y_pred))
# [___CELL_SEPARATOR___]
model = LogisticRegression(class_weight= {0:.01, 1:.99},n_jobs=-1)
model.fit(x_train, y_train)
y_pred = model.predict(test_data)
v_pred = model.predict(x_val)

print('Validation Results')
print('Accuracy: {}'.format(model.score(x_val, y_val)))
print('Recall: {}'.format(recall_score(y_val, model.predict(x_val))))
print('Precision: {}'.format(precision_score(y_val, v_pred, average='micro')))
print('f1: {}'.format(f1_score(y_val, v_pred, average='micro')))
print(confusion_matrix(y_val, v_pred))

print('\nTest Results')
print('Accuracy: {}'.format(model.score(test_data, test_target)))
print('Recall: {}'.format(recall_score(test_target, model.predict(test_data))))
print('Precision: {}'.format(precision_score(test_target, y_pred, average='micro')))
print('f1: {}'.format(f1_score(test_target, y_pred, average='micro')))
print(confusion_matrix(test_target, y_pred))
# [___CELL_SEPARATOR___]
model = DecisionTreeClassifier()
model.fit(x_train, y_train)
y_pred = model.predict(test_data)
v_pred = model.predict(x_val)

print('Validation Results')
print('Accuracy: {}'.format(model.score(x_val, y_val)))
print('Recall: {}'.format(recall_score(y_val, model.predict(x_val))))
print('Precision: {}'.format(precision_score(y_val, v_pred, average='micro')))
print('f1: {}'.format(f1_score(y_val, v_pred, average='micro')))
print(confusion_matrix(y_val, v_pred))

print('\nTest Results')
print('Accuracy: {}'.format(model.score(test_data, test_target)))
print('Recall: {}'.format(recall_score(test_target, model.predict(test_data))))
print('Precision: {}'.format(precision_score(test_target, y_pred, average='micro')))
print('f1: {}'.format(f1_score(test_target, y_pred, average='micro')))
print(confusion_matrix(test_target, y_pred))
# [___CELL_SEPARATOR___]
model = RandomForestClassifier()
model.fit(x_train, y_train)
y_pred = model.predict(test_data)
v_pred = model.predict(x_val)

print('Validation Results')
print('Accuracy: {}'.format(model.score(x_val, y_val)))
print('Recall: {}'.format(recall_score(y_val, model.predict(x_val))))
print('Precision: {}'.format(precision_score(y_val, v_pred, average='micro')))
print('f1: {}'.format(f1_score(y_val, v_pred, average='micro')))
print(confusion_matrix(y_val, v_pred))

print('\nTest Results')
print('Accuracy: {}'.format(model.score(test_data, test_target)))
print('Recall: {}'.format(recall_score(test_target, model.predict(test_data))))
print('Precision: {}'.format(precision_score(test_target, y_pred, average='micro')))
print('f1: {}'.format(f1_score(test_target, y_pred, average='micro')))
print(confusion_matrix(test_target, y_pred))
# [___CELL_SEPARATOR___]
model = BalancedBaggingClassifier(base_estimator=DecisionTreeClassifier(), random_state=0, n_jobs=-1)
model.fit(x_train, y_train)
y_pred = model.predict(test_data)
v_pred = model.predict(x_val)

print('Validation Results')
print('Accuracy: {}'.format(model.score(x_val, y_val)))
print('Recall: {}'.format(recall_score(y_val, model.predict(x_val))))
print('Precision: {}'.format(precision_score(y_val, v_pred, average='micro')))
print('f1: {}'.format(f1_score(y_val, v_pred, average='micro')))
print(confusion_matrix(y_val, v_pred))

print('\nTest Results')
print('Accuracy: {}'.format(model.score(test_data, test_target)))
print('Recall: {}'.format(recall_score(test_target, model.predict(test_data))))
print('Precision: {}'.format(precision_score(test_target, y_pred, average='micro')))
print('f1: {}'.format(f1_score(test_target, y_pred, average='micro')))
print(confusion_matrix(test_target, y_pred))
# [___CELL_SEPARATOR___]
model = BalancedRandomForestClassifier(n_estimators=100, random_state=0, n_jobs=-1)
model.fit(x_train, y_train)
y_pred = model.predict(test_data)
v_pred = model.predict(x_val)

print('Validation Results')
print('Accuracy: {}'.format(model.score(x_val, y_val)))
print('Recall: {}'.format(recall_score(y_val, model.predict(x_val))))
print('Precision: {}'.format(precision_score(y_val, v_pred, average='micro')))
print('f1: {}'.format(f1_score(y_val, v_pred, average='micro')))
print(confusion_matrix(y_val, v_pred))

print('\nTest Results')
print('Accuracy: {}'.format(model.score(test_data, test_target)))
print('Recall: {}'.format(recall_score(test_target, model.predict(test_data))))
print('Precision: {}'.format(precision_score(test_target, y_pred, average='micro')))
print('f1: {}'.format(f1_score(test_target, y_pred, average='micro')))
print(confusion_matrix(test_target, y_pred))
# [___CELL_SEPARATOR___]
w_training_data, w_test_data, q_training_target, q_test_target = train_test_split(data, qtarget, test_size = .2, random_state=42)
w_x_train, w_x_val, q_y_train, q_y_val = train_test_split(w_training_data, q_training_target, test_size = .1, random_state=42)
# [___CELL_SEPARATOR___]
#Basic Logistic Regression
start = time.time()

x = data
y = qtarget
folds = StratifiedKFold(n_splits=5, shuffle=True, random_state=59)
measured= np.zeros((x.shape[0]))
score = 0

for times, (trn_idx, val_idx) in enumerate(folds.split(x.values,y.values)):
    model = LogisticRegression(n_jobs=-1)
    model.fit(x.iloc[trn_idx],y[trn_idx])
    measured[val_idx] = model.predict(x.iloc[val_idx])
    score += model.score(x.iloc[val_idx],y[val_idx])
    print("Fold: {} score: {}".format(times,model.score(x.iloc[val_idx],y[val_idx])))

    gc.collect()

print('Avg Accuracy RF', score / folds.n_splits)

end = time.time()
print('It took {} seconds'.format(end - start))
# [___CELL_SEPARATOR___]
#Basic Lasso
start = time.time()

x = data
y = qtarget
folds = KFold(n_splits=5, shuffle=True, random_state=59)
measured= np.zeros((x.shape[0]))
score = 0

for times, (trn_idx, val_idx) in enumerate(folds.split(x.values,y.values)):
    model = Lasso()
    model.fit(x.iloc[trn_idx],y[trn_idx])
    measured[val_idx] = model.predict(x.iloc[val_idx])
    score += model.score(x.iloc[val_idx],y[val_idx])
    print("Fold: {} score: {}".format(times,model.score(x.iloc[val_idx],y[val_idx])))

    gc.collect()
    
print('Avg Accuracy RF', score / folds.n_splits)

end = time.time()
print('It took {} seconds'.format(end - start))
# [___CELL_SEPARATOR___]
#Basic Decision Tree
start = time.time()

x = data
y = qtarget
folds = KFold(n_splits=5, shuffle=True, random_state=59)
measured= np.zeros((x.shape[0]))
score = 0

for times, (trn_idx, val_idx) in enumerate(folds.split(x.values,y.values)):
    model = DecisionTreeClassifier()
    model.fit(x.iloc[trn_idx],y[trn_idx])
    measured[val_idx] = model.predict(x.iloc[val_idx])
    score += model.score(x.iloc[val_idx],y[val_idx])
    print("Fold: {} score: {}".format(times,model.score(x.iloc[val_idx],y[val_idx])))

    gc.collect()
    
print('Avg Accuracy RF', score / folds.n_splits)

end = time.time()
print('It took {} seconds'.format(end - start))
# [___CELL_SEPARATOR___]
#Basic Linear SVC
start = time.time()

x = data
y = qtarget
folds = KFold(n_splits=5, shuffle=True, random_state=59)
measured= np.zeros((x.shape[0]))
score = 0

for times, (trn_idx, val_idx) in enumerate(folds.split(x.values,y.values)):
    model = LinearSVC()
    model.fit(x.iloc[trn_idx],y[trn_idx])
    measured[val_idx] = model.predict(x.iloc[val_idx])
    score += model.score(x.iloc[val_idx],y[val_idx])
    print("Fold: {} score: {}".format(times,model.score(x.iloc[val_idx],y[val_idx])))

    gc.collect()
    
print('Avg Accuracy RF', score / folds.n_splits)

end = time.time()
print('It took {} seconds'.format(end - start))
# [___CELL_SEPARATOR___]
#Basic K Nearest Neighbor
start = time.time()

x = data
y = qtarget
folds = KFold(n_splits=5, shuffle=True, random_state=59)
measured= np.zeros((x.shape[0]))
score = 0

for times, (trn_idx, val_idx) in enumerate(folds.split(x.values,y.values)):
    model = KNeighborsClassifier()
    model.fit(x.iloc[trn_idx],y[trn_idx])
    measured[val_idx] = model.predict(x.iloc[val_idx])
    score += model.score(x.iloc[val_idx],y[val_idx])
    print("Fold: {} score: {}".format(times,model.score(x.iloc[val_idx],y[val_idx])))

    gc.collect()
    
print('Avg Accuracy RF', score / folds.n_splits)

end = time.time()
print('It took {} seconds'.format(end - start))
# [___CELL_SEPARATOR___]
#Basic Random Forest
start = time.time()

x = data
y = qtarget
folds = KFold(n_splits=5, shuffle=True, random_state=59)
measured= np.zeros((x.shape[0]))
score = 0

for times, (trn_idx, val_idx) in enumerate(folds.split(x.values,y.values)):
    model = RandomForestClassifier(n_jobs=-1)
    model.fit(x.iloc[trn_idx],y[trn_idx])
    measured[val_idx] = model.predict(x.iloc[val_idx])
    score += model.score(x.iloc[val_idx],y[val_idx])
    print("Fold: {} score: {}".format(times,model.score(x.iloc[val_idx],y[val_idx])))

    gc.collect()
    
print('Avg Accuracy RF', score / folds.n_splits)

end = time.time()
print('It took {} seconds'.format(end - start))
# [___CELL_SEPARATOR___]
# Sci Kit Learn's Grid Search for Decision Tree classifier

start = time.time()

parameters = {
    'max_depth': [80, 120, None],
    'max_features': ['auto', None],
    'min_samples_leaf': [3, 25, 50],
    'min_samples_split': [8, 10, 12]
}
model = GridSearchCV(DecisionTreeClassifier(), parameters, scoring='accuracy', cv=5, n_jobs=-1)
model.fit(data, qtarget)
end = time.time()
print('It took {} seconds'.format(end - start))
model.best_estimator_
# [___CELL_SEPARATOR___]
# Sci Kit Learn's Grid Search for Logistic Regression

start = time.time()

parameters = {
    'tol': [1e-4, 1e-5, 1e-3],
    'C': [.001, .01, .1, 1, 10, 100],
    'max_iter': [100, 200, 50]
}
model = GridSearchCV(LogisticRegression(), parameters, scoring='accuracy', cv=5, n_jobs=-1)
model.fit(data, qtarget)
end = time.time()
print('It took {} seconds'.format(end - start))
model.best_estimator_
# [___CELL_SEPARATOR___]
# Sci Kit Learn's Grid Search for Random Forest
#This script could take an hour or more to exectute
start = time.time()

parameters = {
    'criterion': ['gini','entropy'],
    'bootstrap': [True, False],
    'max_depth': [120, None],
    'max_features': ['auto', None],
    'min_samples_leaf': [1, 2, 3],
    'min_samples_split': [2, 4, 8],
    'n_estimators': [100, 500, 1000]
}
model = GridSearchCV(RandomForestClassifier(), parameters, scoring='accuracy', cv=3, n_jobs=-1)
model.fit(data, qtarget)
end = time.time()
print('It took {} seconds'.format(end - start))
model.best_estimator_

# [___CELL_SEPARATOR___]
# Our custom grid search for Random Forest
#This script takes a long time to run.
start = time.time()

grid = {
    'criterion': ['gini','entropy'],
    'bootstrap': [True, False],
    'max_depth': [120, None],
    'max_features': ['auto', None],
    'min_samples_leaf': [1, 2, 3],
    'min_samples_split': [2, 4, 8],
    'n_estimators': [100, 500, 1000],
    'n_jobs': [-1]
}

rf = RandomForestClassifier()
best_score = 0

for g in ParameterGrid(grid):
    rf.set_params(**g)
    rf.fit(w_x_train, q_y_train)
    if rf.score(w_test_data, q_test_target) > best_score:
        best_score = rf.score(w_test_data, q_test_target)
        best_grid = g

end = time.time()
print('It took {} seconds'.format(end - start))
best_grid
# [___CELL_SEPARATOR___]
# Our custom grid search for Decision Trees
start = time.time()

grid = {
    'max_depth': [80, 120, None],
    'max_features': ['auto', None],
    'min_samples_leaf': [3, 25, 50],
    'min_samples_split': [8, 10, 12]
}

dt = DecisionTreeClassifier()
best_score = 0

for g in ParameterGrid(grid):
    dt.set_params(**g)
    dt.fit(w_x_train, q_y_train)
    if dt.score(w_test_data, q_test_target) > best_score:
        best_score = dt.score(w_test_data, q_test_target)
        best_grid = g

end = time.time()
print('It took {} seconds'.format(end - start))
best_grid
# [___CELL_SEPARATOR___]
# Our custom grid search for Logistic Regression
start = time.time()

grid = {
    'tol': [1e-4, 1e-5, 1e-3],
    'C': [.001, .01, .1, 1, 10, 100],
    'max_iter': [100, 200, 50],
    'n_jobs': [-1]
}

lg = LogisticRegression()
best_score = 0

for g in ParameterGrid(grid):
    lg.set_params(**g)
    lg.fit(w_x_train, q_y_train)
    if lg.score(w_test_data, q_test_target) > best_score:
        best_score = lg.score(w_test_data, q_test_target)
        best_grid = g

end = time.time()
print('It took {} seconds'.format(end - start))
best_grid
# [___CELL_SEPARATOR___]
#Our baseline random forest classifier
start = time.time()

model = RandomForestClassifier(n_jobs=-1)
model.fit(w_x_train, q_y_train)
y_pred = model.predict(w_test_data)
v_pred = model.predict(w_x_val)

print('Validation Results')
print('Accuracy: {}'.format(model.score(w_x_val, q_y_val)))
print('Recall: {}'.format(recall_score(q_y_val, model.predict(w_x_val))))
print('Precision: {}'.format(precision_score(q_y_val, v_pred, average='micro')))
print('f1: {}'.format(f1_score(q_y_val, v_pred, average='micro')))
print(confusion_matrix(q_y_val, v_pred))

print('\nTest Results')
print('Accuracy: {}'.format(model.score(w_test_data, q_test_target)))
print('Recall: {}'.format(recall_score(q_test_target, model.predict(w_test_data))))
print('Precision: {}'.format(precision_score(q_test_target, y_pred, average='micro')))
print('f1: {}'.format(f1_score(q_test_target, y_pred, average='micro')))
print(confusion_matrix(q_test_target, y_pred))

end = time.time()
print('It took {} seconds'.format(end - start))
# [___CELL_SEPARATOR___]
#Our custom grid search random forest classifier.
start = time.time()

# These parameters came from the grid search's output.
model = RandomForestClassifier(bootstrap=False, ccp_alpha=0.0, class_weight=None,
                       criterion='entropy', max_depth=120, max_features='auto',
                       max_leaf_nodes=None, max_samples=None,
                       min_impurity_decrease=0.0, min_impurity_split=None,
                       min_samples_leaf=1, min_samples_split=8,
                       min_weight_fraction_leaf=0.0, n_estimators=1000,
                       n_jobs=-1, oob_score=False, random_state=None,
                       verbose=0, warm_start=False)
model.fit(w_x_train, q_y_train)
y_pred = model.predict(w_test_data)
v_pred = model.predict(w_x_val)

print('Validation Results')
print('Accuracy: {}'.format(model.score(w_x_val, q_y_val)))
print('Recall: {}'.format(recall_score(q_y_val, model.predict(w_x_val))))
print('Precision: {}'.format(precision_score(q_y_val, v_pred, average='micro')))
print('f1: {}'.format(f1_score(q_y_val, v_pred, average='micro')))
print(confusion_matrix(q_y_val, v_pred))

print('\nTest Results')
print('Accuracy: {}'.format(model.score(w_test_data, q_test_target)))
print('Recall: {}'.format(recall_score(q_test_target, model.predict(w_test_data))))
print('Precision: {}'.format(precision_score(q_test_target, y_pred, average='micro')))
print('f1: {}'.format(f1_score(q_test_target, y_pred, average='micro')))
print(confusion_matrix(q_test_target, y_pred))

end = time.time()
print('It took {} seconds'.format(end - start))
# [___CELL_SEPARATOR___]
#SKLearn's grid search random forest classifier.
start = time.time()

# These parameters came from the grid search's output.
model = RandomForestClassifier(bootstrap=False, ccp_alpha=0.0, class_weight=None,
                       criterion='entropy', max_depth=None, max_features='auto',
                       max_leaf_nodes=None, max_samples=None,
                       min_impurity_decrease=0.0, min_impurity_split=None,
                       min_samples_leaf=1, min_samples_split=2,
                       min_weight_fraction_leaf=0.0, n_estimators=500,
                       n_jobs=-1, oob_score=False, random_state=None,
                       verbose=0, warm_start=False)
model.fit(w_x_train, q_y_train)
y_pred = model.predict(w_test_data)
v_pred = model.predict(w_x_val)

print('Validation Results')
print('Accuracy: {}'.format(model.score(w_x_val, q_y_val)))
print('Recall: {}'.format(recall_score(q_y_val, model.predict(w_x_val))))
print('Precision: {}'.format(precision_score(q_y_val, v_pred, average='micro')))
print('f1: {}'.format(f1_score(q_y_val, v_pred, average='micro')))
print(confusion_matrix(q_y_val, v_pred))

print('\nTest Results')
print('Accuracy: {}'.format(model.score(w_test_data, q_test_target)))
print('Recall: {}'.format(recall_score(q_test_target, model.predict(w_test_data))))
print('Precision: {}'.format(precision_score(q_test_target, y_pred, average='micro')))
print('f1: {}'.format(f1_score(q_test_target, y_pred, average='micro')))
print(confusion_matrix(q_test_target, y_pred))

end = time.time()
print('It took {} seconds'.format(end - start))
# [___CELL_SEPARATOR___]
#Baseline decision tree classifier.
start = time.time()

model = DecisionTreeClassifier()
model.fit(w_x_train, q_y_train)
y_pred = model.predict(w_test_data)
v_pred = model.predict(w_x_val)

print('Validation Results')
print('Accuracy: {}'.format(model.score(w_x_val, q_y_val)))
print('Recall: {}'.format(recall_score(q_y_val, model.predict(w_x_val))))
print('Precision: {}'.format(precision_score(q_y_val, v_pred, average='micro')))
print('f1: {}'.format(f1_score(q_y_val, v_pred, average='micro')))
print(confusion_matrix(q_y_val, v_pred))

print('\nTest Results')
print('Accuracy: {}'.format(model.score(w_test_data, q_test_target)))
print('Recall: {}'.format(recall_score(q_test_target, model.predict(w_test_data))))
print('Precision: {}'.format(precision_score(q_test_target, y_pred, average='micro')))
print('f1: {}'.format(f1_score(q_test_target, y_pred, average='micro')))
print(confusion_matrix(q_test_target, y_pred))

end = time.time()
print('It took {} seconds'.format(end - start))
# [___CELL_SEPARATOR___]
#Custom decision tree classifier.
start = time.time()

# These parameters came from the grid search's output.
model = DecisionTreeClassifier(ccp_alpha=0.0, class_weight=None, criterion='gini',
                       max_depth=None, max_features=None, max_leaf_nodes=None,
                       min_impurity_decrease=0.0, min_impurity_split=None,
                       min_samples_leaf=3, min_samples_split=8,
                       min_weight_fraction_leaf=0.0, presort='deprecated',
                       random_state=None, splitter='best')
model.fit(w_x_train, q_y_train)
y_pred = model.predict(w_test_data)
v_pred = model.predict(w_x_val)

print('Validation Results')
print('Accuracy: {}'.format(model.score(w_x_val, q_y_val)))
print('Recall: {}'.format(recall_score(q_y_val, model.predict(w_x_val))))
print('Precision: {}'.format(precision_score(q_y_val, v_pred, average='micro')))
print('f1: {}'.format(f1_score(q_y_val, v_pred, average='micro')))
print(confusion_matrix(q_y_val, v_pred))

print('\nTest Results')
print('Accuracy: {}'.format(model.score(w_test_data, q_test_target)))
print('Recall: {}'.format(recall_score(q_test_target, model.predict(w_test_data))))
print('Precision: {}'.format(precision_score(q_test_target, y_pred, average='micro')))
print('f1: {}'.format(f1_score(q_test_target, y_pred, average='micro')))
print(confusion_matrix(q_test_target, y_pred))

end = time.time()
print('It took {} seconds'.format(end - start))
# [___CELL_SEPARATOR___]
#Custom logistic  regression
start = time.time()

# These parameters came from the grid search's output.
model = LogisticRegression(C=100, class_weight=None, dual=False, fit_intercept=True,
                   intercept_scaling=1, l1_ratio=None, max_iter=200,
                   multi_class='auto', n_jobs=None, penalty='l2',
                   random_state=None, solver='lbfgs', tol=0.0001, verbose=0,
                   warm_start=False)
model.fit(w_x_train, q_y_train)
y_pred = model.predict(w_test_data)
v_pred = model.predict(w_x_val)

print('Validation Results')
print('Accuracy: {}'.format(model.score(w_x_val, q_y_val)))
print('Recall: {}'.format(recall_score(q_y_val, model.predict(w_x_val))))
print('Precision: {}'.format(precision_score(q_y_val, v_pred, average='micro')))
print('f1: {}'.format(f1_score(q_y_val, v_pred, average='micro')))
print(confusion_matrix(q_y_val, v_pred))

print('\nTest Results')
print('Accuracy: {}'.format(model.score(w_test_data, q_test_target)))
print('Recall: {}'.format(recall_score(q_test_target, model.predict(w_test_data))))
print('Precision: {}'.format(precision_score(q_test_target, y_pred, average='micro')))
print('f1: {}'.format(f1_score(q_test_target, y_pred, average='micro')))
print(confusion_matrix(q_test_target, y_pred))

end = time.time()
print('It took {} seconds'.format(end - start))
# [___CELL_SEPARATOR___]
# Baseline Credit Card Data Decision Tree Classifier.
start = time.time()

model = DecisionTreeClassifier()
model.fit(x_train, y_train)
y_pred = model.predict(test_data)
v_pred = model.predict(x_val)

print('Validation Results')
print('Accuracy: {}'.format(model.score(x_val, y_val)))
print('Recall: {}'.format(recall_score(y_val, model.predict(x_val))))
print('Precision: {}'.format(precision_score(y_val, v_pred, average='micro')))
print('f1: {}'.format(f1_score(y_val, v_pred, average='micro')))
print(confusion_matrix(y_val, v_pred))

print('\nTest Results')
print('Accuracy: {}'.format(model.score(test_data, test_target)))
print('Recall: {}'.format(recall_score(test_target, model.predict(test_data))))
print('Precision: {}'.format(precision_score(test_target, y_pred, average='micro')))
print('f1: {}'.format(f1_score(test_target, y_pred, average='micro')))
print(confusion_matrix(test_target, y_pred))

end = time.time()
print('It took {} seconds'.format(end - start))
# [___CELL_SEPARATOR___]
# Decision Tree Classifier with classes weighted .2:.8
start = time.time()

model = DecisionTreeClassifier(class_weight= {0:.2, 1:.8})
model.fit(x_train, y_train)
y_pred = model.predict(test_data)
v_pred = model.predict(x_val)

print('Validation Results')
print('Accuracy: {}'.format(model.score(x_val, y_val)))
print('Recall: {}'.format(recall_score(y_val, model.predict(x_val))))
print('Precision: {}'.format(precision_score(y_val, v_pred, average='micro')))
print('f1: {}'.format(f1_score(y_val, v_pred, average='micro')))
print(confusion_matrix(y_val, v_pred))

print('\nTest Results')
print('Accuracy: {}'.format(model.score(test_data, test_target)))
print('Recall: {}'.format(recall_score(test_target, model.predict(test_data))))
print('Precision: {}'.format(precision_score(test_target, y_pred, average='micro')))
print('f1: {}'.format(f1_score(test_target, y_pred, average='micro')))
print(confusion_matrix(test_target, y_pred))

end = time.time()
print('It took {} seconds'.format(end - start))
# [___CELL_SEPARATOR___]
# Random Forest Classifier with Smote data
#this is a long running script.
start = time.time()

model = RandomForestClassifier()
model.fit(cc_smote, cc_smote_target)
y_pred = model.predict(test_data)
v_pred = model.predict(x_val)

print('Validation Results')
print('Accuracy: {}'.format(model.score(x_val, y_val)))
print('Recall: {}'.format(recall_score(y_val, model.predict(x_val))))
print('Precision: {}'.format(precision_score(y_val, v_pred, average='micro')))
print('f1: {}'.format(f1_score(y_val, v_pred, average='micro')))
print(confusion_matrix(y_val, v_pred))

print('\nTest Results')
print('Accuracy: {}'.format(model.score(test_data, test_target)))
print('Recall: {}'.format(recall_score(test_target, model.predict(test_data))))
print('Precision: {}'.format(precision_score(test_target, y_pred, average='micro')))
print('f1: {}'.format(f1_score(test_target, y_pred, average='micro')))
print(confusion_matrix(test_target, y_pred))

end = time.time()
print('It took {} seconds'.format(end - start))
# [___CELL_SEPARATOR___]
# Random Forest Classifier with classes weighted .2:.8 and smote data
# this is a long running script.
start = time.time()

model = RandomForestClassifier(class_weight= {0:.2, 1:.8})
model.fit(cc_smote, cc_smote_target)
y_pred = model.predict(test_data)
v_pred = model.predict(x_val)

print('Validation Results')
print('Accuracy: {}'.format(model.score(x_val, y_val)))
print('Recall: {}'.format(recall_score(y_val, model.predict(x_val))))
print('Precision: {}'.format(precision_score(y_val, v_pred, average='micro')))
print('f1: {}'.format(f1_score(y_val, v_pred, average='micro')))
print(confusion_matrix(y_val, v_pred))

print('\nTest Results')
print('Accuracy: {}'.format(model.score(test_data, test_target)))
print('Recall: {}'.format(recall_score(test_target, model.predict(test_data))))
print('Precision: {}'.format(precision_score(test_target, y_pred, average='micro')))
print('f1: {}'.format(f1_score(test_target, y_pred, average='micro')))
print(confusion_matrix(test_target, y_pred))

end = time.time()
print('It took {} seconds'.format(end - start))
# [___CELL_SEPARATOR___]
# Random Forest Classifier with smote data and 1,000 estimators and bootstrap False
# This is a long running script.
start = time.time()

model = RandomForestClassifier(n_estimators=1000, bootstrap=False, n_jobs=-1)
model.fit(cc_smote, cc_smote_target)
y_pred = model.predict(test_data)
v_pred = model.predict(x_val)

print('Validation Results')
print('Accuracy: {}'.format(model.score(x_val, y_val)))
print('Recall: {}'.format(recall_score(y_val, model.predict(x_val))))
print('Precision: {}'.format(precision_score(y_val, v_pred, average='micro')))
print('f1: {}'.format(f1_score(y_val, v_pred, average='micro')))
print(confusion_matrix(y_val, v_pred))

print('\nTest Results')
print('Accuracy: {}'.format(model.score(test_data, test_target)))
print('Recall: {}'.format(recall_score(test_target, model.predict(test_data))))
print('Precision: {}'.format(precision_score(test_target, y_pred, average='micro')))
print('f1: {}'.format(f1_score(test_target, y_pred, average='micro')))
print(confusion_matrix(test_target, y_pred))

end = time.time()
print('It took {} seconds'.format(end - start))
# [___CELL_SEPARATOR___]
# Random Forest Classifier with the random undersampled data
start = time.time()

model = RandomForestClassifier()
model.fit(new_ccdata, new_cctarget)
y_pred = model.predict(test_data)
v_pred = model.predict(x_val)

print('Validation Results')
print('Accuracy: {}'.format(model.score(x_val, y_val)))
print('Recall: {}'.format(recall_score(y_val, model.predict(x_val))))
print('Precision: {}'.format(precision_score(y_val, v_pred, average='micro')))
print('f1: {}'.format(f1_score(y_val, v_pred, average='micro')))
print(confusion_matrix(y_val, v_pred))

print('\nTest Results')
print('Accuracy: {}'.format(model.score(test_data, test_target)))
print('Recall: {}'.format(recall_score(test_target, model.predict(test_data))))
print('Precision: {}'.format(precision_score(test_target, y_pred, average='micro')))
print('f1: {}'.format(f1_score(test_target, y_pred, average='micro')))
print(confusion_matrix(test_target, y_pred))

end = time.time()
print('It took {} seconds'.format(end - start))
# [___CELL_SEPARATOR___]
# Custom Grid search to find the best random forest model with the undersampled data.
#This is a long running script.
start = time.time()

grid = {
    'criterion': ['gini','entropy'],
    'bootstrap': [True, False],
    'max_depth': [120, None],
    'max_features': ['auto', None],
    'min_samples_leaf': [1, 2, 3],
    'min_samples_split': [2, 4, 8],
    'n_estimators': [100, 500, 1000],
    'n_jobs': [-1]
}

rf = RandomForestClassifier()
best_score = 0

for g in ParameterGrid(grid):
    rf.set_params(**g)
    rf.fit(new_ccdata, new_cctarget)
    # save if best
    if rf.score(test_data, test_target) > best_score:
        best_score = rf.score(test_data, test_target)
        best_grid = g

end = time.time()
print('It took {} seconds'.format(end - start))
best_grid
# [___CELL_SEPARATOR___]
# Our best custom random forest model for the undersampled dataset. Also our best model for this data! 
start = time.time()

model = RandomForestClassifier(bootstrap=False, ccp_alpha=0.0, class_weight=None,
                       criterion='entropy', max_depth=None, max_features='auto',
                       max_leaf_nodes=None, max_samples=None,
                       min_impurity_decrease=0.0, min_impurity_split=None,
                       min_samples_leaf=6, min_samples_split=4,
                       min_weight_fraction_leaf=0.0, n_estimators=1000,
                       n_jobs=-1, oob_score=False, random_state=None,
                       verbose=0, warm_start=False)
model.fit(new_ccdata, new_cctarget)
y_pred = model.predict(test_data)
v_pred = model.predict(x_val)

print('Validation Results')
print('Accuracy: {}'.format(model.score(x_val, y_val)))
print('Recall: {}'.format(recall_score(y_val, model.predict(x_val))))
print('Precision: {}'.format(precision_score(y_val, v_pred, average='micro')))
print('f1: {}'.format(f1_score(y_val, v_pred, average='micro')))
print(confusion_matrix(y_val, v_pred))

print('\nTest Results')
print('Accuracy: {}'.format(model.score(test_data, test_target)))
print('Recall: {}'.format(recall_score(test_target, model.predict(test_data))))
print('Precision: {}'.format(precision_score(test_target, y_pred, average='micro')))
print('f1: {}'.format(f1_score(test_target, y_pred, average='micro')))
print(confusion_matrix(test_target, y_pred))

end = time.time()
print('It took {} seconds'.format(end - start))