from github import Github
import datetime
import csv
import sys
from lxml import html
import json
import yaml
from configparser import ConfigParser 
import os
import pandas as pd

FILTER_LABELS=("Accettato",)

try:
    config=ConfigParser()
    config.read('../../.github.cfg')

    TOKEN=config.get('GitHub','TOKEN')
    USER=config.get('GitHub','USER')
    REPO_NAME=config.get('GitHub','REPO_NAME')
    ORG=config.get('GitHub','ORG')
except Exception as m:
    print(m)
    TOKEN=os.environ.get('GITHUB_PASSWORD')
    USER=os.environ.get('GITHUB_USERNAME')
    REPO_NAME='terremotocentro_segnalazioni'
    ORG='emergenzeHack'

if not TOKEN:
    print ("Need a TOKEN")
    sys.exit(1)

if not USER:
    print ("Need a USER")
    sys.exit(1)

if not REPO_NAME:
    print ("Need a REPO_NAME")
    sys.exit(1)

if not ORG:
    print ("Need a ORG")
    sys.exit(1)

CSVFILE=sys.argv[1]

try:
    JSONFILE=sys.argv[2]
    jwr=file(JSONFILE,"w+")
except:
    jwr=None

try:
    GEOJSONFILE=sys.argv[3]
    gjwr=file(GEOJSONFILE,"w+")
except:
    gjwr=None


g = Github(USER, TOKEN)
org=g.get_organization(ORG)
r = org.get_repo(REPO_NAME)
# [___CELL_SEPARATOR___]
donazioni=pd.read_csv("Mappatura_resilienzacomunitaria - donazioni.csv")
# [___CELL_SEPARATOR___]
donazioni.columns
# [___CELL_SEPARATOR___]
for i,row in donazioni.fillna("").iterrows():
    y='<pre><yamldata>'+yaml.dump(dict(row))+'</yamldata></pre>'
    #print (dict(row))
    try:
        r.create_issue(title=row['descrizione'], body=y,labels=[row['tag']])
    except Exception as m:
        print(m)
        pass

    

# [___CELL_SEPARATOR___]
ii=pd.read_csv("Mappatura_resilienzacomunitaria - iniziative istituzionali.csv")
# [___CELL_SEPARATOR___]
ii.head()
# [___CELL_SEPARATOR___]
for i,row in ii.fillna("").iterrows():
    y='<pre><yamldata>'+yaml.dump(dict(row))+'</yamldata></pre>'
    #print (dict(row))
    try:
        r.create_issue(title=row['descrizione'], body=y,labels=[row['tag']])
    except Exception as m:
        print(m)
        pass
# [___CELL_SEPARATOR___]
insolidali=pd.read_csv('Mappatura_resilienzacomunitaria - Iniziative solidali.csv')
# [___CELL_SEPARATOR___]
insolidali.head()
# [___CELL_SEPARATOR___]
for i,row in insolidali.fillna("").iterrows():
    y='<pre><yamldata>'+yaml.dump(dict(row))+'</yamldata></pre>'
    #print (dict(row))
    try:
        r.create_issue(title=row['descrizione'], body=y,labels=[row['tag']])
    except Exception as m:
        print(m)
        pass
# [___CELL_SEPARATOR___]
