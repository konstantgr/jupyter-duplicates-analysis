!python --version
# [___CELL_SEPARATOR___]
!cat ~/.keras/keras.json
# [___CELL_SEPARATOR___]
import numpy as np
import scipy as sp
import pandas as pd
import matplotlib.pyplot as plt
import sklearn
# [___CELL_SEPARATOR___]
import keras
# [___CELL_SEPARATOR___]
import numpy
print('numpy:', numpy.__version__)

import scipy
print('scipy:', scipy.__version__)

import matplotlib
print('matplotlib:', matplotlib.__version__)

import IPython
print('iPython:', IPython.__version__)

import sklearn
print('scikit-learn:', sklearn.__version__)
# [___CELL_SEPARATOR___]
import keras
print('keras: ', keras.__version__)

# optional
import theano
print('Theano: ', theano.__version__)

import tensorflow as tf
print('Tensorflow: ', tf.__version__)