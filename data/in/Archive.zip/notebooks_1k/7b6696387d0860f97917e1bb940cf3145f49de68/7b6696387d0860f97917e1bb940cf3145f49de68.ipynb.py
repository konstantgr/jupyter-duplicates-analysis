%matplotlib inline
import numpy as np
import pyross
import pandas as pd
import time
import matplotlib.pyplot as plt
from scipy.io import loadmat
# [___CELL_SEPARATOR___]
# population and age classes (4 age groups)
M=4  # number of age classes

my_data = np.genfromtxt('../data/age_structures/UK.csv', delimiter=',', skip_header=1)
aM, aF = my_data[:, 1], my_data[:, 2]

Ni0=aM+aF;   Ni=np.zeros((M))

Ni[0] = (np.sum(Ni0[0:4])).astype('int')
Ni[1] = (np.sum(Ni0[4:8])).astype('int')
Ni[2] = (np.sum(Ni0[8:12])).astype('int')
Ni[3] = (np.sum(Ni0[12:16])).astype('int')
N=np.sum(Ni)
fi = Ni/N 

# Get individual contact matrices
CH0, CW0, CS0, CO0 = pyross.contactMatrix.UK()

CH = np.zeros((M, M))
CW = np.zeros((M, M))
CS = np.zeros((M, M))
CO = np.zeros((M, M))

for i in range(16):
    CH0[i,:] = Ni0[i]*CH0[i,:]
    CS0[i,:] = Ni0[i]*CS0[i,:]
    CW0[i,:] = Ni0[i]*CW0[i,:]
    CO0[i,:] = Ni0[i]*CO0[i,:]

    
for i in range(M):
    for j in range(M):
        i1, j1 = i*4, j*4
        CH[i,j] = np.sum( CH0[i1:i1+4,j1:j1+4]  )/Ni[i]
        CW[i,j] = np.sum( CW0[i1:i1+4,j1:j1+4]  )/Ni[i]
        CS[i,j] = np.sum( CS0[i1:i1+4,j1:j1+4]  )/Ni[i]
        CO[i,j] = np.sum( CO0[i1:i1+4,j1:j1+4]  )/Ni[i]
# [___CELL_SEPARATOR___]
# Generate class with contact matrix for SIR model with UK contact structure
generator = pyross.contactMatrix.ContactMatrixFunction(CH, CW, CS, CO)
# [___CELL_SEPARATOR___]
T_intervention = 30
times= [T_intervention] # temporal boundaries between different contact-behaviour

aW, aS, aO = 0.8, 0.7, 0.7

# prefactors for CW, CS, CO:
interventions = [[1.0,1.0,1.0],      # before first time
                 [aW, aS, aO],       # after first time
                ]         

# generate corresponding contact matrix function
C = generator.interventions_temporal(times=times,interventions=interventions)
# [___CELL_SEPARATOR___]
beta  = 0.04       # contact rate parameter
gIa   = 1./7       # recovery rate of asymptomatic infectives 
gIs   = 1./7       # recovery rate of symptomatic infectives 
alpha = 0.2        # asymptomatic fraction
fsa   = 0.8        # suppresion of contact by symptomatics


# initial conditions    
Is_0 = np.ones(M)*20
Is_0[1] += 10  #make one group different 
Ia_0 = np.zeros((M))*2
Ia_0[1] += 2 
R_0  = np.zeros((M))
S_0  = Ni - (Ia_0 + Is_0 + R_0)

parameters = {'alpha':alpha,'beta':beta, 'gIa':gIa,'gIs':gIs,'fsa':fsa}
true_parameters = parameters
model = pyross.stochastic.SIR(parameters, M, Ni)

# start simulation
Tf=100;  Nf=Tf+1 
data=model.simulate(S_0, Ia_0, Is_0, C, Tf, Nf, method='tau-leaping')
# [___CELL_SEPARATOR___]
IC  = np.zeros((Nf))
for i in range(M):
        IC += data['X'][:,2*M+i] 
t = data['t']
plt.plot(t, IC)
plt.axvspan(0, T_intervention, 
           label='Pre intervention',
           alpha=0.3, color='dodgerblue')
plt.show() 
# [___CELL_SEPARATOR___]
Tf = 30 # truncate to only getting the first few datapoints (up to lockdown) 
Nf = Tf+1

x = data['X'].astype('float')
x = x[:Nf]

# initialise the estimator 
estimator = pyross.inference.SIR(parameters, M, Ni)

# compute -log_p for the original (correct) parameters 
start_time = time.time() 
parameters = {'alpha':alpha, 'beta':beta, 'gIa':gIa, 'gIs':gIs,'fsa':fsa}
logp = estimator.obtain_minus_log_p(parameters, x, Tf, C)
end_time = time.time()
print(logp) 
print(end_time - start_time)

# Check the deterministic simulation against stochstic simulations with the same parameters and initial conditons 
# They are likely to be different due to the inherent stochasticity of the model 
Tf_initial = T_intervention # truncate to only getting the pre-intervention trajectory 
Nf_initial = Tf_initial+1
contactMatrix = generator.constant_contactMatrix()
estimator.set_det_model(parameters)
estimator.set_contact_matrix(contactMatrix)
xm = estimator.integrate(x[0], 0, Tf_initial, Nf_initial)
t = np.linspace(0, Tf_initial, Nf_initial)
plt.plot(t, np.sum(x[:,2*M:3*M], axis=1))
plt.plot(t, np.sum(xm[:,2*M:3*M], axis=1))
plt.show()
# [___CELL_SEPARATOR___]
# take a guess 
eps = 1e-4 
priors = {
    'alpha':{
        'mean': 0.3, 
        'std': 0.2, 
        'bounds': [eps, 0.8]
    }, 
    'beta':{
        'mean': 0.05, 
        'std': 0.1, 
        'bounds': [eps, 0.2]
    }, 
    'gIa':{
        'mean': 0.1, 
        'std': 0.2, 
        'bounds': [eps, 0.6]
    }, 
    'gIs':{
        'mean': 0.2, 
        'std': 0.2, 
        'bounds': [eps, 0.6]
    }
}
estimator.set_lyapunov_method('euler')
start_time = time.time() 



#old function call: deprecated but still working (as a wrapper of infer)
#res = estimator.infer_parameters(x, Tf_initial, contactMatrix, priors, tangent=True, 
#                                    global_max_iter=20, local_max_iter=400,
#                                    cma_population=16, global_atol=1,
#                                    ftol=1e-6, verbose=True, cma_random_seed=413788650)
res = estimator.infer(x, Tf_initial, priors, contactMatrix=contactMatrix, tangent=True, 
                                    global_max_iter=20, local_max_iter=400,
                                    cma_population=16, global_atol=1,
                                    ftol=1e-6, verbose=True, cma_random_seed=413788650)
end_time = time.time()

print(res['params_dict']) # best guess 
print(end_time - start_time)
# [___CELL_SEPARATOR___]
print("True parameters:")
print(true_parameters)

print("\nInferred parameters:")
print(res['params_dict'])
# [___CELL_SEPARATOR___]
priors = {
    'aW':{
        'mean': 0.8, 
        'std': 0.1, 
        'bounds': [0.1, 1]
    }, 
    'aS':{
        'mean': 0.7,
        'std': 0.1, 
        'bounds': [0.1, 1]
    }, 
    'aO':{
        'mean': 0.7, 
        'std': 0.1, 
        'bounds': [0.1, 1]
    }
}

x = data['X'].astype('float')
x = x[T_intervention+1:]
Nf = x.shape[0] 
Tf = Nf-1 

contactMatrix = generator.constant_contactMatrix(aW=aW, aS=aS, aO=aO)

# compute -log_p for the initial guess (for the moment, use correct parameters)
logp = estimator.obtain_minus_log_p(parameters, x, Tf, contactMatrix)
print(logp) 
# [___CELL_SEPARATOR___]
eps = 1e-3 
start_time = time.time() 

best_estimates = res['params_dict']
estimator.set_params(best_estimates)
estimator.set_det_model(best_estimates)
# estimator.set_det_method('LSODA') # slower but performs better for exponential decay (near the end of the pandemic)
#old function call: deprecated but still working (as a wrapper of infer)
#res = estimator.infer_control(x, Tf, generator, priors, 
#                                         tangent=True, verbose=True, 
#                                         global_max_iter=20, cma_random_seed=1266266794)
res = estimator.infer(x, Tf, priors, generator=generator,
                                         tangent=True, verbose=True, 
                                         global_max_iter=20, cma_random_seed=1266266794)

end_time = time.time()

print(res['control_params_dict']) 
print(end_time - start_time)
# [___CELL_SEPARATOR___]
print("True lockdown factors:")
print([aW, aS, aO])

print("\nInferred lockdown factors:")
print(res['control_params_dict'])
# [___CELL_SEPARATOR___]
times = [T_intervention]
interventions = [[1.0,1.0,1.0],      # before first time
                 res['flat_params'],       # after first time
                ]         

# compare the true trajectory with the 
contactMatrix = generator.interventions_temporal(times=times,interventions=interventions)
estimator.set_det_model(parameters)
estimator.set_contact_matrix(contactMatrix)
x = data['X'].astype('float')
estimator.set_det_method('LSODA') # setting deterministic integration to be LSODA 
x_det_control = estimator.integrate(x[T_intervention], T_intervention, Tf+T_intervention, Nf)
plt.plot(np.sum(x[:,M:2*M], axis=1), label='Ia')
plt.plot(np.linspace(T_intervention, Tf+T_intervention, Nf), np.sum(x_det_control[:, M:2*M], axis=1), label='Inferred Ia')
plt.plot(np.sum(x[:,2*M:3*M], axis=1), label='Is')
plt.plot(np.linspace(T_intervention, Tf+T_intervention, Nf), np.sum(x_det_control[:, 2*M:3*M], axis=1), label='Inferred Is')
plt.axvspan(0, T_intervention, 
           label='Pre intervention',
           alpha=0.3, color='dodgerblue')
plt.xlim([0, Tf+T_intervention])
plt.legend()
plt.show()
# [___CELL_SEPARATOR___]
def approx_tanh(t, width, loc):
    cond1 = (t < loc-width/2)
    cond2 = (t >= loc+width/2)
    cond3 = np.logical_and((t < loc+width/2), (t >= loc-width/2))
    cond_list = [cond1, cond2, cond3]
    fun_list = [-1, 1, lambda t: 2*(t-loc)/width]
    return np.piecewise(t, cond_list, fun_list)
    
def intervention_fun(t, M, width=1, loc=0, aW_f=0, aS_f=0, aO_f=0):
    aW = (1-approx_tanh(t, width, loc))/2*(1-aW_f) + aW_f
    aS = (1-approx_tanh(t, width, loc))/2*(1-aS_f) + aS_f
    aO = (1-approx_tanh(t, width, loc))/2*(1-aO_f) + aO_f
    aW_full = np.full((2, M), aW) # must return the full (2, M) array 
    aS_full = np.full((2, M), aS)
    aO_full = np.full((2, M), aO)
    return aW_full, aS_full, aO_full

aW_f = 0.8 
aS_f = 0.7
aO_f = 0.7


# plot aW as a function of t 
width = 10
loc = T_intervention 
time_points = np.linspace(0, 100, 1001)
aW_time_series = np.empty((1001,), dtype='float')
for (i, t) in enumerate(time_points): 
    aW_time_series[i] = intervention_fun(t, 4, width, loc, aW_f, aS_f, aO_f)[0][0, 0]
plt.plot(time_points, aW_time_series)
plt.show()
# [___CELL_SEPARATOR___]
contactMatrix = generator.intervention_custom_temporal(intervention_fun, 
                                                       width=width, loc=loc, 
                                                       aW_f=aW_f, aS_f=aS_f, aO_f=aO_f)

# initial conditions    
Is_0 = np.ones(M)*20
Is_0[1] += 10  #make one group different 
Ia_0 = np.zeros((M))*2
Ia_0[1] += 2 
R_0  = np.zeros((M))
S_0  = Ni - (Ia_0 + Is_0 + R_0)

# start simulation
Tf=100;  Nf=Tf+1 
data=model.simulate(S_0, Ia_0, Is_0, contactMatrix, Tf, Nf, method='tau-leaping')
# [___CELL_SEPARATOR___]
# plot simulation
IC  = np.zeros((Nf))
for i in range(M):
        IC += data['X'][:,2*M+i] 
t = data['t']
plt.plot(t, IC)
plt.axvspan(0, T_intervention, 
           label='Pre intervention',
           alpha=0.3, color='dodgerblue')
plt.show() 
# [___CELL_SEPARATOR___]
x = data['X'].astype('float')
x = x[:60]
Nf = x.shape[0] 
Tf = Nf-1 

contactMatrix = generator.intervention_custom_temporal(intervention_fun, 
                                                       width=width, loc=loc, 
                                                       aW_f=aW_f, aS_f=aS_f, aO_f=aO_f)

# compute -log_p 

estimator = pyross.inference.SIR(parameters, M, Ni)
logp = estimator.obtain_minus_log_p(parameters, x, Tf, contactMatrix)
print(logp) 
# [___CELL_SEPARATOR___]
priors = {
    'alpha':{
        'mean': 0.3, 
        'std': 0.2, 
        'bounds': [eps, 0.8]
    }, 
    'beta':{
        'mean': 0.05, 
        'std': 0.1, 
        'bounds': [eps, 0.2]
    }, 
    'gIa':{
        'mean': 0.1, 
        'std': 0.2, 
        'bounds': [eps, 0.6]
    }, 
    'gIs':{
        'mean': 0.2, 
        'std': 0.2, 
        'bounds': [eps, 0.6]
    },
    'width':{
        'mean': 10,
        'std': 5, 
        'bounds': [1e-3, 40]
    }, 
    'loc':{
        'mean': 35, 
        'std': 10, 
        'bounds': [1e-3, 100]
    }, 
    'aW_f':{
        'mean': 0.8, 
        'std': 0.2, 
        'bounds': [0.1, 1.0]
    }, 
    'aS_f':{
        'mean': 0.7, 
        'std': 0.1, 
        'bounds': [0.1, 1.0]
    }, 
    'aO_f':{
        'mean': 0.7, 
        'std': 0.1, 
        'bounds': [0.1, 1.0]
    }
}

start_time = time.time() 
estimator.set_det_method('LSODA') # slower but performs better for exponential decay (near the end of the pandemic)
estimator.set_lyapunov_method('euler') # fast integration method for lyapunov
res = estimator.infer(x, Tf, priors, generator=generator,
                             intervention_fun=intervention_fun, tangent=False,
                             verbose=True, cma_random_seed=1953449819)
end_time = time.time()



print(end_time - start_time)
# [___CELL_SEPARATOR___]
print("True model parameters:")
print(parameters) 
print("Inferred model parameters:")
print(res['params_dict']) 
print("True control parameters:")
print([width, loc, aW_f, aS_f, aO_f])
print("Inferred control parameters:")
print(res['control_params_dict'])
# [___CELL_SEPARATOR___]
# compare the true trajectory with the deterministic solution with MAP parameters
Tf = 100 
Nf = Tf + 1 


inferred_contactMatrix = generator.intervention_custom_temporal(intervention_fun, **res['control_params_dict'])
estimator.set_det_model(res['params_dict'])
estimator.set_contact_matrix(inferred_contactMatrix)
x_true = data['X'][:Nf].astype('float')
x_det_control = estimator.integrate(x_true[0], 0, Tf, Nf)
fig = plt.figure(num=None, figsize=(10, 8), dpi=80, facecolor='w', edgecolor='k')
plt.rcParams.update({'font.size': 12})
plt.plot(np.sum(x_true[:,M:2*M], axis=1), label='Ia')
plt.plot(np.sum(x_det_control[:, M:2*M], axis=1), label='Inferred Ia')
plt.plot(np.sum(x_true[:,2*M:3*M], axis=1), label='Is')
plt.plot(np.sum(x_det_control[:, 2*M:3*M], axis=1), label='Inferred Is')
plt.axvline(x=T_intervention, label='lockdown time', color='black')
plt.axvline(x=res['control_params_dict']['loc'], label='inferred lockdown time', color='red')
plt.axvspan(0, 60, 
           label='used for inference',
           alpha=0.3, color='orange')
plt.xlim([0, Tf])
plt.legend()
plt.show()


# [___CELL_SEPARATOR___]
