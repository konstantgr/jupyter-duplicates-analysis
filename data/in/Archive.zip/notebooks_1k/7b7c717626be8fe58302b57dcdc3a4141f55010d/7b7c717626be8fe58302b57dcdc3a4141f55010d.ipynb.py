import os
import csv
import numpy as np
import torch as th

from glob import glob
from pprint import pprint

import matplotlib
import matplotlib.pyplot as plt

%matplotlib inline
%config InlineBackend.figure_format = 'retina'

import seaborn as sns
sns.set(font_scale=1.5)
sns.set_style('ticks')

matplotlib.rcParams.update({'font.size': 16})
matplotlib.rc('axes', titlesize=16)

from notebook_helpers import load_params
from notebook_helpers import load_monitored
from notebook_helpers import join_monitored
from notebook_helpers import score_summary

def load_data(path, model, run_index=(0, 20)):
    runs = range(run_index[0], run_index[1]+1)
    exps = []
    for r in runs:
        file = os.path.join(path, f"run_{model}_{int(r)}_monitor.csv")
        try:
            mon = load_monitored(file)
        except FileNotFoundError:
            mon = None
        exps.append(mon)
    return exps
# [___CELL_SEPARATOR___]
path = "/Users/qualia/Code/azad/data/wythoff/exp63/"
exp_63 = {}
models = ["DQN_hot1", 
          "DQN_hot2", 
          "DQN_hot3", 
          "DQN_hot4", 
          "DQN_hot5", 
#           "DQN_conv1", 
          "DQN_conv2", 
          "DQN_conv3"]
for model in models:
    exp_63[model] = load_data(path, model, run_index=(2, 21))
# [___CELL_SEPARATOR___]
pprint(exp_63[models[0]][0].keys())
# [___CELL_SEPARATOR___]
key = 'score'
for model in models:
    plt.figure(figsize=(5, 3))
    for r, mon in enumerate(exp_63[model]):
        _ = plt.plot(mon['episode'], mon[key], color='black')
#         _ = plt.ylim(0, 1)
    _ = plt.ylabel(f"{key}")
    _ = plt.tight_layout()
    _ = plt.xlabel("Episode")
    _ = plt.title(model)
# [___CELL_SEPARATOR___]
pprint(exp_63[models[0]][0].keys())
# [___CELL_SEPARATOR___]
key = 'score'
for model in models:
    episodes, avg, sem = score_summary(exp_63[model], key=key)
    plt.figure(figsize=(5, 3))
    _ = plt.plot(episodes, avg, linestyle="-", color='black', alpha=1.0, linewidth=1)
    _ = plt.fill_between(episodes, 
                           avg + 2*sem, 
                           avg - 2*sem,
                           color='grey', alpha=0.3)
    _ = plt.ylim(0, 1)
    _ = sns.despine()
    _ = plt.title(model)
# [___CELL_SEPARATOR___]
key = 'score'
colors = [ "indianred", "darksalmon", "darkorange", "goldenrod", "khaki", "yellowgreen", "olivedrab", "olive"]
plt.figure(figsize=(7, 4))
for color, model in zip(colors, models):
    episodes, avg, sem = score_summary(exp_63[model], key=key)
    _ = plt.plot(episodes, avg, linestyle="-", color=color, alpha=1.0, linewidth=4, label=model)
    _ = plt.fill_between(episodes, 
                           avg + 2*sem, 
                           avg - 2*sem,
                           color='grey', alpha=0.1)
_ = sns.despine()
_ = plt.legend(loc='center left', bbox_to_anchor=(1, 0.5))
_ = plt.xlabel("Episode")
_ = plt.ylabel(key)
# [___CELL_SEPARATOR___]
key = 'loss'
for model in models:
    episodes, avg, sem = score_summary(exp_63[model], key=key)
    plt.figure(figsize=(5, 3))
    _ = plt.plot(episodes, avg, linestyle="-", color='black', alpha=1.0, linewidth=1)
    _ = plt.fill_between(episodes, 
                           avg + 2*sem, 
                           avg - 2*sem,
                           color='grey', alpha=0.3)
    _ = plt.yscale("log")
    _ = sns.despine()
    _ = plt.title(model)
# [___CELL_SEPARATOR___]
