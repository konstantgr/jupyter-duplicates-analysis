import altair as alt
import ibis
import jupyterlab_omnisci
import IPython.display 
import jupyterlab_omnisci.vega_ibis


alt.data_transformers.enable('ibis')
alt.renderers.enable('ibis')
# [___CELL_SEPARATOR___]
conn = ibis.mapd.connect(
    host='metis.mapd.com', user='mapd', password='HyperInteractive',
    port=443, database='mapd', protocol= 'https'
)
t = conn.table("flights_donotmodify")
# [___CELL_SEPARATOR___]
c = alt.Chart(t[t.carrier_name]).mark_bar().encode(
    x='carrier_name',
    y='count()'
)
# [___CELL_SEPARATOR___]
c
# [___CELL_SEPARATOR___]
delay_by_month = alt.Chart(t[t.flight_dayofmonth, t.flight_month, t.depdelay]).mark_rect().encode(
    x='flight_dayofmonth:O',
    y='flight_month:O',
    color='average(depdelay)'
)
delay_by_month
# [___CELL_SEPARATOR___]
slider = alt.binding_range(min=1, max=12, step=1)
select_month = alt.selection_single(fields=['flight_month'],
                                   bind=slider, init={'flight_month': 1})

alt.Chart(t[t.flight_dayofmonth, t.depdelay, t.flight_month]).mark_line().encode(
    x='flight_dayofmonth:O',
    y='average(depdelay)'
).add_selection(
    select_month
).transform_filter(
    select_month
)
# [___CELL_SEPARATOR___]
t_contributions = conn.table("contributions_donotmodify")
# [___CELL_SEPARATOR___]
amount_by_state = alt.Chart(
    t_contributions[["contributor_state", "amount"]]
).mark_circle().encode(
    x="contributor_state",
    y=alt.Y("mean(amount):Q", axis=alt.Axis(grid=False)),
    color=alt.Color(value="green"),
    size="count()"
)

delay_by_state = alt.Chart(
    t[["origin_state", "depdelay"]]
).mark_square().encode(
    x="origin_state",
    y=alt.Y(
        "mean(depdelay):Q",
        axis=alt.Axis(grid=False)
    ),
    color=alt.Color(value="firebrick"),
    size="count()"
)

combined = (amount_by_state + delay_by_state).resolve_scale(y='independent', size='independent')
combined
# [___CELL_SEPARATOR___]
