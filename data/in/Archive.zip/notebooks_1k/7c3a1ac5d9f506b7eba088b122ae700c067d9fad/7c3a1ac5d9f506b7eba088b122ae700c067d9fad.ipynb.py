import pandas as pd
from bio2bel_kegg.manager import Manager as KeggManager
from bio2bel_wikipathways.manager import Manager as WikiPathwaysManager
from bio2bel_reactome.manager import Manager as ReactomeManager

import matplotlib.pyplot as plt

from matplotlib_venn import venn3
# [___CELL_SEPARATOR___]
%matplotlib inline
# [___CELL_SEPARATOR___]
kegg_wikipathways_df = pd.read_excel(
    'https://github.com/ComPath/curation/raw/master/mappings/kegg_wikipathways.xlsx',
    index_col=0
)
kegg_reactome_df = pd.read_excel(
    'https://github.com/ComPath/curation/raw/master/mappings/kegg_reactome.xlsx',
    index_col=0
)
wikipathways_reactome_df = pd.read_excel(
    'https://github.com/ComPath/curation/raw/master/mappings/wikipathways_reactome.xlsx',
    index_col=0
)
# [___CELL_SEPARATOR___]
kegg_manager = KeggManager()
wikipathways_manager = WikiPathwaysManager()
reactome_manager = ReactomeManager()
# [___CELL_SEPARATOR___]
def get_pathway_ids(manager, names):
    """Return the set of pathway ids given their names and the manager.
    
    :param manager: manager database
    :param list[str] names: pathway names
    :rtype: list
    """
    pathway_ids= set()
    
    for name in names:
        
        pathway = manager.get_pathway_by_name(name)
        
        if pathway is None:
            raise ValueError("Not Valid Pathway Name: {}".format(name))
        
        pathway_ids.add(pathway.resource_id)
        
    return pathway_ids

def get_pathway_names(manager, ids):
    """Return the set of pathway names given their ids and the manager.
    
    :param manager: manager database
    :param list[str] names: pathway ids
    :rtype: list
    """
    return [
        manager.get_pathway_by_id(identifier).name
        for identifier in ids
    ]

def get_pathway_models(reference_manager, compared_manager, pathway_1_name, pathway_2_name):
    """Return the pathway models from their correspondent managers.
    
    :rtype: tuple(Pathway, Pathway)
    """
    pathway_1 = reference_manager.get_pathway_by_name(pathway_1_name)
    
    pathway_2 = compared_manager.get_pathway_by_name(pathway_2_name)
    
    if pathway_1 is None:
        raise ValueError("Not Valid Pathway Name: {}".format(pathway_1_name))
        
    if pathway_2 is None:
        raise ValueError("Not Valid Pathway Name: {}".format(pathway_2_name))
        
    return pathway_1, pathway_2
   
def get_pathways_from_statement(mapping_statement, mapping_type):
    """Return the subject, object of the mapping.
    
    :param str mapping_statement: statement
    :param str mapping_type: type of relationship
    :rtype: tuple[str,str]
    """
    _pathways = mapping_statement.split(mapping_type)
        
    return _pathways[0].strip(), _pathways[1].strip()


def remove_star_from_pathway_name(pathway_name):
    """Remove the star that label the reference pathway in isPartOf statements.
    
    :param str statements: pathway name
    """
    return pathway_name.replace("*", "").strip()

    
def get_pathways_from_is_part_of_mapping(mapping_statement):
    """Return the pathways of a hierarchical mapping."""

    pathway_1, pathway_2 = get_pathways_from_statement(mapping_statement, 'isPartOf')

    if "*" in pathway_1:

        pathway_1 = remove_star_from_pathway_name(pathway_1)
        return pathway_1, pathway_2


    else:
        pathway_2 = remove_star_from_pathway_name(pathway_2)
        return pathway_2, pathway_1


def parse_equivalent_to(df, reference_manager, compared_manager):
    """Parse the column corresponding to equivalentTo mappings in the excel sheet.
    
    :returns: list of overlaps and name of pathways with equivalentTo mappings
    :rtype: tuple(set, set, list)
    """
    
    equivalent_names = set()
    equivalent_ids = set()
    
    reference_names = []
        
    for index, row in df.iterrows(): 
        
        reference_names.append(index)
        
        equivalent_to_mappings = row['equivalentTo Mappings']

        if pd.isnull(equivalent_to_mappings):
            continue

        for mapping_statement in equivalent_to_mappings.split("\n"):
            
            if mapping_statement == '':
                continue
            
            reference_pathway, compared_pathway = get_pathways_from_statement(mapping_statement, "equivalentTo")
          
            pathway_1, pathway_2 = get_pathway_models(reference_manager, compared_manager, reference_pathway, compared_pathway)
            
            equivalent_ids.add((pathway_1.resource_id, pathway_2.resource_id))  
            
            equivalent_names.add((pathway_1.name, pathway_2.name)) 

    return equivalent_names, equivalent_ids, reference_names

# [___CELL_SEPARATOR___]
print("############### KEGG vs WikiPathways #################\n")

kegg_wikipathways_names, kegg_wikipathways_ids, kegg_names_excel = parse_equivalent_to(
    kegg_wikipathways_df,
    kegg_manager,
    wikipathways_manager
)

print("############### KEGG vs Reactome #################\n")

kegg_reactome_names, kegg_reactome_ids, kegg_names_excel = parse_equivalent_to(
    kegg_reactome_df,
    kegg_manager,
    reactome_manager
)

print("############### WikiPathways vs Reactome #################\n")

wikipathways_reactome_names, wikipathways_reactome_ids, wikipathways_names_excel = parse_equivalent_to(
    wikipathways_reactome_df,
    wikipathways_manager,
    reactome_manager
)

# Number of pathway names must be equal to ids
assert len(kegg_wikipathways_names),len(kegg_wikipathways_ids)
assert len(kegg_reactome_names),len(kegg_reactome_ids)
assert len(wikipathways_reactome_names),len(wikipathways_reactome_ids)

# [___CELL_SEPARATOR___]
kegg_names = kegg_names_excel
reactome_names = reactome_manager.get_all_pathway_names() # Get all reactome names
wikipathways_names = wikipathways_names_excel

kegg_ids = get_pathway_ids(kegg_manager, kegg_names)
reactome_ids = get_pathway_ids(reactome_manager, reactome_names)
wikipathways_ids = get_pathway_ids(wikipathways_manager, wikipathways_names)

# Number of pathway names must be equal to ids
assert len(kegg_names),len(kegg_ids)
assert len(reactome_names),len(reactome_ids)
assert len(wikipathways_names),len(wikipathways_ids)

assert len(kegg_names),325 # rows in the excel
assert len(wikipathways_names),420 #rows in the excel

# [___CELL_SEPARATOR___]
def get_pathways_without_mappings(all_pathways_ids, mappings_1, mappings_2):
    """Return pathways without mappings."""
    return {
        pathway_id
        for pathway_id in all_pathways_ids
        if pathway_id not in mappings_1 and pathway_id not in mappings_2
    }

def filter_sets(in_set, not_in_set):
    """Return elements that are in set 1 but not in set 2."""
    return {
        element
        for element in in_set
        if element not in not_in_set
    }
    
# [___CELL_SEPARATOR___]
print('Total KEGG pathways: {}'.format(len(kegg_ids)))
print('Total Reactome pathways: {}'.format(len(reactome_ids)))
print('Total WikiPathways pathways: {}\n'.format(len(wikipathways_ids)))

print('Total KEGG ∩ WikiPathways: {}'.format(len(kegg_wikipathways_ids)))
print('Total KEGG ∩ Reactome: {}'.format(len(kegg_reactome_ids)))
print('Total WikiPathways ∩ Reactome: {}\n'.format(len(wikipathways_reactome_ids)))
# [___CELL_SEPARATOR___]
plt.figure(figsize=(10, 10))
diagram = venn3(
    subsets = (235, 2101, 37, 325, 31, 40, 21),
    set_labels = ("KEGG", "Reactome", "WikiPathways")
)
for text in diagram.set_labels:
    text.set_fontsize(28)
for text in diagram.subset_labels:
    text.set_fontsize(16)


diagram.get_patch_by_id('001').set_color('#5bc0de') #WikiPathways
diagram.get_patch_by_id('001').set_alpha(1.0)
diagram.get_patch_by_id('010').set_color('#df3f18') # Reactome
diagram.get_patch_by_id('010').set_alpha(1.0)
diagram.get_patch_by_id('011').set_color('#9d807b') # Wiki - Reactome
diagram.get_patch_by_id('011').set_alpha(1.0)
diagram.get_patch_by_id('100').set_color('#5cb85c') # KEGG
diagram.get_patch_by_id('100').set_alpha(1.0)
diagram.get_patch_by_id('110').set_color('#f3ac1f') # KEGG U Reactome
diagram.get_patch_by_id('110').set_alpha(0.8)
diagram.get_patch_by_id('111').set_color('#ffffff') # Middle
diagram.get_patch_by_id('111').set_alpha(1.0)
diagram.get_patch_by_id('101').set_color('#a2ded0') # KEGG - Wiki
diagram.get_patch_by_id('101').set_alpha(1.0)
    

plt.show()