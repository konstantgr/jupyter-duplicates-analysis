%env OMP_NUM_THREADS=1
%matplotlib inline
import numpy as np
from matplotlib import pyplot as plt
import pyross
import time 
# [___CELL_SEPARATOR___]
np.random.seed(1)
M  = 2              # the population has two age groups
N  = 5e4            # and this is the total population

# correct params
beta  = 0.02        # infection rate
gIa   = 1./7        # recovery rate of asymptomatic infectives
gIs   = 1./7        # recovery rate of asymptomatic infectives
gE    = 0.1         # exposed to infected rate
alpha = np.array([0.5, 0.2])       # fraction of asymptomatic infectives
fsa   = 0.8         # the self-isolation parameter (assumed to be known)

# set the age structure
fi = np.array([0.25, 0.75])  # fraction of population in age age group
Ni = N*fi

# set the contact structure
C = np.array([[18., 9.], [3., 12.]])

# set up initial condition
E0  = np.array([20, 20])  # each age group has exposed individuals,
Ia0 = np.array([10, 10])  # and asymptomatic infectives,
Is0 = np.array([10, 10])  # and also symptomatic infectives
R0  = np.array([1, 1])    # there are no recovered individuals initially
S0  = Ni - (E0 + Ia0 + Is0 + R0)

Tf = 160
Nf = Tf+1

def contactMatrix(t):
    return C

parameters = {'alpha':alpha, 'beta':beta, 'gIa':gIa, 'gIs':gIs, 'gE':gE, 'fsa':fsa, 'seed':2}
true_parameters = parameters

# use pyross stochastic to generate traj and save 
sto_model = pyross.stochastic.SEIR(parameters, M, Ni)
data = sto_model.simulate(S0, E0, Ia0, Is0, contactMatrix, Tf, Nf)
data_array = data['X']
np.save('latent_SEIR_traj.npy', data_array)
# [___CELL_SEPARATOR___]
# plot the data and obtain the epidemic curve for one age group 
S  = data_array[:,0]
E  = data_array[:,2]
Ia = data_array[:,4]
Is = data_array[:,6]
t  = data['t']

fig = plt.figure(num=None, figsize=(10, 8), dpi=80, facecolor='w', edgecolor='k')
plt.rcParams.update({'font.size': 22})

plt.fill_between(t, 0, S/N, color="#348ABD", alpha=0.3)
plt.plot(t, S/N, '-', color="#348ABD", label='$S$', lw=4)

plt.plot(t, E/N, '-', color="green", label='$E$', lw=4)
plt.fill_between(t, 0, E/N, color='green', alpha=0.3)

plt.fill_between(t, 0, Is/N, color='#A60628', alpha=0.3)
plt.plot(t, Is/N, '-', color='#A60628', label='$I$', lw=4)

R=Ni[0]-S-Ia-Is-E; 
plt.fill_between(t, 0, R/N, color="dimgrey", alpha=0.3)
plt.plot(t, R/N, '-', color="dimgrey", label='$R$', lw=4)

plt.legend(fontsize=26); plt.grid() 
plt.autoscale(enable=True, axis='x', tight=True)
plt.xlabel("time [days]")
plt.show()
# [___CELL_SEPARATOR___]
# load the data and rescale to intensive variables 
N_start = 20  
Tf_inference = 40 # can truncate later 
Nf_inference = Tf_inference + 1

x = np.load('latent_SEIR_traj.npy').astype('float')
x = (x/N)[N_start:N_start+Nf_inference]
steps = 4 # number internal integration steps taken, must be an odd number 


# initialise the estimator 
estimator = pyross.inference.SEIR(parameters, M, fi, int(N), steps, rtol_det=1e-5, rtol_lyapunov=1e-5)


# make a fltr to get N-R and Is for each age class 
fltr=np.kron([[1, 1, 1, 1], [0, 0, 0, 1]], np.identity(M))
obs=np.einsum('ij,kj->ki', fltr, x) 
x0=x[0]

# Compare the deterministic trajectory and the stochastic trajectory with the same 
# initial conditions and parameters 
estimator.set_det_model(parameters)
estimator.set_contact_matrix(contactMatrix)


time_points = np.linspace(0, Tf_inference, Nf_inference)
xm = estimator.integrate(x0, 0, Tf_inference, Nf_inference)

plt.plot(obs[:, -2:])
plt.plot(np.einsum('ij,kj->ki', fltr, xm)[:, -2:])
plt.xlabel("time [days]")
plt.show()

# [___CELL_SEPARATOR___]
# Make parameter guesses (and define bounds for the MAP estimate later)
eps = 1e-5

param_priors = {
    'beta':{
        'mean': 0.02, 
        'std': 0.1,
        'bounds': [eps, 50]
    },
    'gIa':{
        'mean': 0.12, 
        'std': 0.1, 
        'bounds': [eps, 50]
    }, 
    'gIs':{
        'mean': 0.14, 
        'std': 0.05, 
        'bounds': [eps, 50]
    },
    'gE':{
        'mean': 0.1, 
        'std': 0.05, 
        'bounds': [eps, 50]
    }
}

fsa_g = 0.8 # not inferred 

E0_g = x0[M:2*M]
E_std = E0_g*0.3 
bounds_for_E = np.tile([0.01/N, 1000/N], M).reshape(M, 2)

Ia0_g = x0[2*M:3*M]
Ia_std = Ia0_g 
bounds_for_Ia = np.tile([0.01/N, 1000/N], M).reshape(M, 2)

init_fltr = np.repeat([False, True, True, False], M)
init_priors = {
    'independent': {
        'fltr': init_fltr,
        'mean': [*E0_g, *Ia0_g],
        'std': [*E_std, *Ia_std],
        'bounds': [*bounds_for_E, *bounds_for_Ia]
    }
}

start_time = time.time()
sampler = estimator.latent_infer_nested_sampling(obs, fltr, Tf_inference, param_priors, init_priors, contactMatrix=contactMatrix,  
                                                 tangent=True, verbose=True, nlive=150, nprocesses=4) 
end_time = time.time()
print(end_time - start_time)

result, samples = estimator.latent_infer_nested_sampling_process_result(sampler, obs, fltr, param_priors, init_priors, contactMatrix=contactMatrix)
# [___CELL_SEPARATOR___]
print("Model log-evidence for SEIR (computed by nested sampling): ", result.logz[-1])
# [___CELL_SEPARATOR___]
evidence_prms = pyross.evidence.latent_get_parameters(estimator, obs, fltr, Tf_inference, param_priors, init_priors, 
                                                      contactMatrix=contactMatrix, tangent=True)

start_time = time.time()
logz_smc = pyross.evidence.evidence_smc(*evidence_prms, npopulation=150, mcmc_iter=50, nprocesses=4, 
                                        target_cess=0.93, save_samples=False, verbose=False)
end_time = time.time()
print(end_time - start_time)
# [___CELL_SEPARATOR___]
print("Model log-evidence for SEIR (computed by SMC): ", logz_smc) 
# [___CELL_SEPARATOR___]
evidence_prms = pyross.evidence.latent_get_parameters(estimator, obs, fltr, Tf_inference, param_priors, init_priors, 
                                                      contactMatrix=contactMatrix, tangent=True)
steps = np.linspace(0, 1, 26)[1:]**5  # Choose some intermediate steps.
start_time = time.time()
step_list, sampler_list = pyross.evidence.evidence_path_sampling(*evidence_prms, steps=steps, npopulation=25, mcmc_iter=500, 
                                                                 nprocesses=4, verbose=False)
end_time = time.time()
print(end_time - start_time)
# [___CELL_SEPARATOR___]
additional_steps = np.linspace(0, 0.2, 4)[1:]**4  # Add some more steps
step_list, sampler_list = pyross.evidence.evidence_path_sampling(*evidence_prms, steps=additional_steps, npopulation=25, mcmc_iter=500, 
                                                                 nprocesses=4, verbose=False, extend_step_list=step_list, 
                                                                 extend_sampler_list=sampler_list)
# [___CELL_SEPARATOR___]
logz_ps, logl_vals = pyross.evidence.evidence_path_sampling_process_result(*evidence_prms, step_list, sampler_list, nprocesses=4, burn_in=50)
print("Model log-evidence for SEIR (computed by path sampling): ", logz_ps) 
# [___CELL_SEPARATOR___]
map_params = estimator.latent_infer(obs, fltr, Tf_inference, param_priors, init_priors, contactMatrix=contactMatrix, tangent=True, 
                                    global_max_iter=200, local_max_iter=1000, global_atol=1.0, cma_population=50, verbose=True, ftol=1e-7) 

# [___CELL_SEPARATOR___]
post_mean = pyross.utils.posterior_mean(samples)
estimator.set_params(post_mean['params_dict'])
estimator.set_det_model(post_mean['params_dict'])
x_pm = estimator.integrate(post_mean['x0'], N_start-1, Tf, Nf-N_start) * N
estimator.set_params(map_params['params_dict'])
estimator.set_det_model(map_params['params_dict'])
x_map = estimator.integrate(map_params['x0'], N_start-1, Tf, Nf-N_start) * N
x = np.load('latent_SEIR_traj.npy').astype('float')[N_start:]
fig = plt.figure(num=None, figsize=(11, 8), dpi=80, facecolor='w', edgecolor='k')
plt.rcParams.update({'font.size': 11})
plt.plot(x[:,M], label='True E', c="C0", linestyle='dashed')
plt.plot(x_pm[:, M], label='E (post. mean)', c="C0")
plt.plot(x_map[:, M], label='E (MAP)', c="C0", linestyle='dotted')
plt.plot(x_pm[:, 2*M], label='Ia (post. mean)', c="C1")
plt.plot(x_map[:, 2*M], label='Ia (MAP)', c="C1", linestyle='dotted')
plt.plot(x[:,2*M], label='True Ia', c="C1", linestyle='dashed')
plt.plot(np.sum(x_pm[:, 3*M:], axis=1), label='Is (post. mean)', c="C2")
plt.plot(np.sum(x_map[:, 3*M:], axis=1), label='Is (MAP)', c="C2", linestyle='dotted')
plt.plot(np.sum(x[:,3*M:], axis=1), label='True Is', c="C2", linestyle='dashed')
for sample in pyross.utils.resample(samples, 20):
    estimator.set_params(sample['params_dict'])
    estimator.set_det_model(sample['params_dict'])
    x_det = estimator.integrate(sample['x0'], N_start-1, Tf, Nf-N_start) * N
    plt.plot(x_det[:, M], c="C0", alpha=0.2)
    plt.plot(x_det[:, 2*M], c="C1", alpha=0.2)
    plt.plot(np.sum(x_det[:, 3*M:], axis=1), c="C2", alpha=0.2)

plt.axvspan(0, Tf_inference, 
           label='Used for inference',
           alpha=0.3, color='dodgerblue')
plt.xlim([0, Tf-N_start])
plt.legend()
plt.show()
# [___CELL_SEPARATOR___]
estimator2 = pyross.inference.SIR(parameters, M, fi, int(N), steps=4, rtol_det=1e-5, rtol_lyapunov=1e-5)
eps = 1e-5

x = np.load('latent_SEIR_traj.npy').astype('float')
x = (x/N)[N_start:N_start+Nf_inference]

fltr2=np.kron([[1, 1, 1], [0, 0, 1]], np.identity(M))
obs2=np.einsum('ij,kj->ki', fltr, x) 
x02=x[0]

param_priors2 = {
    'beta':{
        'mean': 0.02, 
        'std': 0.1,
        'bounds': [eps, 50]
    },
    'gIa':{
        'mean': 0.12, 
        'std': 0.1, 
        'bounds': [eps, 50]
    }, 
    'gIs':{
        'mean': 0.14, 
        'std': 0.05, 
        'bounds': [eps, 50]
    }
}
init_fltr2 = np.repeat([False, True, False], M)
init_priors2 = {
    'independent':{
        'fltr': init_fltr2, 
        'mean': [*Ia0_g], 
        'std': [*Ia_std], 
        'bounds': [*bounds_for_Ia]
    }
}

start_time = time.time()
# Here we only use nested sampling to compute the evidence because it is the fastest algorithm for this problem.
sampler2 = estimator2.latent_infer_nested_sampling(obs2, fltr2, Tf_inference, param_priors2, init_priors2, contactMatrix=contactMatrix,
                                                   tangent=True, verbose=True, nlive=150, nprocesses=4) 
end_time = time.time()
print(end_time - start_time)

result2, samples2 = estimator2.latent_infer_nested_sampling_process_result(sampler2, obs2, fltr2, param_priors2, init_priors2, 
                                                                           contactMatrix=contactMatrix)
# [___CELL_SEPARATOR___]
print("Model log-evidence for SIR (computed by nested sampling): ", result2.logz[-1])
# [___CELL_SEPARATOR___]
ftol = 1e-9 # the relative tol in (-logp)  

params2 = estimator2.latent_infer(obs2, fltr2, Tf_inference, param_priors2, init_priors2, contactMatrix=contactMatrix,
                                  tangent=True, global_max_iter=200, local_max_iter=1000, global_atol=1.0, 
                                  cma_population=50, verbose=True, ftol=ftol) 
end_time = time.time()
print(end_time - start_time)
# [___CELL_SEPARATOR___]
post_mean = pyross.utils.posterior_mean(samples2)
estimator2.set_params(post_mean['params_dict'])
estimator2.set_det_model(post_mean['params_dict'])
x_pm = estimator2.integrate(post_mean['x0'], N_start-1, Tf, Nf-N_start) * N
estimator2.set_params(params2['params_dict'])
estimator2.set_det_model(params2['params_dict'])
x_map = estimator2.integrate(params2['x0'], N_start-1, Tf, Nf-N_start) * N

fig = plt.figure(num=None, figsize=(11, 8), dpi=80, facecolor='w', edgecolor='k')
plt.rcParams.update({'font.size': 11})
plt.plot(x_pm[:, M], label='Ia (post. mean)', c="C0")
plt.plot(x_map[:, M], label='Ia (MAP)', c="C0", linestyle='dotted')
plt.plot(x_pm[:, 2*M], label='Is (post. mean)', c="C1")
plt.plot(x_map[:, 2*M], label='Is (MAP)', c="C1", linestyle='dotted')
for sample in pyross.utils.resample(samples2, 20):
    estimator2.set_params(sample['params_dict'])
    estimator2.set_det_model(sample['params_dict'])
    x_det = estimator2.integrate(sample['x0'], N_start-1, Tf, Nf-N_start) * N
    plt.plot(x_det[:, M], c="C0", alpha=0.2)
    plt.plot(x_det[:, 2*M], c="C1", alpha=0.2)

plt.axvspan(0, Tf_inference, 
           label='Used for inference',
           alpha=0.3, color='dodgerblue')
plt.xlim([0, Tf-N_start])
plt.legend()
plt.show()
# [___CELL_SEPARATOR___]
