#Load the libraries and configuration
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
%matplotlib inline
from sklearn import tree
from sklearn.externals import joblib
import firefly
# [___CELL_SEPARATOR___]
# Predict `default` probability
# [___CELL_SEPARATOR___]
df = pd.read_csv("../data/historical_loan.csv") 
# [___CELL_SEPARATOR___]
df.dropna(axis=0, inplace=True) 
# [___CELL_SEPARATOR___]
df['log_age'] = np.log(df.age)
df['log_income'] = np.log(df.income)
# [___CELL_SEPARATOR___]
df.plot.scatter(x='log_age', y='log_income', c='default', alpha=0.25, cmap='viridis')
# [___CELL_SEPARATOR___]
X = df.loc[:,('age', 'income')]
y = df.loc[:,'default']
clf = tree.DecisionTreeClassifier(max_depth=10).fit(X,y)
joblib.dump(clf, "clf.pkl")
# [___CELL_SEPARATOR___]
tree.export_graphviz(clf, 
                     out_file="tree.dot", 
                     feature_names=["age", "income"],
                     class_names=["no", "yes"])
                     
# [___CELL_SEPARATOR___]
%%file simple.py
import numpy as np
from sklearn.externals import joblib
model = joblib.load("clf.pkl")

def predict(age, amount):
    features = [age, amount]
    prob0, prob1 = model.predict_proba([features])[0]
    return prob1
# [___CELL_SEPARATOR___]
simple = firefly.Client("http://127.0.0.1:8000")
simple.predict(age=28, amount=10000)
# [___CELL_SEPARATOR___]
