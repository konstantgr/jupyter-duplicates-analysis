import numpy as np
# [___CELL_SEPARATOR___]
vec = [1, 2, 3]
# [___CELL_SEPARATOR___]
np_vec = np.array(vec)
# [___CELL_SEPARATOR___]
np_vec
# [___CELL_SEPARATOR___]
type(np_vec)
# [___CELL_SEPARATOR___]
mat = [[2, 6, 8], [3, 7, 0]]
# [___CELL_SEPARATOR___]
np_mat = np.array(mat)
# [___CELL_SEPARATOR___]
np_mat
# [___CELL_SEPARATOR___]
np.zeros((3,4))
# [___CELL_SEPARATOR___]
np.ones((3,4))
# [___CELL_SEPARATOR___]
np.eye(3) #Identity Matrix
# [___CELL_SEPARATOR___]
np.random.randn(5) #One dimensional
# [___CELL_SEPARATOR___]
np.random.randn(3,4) #Two dimensional
# [___CELL_SEPARATOR___]
np.random.randint(5, 15) #Random number between start and end
# [___CELL_SEPARATOR___]
np.random.randint(5, 150, 5) #Multiple random numbers between specified range
# [___CELL_SEPARATOR___]
np.arange(3, 12)
# [___CELL_SEPARATOR___]
np.arange(3, 12, 2) #With a step of 2
# [___CELL_SEPARATOR___]
np.linspace(2, 5) #Default count is 50 -- Third argument
# [___CELL_SEPARATOR___]
np.linspace(2, 5, 10) #Third argument specifies the count of numbers
# [___CELL_SEPARATOR___]
np_vec
# [___CELL_SEPARATOR___]
np_mat
# [___CELL_SEPARATOR___]
np_vec.shape #to find dimensions
# [___CELL_SEPARATOR___]
np_mat.shape
# [___CELL_SEPARATOR___]
np_vec.max() #Maximum value
# [___CELL_SEPARATOR___]
np_vec.min() #Minimum value
# [___CELL_SEPARATOR___]
np_mat
# [___CELL_SEPARATOR___]
np_mat.reshape(3, 2) #Change dimensions -- only if the total number of values remains the same
# [___CELL_SEPARATOR___]
np_mat.reshape(3, 4) #Error since total number of elements changes
# [___CELL_SEPARATOR___]
np_mat.dtype #to find Data Type of elements
# [___CELL_SEPARATOR___]
a = np.array([0, 1, 2, 3, 4, 5])
# [___CELL_SEPARATOR___]
a + 7 #Add 7 to each element
# [___CELL_SEPARATOR___]
a -2 
# [___CELL_SEPARATOR___]
a * 3
# [___CELL_SEPARATOR___]
a / 2
# [___CELL_SEPARATOR___]
np.sin(a) #Calculate sin of each element
# [___CELL_SEPARATOR___]
np.sum(a) #Sum of all values
# [___CELL_SEPARATOR___]
np.mean(a) #Mean of all values
# [___CELL_SEPARATOR___]
a1 = np.array([[1, 3], [4, 6]])
b1 = np.array([[0, 2], [3, 1]])
# [___CELL_SEPARATOR___]
a1
# [___CELL_SEPARATOR___]
b1
# [___CELL_SEPARATOR___]
a1 + b1
# [___CELL_SEPARATOR___]
a1 - b1
# [___CELL_SEPARATOR___]
a1 * b1 #Element by element multiplication
# [___CELL_SEPARATOR___]
a1.dot(b1) #Matrix Multiplication-- dot refers to matrix multiplication
# [___CELL_SEPARATOR___]
a
# [___CELL_SEPARATOR___]
a > 2 #Compare each and every element
# [___CELL_SEPARATOR___]
d1 = np.arange(25)
# [___CELL_SEPARATOR___]
d1
# [___CELL_SEPARATOR___]
d2 = np.arange(25).reshape(5,5)
# [___CELL_SEPARATOR___]
d2
# [___CELL_SEPARATOR___]
d1[4:12] #Slicing -- d1[start : end+1]
# [___CELL_SEPARATOR___]
d1[4: ]
# [___CELL_SEPARATOR___]
d1[:13]
# [___CELL_SEPARATOR___]
d2
# [___CELL_SEPARATOR___]
d2[0,0] #d2[row, column]
# [___CELL_SEPARATOR___]
d2[2,]
# [___CELL_SEPARATOR___]
d2[1, :]
# [___CELL_SEPARATOR___]
d2[:, 3]
# [___CELL_SEPARATOR___]
d2[ , 4] #Error!
# [___CELL_SEPARATOR___]
d2[1:4, 1:4]
# [___CELL_SEPARATOR___]
d1[0:5]
# [___CELL_SEPARATOR___]
d1[0:5] = -10 #Broadcasting -- Change specific elements of the array
# [___CELL_SEPARATOR___]
d1