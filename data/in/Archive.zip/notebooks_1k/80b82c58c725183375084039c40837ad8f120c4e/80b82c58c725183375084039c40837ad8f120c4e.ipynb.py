function mysum(A)
    acc = zero(eltype(A))
    for a in A
        acc += a
    end
    return acc
end
# [___CELL_SEPARATOR___]
using InteractiveUtils
# [___CELL_SEPARATOR___]
@code_lowered mysum(ones(1))
# [___CELL_SEPARATOR___]
@code_typed mysum(ones(1))
# [___CELL_SEPARATOR___]
@code_llvm mysum(ones(1))
# [___CELL_SEPARATOR___]
@code_native mysum(ones(1))
# [___CELL_SEPARATOR___]
#Lets re-define our previous Laplacians (from 05_ notebook)
function laplacian_bad(lap_x::Array{Float64,2}, x::Array{Float64,2})
    nr,nc = size(x)
    for ir = 2:nr-1, ic = 2:nc-1 # bad loop nesting order
        lap_x[ir,ic] =
            (x[ir+1,ic] + x[ir-1,ic] +
            x[ir,ic+1] + x[ir,ic-1]) - 4*x[ir,ic]
    end
end

#In this version, the two loops are nested properly:
function laplacian_good(lap_x::Array{Float64,2}, x::Array{Float64,2})
    nr,nc = size(x)
    for ic = 2:nc-1, ir = 2:nr-1 # good loop nesting order
        lap_x[ir,ic] =
            (x[ir+1,ic] + x[ir-1,ic] +
            x[ir,ic+1] + x[ir,ic-1]) - 4*x[ir,ic]
    end
end
# [___CELL_SEPARATOR___]
# A way to increase the speed is to remove the array bounds checking, using the macro @inbounds:
function laplacian_good_nocheck(lap_x::Array{Float64,2}, x::Array{Float64,2})
    nr,nc = size(x)
    for ic = 2:nc-1
        for ir = 2:nr-1 # good loop nesting order
            @inbounds begin lap_x[ir,ic] = # no array bounds checking
                (x[ir+1,ic] +  x[ir-1,ic] +
                x[ir,ic+1] + x[ir,ic-1]) - 4*x[ir,ic]
            end
        end
    end
end
# [___CELL_SEPARATOR___]
using Printf #evaluate me to get printf
# [___CELL_SEPARATOR___]
function main_test(nr, nc)
    field = zeros(nr, nc)
    for ic = 1:nc, ir = 1:nr
        if ir == 1 || ic == 1 || ir == nr || ic == nc
            field[ir,ic] = 1.0
        end
    end
    lap_field = zeros(size(field))

    time = @elapsed laplacian_bad(lap_field, field)
    @printf "laplacian_bad:          %.3f s\n" time
    
    time = @elapsed laplacian_good(lap_field, field)
    @printf "laplacian_good:         %.3f s\n" time
    
    time = @elapsed laplacian_good_nocheck(lap_field, field)
    @printf "laplacian_good_nocheck: %.3f s\n" time
end

main_test(10^4, 10^4)
# [___CELL_SEPARATOR___]
using Base.Threads
nthreads()
# [___CELL_SEPARATOR___]
a = zeros(10)
@threads for i = 1:10
    a[i] = Threads.threadid()
end
a
# [___CELL_SEPARATOR___]
function threaded_sum(arr)
   @assert length(arr) % nthreads() == 0
    
   let results = zeros(eltype(arr), nthreads())
       @threads for tid in 1:nthreads()
           # split work
           acc = zero(eltype(arr))
           len = div(length(arr), nthreads())
           domain = ((tid-1)*len +1):tid*len
           @inbounds for i in domain
               acc += arr[i]    
           end
           results[tid] = acc
       end
       sum(results)
   end
end
# [___CELL_SEPARATOR___]
using Distributed

nheads = @distributed (+) for i=1:200000000
  Int(rand(Bool))
end
# [___CELL_SEPARATOR___]
using LinearAlgebra #loading svd()
# [___CELL_SEPARATOR___]
M = Matrix{Float64}[rand(1000,1000) for i=1:10]
pmap(svd, M)