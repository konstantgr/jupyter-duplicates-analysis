import unittest
import numpy as np
import pandas as pd
import numpy.testing as np_testing
import pandas.testing as pd_testing
import os
import sys
import import_ipynb
from sklearn.cluster import KMeans


class Test(unittest.TestCase):

    def _dirname_if_file(self, filename):
        if os.path.isdir(filename):
            return filename
        else:
            return os.path.dirname(os.path.abspath(filename))

    def setUp(self):
        import Exercise2_02
        self.exercise = Exercise2_02
       
        self.data = pd.read_csv('circles.csv')

        
    def test_input_frames(self):
        pd_testing.assert_frame_equal(self.exercise.data, self.data)


    def test_kmeans(self):
        est_kmeans = KMeans(n_clusters=5, random_state=0)
        est_kmeans.fit(self.data)
        pred_kmeans = est_kmeans.predict(self.data)

        np_testing.assert_equal(pred_kmeans, self.exercise.pred_kmeans)


if __name__ == '__main__':
    unittest.main(argv=['first-arg-is-ignored'], exit=False)