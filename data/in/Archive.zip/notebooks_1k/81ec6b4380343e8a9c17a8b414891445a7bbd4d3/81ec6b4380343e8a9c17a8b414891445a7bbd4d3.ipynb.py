import matplotlib
matplotlib.use('Agg')
# import sys
# sys.path.append("/home/ec2-user/anaconda3/external/fastai/")
# sys.path.append('/scratch/arka/miniconda3/external/fastai/')


from tqdm import tqdm
tqdm.monitor_interval = 0

from fastai.imports import *
from fastai.transforms import *
from fastai.conv_learner import *
from fastai.model import *
from fastai.dataset import *
from fastai.sgdr import *
from fastai.plots import *
import json
import pandas as pd
from sklearn.metrics import *
# [___CELL_SEPARATOR___]
%matplotlib inline
%reload_ext autoreload
%autoreload 2
# [___CELL_SEPARATOR___]
from mobile_net import *
# [___CELL_SEPARATOR___]
PATH = Path("/scratch/arka/miniconda3/external/fastai/courses/dl2/data/cifar10/")
classes = ('plane', 'car', 'bird', 'cat', 'deer', 'dog', 'frog', 'horse', 'ship', 'truck')
stats = (np.array([ 0.4914 ,  0.48216,  0.44653]), np.array([ 0.24703,  0.24349,  0.26159]))
def get_data(sz,bs):
    tfms = tfms_from_stats(stats, sz, aug_tfms=[RandomFlip()], pad=sz//8)
    return ImageClassifierData.from_paths(PATH, val_name='test', tfms=tfms, bs=bs)
# [___CELL_SEPARATOR___]
bs=128
sz=32
# [___CELL_SEPARATOR___]
md_mbl = mblnetv1(depthwise_block, 
              inc_list=[64, 64, 128, 256], 
              inc_scale = 1, 
              num_blocks_list=[2, 2, 2], 
              stride_list=[1, 2, 2], 
              num_classes=10)
# [___CELL_SEPARATOR___]
!ls {PATH / 'train'}
# [___CELL_SEPARATOR___]
data = get_data(sz, bs)
# [___CELL_SEPARATOR___]
learn = ConvLearner.from_model_data(md_mbl, data)
# [___CELL_SEPARATOR___]
learn.fit(1e-1, 4, cycle_len=1, best_save_name='mobilenetv1_2', use_clr=(20,5), metrics=[accuracy])
# [___CELL_SEPARATOR___]
learn.fit(1e-1, 4, cycle_len=2, best_save_name='mobilenetv1_3', use_clr=(20,5), metrics=[accuracy])
# [___CELL_SEPARATOR___]
learn.load('mobilenetv1_2')
learn.unfreeze()
# [___CELL_SEPARATOR___]
learn.fit(1e-1, 1, cycle_len=4, best_save_name='mobilenetv1_3n', use_clr_beta=(10,13.68,0.95,0.85), metrics=[accuracy])
# [___CELL_SEPARATOR___]
learn.fit(1e-1, 1, cycle_len=4, best_save_name='mobilenetv1_3n1', use_clr_beta=(10,13.68,0.95,0.85), wds=1e-4,
          metrics=[accuracy])
# [___CELL_SEPARATOR___]
learn.fit(1e-1, 1, cycle_len=10, best_save_name='mobilenetv1_3n1', use_clr_beta=(10,13.68,0.95,0.85), wds=1e-4,
          metrics=[accuracy])
# [___CELL_SEPARATOR___]
learn.fit(1e-2, 4, cycle_len=1, best_save_name='mobilenetv1_4n1', use_clr_beta=(10,13.68,0.95,0.85), wds=1e-4,
          metrics=[accuracy])
# [___CELL_SEPARATOR___]
learn.sched.plot_lr()
# [___CELL_SEPARATOR___]
learn.load('mobilenetv1_1')
# [___CELL_SEPARATOR___]
learn.fit(1e-2, 2, cycle_len=10, cycle_mult=2, best_save_name='mobilenetv1_1', metrics=[accuracy])