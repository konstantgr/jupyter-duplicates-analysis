from geosnap import datasets
# [___CELL_SEPARATOR___]
dir(datasets)
# [___CELL_SEPARATOR___]
datasets.codebook().tail()
# [___CELL_SEPARATOR___]
datasets.tracts_2000().head()
# [___CELL_SEPARATOR___]
datasets.states().plot()
# [___CELL_SEPARATOR___]
from matplotlib import pyplot as plt
# [___CELL_SEPARATOR___]
fig, axs = plt.subplots(1,3, figsize=(15,5))
axs = axs.flatten()

datasets.tracts_1990()[datasets.tracts_1990().geoid.str.startswith('11')].dropna(subset=['median_household_income']).plot(column='median_household_income', cmap='YlOrBr', k=6, scheme='quantiles', ax=axs[0])
axs[0].set_title(1990)
axs[0].axis('off')

datasets.tracts_2000()[datasets.tracts_2000().geoid.str.startswith('11')].dropna(subset=['median_household_income']).plot(column='median_household_income', cmap='YlOrBr', k=6, scheme='quantiles', ax=axs[1])
axs[1].set_title(2000)
axs[1].axis('off')

datasets.tracts_2010()[datasets.tracts_2010().geoid.str.startswith('11')].dropna(subset=['median_household_income']).plot(column='median_household_income', cmap='YlOrBr', k=6, scheme='quantiles', ax=axs[2])
axs[2].set_title(2010)
axs[2].axis('off')

# [___CELL_SEPARATOR___]
from geosnap.io import store_census
store_census()
# [___CELL_SEPARATOR___]
from geosnap.io import store_ltdb

# if the archives were in my downloads folder, the paths might be something like this
sample = "/Users/knaaptime/Downloads/LTDB_Std_All_Sample.zip"
full = "/Users/knaaptime/Downloads/LTDB_Std_All_fullcount.zip"

# uncomment to run
#store_ltdb(sample=sample, fullcount=full)
# [___CELL_SEPARATOR___]
#datasets.ltdb.head()
# [___CELL_SEPARATOR___]
from geosnap.io import store_ncdb

ncdb_path = "~/Downloads/ncdb.csv"

# note this will raise several warnings since NCDB does not contain all the underlying data necessary to calculate all the variables in the codebook

# uncomment to run
# store_ncdb(ncdb_path)
# [___CELL_SEPARATOR___]
#datasets.ncdb.head()
# [___CELL_SEPARATOR___]
