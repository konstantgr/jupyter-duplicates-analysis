import requests
from io import StringIO
from pygenprop.results import GenomePropertiesResults, GenomePropertiesResultsWithMatches, \
    load_assignment_caches_from_database, load_assignment_caches_from_database_with_matches
from pygenprop.database_file_parser import parse_genome_properties_flat_file
from pygenprop.assignment_file_parser import parse_interproscan_file, \
    parse_interproscan_file_and_fasta_file
from sqlalchemy import create_engine
# [___CELL_SEPARATOR___]
# The Genome Properties is a flat-file database that can be fount on Github.
# The latest release of the database can be found at the following URL:

genome_properties_database_url = 'https://raw.githubusercontent.com/ebi-pf-team/genome-properties/master/flatfiles/genomeProperties.txt'

# For this tutorial, we will stream the file directly into the Jupyter notebook. Alternatively, 
# one could download the file with UNIX wget or curl commands and open it from the file system.

with requests.Session() as current_download:
    response = current_download.get(genome_properties_database_url, stream=True)
    tree = parse_genome_properties_flat_file(StringIO(response.text))
# [___CELL_SEPARATOR___]
# There are 1286 properties in the Genome Properties tree.
len(tree)
# [___CELL_SEPARATOR___]
# Find all properties of type "GUILD".
for genome_property in tree:
    if genome_property.type == 'GUILD':
        print(genome_property.name)
# [___CELL_SEPARATOR___]
# Get property by identifier
virulence = tree['GenProp0074']
# [___CELL_SEPARATOR___]
virulence
# [___CELL_SEPARATOR___]
# Iterate to get the identifiers of child properties of virulence
types_of_vir = [genprop.id for genprop in virulence.children]
# [___CELL_SEPARATOR___]
# Iterate the names of steps of Type III Secretion
steps_of_type_3_secretion = [step.name for step in virulence.children[0].steps]
# [___CELL_SEPARATOR___]
steps_of_type_3_secretion
# [___CELL_SEPARATOR___]
# Parse InterProScan files
with open('E_coli_K12.tsv') as ipr5_file_one:
    assignment_cache_1 = parse_interproscan_file(ipr5_file_one)
# [___CELL_SEPARATOR___]
with open('E_coli_O157_H7.tsv') as ipr5_file_two:
    assignment_cache_2 = parse_interproscan_file(ipr5_file_two)
# [___CELL_SEPARATOR___]
# Create results comparison object
results = GenomePropertiesResults(assignment_cache_1, assignment_cache_2, properties_tree=tree)
# [___CELL_SEPARATOR___]
results.sample_names
# [___CELL_SEPARATOR___]
# The property results property is used to compare two property assignments across samples.
results.property_results
# [___CELL_SEPARATOR___]
# The step results property is used to compare two step assignments across samples.
results.step_results
# [___CELL_SEPARATOR___]
# Get properties with differing assignments
results.differing_property_results
# [___CELL_SEPARATOR___]
# Get property assignments for virulence properties
results.get_results(*types_of_vir, steps=False)
# [___CELL_SEPARATOR___]
# Get step assignments for virulence properties
results.get_results(*types_of_vir, steps=True)
# [___CELL_SEPARATOR___]
# Get counts of virulence properties assigned YES, NO, and PARTIAL per organism
results.get_results_summary(*types_of_vir, steps=False, normalize=False)
# [___CELL_SEPARATOR___]
# Get counts of virulence steps assigned YES, NO, and PARTIAL per organism
results.get_results_summary(*types_of_vir, steps=True, normalize=False)
# [___CELL_SEPARATOR___]
# Get percentages of virulence steps assigned YES, NO, and PARTIAL per organism
results.get_results_summary(*types_of_vir, steps=True, normalize=True)
# [___CELL_SEPARATOR___]
# Parse InterProScan files and FASTA files
with open('./E_coli_K12.tsv') as ipr5_file_one:
    with open('./E_coli_K12.faa') as fasta_file_one:
        extended_cache_one = parse_interproscan_file_and_fasta_file(ipr5_file_one, fasta_file_one)
# [___CELL_SEPARATOR___]
# Parse InterProScan files and FASTA files
with open('./E_coli_O157_H7.tsv') as ipr5_file_two:
    with open('./E_coli_O157_H7.faa') as fasta_file_two:
        extended_cache_two = parse_interproscan_file_and_fasta_file(ipr5_file_two, fasta_file_two)
# [___CELL_SEPARATOR___]
# Create a GenomePropertiesResultsWithMatches from the assignment caches.
extended_results = GenomePropertiesResultsWithMatches(extended_cache_one,
                                                      extended_cache_two,
                                                      properties_tree=tree)
# [___CELL_SEPARATOR___]
# GenomePropertiesResultsWithMatches objects possess the same   
# assignment comparison methods as GenomePropertiesResults objects
extended_results.property_results
# [___CELL_SEPARATOR___]
extended_results.step_results
# [___CELL_SEPARATOR___]
# Get the matches and protein sequences that support properties and steps assigned YES across both organisms. 
extended_results.step_matches
# [___CELL_SEPARATOR___]
# Get all matches for E_coli_K12
extended_results.get_sample_matches('E_coli_K12', top=False)
# [___CELL_SEPARATOR___]
type_three_secretion_property_id = types_of_vir[0] # From section above.


# Get all matches for each Type III Secretion step across both organisms.
extended_results.get_property_matches(type_three_secretion_property_id)
# [___CELL_SEPARATOR___]
# Get the lowest E-value matches for each Type III Secretion step for E_coli_O157_H7.
extended_results.get_property_matches(type_three_secretion_property_id, sample='E_coli_O157_H7', top=True)
# [___CELL_SEPARATOR___]
# Get the lowest E-value matches for step 22 of Type III Secretion property across both organisms. 
extended_results.get_step_matches(type_three_secretion_property_id, 22, top=True)
# [___CELL_SEPARATOR___]
# Get all matches for step 22 of the Type III Secretion property for E. coli K12. 
extended_results.get_step_matches(type_three_secretion_property_id, 22, top=False, sample='E_coli_K12')
# [___CELL_SEPARATOR___]
# Get skbio protein objects for a particular step.
extended_results.get_supporting_proteins_for_step(type_three_secretion_property_id, 22, top=True)
# [___CELL_SEPARATOR___]
# Write FASTA file containing the sequences of the lowest E-value matches for 
# Type III Secretion System component 22 across both organisms.
with open('type_3_step_22_top.faa', 'w') as out_put_fasta_file:
    extended_results.write_supporting_proteins_for_step_fasta(out_put_fasta_file, 
                                                              type_three_secretion_property_id, 
                                                              22, top=True)
# [___CELL_SEPARATOR___]
# Write FASTA file containing the sequences of all matches for 
# Type III Secretion System component 22 across both organisms.
with open('type_3_step_22_all.faa', 'w') as out_put_fasta_file:
    extended_results.write_supporting_proteins_for_step_fasta(out_put_fasta_file, 
                                                              type_three_secretion_property_id, 
                                                              22, top=False)
# [___CELL_SEPARATOR___]
# Create a SQLAlchemy engine object for a SQLite3 Micromeda file.  
engine_no_proteins = create_engine('sqlite:///ecoli_compare_no_proteins.micro')

# Write the results to the file.
results.to_assignment_database(engine_no_proteins)
# [___CELL_SEPARATOR___]
# Create a SQLAlchemy engine object for a SQLite3 Micromeda file.  
engine_proteins = create_engine('sqlite:///ecoli_compare.micro')

# Write the results to the file.
extended_results.to_assignment_database(engine_proteins)
# [___CELL_SEPARATOR___]
# Load results from a Micromeda file.
assignment_caches = load_assignment_caches_from_database(engine_no_proteins)
results_reconstituted = GenomePropertiesResults(*assignment_caches, properties_tree=tree)
# [___CELL_SEPARATOR___]
# Load results from a Micromeda file with proteins sequences.
assignment_caches_with_proteins = load_assignment_caches_from_database_with_matches(engine_proteins)
results_reconstituted_with_proteins = GenomePropertiesResultsWithMatches(*assignment_caches_with_proteins, 
                                                                         properties_tree=tree)