import tqdm
from tqdm import tqdm_notebook

import time

import numpy as np
import matplotlib
import matplotlib.pyplot as plt
import mpl_toolkits.mplot3d.axes3d as axes3d

import matplotlib.ticker as ticker
# [___CELL_SEPARATOR___]
# import warnings
# warnings.filterwarnings('ignore')
# [___CELL_SEPARATOR___]
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
# [___CELL_SEPARATOR___]
import os
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
# fonts for ICML
def SetPlotRC():
    #If fonttype = 1 doesn't work with LaTeX, try fonttype 42.
    plt.rc('pdf',fonttype = 42)
    plt.rc('ps',fonttype = 42)
# [___CELL_SEPARATOR___]
SetPlotRC()
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
def get_df(num_models, num_exper, file_names, model_names, y_axe,  y_axe_name, title, num_show = []):
    acc_num = 3
    dist_calc_num = 7
    df = []
    for i in range(len(file_names)):
        file_name = os.path.expanduser(file_names[i])
        data = np.genfromtxt(file_name, dtype=('U10','U10','U10',float,'U10',int,'U10',int,'U10',float)).tolist()
        cur_line = -1
        for mod in range(num_models[i]):
            for j in range(num_exper[i]):
                cur_line += 1
                if y_axe == 11:
                    df.append([1.00001 - data[cur_line][acc_num],
                               1 / data[cur_line][y_axe], model_names[i][mod], title])
                else:
                    df.append([1.00001 - data[cur_line][acc_num],
                              data[cur_line][y_axe], model_names[i][mod], title])

    df = pd.DataFrame(df, columns=["Error = 1 - Recall@1", y_axe_name, "algorithm", "title"])
#     print(df.shape)
    if len(num_show) > 0:
        it = 0
        itt = 0
        num_for_iloc = []
        model_names_list = []
        for i in range(len(file_names)):
            for mod in range(len(model_names[i])):
                model_names_list.append(model_names[i][mod])
        allowed_set = set()
        same_dict = dict()
        for i in range(len(file_names)):
            for mod in range(len(model_names[i])):
                if itt in num_show:
                    allowed_set.add(model_names_list[i])
                    for j in range(num_exper[i]):
                        num_for_iloc.append(it)
                        it += 1
                else:
                    it += num_exper[i]
                itt += 1
    df = df.iloc[num_for_iloc]
    
    return df
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
def show_results(frames, title, y_axe_name, x_log=True, y_log=False,
                      dims=(18, 12), save=False, file_name='trash'):
    size = len(frames)
    ylim = [[500, 5000], [0, 1000],[0, 1000],[0, 1000]]
    a4_dims = dims
    fig, axs = plt.subplots(2, 2, figsize=a4_dims)
    for i in range(2):
        for j in range(2):
            num = i * 2 + j
            if i + j == 2:
                sns.lineplot(x="Error = 1 - Recall@1", y=y_axe_name,hue="algorithm",
                              markers=True, style="algorithm", dashes=False,
                              data=frames[num], ax=axs[i, j], linewidth=3, ms=15)
            else:
                sns.lineplot(x="Error = 1 - Recall@1", y=y_axe_name,hue="algorithm",
                              markers=True, style="algorithm", dashes=False,
                              data=frames[num], ax=axs[i, j], legend=False, linewidth=3, ms=15)
            
            axs[i, j].set_title(title[num], size='30')

            lx = axs[i, j].get_xlabel()
            ly = axs[i, j].get_ylabel()
            axs[i, j].set_xlabel(lx, fontsize=25)
            axs[i, j].set_ylabel(ly, fontsize=25)
            axs[i, j].tick_params(axis='both', which='both', labelsize=25)
            axs[i, j].set_ymargin(0.075)
            if i == 0:
                axs[i, j].set_xlabel('')
            if j == 1:
                axs[i, j].set_ylabel('')
            
            
#             ApplyFont(axs[i,j])
            
    plt.legend(loc=2, bbox_to_anchor=(1.05, 1, 0.5, 0.5), fontsize='30', markerscale=3, borderaxespad=0.)
    if y_log:
        for i in range(2):
            for j in range(2):
                axs[i, j].set(yscale="log")
            
    if x_log:
        for i in range(2):
            for j in range(2):
                axs[i, j].set(xscale="log")# num_exper = [6, 6, 3]
    if save:
        fig.savefig(file_name + ".pdf", bbox_inches='tight')
# [___CELL_SEPARATOR___]
path = '~/Desktop/results/synthetic_n_10_6_d_'
# path = '~/results/synthetic_n_10_6_d_'
# [___CELL_SEPARATOR___]
y_axe = 7
y_axe_name = "dist calc"
model_names = [['kNN', 'kNN + Kl', 'kNN + Kl + llf', 'kNN + beam', 'kNN + beam + Kl + llf']]
num_show = [0, 1, 2, 3, 4]

num_exper = [5]
num_models = [5]
file_names = [path + '3.txt']
df_2 = get_df(num_models, num_exper, file_names, model_names,  y_axe, y_axe_name, title="trash", num_show=num_show)

# print(df_2)

num_exper = [6]
num_models = [5]
file_names = [path + '5.txt']
df_4 = get_df(num_models, num_exper, file_names, model_names, y_axe, y_axe_name, title="trash", num_show=num_show)

num_exper = [6]
num_models = [5]
file_names = [path + '9.txt']
df_8 = get_df(num_models, num_exper, file_names, model_names, y_axe, y_axe_name, title="trash", num_show=num_show)
      
num_exper = [6]
num_models = [5]
file_names = [path + '17.txt']

df_16 = get_df(num_models, num_exper, file_names, model_names, y_axe, y_axe_name, title="trash", num_show=num_show)

frames = [df_2, df_4, df_8, df_16]
show_results(frames, ['d = 2', 'd = 4', 'd = 8', 'd = 16'],  y_axe_name,
                  y_log=False, x_log=True, dims=(24, 14),
                  save=False, file_name='synthetic_datasets_2_2_final')

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
def show_results_dist_1_3(frames, title, y_axe_name,
                          dims=(18, 12), save=False, file_name='trash', legend_size=13):
    size = len(frames)
    a4_dims = dims
    fig, axs = plt.subplots(1, 3, figsize=a4_dims)
    for i in range(3):
        sns.lineplot(x="Error = 1 - Recall@1", y=y_axe_name,hue="algorithm",
                     markers=True, style="algorithm", dashes=False,
                     data=frames[i], ax=axs[i], linewidth=2, ms=10)
        
        axs[i].set_title(title[i], size='20')

        lx = axs[i].get_xlabel()
        ly = axs[i].get_ylabel()
        axs[i].set_xlabel(lx, fontsize=20)
        axs[i].set_ylabel(ly, fontsize=20)
        axs[i].set_xscale('log')
        if i == 0:
            axs[i].set_xticks([0.001, 0.01, .1])
        else:
            axs[i].set_xticks([0.01, 0.1])
        axs[i].get_xaxis().set_major_formatter(matplotlib.ticker.ScalarFormatter())
        axs[i].tick_params(axis='both', which='both', labelsize=15)
        if i > 0:
            axs[i].set_ylabel('')
        
        plt.setp(axs[i].get_legend().get_texts(), fontsize=legend_size)
            
    if save:
        fig.savefig(file_name + ".pdf", bbox_inches='tight')
# [___CELL_SEPARATOR___]
y_axe = 7
y_axe_name = "dist calc"
model_names = [['kNN', 'kNN + Kl + llf 4', 'kNN + Kl + llf 8',
                'kNN + Kl + llf 16', 'kNN + Kl + llf 32']]

num_show = [0, 1, 2, 3, 4]

num_exper = [6]
num_models = [5]
file_names = [path + '5_nlt.txt']
df_kl_4 = get_df(num_models, num_exper, file_names, model_names, y_axe, y_axe_name, title="trash", num_show=num_show)

num_exper = [6]
num_models = [5]
file_names = [path + '9_nlt.txt']
df_kl_8 = get_df(num_models, num_exper, file_names, model_names, y_axe, y_axe_name, title="trash", num_show=num_show)

num_exper = [6]
num_models = [5]
file_names = [path + '17_nlt.txt']
df_kl_16 = get_df(num_models, num_exper, file_names, model_names, y_axe, y_axe_name, title="trash", num_show=num_show)

frames = [df_kl_4, df_kl_8, df_kl_16]
show_results_dist_1_3(frames, ['d = 4', 'd = 8', 'd = 16'], y_axe_name, dims=(20, 6),
                  save=False, file_name='suppl_figure_optimal_kl_number')


# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
path_end = '_llt.txt'
# [___CELL_SEPARATOR___]
y_axe = 7
y_axe_name = "dist calc"
model_names = [['kNN', 'thrNN', 'kNN + Kl-dist + llf', 'kNN + Kl-rank + llf', 'kNN + Kl-rank sample + llf']]

num_show = [0, 1, 2, 3, 4]

num_exper = [6]
num_models = [5]
file_names = [path + '5' + path_end]
df_kl_4 = get_df(num_models, num_exper, file_names, model_names, y_axe, y_axe_name, title="trash", num_show=num_show)

num_exper = [6]
num_models = [5]
file_names = [path + '9' + path_end]
df_kl_8 = get_df(num_models, num_exper, file_names, model_names, y_axe, y_axe_name, title="trash", num_show=num_show)

num_exper = [6]
num_models = [5]
file_names = [path + '17' + path_end]
df_kl_16 = get_df(num_models, num_exper, file_names, model_names, y_axe, y_axe_name, title="trash", num_show=num_show)

frames = [df_kl_4, df_kl_8, df_kl_16]
show_results_dist_1_3(frames, ['d = 4', 'd = 8', 'd = 16'], y_axe_name, dims=(20, 6),
                  save=False, file_name='suppl_figure_optimal_kl_type', legend_size=10)


# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
path_start = "~/Desktop/results/distr_to_1_"
path_end = ".txt"
# [___CELL_SEPARATOR___]

a4_dims = (7, 3)
fig, ax = plt.subplots(figsize=a4_dims)
ax.set_yticks([]) 

file_name = path_start + "sift" + path_end
file_name = os.path.expanduser(file_name)
distr = np.genfromtxt(file_name)
sns.distplot(distr, label="SIFT")

file_name = path_start + "d_9" + path_end
file_name = os.path.expanduser(file_name)
distr = np.genfromtxt(file_name)
sns.distplot(distr, label="d=8")

file_name = path_start + "d_17" + path_end
file_name = os.path.expanduser(file_name)
distr = np.genfromtxt(file_name)
sns.distplot(distr, label="d=16")

file_name = path_start + "d_33" + path_end
file_name = os.path.expanduser(file_name)
distr = np.genfromtxt(file_name)
sns.distplot(distr, label="d=32")

file_name = path_start + "d_65" + path_end
file_name = os.path.expanduser(file_name)
distr = np.genfromtxt(file_name)
sns.distplot(distr, label="d=64")


plt.legend()

fig.savefig("suppl_dist_disrt.pdf", bbox_inches='tight')
# [___CELL_SEPARATOR___]
