%scala
dbutils.fs.mount(
  source = "wasbs://<Container name>@<Storage account name>.blob.core.windows.net",
  mountPoint = "/mnt/data",
  extraConfigs = Map("<conf-key>" -> "<Storage account key>"))
# [___CELL_SEPARATOR___]
%scala

val df = spark.read
  .option("header", "true")
  .option("inferSchema", "true")
  .option("delimiter", ",")
  .csv("/mnt/data/housing.csv")
# [___CELL_SEPARATOR___]
%scala
import org.apache.spark.eventhubs._

// Build connection string with the above information
val connectionString = ConnectionStringBuilder("<Event hub connection string>")
  .setEventHubName("<Event hub name>")
  .build

val customEventhubParameters =
  EventHubsConf(connectionString)
  .setMaxEventsPerTrigger(5)

val streaming_df = spark.readStream.format("eventhubs").options(customEventhubParameters.toMap).load()

streaming_df.join(df)