from textblob import TextBlob
# [___CELL_SEPARATOR___]
testimonial = TextBlob("the weather outside is very good, i love these days for going out.")
# [___CELL_SEPARATOR___]
testimonial.sentiment
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
