import numpy as np
import pandas as pd
import os
import sys
import csv
from sklearn import metrics
from sklearn.metrics import classification_report

sys.path.append("../") 
from bert_sklearn import BertClassifier

DATADIR = os.getcwd() + '/glue_data'
#DATADIR = '/data/glue_data'
# [___CELL_SEPARATOR___]
%%time
%%bash
python3 download_glue_data.py --data_dir glue_data --tasks MNLI 
# [___CELL_SEPARATOR___]
"""
MNLI train data size: 392702 
MNLI dev_matched data size: 9815 
MNLI dev_mismatched data size: 9832 
"""
def read_tsv(filename,quotechar=None):
    with open(filename, "r", encoding='utf-8') as f:
        return list(csv.reader(f,delimiter="\t",quotechar=quotechar))
    
def get_mnli_df(filename):
    rows = read_tsv(filename)    
    df=pd.DataFrame(rows[1:],columns=rows[0])
    df=df[['sentence1','sentence2','gold_label']]
    df.columns=['text_a','text_b','label']
    df = df[pd.notnull(df['label'])]                
    return df    

def get_mnli_data(train_file = DATADIR + '/MNLI/train.tsv',
                  dev_matched_file = DATADIR + '/MNLI/dev_matched.tsv',                  
                  dev_mismatched_file = DATADIR + '/MNLI/dev_mismatched.tsv'):
    
    train = get_mnli_df(train_file) 
    print("MNLI train data size: %d "%(len(train)))        
    dev_matched = get_mnli_df(dev_matched_file) 
    print("MNLI dev_matched data size: %d "%(len(dev_matched)))        
    dev_mismatched = get_mnli_df(dev_mismatched_file)
    print("MNLI dev_mismatched data size: %d "%(len(dev_mismatched)))        
    label_list = np.unique(train['label'].values)

    return train,dev_matched,dev_mismatched,label_list

train,dev_matched,dev_mismatched,label_list = get_mnli_data()

# [___CELL_SEPARATOR___]
print(label_list)
# [___CELL_SEPARATOR___]
train.head()
# [___CELL_SEPARATOR___]
dev_matched.head()
# [___CELL_SEPARATOR___]
dev_mismatched.head()
# [___CELL_SEPARATOR___]
%%time

#nrows = 1000
#train = train.sample(nrows)
#dev_mismatched = dev_mismatched.sample(nrows)
#dev_matched = dev_matched.sample(nrows)

X_train = train[['text_a','text_b']]
y_train = train['label']

# define model
model = BertClassifier()
model.epochs = 4
model.learning_rate = 3e-5
model.max_seq_length = 128
model.validation_fraction = 0.05

print('\n',model,'\n')

# fit model
model.fit(X_train, y_train)

# score model on dev_matched
test = dev_matched
X_test = test[['text_a','text_b']]
y_test = test['label']
m_accy=model.score(X_test, y_test)

# score model on dev_mismatched
test = dev_mismatched
X_test = test[['text_a','text_b']]
y_test = test['label']
mm_accy=model.score(X_test, y_test)

print("Matched/mismatched accuracy: %0.2f/%0.2f %%"%(m_accy,mm_accy))
# [___CELL_SEPARATOR___]
%%time

#nrows = 1000
#train = train.sample(nrows)
#dev_mismatched = dev_mismatched.sample(nrows)
#dev_matched = dev_matched.sample(nrows)

X_train = train[['text_a','text_b']]
y_train = train['label']

# define model
model = BertClassifier()
model.epochs = 4
model.learning_rate = 3e-5
model.max_seq_length = 128
model.validation_fraction = 0.05
model.num_mlp_layers = 4

print('\n',model,'\n')

# fit model
model.fit(X_train, y_train)

# score model on dev_matched
test = dev_matched
X_test = test[['text_a','text_b']]
y_test = test['label']
m_accy=model.score(X_test, y_test)

# score model on dev_mismatched
test = dev_mismatched
X_test = test[['text_a','text_b']]
y_test = test['label']
mm_accy=model.score(X_test, y_test)

print("Matched/mismatched accuracy: %0.2f/%0.2f %%"%(m_accy,mm_accy))
