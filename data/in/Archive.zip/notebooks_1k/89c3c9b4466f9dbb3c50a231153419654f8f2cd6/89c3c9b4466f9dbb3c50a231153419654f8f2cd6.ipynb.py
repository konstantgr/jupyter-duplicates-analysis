import matplotlib
import pandas as pd
import numpy as np
from astropy.io import fits
from astropy.table import Table
import matplotlib.pyplot as plt
import treecorr
import h5py   
from math import *
%matplotlib inline
from scipy import stats
# [___CELL_SEPARATOR___]
input_data_path = '/global/cscratch1/sd/elp25/TXPipe/data/metacal-2.1i-dr1b-inputs/'
# [___CELL_SEPARATOR___]
import sys
# [___CELL_SEPARATOR___]
sys.path.insert(0, '/global/cscratch1/sd/elp25/sacc/')
# [___CELL_SEPARATOR___]
import sacc
# [___CELL_SEPARATOR___]
from astropy.coordinates import SkyCoord
import FoFCatalogMatching
import GCRCatalogs
from GCR import GCRQuery
# [___CELL_SEPARATOR___]
shear_catalog_file = input_data_path + 'shear_catalog.hdf5'
# [___CELL_SEPARATOR___]
photometry_catalog_file = input_data_path + 'photometry_catalog.hdf5'
# [___CELL_SEPARATOR___]
photo_file =  h5py.File(photometry_catalog_file, 'r')
photo_data = photo_file['photometry']
# [___CELL_SEPARATOR___]
shear_file =  h5py.File(shear_catalog_file, 'r')
shear_data = shear_file['metacal']
# [___CELL_SEPARATOR___]
#Note the catalogs are in the metacal format "mcal_T_1m" for example refers to the value of T remeasured on an object 
# that has had a negaive applied shear
cols = [col for col in shear_data]
print(cols[0:5])
# [___CELL_SEPARATOR___]
path = '/global/cscratch1/sd/elp25/TXPipe/outputs/'
# [___CELL_SEPARATOR___]
stacked_photozs =  h5py.File(path + 'photoz_stack.hdf5', 'r')
# [___CELL_SEPARATOR___]
for group in stacked_photozs:
    print(group)
# [___CELL_SEPARATOR___]
for member in stacked_photozs['n_of_z']:
    print(member)
# [___CELL_SEPARATOR___]
for item in stacked_photozs['n_of_z/lens']:
    print(item)
# [___CELL_SEPARATOR___]
for bin_num in ['0','1','2','3']:
    if bin_num=='0':
        plt.plot(stacked_photozs['n_of_z/lens']['z'],stacked_photozs['n_of_z/lens']['bin_'+bin_num],label='bin '+ bin_num + ' (lens)')
    else:
        plt.plot(stacked_photozs['n_of_z/source']['z'],stacked_photozs['n_of_z/source']['bin_'+bin_num],label='bin '+ bin_num + ' (source)')
plt.legend(loc='best')
plt.ylabel('n(z)')
plt.xlabel('z')
plt.show()
# [___CELL_SEPARATOR___]
import pandas as pd
import numpy as np
import healpy as hp
# [___CELL_SEPARATOR___]
maps = h5py.File(path + "diagnostic_maps.hdf5",'r')
# [___CELL_SEPARATOR___]
import healpy
import numpy as np
group = '/maps'
nside = 1024
npix = healpy.nside2npix(nside)
m = np.repeat(healpy.UNSEEN, npix)
pix = maps['maps']['depth']['pixel'][:]
val = maps['maps']['depth']['value'][:]
m[pix] = val
# [___CELL_SEPARATOR___]
lon,lat=healpy.pix2ang(nside,pix,lonlat=True)
npix=healpy.nside2npix(nside)
if len(pix)==0:
    print(f"Empty map {map_name}")
if len(pix)==len(m):
    w = np.where((m!=healpy.UNSEEN)&(m!=0))
else:
    w = None
lon_range = [lon[w].min()-0.1, lon[w].max()+0.1]
lat_range = [lat[w].min()-0.1, lat[w].max()+0.1]
m[m==0] = healpy.UNSEEN
title = 'Depth Map'
view = 'cart'
if view == 'cart':
    healpy.cartview(m, lonra=lon_range, latra=lat_range, title=title, hold=True)#, **kwargs)
elif view == 'moll':
    healpy.mollview(m, title=title, hold=True)#, **kwargs)
# [___CELL_SEPARATOR___]
group = '/maps'
nside = 1024
npix = healpy.nside2npix(nside)
m = np.repeat(healpy.UNSEEN, npix)
pix = maps['maps']['g1_1']['pixel'][:]
val = maps['maps']['g1_1']['value'][:]
m[pix] = val
# [___CELL_SEPARATOR___]
lon,lat=healpy.pix2ang(nside,pix,lonlat=True)
npix=healpy.nside2npix(nside)
if len(pix)==0:
    print(f"Empty map {map_name}")
if len(pix)==len(m):
    w = np.where((m!=healpy.UNSEEN)&(m!=0))
else:
    w = None
lon_range = [lon[w].min()-0.1, lon[w].max()+0.1]
lat_range = [lat[w].min()-0.1, lat[w].max()+0.1]
m[m==0] = healpy.UNSEEN
title = 'Shear Map'
view = 'cart'
if view == 'cart':
    healpy.cartview(m, lonra=lon_range, latra=lat_range, title=title, hold=True)#, **kwargs)
elif view == 'moll':
    healpy.mollview(m, title=title, hold=True)#, **kwargs)
# [___CELL_SEPARATOR___]
# Randoms data

randoms = h5py.File(path + "random_cats.hdf5",'r')

ra = randoms['randoms/ra'][:]
dec = randoms['randoms/dec'][:]
ra[ra>180] -= 360
# [___CELL_SEPARATOR___]
H, xedges, yedges = np.histogram2d(ra, dec,bins=200)
# [___CELL_SEPARATOR___]
plt.figure(figsize=(12,6))
plt.subplot(122)
plt.plot(ra[::100], dec[::100], ',')
plt.axis('equal')
plt.xlabel("Ra")
plt.ylabel("Dec")
plt.title("Randoms Catalog")
plt.grid()
# [___CELL_SEPARATOR___]
# Note one todo for this is to save the covariance output alongside the data vector and n(z) in the SACC output.
#cov_path = 'TXPipe/outputs'
# [___CELL_SEPARATOR___]
#cov_matrix = np.load(cov_path+'cov_test.npy')
# [___CELL_SEPARATOR___]
plt.figure(figsize=(7,7))
plt.imshow(cov_matrix,vmin=0.0,vmax=1e-20)
plt.colorbar()
plt.title('Gaussian Covariance Matrix Fourier Space')
# [___CELL_SEPARATOR___]
twopoint_data = sacc.Sacc.load_fits(path+'twopoint_data.sacc')
# [___CELL_SEPARATOR___]
!ls /global/projecta/projectdirs/lsst/groups/WL/users/zuntz/data/2.1i-inputs
# [___CELL_SEPARATOR___]
c_data = twopoint_data.get_theta_xi('galaxy_density_xi', 'lens_0', 'lens_0')
# [___CELL_SEPARATOR___]
plt.scatter(c_data[0],c_data[1])
plt.xscale('log')
plt.ylabel(r'$w(\theta)$')
plt.xlabel(r'$\theta$ (deg)')
plt.xlabel(r'$\theta$ (deg)')
plt.show()
# [___CELL_SEPARATOR___]
gg_data = twopoint_data.get_theta_xi('galaxy_shearDensity_xi_t', 'source_1', 'lens_0')
# [___CELL_SEPARATOR___]
plt.scatter(gg_data[0],gg_data[1])
plt.ylim(-1e-4,5e-4)
plt.xscale('log')
plt.ylabel(r'$\gamma_T(\theta)$')
plt.xlabel(r'$\theta$ (deg)')
plt.xlabel(r'$\theta$ (deg)')
plt.show()
# [___CELL_SEPARATOR___]
shear_data = twopoint_data.get_theta_xi('galaxy_shear_xi_plus', 'source_1', 'source_1')
# [___CELL_SEPARATOR___]
plt.scatter(shear_data[0],shear_data[1],label=r'$\xi_{+}$')
plt.ylim(-1e-4,5e-4)
plt.ylabel(r'$\chi_+$($\theta$)')
plt.xlabel(r'$\theta$ (deg)')
plt.xscale('log')
plt.xlabel(r'$\theta$ (deg)')
plt.ylabel(r'$\gamma_T(\theta)$')
plt.legend(loc='best')
plt.show()
# [___CELL_SEPARATOR___]
shear_data = twopoint_data.get_theta_xi('galaxy_shear_xi_minus', 'source_1', 'source_1')
# [___CELL_SEPARATOR___]
plt.scatter(shear_data[0],shear_data[1],label=r'$\xi_{-}$')
plt.ylim(-1e-4,5e-4)
plt.ylabel(r'$\chi_+$($\theta$)')
plt.xlabel(r'$\theta$ (deg)')
plt.xscale('log')
plt.xlabel(r'$\theta$ (deg)')
plt.ylabel(r'$\xi (r)$')
plt.legend(loc='best')
plt.show()