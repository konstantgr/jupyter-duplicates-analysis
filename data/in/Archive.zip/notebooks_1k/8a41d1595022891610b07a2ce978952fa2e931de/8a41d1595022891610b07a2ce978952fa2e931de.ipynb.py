from rdkit import Chem
# [___CELL_SEPARATOR___]
mol = Chem.MolFromSmiles("c1cc(ccc1c2c(n(cn2)CC3CC3)c4ccnc(n4)N)F")
# [___CELL_SEPARATOR___]
mol
# [___CELL_SEPARATOR___]
from rdkit.Chem.Draw import IPythonConsole
# [___CELL_SEPARATOR___]
mol
# [___CELL_SEPARATOR___]
def attach_atom(mol, query, atomic_num):
    result_smiles_list = []
    match_list = mol.GetSubstructMatches(query)
    for idx in [x[0] for x in match_list]:
        new_mol = Chem.RWMol(mol)
        new_idx = new_mol.AddAtom(Chem.Atom(atomic_num))
        new_mol.AddBond(idx, new_idx, order=Chem.rdchem.BondType.SINGLE)
        result_smiles_list.append(Chem.MolToSmiles(new_mol, True))
    return result_smiles_list
# [___CELL_SEPARATOR___]
res = list(set(attach_atom(mol,Chem.MolFromSmarts('[#6H,#6H2,#6H3]'),6)))
# [___CELL_SEPARATOR___]
mol_list = [Chem.MolFromSmiles(x) for x in res]
# [___CELL_SEPARATOR___]
Chem.Draw.MolsToGridImage(mol_list)
# [___CELL_SEPARATOR___]
