from tensorflow.examples.tutorials.mnist import input_data
import tensorflow as tf
import matplotlib.pyplot as plt
# [___CELL_SEPARATOR___]
mnist = input_data.read_data_sets('./datasets/ch08/tensorflow/MNIST',one_hot=True)
# [___CELL_SEPARATOR___]
print(mnist.train.images.shape)
print(mnist.train.labels.shape)
# [___CELL_SEPARATOR___]
print(mnist.validation.images.shape)
print(mnist.validation.labels.shape)
# [___CELL_SEPARATOR___]
print(mnist.test.images.shape)
print(mnist.test.labels.shape)
# [___CELL_SEPARATOR___]
# input 代表输入，filter 代表卷积核
# 卷积层
def conv2d(x, filter):
    return tf.nn.conv2d(x, 
                        filter, 
                        strides=[1,1,1,1], 
                        padding='SAME')

# 池化层
def max_pool(x):
    return tf.nn.max_pool(x, 
                          ksize=[1,2,2,1], 
                          strides=[1,2,2,1], 
                          padding='SAME')

# 初始化卷积核或者是权重数组的值
def weight_variable(shape):
    initial = tf.truncated_normal(shape, stddev=0.1)
    return tf.Variable(initial)

# 初始化bias的值
def bias_variable(shape):
    initial = tf.constant(0.1, shape=shape)
    return tf.Variable(initial)
# [___CELL_SEPARATOR___]
# None　代表图片数量未知
x = tf.placeholder(tf.float32, [None,784])/255
# 将input 重新调整结构，适用于CNN的特征提取
x_image = tf.reshape(x, [-1,28,28,1])

# y是最终预测的结果
y = tf.placeholder(tf.float32, [None,10])
# [___CELL_SEPARATOR___]
W_conv1 = weight_variable([5, 5, 1, 32])  # 卷积核尺寸：5x5, 输入通道：1, 输出通道：32
b_conv1 = bias_variable([32])
h_conv1 = tf.nn.relu(conv2d(x_image, W_conv1) + b_conv1)  # 输出尺寸：28x28x32
h_pool1 = max_pool(h_conv1)     # 输出尺寸：14x14x32
# [___CELL_SEPARATOR___]
W_conv2 = weight_variable([5, 5, 32, 64])  # 卷积核尺寸：5x5, 输入通道：32, 输出通道：64
b_conv2 = bias_variable([64])
h_conv2 = tf.nn.relu(conv2d(h_pool1, W_conv2) + b_conv2)  # 输出尺寸：14x14x64
h_pool2 = max_pool(h_conv2)     # 输出尺寸：7x7x64
# [___CELL_SEPARATOR___]
W_fc1 = weight_variable([7*7*64, 1024])
b_fc1 = bias_variable([1024])
h_pool2_flat = tf.reshape(h_pool2, [-1, 7*7*64])  # 展开为一维向量
h_fc1 = tf.nn.relu(tf.matmul(h_pool2_flat, W_fc1) + b_fc1)
# [___CELL_SEPARATOR___]
W_fc2 = weight_variable([1024, 10])
b_fc2 = bias_variable([10])
prediction = tf.nn.softmax(tf.matmul(h_fc1, W_fc2) + b_fc2)
# [___CELL_SEPARATOR___]
cross_entropy = tf.reduce_mean(-tf.reduce_sum(y * tf.log(prediction),reduction_indices=[1]))   
train_step = tf.train.AdamOptimizer(1e-4).minimize(cross_entropy)
# [___CELL_SEPARATOR___]
#判断预测标签和实际标签是否匹配
correct_prediction = tf.equal(tf.argmax(prediction,1), tf.argmax(y,1))
accuracy = tf.reduce_mean(tf.cast(correct_prediction,"float"))
# [___CELL_SEPARATOR___]
sess = tf.Session()
init = tf.global_variables_initializer()
sess.run(init)

cost = []

for i in range(1000):
    batch_x, batch_y = mnist.train.next_batch(100)
    sess.run(train_step, feed_dict={x: batch_x, y: batch_y})
    if (i+1) % 50 == 0:
        print("train accuracy %.3f" % accuracy.eval(session = sess,
                feed_dict = {x:batch_x, y:batch_y}))
print("test accuracy %.3f" % accuracy.eval(session = sess,
    feed_dict = {x:mnist.test.images, y:mnist.test.labels}))
# [___CELL_SEPARATOR___]
