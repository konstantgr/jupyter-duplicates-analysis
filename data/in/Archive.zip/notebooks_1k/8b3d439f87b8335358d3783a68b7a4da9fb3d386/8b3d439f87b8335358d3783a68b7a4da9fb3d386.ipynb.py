from cbrain.imports import *
# [___CELL_SEPARATOR___]
fn = '/scratch/srasp/preprocessed_data/fbp_engy_ess_train_fullyear_norm.nc'
# [___CELL_SEPARATOR___]
!mv {fn} {fn}.orig
# [___CELL_SEPARATOR___]
ds = xr.open_dataset(f'{fn}.orig')
# [___CELL_SEPARATOR___]
ds['target_conv']
# [___CELL_SEPARATOR___]
ds['target_conv'][:30] = C_P
ds['target_conv'][30:60] = L_S
# [___CELL_SEPARATOR___]
ds['target_conv']
# [___CELL_SEPARATOR___]
ds.to_netcdf(fn)
# [___CELL_SEPARATOR___]
ds.close()
# [___CELL_SEPARATOR___]
