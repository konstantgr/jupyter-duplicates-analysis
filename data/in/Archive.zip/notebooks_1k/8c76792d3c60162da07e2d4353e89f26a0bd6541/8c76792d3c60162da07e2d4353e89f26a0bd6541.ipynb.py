from deeputil.datasets import Seeds
# [___CELL_SEPARATOR___]
df = Seeds.load_data_as_pandas_df()
# [___CELL_SEPARATOR___]
df.shape
# [___CELL_SEPARATOR___]
df.describe
# [___CELL_SEPARATOR___]
