import numpy as np
# [___CELL_SEPARATOR___]
m1 = np.array([[5,12,6],[-3,0,14]])
m1
# [___CELL_SEPARATOR___]
m2 = np.array([[9,8,7],[1,3,-5]])
m2
# [___CELL_SEPARATOR___]
t = np.array([m1,m2])
# [___CELL_SEPARATOR___]
t
# [___CELL_SEPARATOR___]
t.shape
# [___CELL_SEPARATOR___]
t_manual = np.array([[[ 5, 12,  6], [-3,  0, 14]], [[ 9,  8,  7], [ 1,  3, -5]]])
# [___CELL_SEPARATOR___]
t_manual