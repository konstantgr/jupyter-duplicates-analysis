from giddy import markov,mobility
mobility.markov_mobility?
# [___CELL_SEPARATOR___]
import libpysal
import numpy as np
import mapclassify as mc
# [___CELL_SEPARATOR___]
income_path = libpysal.examples.get_path("usjoin.csv")
f = libpysal.io.open(income_path)
pci = np.array([f.by_col[str(y)] for y in range(1929, 2010)]) #each column represents an state's income time series 1929-2010
q5 = np.array([mc.Quantiles(y).yb for y in pci]).transpose() #each row represents an state's income time series 1929-2010
m = markov.Markov(q5)
m.p
# [___CELL_SEPARATOR___]
mobility.markov_mobility(m.p, measure="P")
# [___CELL_SEPARATOR___]
mobility.markov_mobility(m.p, measure="D")
# [___CELL_SEPARATOR___]
mobility.markov_mobility(m.p, measure = "L2")
# [___CELL_SEPARATOR___]
pi = np.array([0.1,0.2,0.2,0.4,0.1])
mobility.markov_mobility(m.p, measure = "B1", ini=pi)
# [___CELL_SEPARATOR___]
pi = np.array([0.1,0.2,0.2,0.4,0.1])
mobility.markov_mobility(m.p, measure = "B2", ini=pi)