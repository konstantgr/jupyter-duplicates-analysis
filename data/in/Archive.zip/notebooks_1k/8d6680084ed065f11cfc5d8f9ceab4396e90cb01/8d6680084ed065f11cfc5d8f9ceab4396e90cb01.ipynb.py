%load_ext autoreload
%autoreload 2

import stravaio
from stravaio import StravaIO, strava_oauth2
import numpy as np
import pandas as pd
from plotly.offline import iplot, init_notebook_mode
import plotly
import plotly.graph_objs as go
import plotly_express as px
init_notebook_mode(connected=True)
# [___CELL_SEPARATOR___]
strava_oauth2()
# [___CELL_SEPARATOR___]
import os
import dotenv
dotenv.load_dotenv()
access_token = os.getenv('ACCESS_TOKEN')
if access_token is None:
    raise ValueError("access_token is None! Add it to the .env file or to the system environment variable!")
# [___CELL_SEPARATOR___]
client = StravaIO(access_token)
# [___CELL_SEPARATOR___]
athlete = client.get_logged_in_athlete()
athlete
# [___CELL_SEPARATOR___]
# Returns a list of summary activities
activities = client.get_logged_in_athlete_activities(after='last week')
# [___CELL_SEPARATOR___]
[a.name for a in activities]
# [___CELL_SEPARATOR___]
a = client.get_activity_by_id(id=activities[-2].id)
a
# [___CELL_SEPARATOR___]
s = client.get_activity_streams(activities[-2].id, athlete_id=athlete.id)
s
# [___CELL_SEPARATOR___]
df = pd.DataFrame(s.to_dict())
df.head()
# [___CELL_SEPARATOR___]
ftp=athlete.api_response.ftp
strava_orange = '#fc4c02'
df['color']= 'white'
df.loc[df['watts'] > ftp*0.7, 'color'] = 'grey'
df.loc[df['watts'] > ftp*1.0, 'color'] = strava_orange
df.head()
# [___CELL_SEPARATOR___]
groups, bins = pd.cut(df.watts, bins=np.arange(0, df.watts.max(), 10), retbins=True)
hist = df['watts'].groupby(groups).count()
hist
# [___CELL_SEPARATOR___]
bin_c = pd.DataFrame({'watts': bins})
bin_c['color'] = 'white'
bin_c.loc[bin_c['watts'] > 0.6*ftp, 'color'] = 'grey'
bin_c.loc[bin_c['watts'] > 0.9*ftp, 'color'] = strava_orange
# [___CELL_SEPARATOR___]
altitude = go.Scatter(
    x=df.time,
    y=df.altitude/df.altitude.max()*df.watts.max(),
    fill='tozeroy',
    fillcolor='rgb(30,30,30)',
    line=dict(
        color='rgb(30,30,30)'
    )
)

watts = go.Scattergl(
    x=df.time,
    y=df.watts,
    mode='markers',
    marker=dict(
        color=df['color'],
        size=2
    )
)


watts_b = go.Bar(
    y = bins,
    x = hist,
    orientation='h',
    marker=dict(
        color = bin_c['color']
    )
)



fig = plotly.tools.make_subplots(rows=1, cols=2, shared_yaxes=True)

fig.append_trace(altitude, 1,1)
fig.append_trace(watts, 1,1)
fig.append_trace(watts_b, 1,2)
fig.layout.update(
    autosize=False,
    width=800,
    height=300,
    margin=go.layout.Margin(
        l=50,
        r=20,
        b=10,
        t=30,
        pad=4
    ),
)
fig.layout.update(plot_bgcolor='black')
fig.layout.update(xaxis=dict(domain=[0, 0.8], showticklabels=False))
fig.layout.update(xaxis2=dict(domain=[0.8, 1.0], showticklabels=False))
fig.layout.update(yaxis=dict(showline=False, showticklabels=False, title='Power & Altitude a.u.'))
fig.layout.update(bargap=0)
fig.layout.update(showlegend=False)
fig.layout.update(title='Strava ride replotted using stravaio and plotly')

iplot(fig)