# The number of votes Hillary won over Trump
popular_vote_margin = 2864974
# The total number of non-citizens living in the U.S. in 2016
total_non_citizens = 22984400
# Proportion of non-citizen votes needed for a Trump win
percent_needed_for_trump_win = round(popular_vote_margin / total_non_citizens * 100, 1)
# [___CELL_SEPARATOR___]
import math

def margin_of_error(p, n, z=1.96):
    """Returns the Margin of Error for the given proportion.
    
    Arguments:
    p -- the proportion of the sample with a characteristic
    n -- the size of the sample
    z -- z-score for the desired confidence interval
    
    """
    return z * math.sqrt(p * (1 - p)/n)

# The proportion (11.3%) of non-citizens that may have voted in 2008
p = 0.113 
# The total number (339) of non-citizens in the 2008 survey
n = 339
# Calculate the margin of error for the sample population of 339 non-citizens
moe = round(margin_of_error(p, n) * 100, 1)
# Calculate the 95% confidence interval
ci = (11.3 - moe, 11.3 + moe)

print('Margin of Error: {0:.1f}%'.format(moe))
print('Confidence Interval (95%): {0:.1f} - {1:.1f}%'.format(*ci))
# [___CELL_SEPARATOR___]
# Richman's paper concludes that 6.4% is a more 
# realistic estimate of non-citizen voters
adj_p = 0.064
illegal_voters = adj_p * total_non_citizens
# [___CELL_SEPARATOR___]
# Of those illegal voters 81.8% would have voted for Clinton
clinton = round(illegal_voters * 0.818)
# and 17.5% would have gone to Trump
trump = round(illegal_voters * 0.175)
# Number of popular votes for Clinton minus non-citizens
adj_popular_vote_margin = popular_vote_margin - (clinton - trump)
# The proportion of non-citizens needed to vote to have lost the election
# as a result of illegal voting activity (assuming that 90% of non-citizens
# vote for Clinton and keeping the third party vote constant).
non_citizen_proportion_needed = popular_vote_margin/(total_non_citizens * (0.9 - 0.093))
# [___CELL_SEPARATOR___]
import pandas as pd

cces_panel = pd.read_stata('CCES1012PaneV2.dta')
# [___CELL_SEPARATOR___]
cces_panel.dropna(subset=['V263', 'immstat'], inplace=True)
# [___CELL_SEPARATOR___]
# Citizen in 2010 and Citizen in 2012
cc = cces_panel[(cces_panel.V263 != 'Immigrant non-citizen') & 
                (cces_panel.immstat != 'Immigrant non-citizen')]
# Citizen in 2010 and Non-citizen in 2012
cnc = cces_panel[(cces_panel.V263 != 'Immigrant non-citizen') & 
                 (cces_panel.immstat == 'Immigrant non-citizen')]
# Non-citizen in 2010 and Citizen in 2012
ncc = cces_panel[(cces_panel.V263 == 'Immigrant non-citizen') & 
                 (cces_panel.immstat != 'Immigrant non-citizen')]
# Non-citizen in 2010 and Non-citizen in 2012
ncnc = cces_panel[(cces_panel.V263 == 'Immigrant non-citizen') &                  
                  (cces_panel.immstat == 'Immigrant non-citizen')]
# [___CELL_SEPARATOR___]
cc_percent = round(len(cc)/len(cces_panel) * 100, 2)
cnc_percent = round(len(cnc)/len(cces_panel) * 100, 2)
ncc_percent = round(len(ncc)/len(cces_panel) * 100, 2)
ncnc_percent = round(len(ncnc)/len(cces_panel) * 100, 2)
# [___CELL_SEPARATOR___]
cc.VV_2010_gen.cat.categories
# [___CELL_SEPARATOR___]
voted = ['Absentee', 'Early', 'Mail', 'Voted unknown method']
citizen_voter_rate = sum(cc.VV_2010_gen.isin(voted))/len(cc)
# [___CELL_SEPARATOR___]
n = 1000
non_citizens_proportion = 339/32800
non_citizens = round(n * non_citizens_proportion)
citizens = n - non_citizens
# [___CELL_SEPARATOR___]
error_rate = 0.001
incorrectly_labeled_citizens = round(citizens * error_rate)
# [___CELL_SEPARATOR___]
illegal_voter_rate = incorrectly_labeled_citizens/non_citizens * citizen_voter_rate
illegal_votes = total_non_citizens * illegal_voter_rate
# [___CELL_SEPARATOR___]
moe_small_survey = margin_of_error(illegal_voter_rate, non_citizens)
ci_small_survey_low = round((illegal_voter_rate - moe_small_survey) * total_non_citizens)
ci_small_survey_high = round((illegal_voter_rate + moe_small_survey) * total_non_citizens)
# [___CELL_SEPARATOR___]
moe_large_survey = margin_of_error(illegal_voter_rate, 339)
ci_large_survey_low = round((illegal_voter_rate - moe_large_survey) * total_non_citizens)
ci_large_survey_high = round((illegal_voter_rate + moe_large_survey) * total_non_citizens)
# [___CELL_SEPARATOR___]
%%HTML
<script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>