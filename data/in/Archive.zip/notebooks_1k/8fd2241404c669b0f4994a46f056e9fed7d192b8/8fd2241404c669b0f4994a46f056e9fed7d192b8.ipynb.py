import matplotlib.pyplot as plt

plt.arrow(0, 0, 3, 2, width=0.04)
plt.xlim(0,4)
plt.ylim(0,4);
# [___CELL_SEPARATOR___]
import numpy as np

norm = np.linalg.norm(np.array([17, -4, -2, 1]))
print(norm)
# [___CELL_SEPARATOR___]
c = np.array([3,  7, -2, 12])
d = np.array([9, -7,  4,  6])

print(np.dot(c, d))
# [___CELL_SEPARATOR___]
E = np.array([[7, 4,  2],
              [1, 3, -1],
              [2, 6, -4]])

print(np.linalg.inv(E))
print(E.T)
# [___CELL_SEPARATOR___]
import pandas as pd

customers = [820, 760, 1250, 990, 1080, 1450, 1600]
snow = [0, 1, 7, 1, 0, 6, 4]

df = pd.DataFrame({'customers': customers, 'snow': snow})

df.head()
# [___CELL_SEPARATOR___]
df.mean()
# [___CELL_SEPARATOR___]
df.std(ddof=0)
# [___CELL_SEPARATOR___]
df.var(ddof=0)
# [___CELL_SEPARATOR___]
df.cov()
# [___CELL_SEPARATOR___]
# Let me get you some data to start you off.
import pandas as pd

data = {"Country": ["England","Wales","Scotland","North Ireland"], 
        "Cheese": [105,103,103,66], 
        "Carcass_Meat": [245,227,242,267], 
        "Other_Meat": [685, 803, 750, 586], 
        "Fish": [147, 160, 122, 93], 
        "Fats_and_Oils": [193, 235, 184, 209], 
        "Sugars": [156, 175, 147, 139], 
        "Fresh_Potatoes": [720, 874, 566, 1033], 
        "Fresh_Veg": [253, 265, 171, 143], 
        "Other_Veg": [488, 570, 418, 355], 
        "Processed_Potatoes": [198, 203, 220, 187], 
        "Processed_Veg": [360, 365, 337, 334], 
        "Fresh_Fruit": [1102, 1137, 957, 674], 
        "Cereals": [1472, 1582, 1462, 1494], 
        "Beverages": [57,73,53,47], 
        "Soft_Drinks": [1374, 1256, 1572, 1506], 
        "Alcoholic Drinks": [375, 475, 458, 135], 
        "Confectionery": [54, 64, 62, 41]}

df = pd.DataFrame(data)

# Look at the data
df.head()
# [___CELL_SEPARATOR___]
from sklearn.preprocessing import StandardScaler

df_zstand = StandardScaler().fit_transform(df.select_dtypes('number'))
# [___CELL_SEPARATOR___]
from sklearn.decomposition import PCA

pca = PCA(2).fit_transform(df_zstand)

print(pca)

plt.scatter(x=[_[0] for _ in pca], y=[_[1] for _ in pca]);
# [___CELL_SEPARATOR___]
points = pd.read_csv('https://raw.githubusercontent.com/ryanleeallred/datasets/master/points.csv')
points.head()
# [___CELL_SEPARATOR___]
from sklearn.cluster import KMeans

sum_of_squared_distances = []
xs = range(1,15)
for x in xs:
    km = KMeans(n_clusters=x)
    km = km.fit(points)
    sum_of_squared_distances.append(km.inertia_)
# [___CELL_SEPARATOR___]
plt.plot(list(range(1,15)), sum_of_squared_distances);
# [___CELL_SEPARATOR___]
labels = KMeans(4).fit(points).labels_
# [___CELL_SEPARATOR___]
fig, ax = plt.subplots()
ax.scatter(x='x', y='y', data=points, c=labels)
ax.set_aspect('equal');