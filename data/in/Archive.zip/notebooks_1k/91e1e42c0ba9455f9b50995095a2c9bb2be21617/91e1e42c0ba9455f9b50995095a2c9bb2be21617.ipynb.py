import igv
# [___CELL_SEPARATOR___]
b = igv.Browser(
    {
        "genome": "hg19",
        "locus": "chr22:24,376,166-24,376,456"
    }
)
# [___CELL_SEPARATOR___]
b.show()
# [___CELL_SEPARATOR___]
b.load_track(
    {
        "name": "Local BAM",
        "url": "files/data/gstt1_sample.bam",
        "indexURL": "files/data/gstt1_sample.bam.bai",
        "format": "bam",
        "type": "alignment"
    })

# [___CELL_SEPARATOR___]
b.zoom_in()
# [___CELL_SEPARATOR___]
b.get_svg()
# [___CELL_SEPARATOR___]
b.display_svg()
# [___CELL_SEPARATOR___]
