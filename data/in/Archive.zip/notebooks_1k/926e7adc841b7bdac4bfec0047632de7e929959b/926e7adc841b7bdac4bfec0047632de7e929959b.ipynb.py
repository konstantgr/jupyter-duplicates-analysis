using Parameters
# [___CELL_SEPARATOR___]
@with_kw struct MyParams
    x::Int = 4
    y::Float64
end
# [___CELL_SEPARATOR___]
MyParams()
# [___CELL_SEPARATOR___]
MyParams(y = 2)
# [___CELL_SEPARATOR___]
@with_kw struct MyParams2
    x::Int = 4;
    y::Float64 = 5.3
    z::Int = floor(x+y)
end
# [___CELL_SEPARATOR___]
MyParams2()
# [___CELL_SEPARATOR___]
@with_kw struct MyParams3
    x::Int = 4; @assert x != 2
    y::Float64 = 5.3
    @assert x + y >= 9
end
# [___CELL_SEPARATOR___]
MyParams3(y = 3)
# [___CELL_SEPARATOR___]
MyParams3(x = 2)
# [___CELL_SEPARATOR___]
@with_kw mutable struct MyParams4 @deftype Int
    x = 4;
    y::Float64 = 5.3
    z = floor(x+y)
    a = 1
    b = 2
end
# [___CELL_SEPARATOR___]
using ProgressMeter
# [___CELL_SEPARATOR___]
@showprogress .5 for i in 1:20
    sleep(rand())
end
# [___CELL_SEPARATOR___]
using StaticArrays
# [___CELL_SEPARATOR___]
m = SMatrix{2,2}(1, 2, 3, 4)
# [___CELL_SEPARATOR___]
size(m)
# [___CELL_SEPARATOR___]
size(typeof(m))
# [___CELL_SEPARATOR___]
# compare to
M = Matrix(m)
size(typeof(M))
# [___CELL_SEPARATOR___]
m2 = @SMatrix [ 1  3 ;
                2  4 ]
# [___CELL_SEPARATOR___]
m3 = @SMatrix rand(4,4)
# [___CELL_SEPARATOR___]
a = @SArray randn(2, 2, 2)
# [___CELL_SEPARATOR___]
using BenchmarkTools, LinearAlgebra
# [___CELL_SEPARATOR___]
println("Inversion")
@btime inv($m);
@btime inv($M);
# [___CELL_SEPARATOR___]
println("Matrix x vector")
v = rand(2)
@btime $m * $v;
@btime $M * $v;
# [___CELL_SEPARATOR___]
# takes a long time to compile and is slower
N = 50
M = rand(N,N);
v = rand(N);
m = SMatrix{N,N}(M);

println("Inversion")
@btime inv($m);
@btime inv($M);

println("Matrix x vector")
@btime $m * $v;
@btime $M * $v;
# [___CELL_SEPARATOR___]
# takes a long time to compile and is slower
N = 50
M = rand(N,N);
v = rand(N);
m = SMatrix{N,N}(M);

println("Inversion")
@btime inv($m);
@btime inv($M);

println("Matrix x vector")
@btime $m * $v;
@btime $M * $v;
# [___CELL_SEPARATOR___]
using LsqFit
# [___CELL_SEPARATOR___]
model(x, p) = p[1]*exp.(-x.*p[2]) # f(x) = α*exp(-γ*x)

xdata = linspace(0, 10, 20)
ydata = model(xdata, [1.0 2.0]) + 0.01*randn(length(xdata))
p0 = [0.5, 0.5]

fit = curve_fit(model, xdata, ydata, p0)

fit.param

# define function for fit result
modelfit = x -> model(x, fit.param)
modelfit(0.2)
# [___CELL_SEPARATOR___]
using Polynomials
# [___CELL_SEPARATOR___]
myp(x) = 3*x
xdata = -1:.1:1
ydata = myfunc.(xdata);
p = polyfit(xdata, ydata)
# [___CELL_SEPARATOR___]
using PyPlot
grid = linspace(-1, 1, 100)
plot(grid, p.(grid), label="polynomial")
plot(xdata, ydata, "o", label="data")
legend()
# [___CELL_SEPARATOR___]
using FFTW
# [___CELL_SEPARATOR___]
x = [4,3,2,1,0,1,2,3]
y = rfft(x)
# [___CELL_SEPARATOR___]
using Measurements
# [___CELL_SEPARATOR___]
x = 4 ± 0.1
# [___CELL_SEPARATOR___]
typeof(x)
# [___CELL_SEPARATOR___]
y = measurement(5.1, 0.2)
# [___CELL_SEPARATOR___]
x + y
# [___CELL_SEPARATOR___]
x * y
# [___CELL_SEPARATOR___]
1/x # Δ(1/x) = d(1/x)/dx * Δx
# [___CELL_SEPARATOR___]
(3 ± 0.1) === (3 ± 0.1)
# [___CELL_SEPARATOR___]
(3 ± 0.1) / (3 ± 0.1)
# [___CELL_SEPARATOR___]
using Unitful
# [___CELL_SEPARATOR___]
1u"kg"
# [___CELL_SEPARATOR___]
unit(1u"kg")
# [___CELL_SEPARATOR___]
ustrip(1u"kg") # strip the units
# [___CELL_SEPARATOR___]
uconvert(u"g", 1u"kg")
# [___CELL_SEPARATOR___]
1u"A" * 2u"Ω" isa Unitful.Voltage
# [___CELL_SEPARATOR___]
using Unitful: ms, s, minute, hr, rad, °, mm, cm, m, km
# [___CELL_SEPARATOR___]
t = 1.0s
# [___CELL_SEPARATOR___]
t + 2s
# [___CELL_SEPARATOR___]
2*t
# [___CELL_SEPARATOR___]
t^2
# [___CELL_SEPARATOR___]
t + t^2
# [___CELL_SEPARATOR___]
using PeriodicTable
# [___CELL_SEPARATOR___]
elements
# [___CELL_SEPARATOR___]
elements["Sodium"] # or elements[:Na] or elements[11]
# [___CELL_SEPARATOR___]
using HDF5
# [___CELL_SEPARATOR___]
A = rand(2,3)
# [___CELL_SEPARATOR___]
h5write("test.h5", "A", A)
# [___CELL_SEPARATOR___]
Aloaded = h5read("test.h5", "A")
# [___CELL_SEPARATOR___]
# r = read existing file
# r+ = read and write existing file
# w = overwrite existing / create new file
h5open("test.h5", "r+") do f
    for k in 1:5
        f[string(k)] = rand(2,2)
        # or write(f, string(k), rand(2,2))
    end
end
# [___CELL_SEPARATOR___]
f = h5open("test.h5", "r+")
# [___CELL_SEPARATOR___]
names(f)
# [___CELL_SEPARATOR___]
f["A"]
# [___CELL_SEPARATOR___]
read(f["A"])
# [___CELL_SEPARATOR___]
h5open("test.h5", "r+") do f
    HDF5.has(f, "A") && o_delete(f, "A")
    f["A"] = rand(2, 2)
end
# [___CELL_SEPARATOR___]
C = rand(ComplexF64, 2, 2)
h5write("test.h5", "C", C)
# [___CELL_SEPARATOR___]
close(f);
rm("test.h5");
# [___CELL_SEPARATOR___]
using JLD2
# [___CELL_SEPARATOR___]
A = rand(2,3)
# [___CELL_SEPARATOR___]
@save "test.jld2" A
# [___CELL_SEPARATOR___]
B = rand(2,3)
# [___CELL_SEPARATOR___]
@save "test.jld2" B # overwrites(!) test.jld2 file
# [___CELL_SEPARATOR___]
@load "test.jld2" B # will load dataset "B" automatically to variable B
# [___CELL_SEPARATOR___]
jldopen("test.jld2", "r+") do f
    @show f["B"] # no read necessary
    @show f["C"] = rand(ComplexF64, 2, 2); # can store arbitrary Julia objects
end;
# [___CELL_SEPARATOR___]
@load "test.jld2" # loads everything from file to variables
# [___CELL_SEPARATOR___]
C
# [___CELL_SEPARATOR___]
# clean up
rm("test.jld2")
# [___CELL_SEPARATOR___]
using PyCall
# [___CELL_SEPARATOR___]
np = pyimport("numpy")
# [___CELL_SEPARATOR___]
x = rand(2,2)
# [___CELL_SEPARATOR___]
np.linalg.eig(x)
# [___CELL_SEPARATOR___]
using Distributions
# [___CELL_SEPARATOR___]
d = Normal()
# [___CELL_SEPARATOR___]
rand(d, 10)
# [___CELL_SEPARATOR___]
d = Binomial()
# [___CELL_SEPARATOR___]
rand(d, 10)
# [___CELL_SEPARATOR___]
using StatsBase, Random
# [___CELL_SEPARATOR___]
x = randn(100);
# [___CELL_SEPARATOR___]
h = fit(Histogram, rand(100), nbins=10)
# [___CELL_SEPARATOR___]
countmap(rand(1:5, 100))
# [___CELL_SEPARATOR___]
using ITensors
# [___CELL_SEPARATOR___]
i = Index(3,"i")
j = Index(5,"j")
k = Index(4,"k")
l = Index(7,"l")

A = ITensor(i,j,k)
B = ITensor(j,l)

A[i(1),j(1),k(1)] = 11.1
A[i(2),j(1),k(2)] = 21.2
A[i(3),j(1),k(1)] = 31.1
# ...

# contract over index j
C = A*B

@show hasinds(C,i,k,l) # == true

D = randomITensor(k,j,i)

# add two ITensors
R = A+D
# [___CELL_SEPARATOR___]
using OMEinsum
# [___CELL_SEPARATOR___]
x, y = rand(3), rand(3);
# [___CELL_SEPARATOR___]
ein"i->"(x)
# [___CELL_SEPARATOR___]
ein"i,i->"(x,y)
# [___CELL_SEPARATOR___]
ein"i,j->ij"(x,y)
# [___CELL_SEPARATOR___]
x*y'
# [___CELL_SEPARATOR___]
a, b = rand(2,2), rand(2,2);
# [___CELL_SEPARATOR___]
ein"ij,jk->"(a,b)
# [___CELL_SEPARATOR___]
ein"ij,jk->"(a,b)[] ≈ sum(a * b)