import pandas as pd
import os
import numpy as np
import re
# [___CELL_SEPARATOR___]
word_list = []
author_list = []
number_of_authors = 0
file_idx = 0

for file in os.listdir('books/'):
    if file.endswith(".txt"):
        with open(os.path.join('books/'+file), 'r',encoding='utf-8') as f:
            for line in f:
                for word in line.split():
                    word1 = " ".join(re.findall('[a-zA-ZäöüßÄÖÜẞ]+', word))
                    if not word1 in word_list:
                        word_list.append(word1.lower())
        number_of_authors += 1
        author_list.append(file.split('_')[0])
        

p_x_y = np.zeros((word_list.__len__(),number_of_authors))
for file in os.listdir('books/'):
    if file.endswith(".txt"):
        with open(os.path.join('books/'+file), 'r',encoding='utf-8') as f:
            for line in f:
                for word in line.split():
                    word1 = " ".join(re.findall('[a-zA-ZäöüßÄÖÜẞ]+', word))
                    index = word_list.index(word1.lower())
                    p_x_y[index,file_idx] += 1
        file_idx += 1
        
p_x_y /= p_x_y.sum()
p_y = p_x_y.sum(axis=1)
# [___CELL_SEPARATOR___]
np.argmax(p_x_y[:,1])
# [___CELL_SEPARATOR___]
non_unique_indices = np.nonzero(np.sum(p_x_y!=0,axis=1)>1)[0]
p_y = p_y[non_unique_indices]
p_x_y = p_x_y[non_unique_indices,:]
#non_unique_indices
word_list = [word_list[j] for j in non_unique_indices]
# [___CELL_SEPARATOR___]
word_table = pd.DataFrame({ 'Pr(Word)' : p_y,
                          'Word' : word_list})
# [___CELL_SEPARATOR___]
word_table.sort_values(by='Pr(Word)', ascending=False)
# [___CELL_SEPARATOR___]
from information_bottleneck.information_bottleneck_algorithms.KLmeansIB_class import KLmeansIB as KLmeans

card_T = 10
IB_inst = KLmeans(p_x_y+1e-34,
                   card_T,
                   nror=100)
IB_inst.run_IB_algo()
# [___CELL_SEPARATOR___]
IB_inst.display_MIs()
# [___CELL_SEPARATOR___]
p_t_given_y, p_x_given_t, p_t = IB_inst.get_results()
# [___CELL_SEPARATOR___]
cluster_ind = p_t_given_y.argmax(axis=1)
word_list = np.asarray(word_list)

words_in_cluster = [None]*card_T

for t in range(card_T):
    indices = np.argsort(p_y[np.argwhere(cluster_ind == t)][:, 0])
    words_in_cluster[t] = []
    for item in word_list[np.argwhere(cluster_ind == t)[indices]]:
        words_in_cluster[t].append(item[0])
    
result_dataframe = pd.DataFrame(
    {'cluster index t' : np.arange(card_T),
     'words in cluster': words_in_cluster
    }
)
for x in range(p_x_given_t.shape[1]):
    result_dataframe['p(X='+author_list[x]+'|t)'] = pd.Series(p_x_given_t[:,x])
result_dataframe
# [___CELL_SEPARATOR___]
