import re
import urllib
import urllib3
import csv
import requests
from bs4 import BeautifulSoup
from collections import OrderedDict
headers = {'User-Agent':'Mozilla/5.0'}
urllib3.disable_warnings()

# [___CELL_SEPARATOR___]
data1=[]
import random
import csv
from time import sleep
# [___CELL_SEPARATOR___]
li='https://www.floridabids.us/florida-contractors/location-Altamonte%20Springs.2.htm'
page = requests.get(li, headers=headers, verify=False)
data = page.content
soup = BeautifulSoup(data, "html.parser")

cities_link=soup.find_all(id="filter-city")[0].find_all('a')
# [___CELL_SEPARATOR___]
len(cities_link)
# [___CELL_SEPARATOR___]
for g in range(0,len(cities_link)):
    link_city0=cities_link[g].get('href')
    linkto_city='https://www.floridabids.us'+link_city0
    sleep(1)

    page = requests.get(linkto_city, headers=headers, verify=False)
    data = page.content
    soup_companies = BeautifulSoup(data, "html.parser")

    allcomp=soup_companies.find_all('div',class_="lr-title lr-mar")
    for i in range(len(allcomp)):
        data0=[]
        link0=allcomp[i].find('a').get('href')
        linkto_comp='https://www.floridabids.us'+link0
#         print (linkto_comp)
        data0.append(linkto_comp)
        data1.append(data0)
    print(len(data1))
        
    if len(allcomp)>0:
        total_page=(int((soup_companies.find(class_="list-total").find_all('span')[-1].text).replace(',',''))/25)+1
        print 'Total_pages:',total_page

        for q in range(2,total_page+1):
            url=linkto_city.replace('.htm','.'+str(q)+'.htm')
            sleep(1)
            page = requests.get(url, headers=headers, verify=False)
            data = page.content
            soup = BeautifulSoup(data, "html.parser")

            allcomp=soup.find_all('div',class_="lr-title lr-mar")
            for i in range(len(allcomp)):
                data0=[]
                link0=allcomp[i].find('a').get('href')
                linkto_comp='https://www.floridabids.us'+link0
#                 print (linkto_comp)
                data0.append(linkto_comp)
                data1.append(data0)
                csvWriter = csv.writer(open('output_0.csv', 'a'))
                csvWriter.writerow(data0)
            print(len(data1))
# [___CELL_SEPARATOR___]
78351/25
# [___CELL_SEPARATOR___]
len(allcomp)
# [___CELL_SEPARATOR___]
data1
# 11833
https://www.floridabids.us/florida-contractors/contractor-5821354-STRATIGENT-INC.htm

# 20567
https://www.floridabids.us/florida-contractors/contractor-5610736-L-J-DIESEL-SERVICE-INC.htm

# 30978
https://www.floridabids.us/florida-contractors/contractor-5548974-LUNA-SOURCE.htm

# 39187
https://www.floridabids.us/florida-contractors/contractor-5215930-AIRCRAFT-ENGINEERIN.htm

# 41904
https://www.floridabids.us/florida-contractors/contractor-5815006-MAPPING-SUSTAINABILIT.htm

# 57603
https://www.floridabids.us/florida-contractors/contractor-5101540-Venatore-LLC.htm
# [___CELL_SEPARATOR___]
checklink=[]
# [___CELL_SEPARATOR___]
link='https://www.floridabids.us/florida-contractors/search.htm?keyword=&city=Tampa%2C+FL&naics='

# link='https://www.floridabids.us/florida-contractors/search.htm?keyword=&city=Palm%2C+FL&naics='

# link='https://www.floridabids.us/florida-contractors/search.htm?keyword=&city=Orlando%2C+FL&naics='

# link='https://www.floridabids.us/florida-contractors/search.htm?keyword=&city=Miami%2C+FL&naics='

# link='https://www.floridabids.us/florida-contractors/search.htm?keyword=&city=Jacksonville%2C+FL&naics='

# link='https://www.floridabids.us/florida-contractors/search.htm?keyword=&city=Fort+Lauderdale%2C+FL&naics='

# [___CELL_SEPARATOR___]

page = requests.get(link, headers=headers, verify=False)
data = page.content
soup = BeautifulSoup(data, "html.parser")

total_page=(int((soup.find(class_="list-total").find_all('span')[-1].text).replace(',',''))/25)+1
total_page
# [___CELL_SEPARATOR___]
filters=soup.find_all(class_="filter-box")

linkscate=filters[3].find_all('a')

for k in range(len(linkscate)):
    checklink.append('https://www.floridabids.us'+linkscate[k].get('href'))
print (len(checklink))
# [___CELL_SEPARATOR___]
checklink[0]
'https://www.floridabids.us/florida-contractors/search.htm?city=Fort+Lauderdale%2C+FL&naics=11'
'https://www.floridabids.us/florida-contractors/search.htm?city=Fort+Lauderdale%2C+FL&naics=11&page=2'
# [___CELL_SEPARATOR___]
checklink[5]
# [___CELL_SEPARATOR___]
for g in range(5,len(checklink)):

    sleep(1)

    page = requests.get(checklink[g], headers=headers, verify=False)
    data = page.content
    soup_companies = BeautifulSoup(data, "html.parser")

    allcomp=soup_companies.find_all('div',class_="lr-title lr-mar")
    for i in range(len(allcomp)):
        data0=[]
        link0=allcomp[i].find('a').get('href')
        linkto_comp='https://www.floridabids.us'+link0
        
#         print (linkto_comp)
        data0.append(linkto_comp)
        
        csvWriter = csv.writer(open('output_rem.csv', 'a'))
        csvWriter.writerow(data0)
        
        data1.append(data0)
    print(len(data1))
        
    if len(allcomp)>0:
        total_page=(int((soup_companies.find(class_="list-total").find_all('span')[-1].text).replace(',',''))/25)+1
        print 'Total_pages:',total_page

        for q in range(2,total_page+1):
            url=checklink[g]+'&page='+str(q)
            sleep(1)
            page = requests.get(url, headers=headers, verify=False)
            data = page.content
            soup = BeautifulSoup(data, "html.parser")

            allcomp=soup.find_all('div',class_="lr-title lr-mar")
            for i in range(len(allcomp)):
                data0=[]
                link0=allcomp[i].find('a').get('href')
                linkto_comp='https://www.floridabids.us'+link0
#                 print (linkto_comp)
                data0.append(linkto_comp)
                data1.append(data0)
                csvWriter = csv.writer(open('output_rem.csv', 'a'))
                csvWriter.writerow(data0)
            print(len(data1))
# [___CELL_SEPARATOR___]
