import os
import json
from testing_utilities import write_json_to_file
%load_ext dotenv
# [___CELL_SEPARATOR___]
%%writefile --append .env
# This cell is tagged `parameters`
# Please modify the values below as you see fit

# If you have multiple subscriptions select the subscription you want to use 
selected_subscription = "Team Danielle Internal"

# Resource group, name and location for AKS cluster.
resource_group = "mabouaks" 
aks_name = "mabouaks"
location = "eastus"
# [___CELL_SEPARATOR___]
%dotenv -o
image_name = os.getenv('docker_login') + os.getenv('image_repo')
# [___CELL_SEPARATOR___]
%%bash
list=`az account list -o table`
if [ "$list" == '[]' ] || [ "$list" == '' ]; then 
  az login -o table
else
  az account list -o table 
fi
# [___CELL_SEPARATOR___]
!az account set --subscription "$selected_subscription"
# [___CELL_SEPARATOR___]
!az account show
# [___CELL_SEPARATOR___]
!az provider register -n Microsoft.ContainerService
# [___CELL_SEPARATOR___]
!az provider show -n Microsoft.ContainerService
# [___CELL_SEPARATOR___]
 !az group create --name $resource_group --location $location
# [___CELL_SEPARATOR___]
!az aks create --resource-group $resource_group --name $aks_name --node-count 1 --generate-ssh-keys -s Standard_NC6
# [___CELL_SEPARATOR___]
!sudo az aks install-cli
# [___CELL_SEPARATOR___]
!az aks get-credentials --resource-group $resource_group --name $aks_name
# [___CELL_SEPARATOR___]
!kubectl get nodes
# [___CELL_SEPARATOR___]
!kubectl get pods --all-namespaces
# [___CELL_SEPARATOR___]
app_template = {
  "apiVersion": "apps/v1beta1",
  "kind": "Deployment",
  "metadata": {
      "name": "azure-dl"
  },
  "spec":{
      "replicas":1,
      "template":{
          "metadata":{
              "labels":{
                  "app":"azure-dl"
              }
          },
          "spec":{
              "containers":[
                  {
                      "name": "azure-dl",
                      "image": image_name,
                      "env":[
                          {
                              "name": "LD_LIBRARY_PATH",
                              "value": "$LD_LIBRARY_PATH:/usr/local/nvidia/lib64:/opt/conda/envs/py3.6/lib"
                          }
                      ],
                      "ports":[
                          {
                              "containerPort":80,
                              "name":"model"
                          }
                      ],
                      "volumeMounts":[
                          {
                            "mountPath": "/usr/local/nvidia",
                            "name": "nvidia"
                          }
                      ],
                      "resources":{
                           "requests":{
                               "alpha.kubernetes.io/nvidia-gpu": 1
                           },
                           "limits":{
                               "alpha.kubernetes.io/nvidia-gpu": 1
                           }
                       }  
                  }
              ],
              "volumes":[
                  {
                      "name": "nvidia",
                      "hostPath":{
                          "path":"/usr/local/nvidia"
                      },
                  },
              ]
          }
      }
  }
}

service_temp = {
  "apiVersion": "v1",
  "kind": "Service",
  "metadata": {
      "name": "azure-dl"
  },
  "spec":{
      "type": "LoadBalancer",
      "ports":[
          {
              "port":80
          }
      ],
      "selector":{
            "app":"azure-dl"
      }
   }
}
# [___CELL_SEPARATOR___]
write_json_to_file(app_template, 'az-dl.json') # We write the service template to the json file
# [___CELL_SEPARATOR___]
write_json_to_file(service_temp, 'az-dl.json', mode='a') # We add the loadbelanacer template to the json file
# [___CELL_SEPARATOR___]
!cat az-dl.json
# [___CELL_SEPARATOR___]
!kubectl create -f az-dl.json
# [___CELL_SEPARATOR___]
!kubectl get pods --all-namespaces
# [___CELL_SEPARATOR___]
!kubectl get events
# [___CELL_SEPARATOR___]
pod_json = !kubectl get pods -o json
pod_dict = json.loads(''.join(pod_json))
!kubectl logs {pod_dict['items'][0]['metadata']['name']}
# [___CELL_SEPARATOR___]
!kubectl get service azure-dl