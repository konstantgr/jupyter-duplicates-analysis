import pandas as pd
import numpy as np
import folium
import sys
from IPython.display import display
import ipywidgets as widgets
# [___CELL_SEPARATOR___]
def load_dataset():  
    veh_cols = ['Num_Acc', 'num_veh', 'senc', 'catv', 'obs', 'obsm', 'choc']
    usa_cols = ['Num_Acc', 'num_veh', 'place', 'catu', 'grav', 'sexe', 'an_nais', 'trajet', 'secu', 'locp']
    lie_cols = ['Num_Acc', 'catr', 'circ', 'nbv', 'vosp', 'prof', 'plan', 'lartpc', 'larrout', 'surf', 'infra', 'situ']
    car_cols = ['Num_Acc', 'jour', 'mois', 'an', 'hrmn', 'lum', 'dep', 'com', 'agg', 'atm', 'col', 'gps', 'lat', 'long']

    veh = pd.read_csv('../Accidents/vehicules_2005.csv', usecols=veh_cols)
    usa = pd.read_csv('../Accidents/usagers_2005.csv', usecols=usa_cols)
    lie = pd.read_csv('../Accidents/lieux_2005.csv', usecols=lie_cols)
    car = pd.read_csv('../Accidents/caracteristiques_2005.csv', encoding='latin-1', usecols=car_cols)

    for i in range(2006, 2018, 1):
        lie = pd.concat([lie, pd.read_csv('../Accidents/lieux_' + str(i) + '.csv', usecols=lie_cols)], axis=0)
        usa = pd.concat([usa, pd.read_csv('../Accidents/usagers_' + str(i) + '.csv', usecols=usa_cols)], axis=0)
        veh = pd.concat([veh, pd.read_csv('../Accidents/vehicules_' + str(i) + '.csv', usecols=veh_cols)], axis=0)
        try:
            car = pd.concat([car, pd.read_csv('../Accidents/caracteristiques_' + str(i) + '.csv',
                                              encoding='latin-1', usecols=car_cols)], axis=0)
        except:
            car = pd.concat(
                [car, pd.read_csv('../Accidents/caracteristiques_' + str(i) + '.csv', usecols=car_cols,
                                  encoding='latin-1', sep='\t')], axis=0)
            
    return veh, usa, car, lie

veh, usa, car, lie = load_dataset()

car.head()
# [___CELL_SEPARATOR___]
postal_1 = pd.read_csv('../Accidents/postal_part1.csv')
postal_2 = pd.read_csv('../Accidents/postal_part2.csv')

com_postal_pivot = pd.concat([postal_1, postal_2], ignore_index=True).set_index('Code_postal')
com_postal_pivot.head(5)
# [___CELL_SEPARATOR___]
def postal_code_selection(code = None):
    
    # Handle given postal code (optional)
    if isinstance(code, str): 
        postal_code_input = code
    else: 
        postal_code_input = input("Select a postal code : ")
        
    try:
        result = com_postal_pivot.loc[int(postal_code_input) , : ]
    except:
        print('Postal code not found in database')

    if isinstance(result, pd.Series):
        #print("Single line result")
        return result
    elif isinstance(result, pd.DataFrame):
        #print("Multi line result") Get first row
        return result.iloc[0]
    else:
        print(result.shape)

postal_code_selection('75015')
# [___CELL_SEPARATOR___]
def export_map(
    scale='Country',
    post_code='75013', 
    department='75',
    veh_type='all', 
    weather='all', 
    luminosity='all', 
    gravity='all',
    usa_sexe='all',
    export_name='plot_map.html',
    begin='10', end='18'):

    # Cross data - Filter on Dpt & Com
    if scale == 'City':
        result = postal_code_selection(post_code)
        display_scale = 14
        car_tmp = car[(car['dep'] == int(result['CODE_DEPT']+'0')) & (car['com'] == result['CODE_COM'])]
        centered_location = [float(result["Geo Point"].split(",")[0]), float(result["Geo Point"].split(",")[1])]
    elif scale == 'Department':
        car_tmp = car[(car['dep'] == int(str(department) + '0'))]
        if department == '75':
            display_scale = 12
            centered_location = [48.866997, 2.339459]
        else:
            display_scale = 9
            result = postal_code_selection(department+'000')
            centered_location = [float(result["Geo Point"].split(",")[0]), float(result["Geo Point"].split(",")[1])]
    elif scale == 'Country':
        car_tmp = car
        display_scale = 6
        centered_location = [47.12, 2.5]
    
    zone_df = pd.merge(veh, car_tmp, on='Num_Acc')
    zone_df = pd.merge(zone_df, lie, on='Num_Acc')
    zone_df = zone_df[zone_df.gps == 'M']
    
    # Filter on road type
    #if scale == 'Country':
        #zone_df = zone_df[zone_df.catr == 1.0]

    # Filter empty coordinates
    zone_df = zone_df[(zone_df.long != 0) & (zone_df.lat != 0)]
    zone_df = zone_df[(zone_df.long != 0.0) & (zone_df.lat != 0.0)]
    zone_df = zone_df.dropna(subset=['lat', 'long'])
    
    # Filter on vehicle type
    if (veh_type == 'Cars'):
        zone_df = zone_df[(zone_df.catv == 7)]
    elif veh_type == 'Motorcycles':
        zone_df = zone_df[(zone_df.catv == 2) | (zone_df.catv == 30) | (zone_df.catv == 31) | 
                          (zone_df.catv == 32) | (zone_df.catv == 33) | (zone_df.catv == 34)]
    elif veh_type == 'Bikes':
        zone_df = zone_df[(zone_df.catv == 1)]
    elif veh_type == 'Public transports':
        zone_df = zone_df[(zone_df.catv == 37) | (zone_df.catv == 38) | (zone_df.catv == 39) | 
                          (zone_df.catv == 40)]
        
    # Luminosity conditions
    if (luminosity == 'Day'):                   zone_df = zone_df[(zone_df.lum == 1)]
    elif luminosity == 'Dusk/Dawn':             zone_df = zone_df[(zone_df.lum == 2)]
    elif luminosity == 'Night (with lighting)': zone_df = zone_df[(zone_df.lum == 5)]
    elif luminosity == 'Night (no lighting)':   zone_df = zone_df[(zone_df.lum == 3) | (zone_df.lum == 4)]
    
    # Atmospheric conditions
    if weather == 'Normal/Sunny':   zone_df = zone_df[(zone_df.atm == 1) | (zone_df.atm == 7)]
    elif weather == 'Rain':         zone_df = zone_df[(zone_df.atm == 2) | (zone_df.atm == 3)]
    elif weather == 'Snow':         zone_df = zone_df[(zone_df.atm == 4)]
    elif weather == 'Fog':          zone_df = zone_df[(zone_df.atm == 5)]
        
    # Filter on time interval
    zone_df = zone_df[(zone_df.an >= int(begin)) & (zone_df.an <= int(end))]
    zone_df = pd.merge(zone_df, usa, on='Num_Acc')
    
    # Coordinates conversion
    zone_df['lat'] = zone_df['lat'].replace('-', 0).fillna(0).astype('float') / 100000
    zone_df['long'] = zone_df['long'].replace('-', 0).fillna(0).astype('float') / 100000
    zone_df = zone_df[zone_df.long != 0.0]
    #print(zone_df.shape[0], ' rows with good gps cordinates.\n')

    return zone_df

zone_df = export_map()
# [___CELL_SEPARATOR___]
zone_df['dep'] = zone_df['dep'].astype(str)
zone_df = zone_df[zone_df['lat'] > 40]
zone_df['lat'] = zone_df['lat'] - np.mean(zone_df['lat'])
# [___CELL_SEPARATOR___]
zone_df.columns
# [___CELL_SEPARATOR___]
def genre_proc(genre):
    if str(genre) == '1': return 'male'
    else: return 'female'
    
    
def vehicle_proc(vehicle):
    if str(vehicle) in ['3', '7', '8', '9']: return 'Voiture'
    elif str(vehicle) in ['33', '34', '2', '30', '31', '32']: return 'Moto'
    elif str(vehicle) in ['1']: return 'Velo'
    elif str(vehicle) in ['10', '13', '14', '20', '21', '16', '17']: return 'Camion'
    
    
def atm_proc(weather):
    if str(weather) in ['2.0', '3.0', '5.0']:        return 'Rain'
    elif str(weather) in ['4.0', '6.0']:     return 'Snow, Storm'
    elif str(weather) in ['1.0', '8.0', '7.0']: return 'Normal'
    
zone_df['catv_str'] = zone_df['catv'].apply(lambda x: vehicle_proc(x))
zone_df['sexe_str'] = zone_df['sexe'].apply(lambda x: genre_proc(x))
zone_df['atm_str'] = zone_df['atm'].apply(lambda x: atm_proc(x))
# [___CELL_SEPARATOR___]
def treat_year(an) :
    return int(str(20) + str(an))

zone_df['annee'] = zone_df['an'].apply(lambda x: treat_year(x))
zone_df['age'] = zone_df['annee'] - zone_df['an_nais']
# [___CELL_SEPARATOR___]
zone_df = zone_df.dropna()
# [___CELL_SEPARATOR___]
zone_df = zone_df[zone_df['larrout'] < 200]
# [___CELL_SEPARATOR___]
zone_df = zone_df[zone_df['larrout'] > 0]
# [___CELL_SEPARATOR___]
def modif_grav(grav) :
    if grav == 1 :
        return "Indemne"
    elif grav == 3 or grav == 4 :
        return "Blessé"
    else :
        return "Mort"
zone_df['grav_str'] = zone_df['grav'].apply(lambda x : modif_grav(x))
# [___CELL_SEPARATOR___]
zone_df['grav'] = zone_df['grav'].astype(str)
# [___CELL_SEPARATOR___]
import altair as alt

def plot_map(df) :

    df = df[df['catr']==4]
    
    if len(df) >= 5000 :
        df = df.sample(30000)

    scales = alt.selection_interval(bind='scales')

    selection = alt.selection_multi(fields=['grav'])

    color = alt.Color('grav:Q', scale=alt.Scale(scheme='redblue', domain=[5,0]), legend=None)

    brush = alt.selection(type='interval')

    ### MAP
    map = alt.Chart(df).mark_circle(size=10).encode(
        x='long',
        y=alt.Y('lat'),
        color=color,
        tooltip=[
            alt.Tooltip('hrmn:Q', title="Heure"),
            alt.Tooltip('catv_str:N', title="Veh. Cat."),
            alt.Tooltip('grav_str:N', title="Gravity"),
            alt.Tooltip('sexe_str:N', title="Casualty genre")
        ]
    ).properties(
        width=275,
        height=275
    ).add_selection(
        brush
    )
    
    ## LEFT - RIGHT
    bars_0 = alt.Chart(df).mark_bar().encode(
        alt.X("grav_str:N", axis=alt.Axis(title='Gravité')),
        y='count()',
        color=color,
        tooltip=[
            alt.Tooltip('grav_str:N', title="Gravité")]
    ).transform_filter(
        brush
    ).properties(
        width=275,
        height=150
    )

    bars_1 = alt.Chart(df).mark_bar().encode(
        alt.X("hrmn:Q", axis=alt.Axis(title='Heure')),
        y='count()',
        color=color,
        tooltip=[
            alt.Tooltip('hrmn:Q', title="Heure"),
            alt.Tooltip('grav_str:N', title="Gravité")]
    ).transform_filter(
        brush
    ).properties(
        width=275,
        height=150
    )

    
    bars_2 = alt.Chart(df).mark_bar().encode(
        alt.X("sexe_str:N", axis=alt.Axis(title='Sexe')),
        y='count()',
        color=color,
        tooltip=[
            alt.Tooltip('sexe_str:N', title="Sexe"),
            alt.Tooltip('grav_str:N', title="Gravité")]
    ).transform_filter(
        brush
    ).properties(
        width=275,
        height=150
    )

    
    bars_3 = alt.Chart(df).mark_bar().encode(
        alt.X("catv_str:N", axis=alt.Axis(title='Cat. Véhicule')),
        y='count()',
        color=color,
        tooltip=[
            alt.Tooltip('catv_str:N', title="Cat. Véhicule"),
            alt.Tooltip('grav_str:N', title="Gravité")]
    ).transform_filter(
        brush
    ).properties(
        width=275,
        height=150
    )

    bars_4 = alt.Chart(df).mark_bar().encode(
        alt.X("lartpc:Q", bin=alt.Bin(maxbins=50), axis=alt.Axis(title='Largeur TPC')),
        y='count()',
        color=color,
        tooltip=[
            alt.Tooltip('lartpc:Q', title="Largeur TPC"),
            alt.Tooltip('grav_str:N', title="Gravité")]
    ).transform_filter(
        brush
    ).properties(
        width=275,
        height=150
    )

    
    bars_5 = alt.Chart(df).mark_bar().encode(
        alt.X("atm_str:N", axis=alt.Axis(title='Météo')),
        y='count()',
        color=color,
        tooltip=[
            alt.Tooltip('atm_str:N', title="Météo"),
            alt.Tooltip('grav_str:N', title="Gravité")]
    ).transform_filter(
        brush
    ).properties(
        width=275,
        height=150
    )
    
    
    bars_left = alt.Chart(df).mark_bar().encode(
        alt.X("annee:Q", axis=alt.Axis(title='Année')),
        y='count()',
        color=color,
        tooltip=[
            alt.Tooltip('annee:Q', title="Année"),
            alt.Tooltip('grav_str:N', title="Gravité")]
    ).transform_filter(
        brush
    ).properties(
        width=275,
        height=275
    )


    bars_right = alt.Chart(df).mark_bar().encode(
        alt.X("age:Q", bin=alt.Bin(maxbins=50), axis=alt.Axis(title='Age')),
        y='count()',
        color=color,
        tooltip=[
            alt.Tooltip('age:Q', title="Age"),
            alt.Tooltip('grav_str:N', title="Gravité")]
    ).transform_filter(
        brush
    ).properties(
        width=275,
        height=275
    )

    chart = ( bars_0 | bars_1 | bars_2 ) & (bars_left | map | bars_right) & ( bars_3 | bars_4 | bars_5 )

    return chart.save('multiple_interactions_com_4.html')
# [___CELL_SEPARATOR___]
plot_map(zone_df)
# [___CELL_SEPARATOR___]
zone_df.to_csv('zone_df.csv')