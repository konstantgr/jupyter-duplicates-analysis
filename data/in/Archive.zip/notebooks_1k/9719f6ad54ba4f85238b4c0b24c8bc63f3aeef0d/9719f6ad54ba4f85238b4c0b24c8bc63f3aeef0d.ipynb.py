import os
import numpy as np
import pandas as pd
import json
from skimage.io import imread
# [___CELL_SEPARATOR___]
from psf import compute, plotPSF
# [___CELL_SEPARATOR___]
import matplotlib.pyplot as plt
%matplotlib inline
import seaborn as sns
sns.set_context('paper', font_scale=2.0)
sns.set_style('ticks')
# [___CELL_SEPARATOR___]
from IPython.html.widgets import interactive
from IPython.html.widgets import IntSliderWidget 
from IPython.display import display
# [___CELL_SEPARATOR___]
FOVumLat = 61.0
FOVpxLat = 512.0 # 512
pxPerUmLat = FOVpxLat/FOVumLat
pxPerUmAx = 2.0 # 2.0
wavelength = 970.0
NA = 0.6
windowUm = [12, 2, 2]
options = {'FOVumLat':FOVumLat, 'FOVpxLat':FOVpxLat, 'pxPerUmLat':FOVpxLat/FOVumLat, 'pxPerUmAx':pxPerUmAx, 'wavelength':970.0, 'NA':0.6, 'windowUm':windowUm}
options['thresh'] = .05
# [___CELL_SEPARATOR___]
options
# [___CELL_SEPARATOR___]
im = imread('./data/images.tif', plugin='tifffile')   
# [___CELL_SEPARATOR___]
data, beads, maxima, centers, smoothed = compute(im, options)
# [___CELL_SEPARATOR___]
PSF = pd.concat([x[0] for x in data])
PSF['Max'] = maxima
PSF = PSF.reset_index().drop(['index'],axis=1)
latProfile = [x[1] for x in data]
axProfile = [x[2] for x in data]
# [___CELL_SEPARATOR___]
PSF
# [___CELL_SEPARATOR___]
print len(PSF)
print PSF.mean()
print PSF.std()
# [___CELL_SEPARATOR___]
plt.figure(figsize=(5,5));
plt.imshow(smoothed);
plt.plot(centers[:, 2], centers[:, 1], 'r.', ms=10);
plt.xlim([0, smoothed.shape[0]])
plt.ylim([smoothed.shape[1], 0])
plt.axis('off');
# [___CELL_SEPARATOR___]
beadInd = 1
average = beads[beadInd]
# [___CELL_SEPARATOR___]
plane = IntSliderWidget(min=0, max=average.shape[0]-1, step=1, value=average.shape[0]/2)
interactive(plotAvg, i=plane)
# [___CELL_SEPARATOR___]
plt.imshow(average.mean(axis=0));
plt.axis('off');
# [___CELL_SEPARATOR___]
plt.imshow(average.mean(axis=1), aspect = pxPerUmLat/pxPerUmAx);
plt.axis('off');
# [___CELL_SEPARATOR___]
plt.imshow(average.mean(axis=2), aspect = pxPerUmLat/pxPerUmAx);
plt.axis('off');
# [___CELL_SEPARATOR___]
plotPSF(latProfile[beadInd][0],latProfile[beadInd][1],latProfile[beadInd][2],latProfile[beadInd][3],pxPerUmLat,PSF.Max.iloc[beadInd])
# [___CELL_SEPARATOR___]
plotPSF(axProfile[beadInd][0],axProfile[beadInd][1],axProfile[beadInd][2],axProfile[beadInd][3],pxPerUmAx,PSF.Max.iloc[beadInd])
# [___CELL_SEPARATOR___]
