listOfNumbers = [1, 2, 3, 4, 5, 6]

for number in listOfNumbers:
    if (number % 2 == 0):
        print(number, "is even")
    else:
        print(number, "is odd")
        
print ("All done.")
        
# [___CELL_SEPARATOR___]
import numpy as np

A = np.random.normal(25.0, 5.0, 10)
print (A)
# [___CELL_SEPARATOR___]
x = [1, 2, 3, 4, 5, 6]
print(len(x))
# [___CELL_SEPARATOR___]
x[:3]
# [___CELL_SEPARATOR___]
x[3:]
# [___CELL_SEPARATOR___]
x[-2:]
# [___CELL_SEPARATOR___]
x.extend([7,8])
x
# [___CELL_SEPARATOR___]
x.append(9)
x
# [___CELL_SEPARATOR___]
y = [10, 11, 12]
listOfLists = [x, y]
listOfLists
# [___CELL_SEPARATOR___]
y[1]
# [___CELL_SEPARATOR___]
z = [3, 2, 1]
z.sort()
z
# [___CELL_SEPARATOR___]
z.sort(reverse=True)
z
# [___CELL_SEPARATOR___]
#Tuples are just immutable lists. Use () instead of []
x = (1, 2, 3)
len(x)
# [___CELL_SEPARATOR___]
y = (4, 5, 6)
y[2]
# [___CELL_SEPARATOR___]
listOfTuples = [x, y]
listOfTuples
# [___CELL_SEPARATOR___]
(age, income) = "32,120000".split(',')
print(age)
print(income)
# [___CELL_SEPARATOR___]
# Like a map or hash table in other languages
captains = {}
captains["Enterprise"] = "Kirk"
captains["Enterprise D"] = "Picard"
captains["Deep Space Nine"] = "Sisko"
captains["Voyager"] = "Janeway"

print(captains["Voyager"])
# [___CELL_SEPARATOR___]
print(captains.get("Enterprise"))
# [___CELL_SEPARATOR___]
print(captains.get("NX-01"))
# [___CELL_SEPARATOR___]
for ship in captains:
    print(ship + ": " + captains[ship])
# [___CELL_SEPARATOR___]
def SquareIt(x):
    return x * x

print(SquareIt(2))

# [___CELL_SEPARATOR___]
#You can pass functions around as parameters
def DoSomething(f, x):
    return f(x)

print(DoSomething(SquareIt, 3))
# [___CELL_SEPARATOR___]
#Lambda functions let you inline simple functions
print(DoSomething(lambda x: x * x * x, 3))
# [___CELL_SEPARATOR___]
print(1 == 3)
# [___CELL_SEPARATOR___]
print(True or False)
# [___CELL_SEPARATOR___]
print(1 is 3)
# [___CELL_SEPARATOR___]
if 1 is 3:
    print("How did that happen?")
elif 1 > 3:
    print("Yikes")
else:
    print("All is well with the world")
# [___CELL_SEPARATOR___]
for x in range(10):
    print(x)
# [___CELL_SEPARATOR___]
for x in range(10):
    if (x is 1):
        continue
    if (x > 5):
        break
    print(x)
# [___CELL_SEPARATOR___]
x = 0
while (x < 10):
    print(x)
    x += 1
# [___CELL_SEPARATOR___]
