# Example 1
p = (4, 5)
x, y = p
print x
print y
# [___CELL_SEPARATOR___]
# Example 2
data = ['ACME', 50, 91.1, (2012, 12, 21)]
name, shares, price, date = data
print name
print date

name, shares, price, (year, mon, day) = data
print name
print year
print mon
print day
# [___CELL_SEPARATOR___]
# Example 3
# error with mismatch in number of elements
p = (4, 5)
x, y, z = p
# [___CELL_SEPARATOR___]
# Example 4: string
s = 'Hello'
a, b, c, d, e = s
print a
print b
print e
# [___CELL_SEPARATOR___]
# Example 5
# discard certain values
data = [ 'ACME', 50, 91.1, (2012, 12, 21) ]
_, shares, price, _ = data
print shares
print price
# [___CELL_SEPARATOR___]
!python ../code/01_unpacking_a_sequence_into_variables.py
# [___CELL_SEPARATOR___]
