%matplotlib inline
%config IPython.matplotlib.backend = "retina"
from matplotlib import rcParams
rcParams["figure.dpi"] = 150
rcParams["savefig.dpi"] = 150
# [___CELL_SEPARATOR___]
import numpy as np
import matplotlib.pyplot as plt

from astropy.io import fits
from astropy import units as u

url = "https://archive.stsci.edu/hlsps/everest/v2/c01/201300000/67065/hlsp_everest_k2_llc_201367065-c01_kepler_v2.0_lc.fits"
with fits.open(url) as hdus:
    data = hdus[1].data
    t = data["TIME"]
    y = data["FLUX"]
    q = data["QUALITY"]
    
# This is from the EVEREST source. These are the flagged data points
# that should be removed. Ref: https://github.com/rodluger/everest
m = np.isfinite(t) & np.isfinite(y)
for b in [1, 2, 3, 4, 5, 6, 7, 8, 9, 11, 12, 13, 14, 16, 17]:
    m &= (q & (2 ** (b - 1))) == 0

t = np.ascontiguousarray(t[m], dtype=np.float64) * u.day
y = np.ascontiguousarray(y[m], dtype=np.float64)
y = (y / np.median(y) - 1)*1e3

fig, ax = plt.subplots(1, 1, sharex=True, figsize=(6, 3))
ax.plot(t, y, "k")
ax.set_xlim(t.min().value, t.max().value)
ax.set_xlabel("time [days]")
ax.set_ylabel("relative flux [ppt]");
# [___CELL_SEPARATOR___]
from scipy.signal import medfilt
trend = medfilt(y, 45)
mu = np.median(y)
y_filt =(y - trend)

fig, axes = plt.subplots(2, 1, sharex=True, figsize=(6, 6))
ax = axes[0]
ax.plot(t, y, "k")
ax.plot(t, trend)
ax.set_ylabel("relative flux [ppt]")

ax = axes[1]
ax.plot(t, y_filt, "k")
ax.set_xlim(t.min().value, t.max().value)
ax.set_xlabel("time [days]")
ax.set_ylabel("de-trended flux [ppt]");
# [___CELL_SEPARATOR___]
from bls import BLS
durations = np.linspace(0.05, 0.2, 10) * u.day
model = BLS(t, y_filt)
results = model.autopower(durations, frequency_factor=5.0)
print(results)
# [___CELL_SEPARATOR___]
# Find the period of the peak
period = results.period[np.argmax(results.power)]

fig, ax = plt.subplots(1, 1, figsize=(6, 3))

# Highlight the harmonics of the peak period
ax.axvline(period.value, alpha=0.4, lw=3)
for n in range(2, 10):
    ax.axvline(n*period.value, alpha=0.4, lw=1, linestyle="dashed")
    ax.axvline(period.value / n, alpha=0.4, lw=1, linestyle="dashed")

# Plot the periodogram
ax.plot(results.period, results.power, "k", lw=0.5)

ax.set_xlim(results.period.min().value, results.period.max().value)
ax.set_xlabel("period [days]")
ax.set_ylabel("log likelihood");
# [___CELL_SEPARATOR___]
index = np.argmax(results.power)
period = results.period[index]
t0 = results.transit_time[index]
duration = results.duration[index]

model.compute_stats(period, duration, t0)
# [___CELL_SEPARATOR___]
model.compute_stats?
# [___CELL_SEPARATOR___]
# Extract the parameters of the best-fit model
index = np.argmax(results.power)
period = results.period[index]
t0 = results.transit_time[index]
duration = results.duration[index]

fig, axes = plt.subplots(2, 1, figsize=(6, 6))
fig.subplots_adjust(hspace=0.3)

# Plot the light curve and best-fit model
ax = axes[0]
ax.plot(t, y_filt, ".k", ms=3)
x = np.linspace(t.min(), t.max(), 3*len(t))
f = model.model(x, period, duration, t0)
ax.plot(x, f, lw=0.75)
ax.set_xlim(t.min().value, t.max().value)
ax.set_ylim(-1.52, 0.4)
ax.set_xlabel("time [days]")
ax.set_ylabel("de-trended flux [ppt]");

# Plot the folded data points within 0.5 days of the transit time
ax = axes[1]
x = (t - t0 + 0.5*period) % period - 0.5*period
m = np.abs(x) < 0.5 * u.day
ax.plot(x[m], y_filt[m], ".k", ms=3)

# Over-plot the best fit model
x = np.linspace(-0.5, 0.5, 1000) * u.day
f = model.model(x + t0, period, duration, t0)
ax.plot(x, f, lw=0.75)
ax.set_xlim(-0.5, 0.5)
ax.set_xlabel("time since transit [days]")
ax.set_ylabel("de-trended flux [ppt]");
# [___CELL_SEPARATOR___]
# Find the in-transit points using a longer duration as a buffer to avoid ingress and egress
in_transit = model.transit_mask(t, period, 2*duration, t0)

# Re-run the algorithm, and plot the results
model2 = BLS(t[~in_transit], y_filt[~in_transit])
results2 = model2.autopower(durations, frequency_factor=5.0)

# Extract the parameters of the best-fit model
index = np.argmax(results2.power)
period2 = results2.period[index]
t02 = results2.transit_time[index]
duration2 = results2.duration[index]

fig, axes = plt.subplots(3, 1, figsize=(6, 9))
fig.subplots_adjust(hspace=0.3)

# Highlight the harmonics of the peak period
ax = axes[0]
ax.axvline(period2.value, alpha=0.4, lw=3)
for n in range(2, 15):
    ax.axvline(n*period2.value, alpha=0.4, lw=1, linestyle="dashed")
    ax.axvline(period2.value / n, alpha=0.4, lw=1, linestyle="dashed")

# Plot the periodogram
ax.plot(results2.period, results2.power, "k", lw=0.5)

ax.set_xlim(results2.period.min().value, results2.period.max().value)
ax.set_xlabel("period [days]")
ax.set_ylabel("log likelihood")

# Plot the light curve and best-fit model
ax = axes[1]
ax.plot(t[~in_transit], y_filt[~in_transit], ".k", ms=3)
x = np.linspace(t.min(), t.max(), 3*len(t))
f = model2.model(x, period2, duration2, t02)
ax.plot(x, f, lw=0.75)
ax.set_xlim(t.min().value, t.max().value)
ax.set_ylim(-0.9, 0.4)
ax.set_xlabel("time [days]")
ax.set_ylabel("de-trended flux [ppt]");

ax = axes[2]
x = (t[~in_transit] - t02 + 0.5*period2) % period2 - 0.5*period2
m = np.abs(x) < 0.5 * u.day
ax.plot(x[m], y_filt[~in_transit][m], ".k", ms=3)
x = np.linspace(-0.5, 0.5, 1000) * u.day
f = model2.model(x + t02, period2, duration2, t02)
ax.plot(x, f, lw=0.75)
ax.set_xlim(-0.5, 0.5)
ax.set_xlabel("time since transit [days]")
ax.set_ylabel("de-trended flux [ppt]");
# [___CELL_SEPARATOR___]
model2.compute_stats(period2, duration2, t02)
# [___CELL_SEPARATOR___]
in_transit2 = in_transit | model2.transit_mask(t, period2, 2*duration2, t02)

# Re-run the algorithm, and plot the results
model3 = BLS(t[~in_transit2], y_filt[~in_transit2])
results3 = model3.autopower(durations, maximum_period=50, frequency_factor=5.0)

# Extract the parameters of the best-fit model
index = np.argmax(results3.power)
period3 = results3.period[index]
t03 = results3.transit_time[index]
duration3 = results3.duration[index]

fig, axes = plt.subplots(3, 1, figsize=(6, 9))
fig.subplots_adjust(hspace=0.3)

# Highlight the harmonics of the peak period
ax = axes[0]
ax.axvline(period3.value, alpha=0.4, lw=3)
for n in range(2, 15):
    ax.axvline(n*period3.value, alpha=0.4, lw=1, linestyle="dashed")
    ax.axvline(period3.value / n, alpha=0.4, lw=1, linestyle="dashed")

# Plot the periodogram
ax.plot(results3.period, results3.power, "k", lw=0.5)

ax.set_xlim(results3.period.min().value, results3.period.max().value)
ax.set_xlabel("period [days]")
ax.set_ylabel("log likelihood")

ax = axes[1]
ax.plot(t[~in_transit2], y_filt[~in_transit2], ".k", ms=3)
x = np.linspace(t.min(), t.max(), 3*len(t))
f = model3.model(x, period3, duration3, t03)
ax.plot(x, f, lw=0.75)
ax.set_xlim(t.min().value, t.max().value)
ax.set_ylim(-0.8, 0.3)
ax.set_xlabel("time [days]")
ax.set_ylabel("de-trended flux [ppt]")

ax = axes[2]
x = (t[~in_transit2] - t03 + 0.5*period3) % period3 - 0.5*period3
m = np.abs(x) < 0.5 * u.day
ax.plot(x[m], y_filt[~in_transit2][m], ".k", ms=3)
x = np.linspace(-0.5, 0.5, 1000) * u.day
f = model3.model(x + t03, period3, duration3, t03)
ax.plot(x, f, lw=0.75)
ax.set_xlim(-0.5, 0.5)
ax.set_ylim(-0.8, 0.3)
ax.set_xlabel("time since transit [days]")
ax.set_ylabel("de-trended flux [ppt]");
# [___CELL_SEPARATOR___]
model3.compute_stats(period3, duration3, t03)
# [___CELL_SEPARATOR___]
