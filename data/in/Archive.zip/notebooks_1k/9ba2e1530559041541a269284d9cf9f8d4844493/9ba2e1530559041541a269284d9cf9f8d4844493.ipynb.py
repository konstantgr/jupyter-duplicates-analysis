%store -r __importRegression
# [___CELL_SEPARATOR___]
__importRegression
# [___CELL_SEPARATOR___]
from itertools import product
from sklearn.linear_model import LinearRegression
import gc
# [___CELL_SEPARATOR___]
#sales = pd.read_csv('../input/train.csv')
#all_data = pd.read_csv('all_data.csv')
all_data = pd.read_csv('../input/all_data_1_2_3_4_5_12_cat.csv')
test = pd.read_csv('../input/test_1_2_3_4_5_12_cat.csv')
#test = pd.read_csv('../input/test.csv')
#items = pd.read_csv("../input/items.csv")
#categories = pd.read_csv("../input/item_categories.csv")
#print (sales.shape)
# [___CELL_SEPARATOR___]
def reduce_mem_usage(props):
    start_mem_usg = props.memory_usage().sum() / 1024**2 
    print("Memory usage of properties dataframe is :",start_mem_usg," MB")
    NAlist = [] # Keeps track of columns that have missing values filled in. 
    for col in props.columns:
        if props[col].dtype != object:  # Exclude strings
            
            # Print current column type
            print("******************************")
            print("Column: ",col)
            print("dtype before: ",props[col].dtype)
            
            # make variables for Int, max and min
            IsInt = False
            mx = props[col].max()
            mn = props[col].min()
            
            # Integer does not support NA, therefore, NA needs to be filled
            if not np.isfinite(props[col]).all(): 
                NAlist.append(col)
                props[col].fillna(mn-1,inplace=True)  
                   
            # test if column can be converted to an integer
            asint = props[col].fillna(0).astype(np.int64)
            result = (props[col] - asint)
            result = result.sum()
            if result > -0.01 and result < 0.01:
                IsInt = True

            
            # Make Integer/unsigned Integer datatypes
            if IsInt:
                if mn >= 0:
                    if mx < 255:
                        props[col] = props[col].astype(np.uint8)
                    elif mx < 65535:
                        props[col] = props[col].astype(np.uint16)
                    elif mx < 4294967295:
                        props[col] = props[col].astype(np.uint32)
                    else:
                        props[col] = props[col].astype(np.uint64)
                else:
                    if mn > np.iinfo(np.int8).min and mx < np.iinfo(np.int8).max:
                        props[col] = props[col].astype(np.int8)
                    elif mn > np.iinfo(np.int16).min and mx < np.iinfo(np.int16).max:
                        props[col] = props[col].astype(np.int16)
                    elif mn > np.iinfo(np.int32).min and mx < np.iinfo(np.int32).max:
                        props[col] = props[col].astype(np.int32)
                    elif mn > np.iinfo(np.int64).min and mx < np.iinfo(np.int64).max:
                        props[col] = props[col].astype(np.int64)    
            
            # Make float datatypes 32 bit
            else:
                props[col] = props[col].astype(np.float32)
            
            # Print new column type
            print("dtype after: ",props[col].dtype)
            print("******************************")
    
    # Print final result
    print("___MEMORY USAGE AFTER COMPLETION:___")
    mem_usg = props.memory_usage().sum() / 1024**2 
    print("Memory usage is: ",mem_usg," MB")
    print("This is ",100*mem_usg/start_mem_usg,"% of the initial size")
    return props, NAlist
# [___CELL_SEPARATOR___]
# Add date_block_num for test with value 34 (next month)
test['date_block_num'] = 34
# [___CELL_SEPARATOR___]
all_data, NAs = reduce_mem_usage(all_data)
# [___CELL_SEPARATOR___]
test, NAs = reduce_mem_usage(test)
# [___CELL_SEPARATOR___]
index_cols = ['shop_id', 'item_id', 'date_block_num']
# [___CELL_SEPARATOR___]
all_data.head()
# [___CELL_SEPARATOR___]
all_data.target.plot()
# [___CELL_SEPARATOR___]
all_data.target.describe()
# [___CELL_SEPARATOR___]

# For every month we create a grid from all shops/items combinations from that month
grid = [] 
for block_num in sales['date_block_num'].unique():
    cur_shops = sales[sales['date_block_num']==block_num]['shop_id'].unique()
    cur_items = sales[sales['date_block_num']==block_num]['item_id'].unique()
    grid.append(np.array(list(product(*[cur_shops, cur_items, [block_num]])),dtype='int32'))

#turn the grid into pandas dataframe
grid = pd.DataFrame(np.vstack(grid), columns = index_cols,dtype=np.int32)

#get aggregated values for (shop_id, item_id, month)
gb = sales.groupby(index_cols,as_index=False).agg({'item_cnt_day':{'target':'sum'}})
#fix column names
gb.columns = [col[0] if col[-1]=='' else col[-1] for col in gb.columns.values]
#join aggregated data to the grid
all_data = pd.merge(grid,gb,how='left',on=index_cols).fillna(0)

# Same as above but with shop-month aggregates
gb = sales.groupby(['shop_id', 'date_block_num'],as_index=False).agg({'item_cnt_day':{'target_shop':'sum'}})
gb.columns = [col[0] if col[-1]=='' else col[-1] for col in gb.columns.values]
all_data = pd.merge(all_data, gb, how='left', on=['shop_id', 'date_block_num']).fillna(0)

# Same as above but with item-month aggregates
gb = sales.groupby(['item_id', 'date_block_num'],as_index=False).agg({'item_cnt_day':{'target_item':'sum'}})
gb.columns = [col[0] if col[-1] == '' else col[-1] for col in gb.columns.values]
all_data = pd.merge(all_data, gb, how='left', on=['item_id', 'date_block_num']).fillna(0)

#sort the data
all_data.sort_values(['date_block_num','shop_id','item_id'],inplace=True)
# [___CELL_SEPARATOR___]
all_data, NAS = reduce_mem_usage(all_data)

del grid, gb 
gc.collect();
# [___CELL_SEPARATOR___]
all_data.head()
# [___CELL_SEPARATOR___]
all_data.to_csv('all_data.csv', index=False)
# [___CELL_SEPARATOR___]
# List of columns that we will use to create lags
cols_to_rename = list(all_data.columns.difference(index_cols))
# [___CELL_SEPARATOR___]
cols_to_rename
# [___CELL_SEPARATOR___]
cols_to_rename = ['target', 'target_item', 'target_shop']
# [___CELL_SEPARATOR___]
# lag months: 1 = last month sales; 12 = last year same month sales
shift_range = [1, 2, 3, 4, 5, 12]
# [___CELL_SEPARATOR___]
from tqdm import tqdm_notebook
# [___CELL_SEPARATOR___]
for month_shift in tqdm_notebook(shift_range):
    train_shift = all_data[index_cols + cols_to_rename].copy()
    
    train_shift['date_block_num'] = train_shift['date_block_num'] + month_shift
    
    
    
    foo = lambda x: '{}_lag_{}'.format(x, month_shift) if x in cols_to_rename else x
    train_shift = train_shift.rename(columns=foo)
    
    # Merge lag feature with train data
    all_data = pd.merge(all_data, train_shift, on=index_cols, how='left').fillna(0)
    
    # Merge lag feature with test data
    test = pd.merge(test, train_shift, on=index_cols, how='left').fillna(0)
    
del train_shift
gc.collect();
# [___CELL_SEPARATOR___]
items = pd.read_csv("../input/items.csv")
#items, NAs = reduce_mem_usage(items)
print items.shape
# [___CELL_SEPARATOR___]
items.head()
# [___CELL_SEPARATOR___]
# Category for each item
item_category_mapping = items[['item_id','item_category_id']].drop_duplicates()

all_data = pd.merge(all_data, item_category_mapping, how='left', on='item_id')

test = pd.merge(test, item_category_mapping, how='left', on='item_id')
# [___CELL_SEPARATOR___]
test.head()
# [___CELL_SEPARATOR___]
test, NAs = reduce_mem_usage(test)
# [___CELL_SEPARATOR___]
test.to_csv('../input/test_1_2_3_4_5_12_cat.csv', index=False)
# [___CELL_SEPARATOR___]
all_data, NAs = reduce_mem_usage(all_data)
# [___CELL_SEPARATOR___]
all_data.to_csv('../input/all_data_1_2_3_4_5_12_cat.csv', index=False)
# [___CELL_SEPARATOR___]
## Add lag feature differences (feature interaction)
for i in [2,3,4,5]:
    fname = '_lag' + str(i-1) + '_lag' + str(i)
    lag1 = '_lag_' + str(i-1)
    lag2 = '_lag_' + str(i)
    all_data['target' + fname] = all_data['target' + lag1] - all_data['target' + lag2]
    test['target' + fname] = test['target' + lag1] - test['target' + lag2]
    all_data['target_item' + fname] = all_data['target_item' + lag1] - all_data['target_item' + lag2]
    test['target_item' + fname] = test['target_item' + lag1] - test['target_item' + lag2]
    all_data['target_shop' + fname] = all_data['target_shop' + lag1] - all_data['target_shop' + lag2]
    test['target_shop' + fname] = test['target_shop' + lag1] - test['target_shop' + lag2]
# [___CELL_SEPARATOR___]
print (all_data.shape, test.shape)
# [___CELL_SEPARATOR___]
# List of all lagged features
fit_cols = [col for col in all_data.columns if col[-1] in [str(item) for item in shift_range]] 
fit_cols.append('item_category_id')
# We will drop these at fitting stage
to_drop_cols = list(set(list(all_data.columns)) - (set(fit_cols)|set(index_cols))) + ['date_block_num'] 

print fit_cols
print to_drop_cols
# [___CELL_SEPARATOR___]
# Drop data from 2013
all_data = all_data[all_data.date_block_num >= 12]
# [___CELL_SEPARATOR___]
all_data, NAs = reduce_mem_usage(all_data)
# [___CELL_SEPARATOR___]
from sklearn.preprocessing import StandardScaler
# [___CELL_SEPARATOR___]
X = all_data.drop(to_drop_cols, axis=1)
# [___CELL_SEPARATOR___]
X.head()
# [___CELL_SEPARATOR___]
## Standardize the data
X_std = StandardScaler().fit_transform(X)
# [___CELL_SEPARATOR___]
## Get Covariance matrix

cov_mat = np.cov(X_std.T)
print('Covariance matrix shape', cov_mat.shape)
# [___CELL_SEPARATOR___]
## Getting eigen vectors and eigen values
eig_vals, eig_vecs = np.linalg.eig(cov_mat)
# [___CELL_SEPARATOR___]
print('\nEigenvalues \n%s' %eig_vals)
# [___CELL_SEPARATOR___]
## Making sure eigen vectors have a norm of 1
for ev in eig_vecs:
    np.testing.assert_array_almost_equal(1.0, np.linalg.norm(ev))
print('Everything ok!')
# [___CELL_SEPARATOR___]
# Make a list of (eigenvalue, eigenvector) tuples
eig_pairs = [(np.abs(eig_vals[i]), eig_vecs[:,i]) for i in range(len(eig_vals))]

# Sort the (eigenvalue, eigenvector) tuples from high to low
eig_pairs.sort()
eig_pairs.reverse()

# Visually confirm that the list is correctly sorted by decreasing eigenvalues
print('Eigenvalues in descending order:')
for i in eig_pairs:
    print(i[0])
# [___CELL_SEPARATOR___]
tot = sum(eig_vals)
var_exp = [(i / tot)*100 for i in sorted(eig_vals, reverse=True)]
cum_var_exp = np.cumsum(var_exp)

with plt.style.context('seaborn-whitegrid'):
    plt.figure(figsize=(10, 6))

    plt.bar(range(33), var_exp, alpha=0.5, align='center',
            label='individual explained variance')
    plt.step(range(33), cum_var_exp, where='mid',
             label='cumulative explained variance')
    plt.ylabel('Explained variance ratio')
    plt.xlabel('Principal components')
    plt.legend(loc='best')
    plt.tight_layout()
# [___CELL_SEPARATOR___]
matrix_w = np.hstack((eig_pairs[0][1].reshape(33,1),
                      eig_pairs[1][1].reshape(33,1)))
# [___CELL_SEPARATOR___]
X_2 = X_std.dot(matrix_w)
# [___CELL_SEPARATOR___]
X_2.shape
# [___CELL_SEPARATOR___]
all_data.shape
# [___CELL_SEPARATOR___]
X_2 = pd.DataFrame(X_2, columns=['PCA_1', 'PCA_2'])
# [___CELL_SEPARATOR___]
X_2.head()
# [___CELL_SEPARATOR___]
all_data['PCA_1'] = X_2['PCA_1']
all_data['PCA_2'] = X_2['PCA_2']
# [___CELL_SEPARATOR___]
all_data.head()
# [___CELL_SEPARATOR___]
# Save `date_block_num`, as we can't use them as features, but will need them to split the dataset into parts 
dates = all_data['date_block_num']

last_block = dates.max()
print('Test `date_block_num` is %d' % last_block)
# [___CELL_SEPARATOR___]
lgb_params = {
               'feature_fraction': 0.75,
               'metric': 'rmse',
               'n_jobs': -1, 
               'min_data_in_leaf': 2**7, 
               'bagging_fraction': 0.75, 
               'learning_rate': 0.03, 
               'objective': 'mse', 
               'bagging_seed': 2**7, 
               'num_leaves': 2**7,
               'bagging_freq':1,
               'verbose':0 
              }

model = LGBMRegressor(**lgb_params)
# [___CELL_SEPARATOR___]
model = LGBMRegressor(n_jobs=-1, metric='rmse', objective='mse')
# [___CELL_SEPARATOR___]
model = RandomForestRegressor(n_jobs=-1)
# [___CELL_SEPARATOR___]
model = LinearRegression()
# [___CELL_SEPARATOR___]
all_data.target.describe()
# [___CELL_SEPARATOR___]
# Clipping to 40 seems to improve RMSE score.
# Tune this value to further improve score?
all_data['target'] = all_data.target.clip(lower=-1, upper=40)
# [___CELL_SEPARATOR___]
all_data.target.describe()
# [___CELL_SEPARATOR___]
# Moving window validation scheme.
# On each iteration, use last month for validation
validation_months = [33, 32, 31, 30, 29]

for last_month in validation_months:
    # Split train and validation data
    dates_train = dates[dates <  last_month]
    dates_test  = dates[dates == last_month]

    X_train = all_data.loc[dates <  last_month].drop(to_drop_cols, axis=1)
    X_test =  all_data.loc[dates == last_month].drop(to_drop_cols, axis=1)

    y_train = all_data.loc[dates <  last_month, 'target'].values
    y_test =  all_data.loc[dates == last_month, 'target'].values
    
    model.fit(X_train, y_train)

    pred_train = model.predict(X_train)
    pred_test = model.predict(X_test)
    
    ## R2 and RMSE score for each validation fold
    print('Month {0:d} Test R-2: {1:f}'.format(last_month, r2_score(y_test, pred_test)))
    print('Month {0:d} Test RMSE {1:f}'.format(last_month, np.sqrt(mean_squared_error(y_test, pred_test))))
    
del dates_train, dates_test, X_train, X_test, y_train, y_test, pred_train, pred_test
gc.collect()
# [___CELL_SEPARATOR___]
## Take all train data
X_train_all = all_data.drop(to_drop_cols, axis=1)
y_train_all = all_data.target.values
# [___CELL_SEPARATOR___]
y = pd.DataFrame(y_train_all)
# [___CELL_SEPARATOR___]
y.describe()
# [___CELL_SEPARATOR___]
X_train_all.head()
# [___CELL_SEPARATOR___]
X_train_all.target_lag_1.describe()
# [___CELL_SEPARATOR___]
test.sort(columns='ID')
# [___CELL_SEPARATOR___]
test_id = test.pop('ID')
test.drop('date_block_num', axis=1, inplace=True)
# [___CELL_SEPARATOR___]
test.head()
# [___CELL_SEPARATOR___]
X_train_all.head()
# [___CELL_SEPARATOR___]
model.fit(X_train_all, y_train_all)

pred_train_all = model.predict(X_train_all)
pred_test = model.predict(test)

## R2 and RMSE score for each validation fold
print('Train R-2: {0:f}'.format(r2_score(y_train_all, pred_train_all)))
print('Train RMSE {0:f}'.format(np.sqrt(mean_squared_error(y_train_all, pred_train_all))))
# [___CELL_SEPARATOR___]
pred_test.shape
# [___CELL_SEPARATOR___]
for i in range(len(pred_test)):
    if pred_test[i] > 20:
        pred_test[i] = 20
    if pred_test[i] < 0:
        pred_test[i] = 20
# [___CELL_SEPARATOR___]
test_submit = pd.DataFrame({'ID': test_id, 'item_cnt_month': pred_test})
print test_submit.shape
test_submit.to_csv('new_lgb_Clip40_before_train.csv', index=False)
test_submit.head()
# [___CELL_SEPARATOR___]
