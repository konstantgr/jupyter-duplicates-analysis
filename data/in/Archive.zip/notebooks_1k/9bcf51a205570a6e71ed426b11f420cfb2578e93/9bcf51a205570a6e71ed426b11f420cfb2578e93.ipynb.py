from wc_rules.indexer import NumericIndexer
# [___CELL_SEPARATOR___]
# initialize
I = NumericIndexer()
# update using dict objects or other indexers of the same type.
I.update(dict(a=1,b=1,c=2))
# [___CELL_SEPARATOR___]
# use `[key]` to query the value associated with a key
I['a']
# [___CELL_SEPARATOR___]
# use value_cache[value] to get a slicer of keys associated with a value
I.value_cache[1]
# [___CELL_SEPARATOR___]
type(I.value_cache[1])
# [___CELL_SEPARATOR___]
I = NumericIndexer().update(dict(a=1,b=1,c=2))
S = I==1
S
# [___CELL_SEPARATOR___]
J = NumericIndexer().update(dict(a=1,b=1,c=3))
S = I==J
S
# [___CELL_SEPARATOR___]
S = I!=1
S
# [___CELL_SEPARATOR___]
S = I!=J
S
# [___CELL_SEPARATOR___]
I = NumericIndexer().update(dict(a=1,b=2,c=3,d=4))
J = NumericIndexer().update(dict(a=1,b=1,c=2,d=5))
# [___CELL_SEPARATOR___]
S = I < J
S
# [___CELL_SEPARATOR___]
S = I >= J
S
# [___CELL_SEPARATOR___]
S = I > 2
S
# [___CELL_SEPARATOR___]
I = NumericIndexer().update(dict(a=1,b=2,c=3,d=4))
S = I > 2
I[S]
# [___CELL_SEPARATOR___]
I[ I > 2 ]
# [___CELL_SEPARATOR___]
I[ I!=2 ]
# [___CELL_SEPARATOR___]
I[ (I>2) & (I<4) ]