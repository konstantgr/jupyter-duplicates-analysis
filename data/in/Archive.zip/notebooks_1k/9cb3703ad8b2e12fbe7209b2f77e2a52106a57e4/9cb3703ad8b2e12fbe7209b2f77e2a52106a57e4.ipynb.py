using StatPlots
# [___CELL_SEPARATOR___]
plot(1:100, cumsum(randn(100)))
# [___CELL_SEPARATOR___]
plot(1:100, cumsum(randn(100)), 
    marker = :circle, markercolor = :blue, markersize = 4, markerstrokecolor = :white, 
    linewidth = 4, linecolor = :red, 
    legend = :topleft, xscale = :log10)
# [___CELL_SEPARATOR___]
plotattr()
# [___CELL_SEPARATOR___]
plotattr(:Series)
# [___CELL_SEPARATOR___]
plotattr("linestyle")
# [___CELL_SEPARATOR___]
a = randn(1000)
histogram(a, norm = :pdf)
density!(a, lw = 3)
# [___CELL_SEPARATOR___]
plot(cumsum(randn(100,4), dims = 1), linestyle = [:solid :dot :dash :dashdot], lw = 2)
# [___CELL_SEPARATOR___]
plotattr("seriestype")
# [___CELL_SEPARATOR___]
using DataFrames, RDatasets
iris = dataset("datasets", "iris")
first(iris, 4)
# [___CELL_SEPARATOR___]
#when plotting data in a DataFrame use the @df macro
p = @df iris scatter(:SepalLength, :SepalWidth, group = :Species, smooth = true)
# [___CELL_SEPARATOR___]
@df iris scatter(:SepalLength, :SepalWidth, group = :Species, smooth = true, 
    layout = (1,3), link = :all, size = (900, 270))
# [___CELL_SEPARATOR___]

@df iris scatter(:SepalLength, :SepalWidth, group = :Species, smooth = true, 
    layout = @layout([a{0.5h};[b{0.7w} c]]), legend = :bottomright)

# [___CELL_SEPARATOR___]
plot([sin, x->x^2 / 20])
# [___CELL_SEPARATOR___]
using Distributions
N = Poisson(5)
plot(N, st = :bar)
# [___CELL_SEPARATOR___]
 histogram2d(randn(10000), randn(10000), color = :viridis)
# [___CELL_SEPARATOR___]
clibraries()
# [___CELL_SEPARATOR___]
showlibrary(:colorcet)
# [___CELL_SEPARATOR___]
@df iris scatter(:SepalLength, :SepalWidth, marker_z = :PetalWidth)
# [___CELL_SEPARATOR___]
showtheme(:solarized)
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
