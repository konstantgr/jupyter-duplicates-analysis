# the following line gets the bucket name attached to our cluster
bucket = spark._jsc.hadoopConfiguration().get("fs.gs.system.bucket")

# specifying the path to our bucket where the data is located (no need to edit this path anymore)
data = "gs://" + bucket + "/notebooks/jupyter/data/"
print(data)
# [___CELL_SEPARATOR___]
df = spark.read.json(data + "simple-ml")
df.orderBy("value2").show(5)
# [___CELL_SEPARATOR___]
from pyspark.ml.feature import RFormula

supervised = RFormula(formula="lab ~ . + color:value1 + color:value2")
# [___CELL_SEPARATOR___]
fittedRF = supervised.fit(df)  # fit the transformer
preparedDF = fittedRF.transform(df)  # transform
preparedDF.show(5, False)
# [___CELL_SEPARATOR___]
train, test = preparedDF.randomSplit([0.7, 0.3], seed = 843)
test.show(2)
# [___CELL_SEPARATOR___]
from pyspark.ml.classification import LogisticRegression

lr = LogisticRegression(labelCol="label",featuresCol="features")
# [___CELL_SEPARATOR___]
print(lr.explainParams())
# [___CELL_SEPARATOR___]
fittedLR = lr.fit(train)
# [___CELL_SEPARATOR___]
fittedLR.transform(test).select("label", "prediction").show(5)
# [___CELL_SEPARATOR___]
from pyspark.ml.feature import RFormula
from pyspark.ml.classification import LogisticRegression

supervised = RFormula(formula="lab ~ . + color:value1 + color:value2")  # define the R formula
fittedRF = supervised.fit(df)  # fit the transformer
preparedDF = fittedRF.transform(df)  # transform

train, test = preparedDF.randomSplit([0.7, 0.3], seed = 843)  # split into train/test
lr = LogisticRegression()  # instantiate an instance of LogisticRegression
fittedLR = lr.fit(train)  # fit the estimator
#fittedLR.transform(train).select("probability", "prediction").show(5)  # checkout the prediction on train dataset
# [___CELL_SEPARATOR___]
fittedLR.transform(test).select("probability", "prediction").show(5, False)
# [___CELL_SEPARATOR___]
train, test = df.randomSplit([0.7, 0.3], seed = 843)
test.show(2)
# [___CELL_SEPARATOR___]
rForm = RFormula()
lr = LogisticRegression().setLabelCol("label").setFeaturesCol("features")
# [___CELL_SEPARATOR___]
from pyspark.ml import Pipeline

stages = [rForm, lr]
pipeline = Pipeline().setStages(stages)
# [___CELL_SEPARATOR___]
from pyspark.ml.tuning import ParamGridBuilder

params = ParamGridBuilder()\
  .addGrid(rForm.formula, [
    "lab ~ . + color:value1",
    "lab ~ . + color:value1 + color:value2"])\
  .addGrid(lr.elasticNetParam, [0.0, 0.5, 1.0])\
  .addGrid(lr.regParam, [0.1, 2.0])\
  .build()
# [___CELL_SEPARATOR___]
from pyspark.ml.evaluation import BinaryClassificationEvaluator

evaluator = BinaryClassificationEvaluator(metricName='areaUnderROC')
# [___CELL_SEPARATOR___]
from pyspark.ml.tuning import TrainValidationSplit

tvs = TrainValidationSplit()\
  .setTrainRatio(0.75)\
  .setEstimatorParamMaps(params)\
  .setEstimator(pipeline)\
  .setEvaluator(evaluator)
# [___CELL_SEPARATOR___]
tvsFitted = tvs.fit(train)
# [___CELL_SEPARATOR___]
evaluator.evaluate(tvsFitted.transform(test))
# [___CELL_SEPARATOR___]
from pyspark.ml import Pipeline
from pyspark.ml.tuning import ParamGridBuilder, TrainValidationSplit
from pyspark.ml.evaluation import BinaryClassificationEvaluator

train, test = df.randomSplit([0.7, 0.3], seed = 843)  # create a holdout set before transformation
rForm = RFormula()  # defining stage 1 by creating an empty R formula
lr = LogisticRegression().setLabelCol("label").setFeaturesCol("features")  # defining stage 2 by instantiating an instance of LogisticRegression

stages = [rForm, lr]  # setting the stages
pipeline = Pipeline().setStages(stages)  # adding the stages to the pipeline

# building the hyperparameter grid
params = ParamGridBuilder()\
  .addGrid(rForm.formula, [
    "lab ~ . + color:value1",
    "lab ~ . + color:value1 + color:value2"])\
  .addGrid(lr.elasticNetParam, [0.0, 0.5, 1.0])\
  .addGrid(lr.regParam, [0.1, 2.0])\
  .build()

# setting the evaluator as AUC
evaluator = BinaryClassificationEvaluator(metricName='areaUnderROC')

# defining Train Validation Split to be used for hypyerparameter tuning
tvs = TrainValidationSplit()\
  .setTrainRatio(0.75)\
  .setEstimatorParamMaps(params)\
  .setEstimator(pipeline)\
  .setEvaluator(evaluator)

tvsFitted = tvs.fit(train)  # fit the estimator

evaluator.evaluate(tvsFitted.transform(test))  # evaluate the test set (AUC)
# [___CELL_SEPARATOR___]
tvsFitted.bestModel.write().overwrite().save(data + "model/firstModel")
# [___CELL_SEPARATOR___]
from pyspark.ml import PipelineModel

model = PipelineModel.load(data + "model/firstModel")
prediction = model.transform(test)
# [___CELL_SEPARATOR___]
prediction.select("probability", "prediction", "label").show(10, False)