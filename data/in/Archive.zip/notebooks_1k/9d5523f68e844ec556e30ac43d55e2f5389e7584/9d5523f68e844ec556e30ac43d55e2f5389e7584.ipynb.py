#%% make sure figures appears inline and animations works
%matplotlib notebook
# [___CELL_SEPARATOR___]
#%% Initial imports etc
import numpy
from numpy.linalg import norm
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import os
import sys
import shutil
import string
#import scipy
#from scipy import optimize
import sirf.STIR as pet
from sirf.Utilities import examples_data_path
#os.getcwd()

# Get to correct directory
os.chdir(examples_data_path('Synergistic'))

#%% copy files to working folder and change directory to where the output files are
shutil.rmtree('working_folder/HKEM',True)
shutil.copytree('brainweb','working_folder/HKEM')
os.chdir('working_folder/HKEM')
# [___CELL_SEPARATOR___]
#%% some handy function definitions
def imshow(image, limits, title=''):
    """Usage: imshow(image, [min,max], title)"""
    plt.title(title)
    bitmap = plt.imshow(image)
    if len(limits)==0:
        limits = [image.min(), image.max()]

    plt.clim(limits[0], limits[1])
    plt.colorbar(shrink=.6)
    plt.axis('off')
    return bitmap

def make_positive(image_array):
    """truncate any negatives to zero"""
    image_array[image_array<0] = 0
    return image_array

def make_cylindrical_FOV(image):
    """truncate to cylindrical FOV"""
    filter = pet.TruncateToCylinderProcessor()
    filter.apply(image)
# [___CELL_SEPARATOR___]
full_sino = pet.AcquisitionData('FDG_sino_noisy.hs')
sino = full_sino.rebin(1)

atten = pet.ImageData('uMap.hv')
num_subsets = 21
num_subiters = 1

# Anatomical image
anatomical = pet.ImageData('T1_small.hv')
anatomical.fill(make_positive(anatomical.as_array()))

#%%  create initial image
init_image=atten.get_uniform_copy(atten.as_array().max()*.1)
make_cylindrical_FOV(init_image)
# [___CELL_SEPARATOR___]
#%% create acquisition model
am = pet.AcquisitionModelUsingRayTracingMatrix()
am.set_num_tangential_LORs(5)

# Set up sensitivity due to attenuation
asm_attn = pet.AcquisitionSensitivityModel(atten, am)
asm_attn.set_up(sino)
bin_eff = pet.AcquisitionData(sino)
bin_eff.fill(1.0)
asm_attn.unnormalise(bin_eff)
asm_attn = pet.AcquisitionSensitivityModel(bin_eff)

# Set sensitivity of the model and set up
am.set_acquisition_sensitivity(asm_attn)
am.set_up(sino,atten)

#%% create objective function
obj_fun = pet.make_Poisson_loglikelihood(sino)
obj_fun.set_acquisition_model(am)
# [___CELL_SEPARATOR___]
recon = pet.KOSMAPOSLReconstructor()
recon.set_objective_function(obj_fun)

recon.set_input(sino)

recon.set_anatomical_prior(anatomical)
recon.set_only_2D(True)
recon.set_num_non_zero_features(1)

recon.set_num_subsets(num_subsets)
recon.set_num_subiterations(num_subiters)
# [___CELL_SEPARATOR___]
#%% reconstruct the image 
H1n_reconstructed_image = [] 
H0n_reconstructed_image = []

#fix other parameters
recon.set_sigma_m(0.5)
recon.set_sigma_p(0.5)
recon.set_sigma_dm(3.0)
recon.set_sigma_dp(3.0)

n={3, 5, 7, 9}
ii=0
for i in n:

    H1n_reconstructed_image.append(init_image.clone())
    H0n_reconstructed_image.append(init_image.clone())

    recon.set_num_neighbours(i)
    j="{}".format(i)
    jj=j.replace(".", "_")

#   reconstruct using side information from MR and PET (H0 is KEM H1 is HKEM)
    output_prefix = "H1_N{}".format(jj)
#   set up the reconstructor
    recon.set_output_filename_prefix(output_prefix)
    recon.set_hybrid(True)
    recon.set_up(H1n_reconstructed_image[ii])
    recon.reconstruct(H1n_reconstructed_image[ii])

#   reconstruct using only side information from MR (H0 is KEM H1 is HKEM)
    output_prefix = "H0_N{}".format(jj)
#   set up the reconstructor
    recon.set_output_filename_prefix(output_prefix)
    recon.set_hybrid(False)
    recon.set_up(H0n_reconstructed_image[ii])
    recon.reconstruct(H0n_reconstructed_image[ii])
    ii=ii+1;
# [___CELL_SEPARATOR___]
#%% bitmap display of images
# define lists

H1n_reconstructed_array = []
H0n_reconstructed_array = []
diffn_image_array = []
H1n_error_array = []
H0n_error_array = []
ii=0

for i in n:

    j="{}".format(i)
    jj=j.replace(".", "_")
    #H0n_reconstructed_image[ii]=pet.ImageData('H0_N'+jj+'_12.hv')
    H1n_reconstructed_array.append(H1n_reconstructed_image[ii].as_array())
    H0n_reconstructed_array.append(H0n_reconstructed_image[ii].as_array())

#   anatomical_image_array = anatomical_image.as_array()
    diffn_image_array.append(H1n_reconstructed_array[ii] - H0n_reconstructed_array[ii])
    H1n_error_array.append(image_array - H1n_reconstructed_array[ii])
    H0n_error_array.append(image_array - H0n_reconstructed_array[ii])

    plt.figure()
    plt.subplot(3,3,1)
    imshow(image_array[im_slice,:,:,], [0,cmax*1.5],'True image')
    plt.subplot(3,3,2)
    imshow(H1n_reconstructed_array[ii][im_slice,:,:,], [0,cmax*1.5], 'HKEM, n ='+j)
    plt.subplot(3,3,3)
    imshow(H0n_reconstructed_array[ii][im_slice,:,:,], [0,cmax*1.5], 'KEM, n ='+j)
    plt.subplot(3,3,4)
    imshow(diffn_image_array[ii][im_slice,:,:,], [-cmax*0.1,cmax*0.1], 'HKEM - KEM')
    plt.subplot(3,3,5)
    imshow(H1n_error_array[ii][im_slice,:,:,], [-cmax*1,cmax*1], 'HKEM error')
    plt.subplot(3,3,6)
    imshow(H0n_error_array[ii][im_slice,:,:,], [-cmax*1,cmax*.1], 'KEM error')

    ii=ii+1;
# [___CELL_SEPARATOR___]
#%% reconstruct the image 
H1m_reconstructed_image = [] 
H0m_reconstructed_image = []

#fix other parameters
recon.set_num_neighbours(5)
recon.set_sigma_p(0.5)
recon.set_sigma_dm(3.0)
recon.set_sigma_dp(3.0)

sigma_m={0.05, 0.1, 0.5, 1, 3, 5, 8, 10}
ii=0
for i in sigma_m:

    H1m_reconstructed_image.append(init_image.clone())
    H0m_reconstructed_image.append(init_image.clone())

    recon.set_sigma_m(i)
    j="{}".format(i)
    jj=j.replace(".", "_")

#   reconstruct using side information from MR and PET (H0 is KEM H1 is HKEM)
    output_prefix = "H1_N5_M{}".format(jj)
#   set up the reconstructor
    recon.set_output_filename_prefix(output_prefix)
    recon.set_hybrid(True)
    recon.set_up(H1m_reconstructed_image[ii])
    recon.reconstruct(H1m_reconstructed_image[ii])

#   reconstruct using only side information from MR (H0 is KEM H1 is HKEM)
    output_prefix = "H0_N5_M{}".format(jj)
#   set up the reconstructor
    recon.set_output_filename_prefix(output_prefix)
    recon.set_hybrid(False)
    recon.set_up(H0m_reconstructed_image[ii])
    recon.reconstruct(H0m_reconstructed_image[ii])
    ii=ii+1;
# [___CELL_SEPARATOR___]
#%% bitmap display of images
# define lists
H1m_reconstructed_array = []
H0m_reconstructed_array = []
diffm_image_array = []
H1m_error_array = []
H0m_error_array = []
ii=0
sigma_m={0.05, 0.1, 0.5, 1, 3, 5, 8, 10}
for i in sigma_m:

    j="{}".format(i)
    jj=j.replace(".", "_")

    H1m_reconstructed_array.append(H1m_reconstructed_image[ii].as_array())
    H0m_reconstructed_array.append(H0m_reconstructed_image[ii].as_array())

#   anatomical_image_array = anatomical_image.as_array()
    diffm_image_array.append(H1m_reconstructed_array[ii] - H0m_reconstructed_array[ii])
    H1m_error_array.append(image_array - H1m_reconstructed_array[ii])
    H0m_error_array.append(image_array - H0m_reconstructed_array[ii])

    plt.figure()
    plt.subplot(3,3,1)
    imshow(image_array[im_slice,:,:,], [0,cmax*1.5],'True image')
    plt.subplot(3,3,2)
    imshow(H1m_reconstructed_array[ii][im_slice,:,:,], [0,cmax*1.5], 'HKEM, sigma_m='+j)
    plt.subplot(3,3,3)
    imshow(H0m_reconstructed_array[ii][im_slice,:,:,], [0,cmax*1.5], 'KEM, sigma_m='+j)
    plt.subplot(3,3,4)
    imshow(diffm_image_array[ii][im_slice,:,:,], [-cmax*0.1,cmax*0.1], 'HKEM - KEM')
    plt.subplot(3,3,5)
    imshow(H1m_error_array[ii][im_slice,:,:,], [-cmax*1,cmax*1], 'HKEM error')
    plt.subplot(3,3,6)
    imshow(H0m_error_array[ii][im_slice,:,:,], [-cmax*1,cmax*1], 'KEM error')

    ii=ii+1;
# [___CELL_SEPARATOR___]
#%% reconstruct the image 
H1p_reconstructed_image = [] 
H0p_reconstructed_image = []

#fix other parameters
recon.set_num_neighbours(5)
recon.set_sigma_m(0.5)
recon.set_sigma_dm(3.0)
recon.set_sigma_dp(3.0)

sigma_p={0.05, 0.1, 0.5, 1, 3, 5, 8, 10}
ii=0
for i in sigma_p:

    H1p_reconstructed_image.append(init_image.clone())
    H0p_reconstructed_image.append(init_image.clone())

    recon.set_sigma_p(i)
    j="{}".format(i)
    jj=j.replace(".", "_")

#   reconstruct using side information from MR and PET (H0 is KEM H1 is HKEM)
    output_prefix = "H1_N5_P{}".format(jj)
#   set up the reconstructor
    recon.set_output_filename_prefix(output_prefix)
    recon.set_hybrid(True)
    recon.set_up(H1p_reconstructed_image[ii])
    recon.reconstruct(H1p_reconstructed_image[ii])

#   reconstruct using only side information from MR (H0 is KEM H1 is HKEM)
    output_prefix = "H0_N5_P{}".format(jj)
#   set up the reconstructor
    recon.set_output_filename_prefix(output_prefix)
    recon.set_hybrid(False)
    recon.set_up(H0p_reconstructed_image[ii])
    recon.reconstruct(H0p_reconstructed_image[ii])
    ii=ii+1;
# [___CELL_SEPARATOR___]
#%% bitmap display of images
# define lists
H1p_reconstructed_array = []
H0p_reconstructed_array = []
diffp_image_array = []
H1p_error_array = []
H0p_error_array = []
ii=0

for i in sigma_p:

    j="{}".format(i)
    jj=j.replace(".", "_")

    H1p_reconstructed_array.append(H1p_reconstructed_image[ii].as_array())
    H0p_reconstructed_array.append(H0p_reconstructed_image[ii].as_array())

#   anatomical_image_array = anatomical_image.as_array()
    diffp_image_array.append(H1p_reconstructed_array[ii] - H0p_reconstructed_array[ii])
    H1p_error_array.append(image_array - H1p_reconstructed_array[ii])
    H0p_error_array.append(image_array - H0p_reconstructed_array[ii])

    plt.figure()
    plt.subplot(3,3,1)
    imshow(image_array[im_slice,:,:,], [0,cmax*1.5],'True image')
    plt.subplot(3,3,2)
    imshow(H1p_reconstructed_array[ii][im_slice,:,:,], [0,cmax*1.5], 'HKEM, sigma_p='+j)
    plt.subplot(3,3,3)
    imshow(H0p_reconstructed_array[ii][im_slice,:,:,], [0,cmax*1.5], 'KEM, sigma_p='+j)
    plt.subplot(3,3,4)
    imshow(diffp_image_array[ii][im_slice,:,:,], [-cmax*0.1,cmax*0.1], 'HKEM - KEM')
    plt.subplot(3,3,5)
    imshow(H1p_error_array[ii][im_slice,:,:,], [-cmax*1.,cmax*1.], 'HKEM error')
    plt.subplot(3,3,6)
    imshow(H0p_error_array[ii][im_slice,:,:,], [-cmax*1.,cmax*1.], 'KEM error')

    ii=ii+1;
# [___CELL_SEPARATOR___]
#%% reconstruct the image 
H1d_reconstructed_image = [] 
H0d_reconstructed_image = []

#fix other parameters
recon.set_num_neighbours(5)
recon.set_sigma_m(0.5)
recon.set_sigma_p(0.5)

sigma_dm={0.05, 0.1, 0.5, 1, 3, 5, 8, 10}
ii=0
for i in sigma_dm:

    H1d_reconstructed_image.append(init_image.clone())
    H0d_reconstructed_image.append(init_image.clone())

    recon.set_sigma_dp(i)
    recon.set_sigma_dm(i)

    j="{}".format(i)
    jj=j.replace(".", "_")

#   reconstruct using side information from MR and PET (H0 is KEM H1 is HKEM)
    output_prefix = "H1_N5_D{}".format(jj)
#   set up the reconstructor
    recon.set_output_filename_prefix(output_prefix)
    recon.set_hybrid(True)
    recon.set_up(H1d_reconstructed_image[ii])
    recon.reconstruct(H1d_reconstructed_image[ii])

#   reconstruct using only side information from MR (H0 is KEM H1 is HKEM)
    output_prefix = "H0_N5_D{}".format(jj)
#   set up the reconstructor
    recon.set_output_filename_prefix(output_prefix)
    recon.set_hybrid(False)
    recon.set_up(H0d_reconstructed_image[ii])
    recon.reconstruct(H0d_reconstructed_image[ii])
    ii=ii+1;
# [___CELL_SEPARATOR___]
#%% bitmap display of images
# define lists
H1d_reconstructed_array = []
H0d_reconstructed_array = []
diffd_image_array = []
H1d_error_array = []
H0d_error_array = []
ii=0

for i in sigma_dm:

    j="{}".format(i)
    jj=j.replace(".", "_")

    H1d_reconstructed_array.append(H1d_reconstructed_image[ii].as_array())
    H0d_reconstructed_array.append(H0d_reconstructed_image[ii].as_array())

#   anatomical_image_array = anatomical_image.as_array()
    diffd_image_array.append(H1d_reconstructed_array[ii] - H0d_reconstructed_array[ii])
    H1d_error_array.append(image_array - H1d_reconstructed_array[ii])
    H0d_error_array.append(image_array - H0d_reconstructed_array[ii])

    plt.figure()
    plt.subplot(3,3,1)
    imshow(image_array[im_slice,:,:,], [0,cmax*1.5],'True image')
    plt.subplot(3,3,2)
    imshow(H1d_reconstructed_array[ii][im_slice,:,:,], [0,cmax*1.5], 'HKEM, sigma_d='+j)
    plt.subplot(3,3,3)
    imshow(H0d_reconstructed_array[ii][im_slice,:,:,], [0,cmax*1.5], 'KEM, sigma_d='+j)
    plt.subplot(3,3,4)
    imshow(diffd_image_array[ii][im_slice,:,:,], [-cmax*0.1,cmax*0.1], 'HKEM - KEM')
    plt.subplot(3,3,5)
    imshow(H1d_error_array[ii][im_slice,:,:,], [-cmax*1.,cmax*1.], 'HKEM error')
    plt.subplot(3,3,6)
    imshow(H0d_error_array[ii][im_slice,:,:,], [-cmax*1.,cmax*1.], 'KEM error')

    ii=ii+1
    