import seaborn as sns
import matplotlib.pyplot as plt
%matplotlib inline
# [___CELL_SEPARATOR___]
iris = sns.load_dataset('iris')
# [___CELL_SEPARATOR___]
iris.head()

# [___CELL_SEPARATOR___]
# Just the Grid
sns.PairGrid(iris)
# [___CELL_SEPARATOR___]
# Then you map to the grid
g = sns.PairGrid(iris)
g.map(plt.scatter)
# [___CELL_SEPARATOR___]
# Altera os tipos de plots na diagonal, parte superior e inferior.
g = sns.PairGrid(iris)
g.map_diag(plt.hist)
g.map_upper(plt.scatter)
g.map_lower(sns.kdeplot)
# [___CELL_SEPARATOR___]
sns.pairplot(iris)
# [___CELL_SEPARATOR___]
sns.pairplot(iris,hue='species',palette='rainbow')
# [___CELL_SEPARATOR___]
tips = sns.load_dataset('tips')
# [___CELL_SEPARATOR___]
tips.head()
# [___CELL_SEPARATOR___]
# Só a grade
g = sns.FacetGrid(tips, col="time", row="smoker")
# [___CELL_SEPARATOR___]
g = sns.FacetGrid(tips, col="time",  row="smoker")
g = g.map(plt.hist, "total_bill")
# [___CELL_SEPARATOR___]
g = sns.FacetGrid(tips, col="time",  row="smoker",hue='sex')
# Observe como os argumentos vêm após a chamada do plt.scatter
g = g.map(plt.scatter, "total_bill", "tip").add_legend()
# [___CELL_SEPARATOR___]
g = sns.JointGrid(x="total_bill", y="tip", data=tips)
# [___CELL_SEPARATOR___]
g = sns.JointGrid(x="total_bill", y="tip", data=tips)
g = g.plot(sns.regplot, sns.distplot)