from keras.preprocessing.image import ImageDataGenerator, array_to_img, img_to_array, load_img
import matplotlib.pyplot as plt

# Load the most beautiful picture in the world
img = load_img('./data/benfica.jpg')
print('Original')
plt.imshow(img)
plt.show()

# Create object to transform data
data_generator = ImageDataGenerator(rotation_range=15,
                                    width_shift_range=0.1,
                                    height_shift_range=0.1,
                                    shear_range=0.2,
                                    zoom_range=0.2,
                                    horizontal_flip=True,
                                    fill_mode='nearest')

# Preprocess data
X = img_to_array(img)  
X = X.reshape((1,) + X.shape)  

# Apply transformation
i = 0
print('Transfomed')
for batch in data_generator.flow(X):
    i += 1
    plt.imshow(array_to_img(batch[0]))
    plt.show()
    if i % 3 == 0:  # Generate three transformed pictures
        break  # To avoid generator to loop indefinitely