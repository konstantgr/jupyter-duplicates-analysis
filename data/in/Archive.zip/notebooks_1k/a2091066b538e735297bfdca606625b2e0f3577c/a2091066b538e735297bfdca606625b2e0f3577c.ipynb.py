import numpy as np
from functools import reduce
# [___CELL_SEPARATOR___]
def factorial(n):
    return reduce(lambda a, b: a* b, range(1, n+1))
# [___CELL_SEPARATOR___]
for n in (5, 20, 50):
    print('n =', n)
    print('-'*40)
    print('log    ', int(np.log2(n)))
    print('linear ', n)
    print('n log n', int(n*np.log2(n)))
    print('n^2    ', n**2)
    print('n^3    ', n**3)
    print('e^n    ', int(np.exp(n)))
    print('n!     ', factorial(n))
    print()
# [___CELL_SEPARATOR___]
testx = np.random.randint(0, 2*n, 1000)
# [___CELL_SEPARATOR___]
%%time

n = 10000
xs  = list(range(n))
hits = 0
for x in testx:
    if x in xs:
        hits += 1
print(hits)
# [___CELL_SEPARATOR___]
import bisect
# [___CELL_SEPARATOR___]
%%time

n = 10000
xs  = list(range(n))
xs.sort()
hits = 0
for x in testx:
    if bisect.bisect(xs, x) != n:
        hits += 1
print(hits)
# [___CELL_SEPARATOR___]
def bubblesort(xs):
    """Bubble sort."""
    
    n = len(xs)
    for i in range(n):
        print(xs)
        for j in range(i+1, n):
            if xs[i] > xs[j]:
                xs[i], xs[j] = xs[j], xs[i]
# [___CELL_SEPARATOR___]
xs = [5,1,3,4,2]
bubblesort(xs)
xs
# [___CELL_SEPARATOR___]
def selectionsort(xs):
    """Selection sort."""
    
    n = len(xs)
    for i in range(n):
        best = xs[i]
        idx = i
        print(xs)
        for j in range(i+1, n):
            if xs[j] < best:
                best = xs[j]
                idx = j
        xs[i], xs[idx] = xs[idx], xs[i]
# [___CELL_SEPARATOR___]
xs = [5,1,3,4,2]
selectionsort(xs)
xs
# [___CELL_SEPARATOR___]
def quicksort(xs):
    """Quicksort."""
    
    if len(xs) < 2:
        return xs
    else:
        pivot = xs[0]
        left = [x for x in xs[1:] if x <= pivot]
        right = [x for x in xs[1:] if x > pivot]
        print(pivot, left, right)
        return quicksort(left) + [pivot] + quicksort(right)
# [___CELL_SEPARATOR___]
xs = [5,1,3,4,2]
quicksort(xs)
# [___CELL_SEPARATOR___]
import sys
# [___CELL_SEPARATOR___]
xs = np.random.randint(0, 10, (100,100))
# [___CELL_SEPARATOR___]
sys.getsizeof(xs)
# [___CELL_SEPARATOR___]
xs.nbytes
# [___CELL_SEPARATOR___]
from time import sleep
# [___CELL_SEPARATOR___]
%time sleep(0.1)
# [___CELL_SEPARATOR___]
%%time

sleep(0.1)
# [___CELL_SEPARATOR___]
%timeit sleep(0.1)
# [___CELL_SEPARATOR___]
%timeit -r 3 -n 10 sleep(0.1)
# [___CELL_SEPARATOR___]
from timeit import timeit
# [___CELL_SEPARATOR___]
t = timeit('from time import sleep; sleep(0.1)', number=1)
t
# [___CELL_SEPARATOR___]
t = timeit(lambda: sleep(0.1), number=1)
t