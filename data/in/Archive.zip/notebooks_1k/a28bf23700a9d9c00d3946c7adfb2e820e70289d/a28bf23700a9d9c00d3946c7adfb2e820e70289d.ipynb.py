%reload_ext autoreload
%autoreload 2
%matplotlib inline
import matplotlib.pyplot as plt

import scipy.stats as st
import numpy as np
import scipy as sp
import sklearn
import sklearn.isotonic
import sklearn.pipeline
import sklearn.preprocessing
from sklearn.metrics import auc, roc_curve
from sklearn.linear_model import LogisticRegression
from sklearn.cross_validation import StratifiedKFold
from sklearn.metrics import mean_squared_error, r2_score

from elevation import util

def compare_x(x, y):
    f, (ax1, ax2) = plt.subplots(1, 2, sharex=True)
    ax1.scatter(x[0], y[0])
    ax2.scatter(x[1], y[1])

def compare_y(x1, x2, title1="x1", title2="x2"):
    f, (ax1, ax2) = plt.subplots(1, 2, sharey=True)
    f.set_size_inches(20, 10)
    ax1.plot(np.arange(x1.shape[0]), x1)
    ax1.set_title(title1)
    ax2.plot(np.arange(x2.shape[0]), x2)
    ax2.set_title(title2)

def compare_hist(x1, x2, num_bins=100, label1="x1", label2="x2", max_mean=False, min_mean=False):
    # plt.figure(num=None, figsize=(8, 6), dpi=80, facecolor='w', edgecolor='k')
    plt.figure(figsize=(16, 12))
    minf = np.mean if min_mean else np.min
    maxf = np.mean if max_mean else np.max
    min_x = minf(map(minf, (x1, x2)))
    max_x = maxf(map(maxf, (x1, x2)))
    bins = np.linspace(min_x, max_x, num_bins)
    plt.hist(x1, bins, alpha=0.5, label=label1)
    plt.hist(x2, bins, alpha=0.5, label=label2)
    plt.legend(loc='upper right')

def compare_box(pairs, title="Compare", margins=None):
    f, axes = plt.subplots(len(pairs), sharex=True)
    if len(pairs) == 1: axes = [axes]
    f.set_size_inches(6, 6*len(pairs))
    for i in range(len(pairs)):
        ax = axes[i]
        ax.boxplot(pairs[i])
        minf = np.min
        maxf = np.max
        if margins is not None:
            min_x = minf(map(minf, pairs[i]))
            max_x = maxf(map(maxf, pairs[i]))
            ax.set_ylim([min_x - margins[i], max_x + margins[i]])

def compare_scatter(pairs, title="Compare", margins=None):
    f, axes = plt.subplots(len(pairs), sharex=True)
    if len(pairs) == 1: axes = [axes]
    f.set_size_inches(6, 6*len(pairs))
    for i in range(len(pairs)):
        ax = axes[i]
        ax.scatter(*pairs[i], alpha=0.5)
        minf = np.min
        maxf = np.max
        if margins is not None:
            min_x = minf(map(minf, pairs[i]))
            max_x = maxf(map(maxf, pairs[i]))
            ax.set_ylim([min_x - margins[i], max_x + margins[i]])

def fit_lasso(ind_keep, X, y, y_transf):
    seed = 12345
    normX = True

    # what been using up until 9/12/2016
    # clf = sklearn.linear_model.LassoCV(cv=10, fit_intercept=True, normalize=True)

    # from IPython.core.debugger import Tracer; Tracer()()
    # now using this:
    kfold = StratifiedKFold(y[ind_keep].flatten()==0, 10, random_state=seed)
    clf = sklearn.linear_model.LassoCV(cv=kfold, fit_intercept=True, normalize=(~normX),
                                       n_jobs=10, random_state=seed)
    if normX:
        clf = sklearn.pipeline.Pipeline([['scaling', sklearn.preprocessing.StandardScaler()], ['lasso', clf]])

    # y_transf2 = st.boxcox(y[ind_keep] - y[ind_keep].min() + 0.001)[0]
    # assert np.allclose(y_transf, y_transf2)
    # y_transf = st.boxcox(y[ind_keep] + 0.00000001)[0]
    # y_transf = y[ind_keep]
    clf.fit(X[ind_keep], y_transf)
    return clf

def fit_lr(X, y):
    clf = LogisticRegression(fit_intercept=True, solver='lbfgs')
    clf.fit(X, y)
    return clf
# [___CELL_SEPARATOR___]
X1 = np.array([1,2,3,5,7,4,9]).reshape(7,1)
y = np.array([1,1,1,0,1,0,0])

# for X in [X1, X2]:
sign = -1
for i in range(100):
    rs = np.random.RandomState(i)
    mean = np.random.randint(-100, 100)
    scale = np.random.randint(-10, 10)
    # X = X1
    X = X1*scale + mean
    # X = np.random.permutation(X1)
    clf = LogisticRegression(fit_intercept=True, solver='lbfgs', random_state=rs)
    clf.fit(X, y)
    new_sign = sp.stats.spearmanr(clf.predict_proba(X).T[1], X.T[0])[0]
    if sign != new_sign:
        print sign, new_sign, i
        break
# [___CELL_SEPARATOR___]
ind_keep1 = util.from_temp("lrs_ind_keep")

# guideseq predictions
X1 = util.from_temp("lrs_X")

# cd33 predictions
Xtest1 = util.from_temp("lrs_Xtest")

# guideseq_data['GUIDE-SEQ Reads']
y_raw1 = util.from_temp("lrs_y_raw")
y1 = util.from_temp("lrs_y")

X2 = util.from_temp("lrs_X_new")
Xtest2 = util.from_temp("lrs_Xtest_new")
y_raw2 = util.from_temp("lrs_y_raw_new")
y2 = util.from_temp("lrs_y_new")
ind_keep2 = util.from_temp("lrs_ind_keep_new")

# same for both
cd33_data = util.from_temp("cd33")[0]
Y_bin = cd33_data['Day21-ETP-binarized'].values
Y = cd33_data['Day21-ETP'].values

# tests
print Xtest1.shape, Xtest2.shape
print np.allclose(Xtest1, Xtest2)
# [___CELL_SEPARATOR___]
print np.sum(y1 == 0), y1.shape[0]
print np.sum(y2 == 0), y2.shape[0]
print np.sum(y_raw1[ind_keep1] == 0.0), np.sum(ind_keep1), float(np.sum(y_raw1[ind_keep1] == 0.0))/np.sum(ind_keep1)
print np.sum(y_raw2[ind_keep2] == 0.0), np.sum(ind_keep2), float(np.sum(y_raw2[ind_keep2] == 0.0))/np.sum(ind_keep2)
print y_raw1[ind_keep1].min(), y_raw1[ind_keep1].max()
print y_raw2[ind_keep2].min(), y_raw2[ind_keep2].max()
# [___CELL_SEPARATOR___]
compare_y(y1, y2, "Transformed GUIDE-SEQ Reads (Original)", "Transformed GUIDE-SEQ Reads (New)")
# [___CELL_SEPARATOR___]
compare_hist(y1, y2, 100, "Transformed GUIDE-SEQ Reads (Original)", "Transformed GUIDE-SEQ Reads (New)")
# [___CELL_SEPARATOR___]
compare_hist(y_raw1, y_raw2, 100, "GUIDE-SEQ Reads (Original)", "GUIDE-SEQ Reads (New)", max_mean=True)
# [___CELL_SEPARATOR___]
compare_box(y1, y2)
# [___CELL_SEPARATOR___]
compare_box(y_raw1, y_raw2, margin=0.1)
# [___CELL_SEPARATOR___]
compare_y(Xtest1, Xtest2)
# [___CELL_SEPARATOR___]
lasso1 = fit_lasso(ind_keep1, X1, y_raw1, y1)
lassopred1 = lasso1.predict(Xtest1)
lr_model1 = fit_lr(lassopred1[:, None], Y_bin)
predprob1 = lr_model1.predict_proba(lassopred1[:, None])[:, 1]
print sp.stats.spearmanr(predprob1, lassopred1)[0]
# [___CELL_SEPARATOR___]
lasso2 = fit_lasso(ind_keep2, X2, y_raw2, y2)
lassopred2 = lasso2.predict(Xtest2)
lr_model2 = fit_lr(lassopred2[:, None], Y_bin)
predprob2 = lr_model2.predict_proba(lassopred2[:, None])[:, 1]
print sp.stats.spearmanr(predprob2, lassopred2)[0]
# [___CELL_SEPARATOR___]
print "train1", r2_score(lasso1.predict(X1[ind_keep1]), y1)
print "test1", r2_score(lasso1.predict(Xtest1), Y)

print "train2", r2_score(lasso2.predict(X2[ind_keep2]), y2)
print "test2", r2_score(lasso2.predict(Xtest2), Y)
# [___CELL_SEPARATOR___]
print "train1", r2_score(lasso1.predict(X1[ind_keep1]), y_raw1[ind_keep1])
print "test1", r2_score(lasso1.predict(Xtest1), Y)

print "train2", r2_score(lasso2.predict(X2[ind_keep2]), y_raw2[ind_keep2])
print "test2", r2_score(lasso2.predict(Xtest2), Y)
# [___CELL_SEPARATOR___]
# w/o boxcot
print "train1", r2_score(lasso1.predict(X1[ind_keep1]), y_raw1[ind_keep1])
print "test1", r2_score(lasso1.predict(Xtest1), Y)

print "train2", r2_score(lasso2.predict(X2[ind_keep2]), y_raw2[ind_keep2])
print "test2", r2_score(lasso2.predict(Xtest2), Y)
# [___CELL_SEPARATOR___]
np.sum(predprob1 > 0.5), np.sum(predprob1 < 0.5)
# [___CELL_SEPARATOR___]
np.sum(predprob2 > 0.5), np.sum(predprob2 < 0.5)
# [___CELL_SEPARATOR___]
plt.scatter(predprob1[(predprob1 < 0.2) | (predprob1 > 0.8)], Y_bin[(predprob1 < 0.2) | (predprob1 > 0.8)], alpha=0.3)
# [___CELL_SEPARATOR___]
plt.scatter(predprob2[(predprob2 < 0.4) | (predprob2 > 0.6)], Y_bin[(predprob2 < 0.4) | (predprob2 > 0.6)], alpha=0.3)
# [___CELL_SEPARATOR___]
plt.scatter(predprob1, predprob2, alpha=0.3)
# [___CELL_SEPARATOR___]
compare_y(lasso1.predict(Xtest1), lasso2.predict(Xtest2), "original lasso model", "new lasso model")
# [___CELL_SEPARATOR___]
print lasso1.named_steps['lasso'].intercept_
print lasso2.named_steps['lasso'].intercept_
print lasso1.named_steps['lasso'].coef_[:6]
print lasso2.named_steps['lasso'].coef_[:6]
# [___CELL_SEPARATOR___]
compare_scatter([[lasso1.predict(Xtest1), lasso2.predict(Xtest2)]])
# [___CELL_SEPARATOR___]
print min(lasso1.predict(Xtest2)), max(lasso1.predict(Xtest2))
# [___CELL_SEPARATOR___]
compare_y(X1, X2)
# [___CELL_SEPARATOR___]
assert X1.shape[1] == X2.shape[1]
print X1[ind_keep1].shape, X2[ind_keep2].shape
# [___CELL_SEPARATOR___]
X_ind_keep1 = X1[ind_keep1]
X_ind_keep2 = X2[ind_keep2]
# [___CELL_SEPARATOR___]
compare_y(X_ind_keep1, X_ind_keep2, "X[ind_keep] original", "X[ind_keep] new")
# [___CELL_SEPARATOR___]
compare_range = range(X_ind_keep1.shape[1])
margins = [0.1 for i in compare_range]
compare_box([
        (X_ind_keep1[:, j], X_ind_keep2[:, j]) for j in compare_range
], margins=margins)

# [___CELL_SEPARATOR___]
scaler = sklearn.preprocessing.StandardScaler()

print scaler.fit_transform(X_ind_keep1[:, 0])[:100]
print scaler.fit_transform(X_ind_keep2[:, 0])[:100]
# [___CELL_SEPARATOR___]
compare_range = range(X_ind_keep1.shape[1])
margins = [0.1 for i in compare_range]
pairs1 = [(X_ind_keep1[:, j], y1) for j in compare_range]
pairs2 = [(X_ind_keep2[:, j], y2) for j in compare_range]

compare_scatter(pairs, margins=margins)