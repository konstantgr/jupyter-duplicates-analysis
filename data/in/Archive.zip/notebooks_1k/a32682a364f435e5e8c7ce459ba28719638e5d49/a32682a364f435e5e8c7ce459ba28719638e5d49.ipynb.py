from naginterfaces.library import opt
from naginterfaces.library import rand
import numpy as np
from naginterfaces.base import utils
import warnings
# [___CELL_SEPARATOR___]
import io
import base64
from IPython.display import HTML
video = io.open('animation.mp4', 'r+b').read()
encoded = base64.b64encode(video)
HTML(data='''<video alt="test" controls>
                <source src="data:video/mp4;base64,{0}" type="video/mp4" />
             </video>'''.format(encoded.decode('ascii')))
# [___CELL_SEPARATOR___]
def problem_char(pname):
    n = None
    xstart = None
    target = None
    # From a problem name pname, return:
    # number of variables, starting point, optimal value of the objective, lower bound, upper bound
    if pname == 'HART6':
        n = 6
        xstart = [0.2]*n
        target = -3.32288689
        xl = [0.0]*n
        xu = [1.0]*n
        
    elif pname == 'ENGVAL2':
        n = 3
        xstart = [1.0, 2.0, 0.0]
        target = 0.0
        xl = [-1.0e20]*n
        xu = [1.0e20]*n
    
    elif pname == 'HATFLDC':
        n = 25
        xstart = [0.9]*n
        target = 0.0
        xl = [0.0]*n
        xu = [10.0]*n
        
    else:
        print('problem name not known')
    return n, xstart, target, xl, xu
# [___CELL_SEPARATOR___]
# initialize the NAG random number generator
seed = [42]
genid = 1
statecomm = rand.init_repeat(genid, seed)
# [___CELL_SEPARATOR___]
class usr_data:
    def __init__(self, fun, statecomm=None, target=0.0, tol = 1.0e-08):
        self.fun = fun
        self.nf = 0
        self.noiselev = 0.0
        self.statecomm = statecomm
        self.pdata = None
        self.tol = tol
        self.nf = 0
        self.ok = False
        self.target = target
        self.sol = 1.0e20
        
        
class hart6_data:
    def __init__(self):
        self.c = [1.0, 1.2, 3.0, 3.2]
        self.a = [[10.0, 0.05, 3.0, 17.0],
                  [0.05, 10.0, 3.5, 8.0],
                  [17.0, 17.0, 1.7, 0.05],
                  [3.5, 0.1, 10.0, 10.0],
                  [1.7, 8.0, 17.0, 0.1],
                  [8.0, 14.0, 8.0, 14.0]]
        self.p = [[0.1312, 0.2329, 0.2348, 0.4047],
                  [0.1696, 0.4135, 0.1451, 0.8828],
                  [0.5569, 0.8307, 0.3522, 0.8732],
                  [0.0124, 0.3736, 0.2883, 0.5743],
                  [0.8283, 0.1004, 0.3047, 0.1091],
                  [0.5886, 0.9991, 0.665, 0.0381]]
# [___CELL_SEPARATOR___]
def objfun(x, inform, data=None):
    inform = 0
    n = len(x)
    obj = 0.0
    
    # Compute the objective
    if data.fun == 'HART6':
        c = data.pdata.c
        a = data.pdata.a
        p = data.pdata.p
        for i in range(len(c)):
            aux = 0.0
            for j in range(len(a)):
                aux -= a[j][i] * (x[j] - p[j][i])**2
            obj -= c[i]*np.exp(aux)
            
    elif data.fun == 'ENGVAL2':
        obj = (x[0]**2 + x[1]**2 + x[2]**2 - 1)**2 + \
        (x[0]**2 + x[1]**2 + (x[2]-2)**2 - 1)**2 + \
        (x[0] + x[1] + x[2] - 1)**2 +\
        (x[0] + x[1] - x[2] + 1)**2 +\
        (3*x[1]**2 + x[0]**3 +\
        (5*x[2] - x[0] + 1)**2 - 36)**2
        
    elif data.fun == 'HATFLDC':
        obj = (x[0]-1)**2
        for i in range(1, n-1):
            obj += (x[i+1] - x[i]**2)**2
        obj += (x[n-1]-1)**2

    else:
        print('Unknown objective function')
        inform = -1
        
    # Add noise if required
    if data.noiselev > 0.0:
        noise = rand.dist_uniform(1,-data.noiselev, data.noiselev, data.statecomm)
        obj += noise[0]
        
    # count the number of evaluations if not solved yet
    #print(abs(obj-target), obj, target)
    if not data.ok and abs(obj-data.target) < data.tol:
        data.ok = True
        data.sol = obj
        data.nf += 1
        inform = -2
    elif not data.ok:
        data.nf +=1
        
    return (obj, inform) 

# objective for the derivative based solver
def objfun_bob(x, data):
    inform = 0
    obj, inform = objfun(x, inform, data)
    return obj
# [___CELL_SEPARATOR___]
def solve_fd(pname, noiselevel=0.0, statecomm=None , tol=1.0e-08):
    
    n, xstart, target, xl, xu = problem_char(pname)
    data = usr_data(pname, target=target, statecomm=statecomm, tol=tol)
    if pname == 'HART6':
        h6dat = hart6_data()
        data.pdata = h6dat
    data.fun = pname
    data.noiselev = noiselevel
    print(data.fun)
    try:
        sln = opt.bounds_quasi_func_easy(ibound, objfun_bob, xl, xu, xstart, data=data)
    except utils.NagValueError as e:
        if e.errno == 2 and not data.ok:
            print('Maximum number of evaluations exceeded:', 400*n)
        elif e.errno != 2:
            print('error number not expected: ', e.errno)
    if data.ok:
        print('Final objective value', data.sol)
        print('objective evaluations', data.nf, '\n')
    else:
        print('solution not within the tolerance', data.tol, 'of the solution\n')
# [___CELL_SEPARATOR___]
warnings.simplefilter('error', utils.NagCallbackTerminateWarning)

def solve_dfo(pname, noiselevel=0.0, statecomm=None, options=None, tol=1.0e-08):
    iom = utils.FileObjManager(locus_in_output=False)
    # Initialize the user data with the problem name, the noise level and the convergence tolerance
    n, xstart, target, xl, xu = problem_char(pname)
    data = usr_data(pname, statecomm=statecomm, target=target, tol=tol)
    if pname == 'HART6':
        h6dat = hart6_data()
        data.pdata = h6dat
    data.fun = pname
    data.noiselev = noiselevel
    # Initialize the NAG handle data structures
    handle = opt.handle_init(n)
    # Define a nonlinear objective function in the model
    opt.handle_set_nlnobj(handle, idxfd=list(range(1, n+1)))
    # Define the bounds on the variables 
    opt.handle_set_simplebounds(handle, xl, xu)
    # Set the options
    for optstr in options:
        opt.handle_opt_set(handle, optstr)
    # Call the solver
    try:
        x, rinfo, stats = opt.handle_solve_dfno(handle, objfun, xstart, data=data, io_manager=iom)
    except utils.NagCallbackTerminateWarning as e:
        pass
    # print results
    print(pname)
    print('Final objective value', data.sol)
    print('Objective evaluations', data.nf)
    print()
    opt.handle_free(handle)
# [___CELL_SEPARATOR___]
print('No noise, derivative based solver')
print('---------------------------------')
ibound = 0

solve_fd('HART6')
solve_fd('ENGVAL2')
solve_fd('HATFLDC')
# [___CELL_SEPARATOR___]
warnings.simplefilter('ignore', utils.NagAlgorithmicMajorWarning)
warnings.simplefilter('ignore', utils.NagAlgorithmicWarning)
options = ['Print file = -1',
           'DFO Max Objective Calls = 5000',
           'DFO Maximum Slow Steps = 1000']

print('No noise, derivative free solver')
print('--------------------------------')

solve_dfo('HART6', options=options)
solve_dfo('ENGVAL2', options=options)
solve_dfo('HATFLDC', options=options)
# [___CELL_SEPARATOR___]
noiselev = 1.0e-08
tol = 1.0e-06 # relax the tolerance to be lower than the noise

solve_fd('HART6', noiselevel=noiselev, statecomm=statecomm, tol=tol)
solve_fd('ENGVAL2', noiselevel=noiselev, statecomm=statecomm, tol=tol)
solve_fd('HATFLDC', noiselevel=noiselev, statecomm=statecomm, tol=tol)
    
# [___CELL_SEPARATOR___]
options = ['Print File = -1',
           'DFO Maximum Slow Steps = 1000',
           'DFO Max Objective Calls = 1500']

solve_dfo('HART6', noiselevel=noiselev, statecomm=statecomm, options=options, tol=tol)
solve_dfo('ENGVAL2', noiselevel=noiselev, statecomm=statecomm, options=options, tol=tol)
solve_dfo('HATFLDC', noiselevel=noiselev, statecomm=statecomm, options=options, tol=tol)
# [___CELL_SEPARATOR___]
help(opt.handle_solve_dfno)
# [___CELL_SEPARATOR___]
help(opt.bounds_quasi_func_easy)