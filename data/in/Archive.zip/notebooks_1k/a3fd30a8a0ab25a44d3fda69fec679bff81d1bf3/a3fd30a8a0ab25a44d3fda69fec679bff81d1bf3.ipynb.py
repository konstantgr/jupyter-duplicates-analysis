view_mode = 'no_render'
# [___CELL_SEPARATOR___]
from nilearn import plotting
%matplotlib inline
import matplotlib.pyplot as plt
import nibabel as nb
import numpy as np
from IPython.display import Image
# [___CELL_SEPARATOR___]
t1 = nb.load('data/diffusion/stanford_hardi/t1.nii.gz')
pve_csf = nb.load('data/diffusion/stanford_hardi/pve_csf.nii.gz')
pve_gm = nb.load('data/diffusion/stanford_hardi/pve_gm.nii.gz')
pve_wm = nb.load('data/diffusion/stanford_hardi/pve_wm.nii.gz')
img = nb.load('data/diffusion/stanford_hardi/HARDI150.nii.gz')
labels_img = nb.load('data/diffusion/stanford_hardi/HARDI150_labels.nii.gz')
# [___CELL_SEPARATOR___]
axial_middle = img.shape[2] // 2
# [___CELL_SEPARATOR___]
plt.figure(figsize=(12, 4))
plt.subplot(1, 4, 1).set_axis_off()
plt.imshow(t1.get_data()[:, :, axial_middle].T, cmap='magma', origin='lower')
plt.title('T1 image')

plt.subplot(1, 4, 2).set_axis_off()
plt.imshow(img.get_data()[:, :, axial_middle, 0].T, cmap='magma', origin='lower')
plt.title('Without diffusion weights')

plt.subplot(1, 4, 3).set_axis_off()
plt.imshow(img.get_data()[:, :, axial_middle, 30].T, cmap='magma', origin='lower')
plt.title('Diffusion weights direc. 20')

plt.subplot(1, 4, 4).set_axis_off()
plt.imshow(img.get_data()[:, :, axial_middle, 110].T, cmap='magma', origin='lower')
plt.title('Diffusion weights direc. 100')
# [___CELL_SEPARATOR___]
plt.figure(figsize=(12, 4))
plt.subplot(1, 4, 1).set_axis_off()
plt.imshow(labels_img.get_data()[:, :, axial_middle].T, cmap='nipy_spectral', origin='lower')
plt.title('Volume labels')

plt.subplot(1, 4, 2).set_axis_off()
plt.imshow(pve_csf.get_data()[:, :, axial_middle].T, cmap='magma', origin='lower')
plt.title('CSF segmentation')

plt.subplot(1, 4, 3).set_axis_off()
plt.imshow(pve_gm.get_data()[:, :, axial_middle].T, cmap='magma', origin='lower')
plt.title('GM segmentation')

plt.subplot(1, 4, 4).set_axis_off()
plt.imshow(pve_wm.get_data()[:, :, axial_middle].T, cmap='magma', origin='lower')
plt.title('WM segmentation')
# [___CELL_SEPARATOR___]
bvals = 'data/diffusion/stanford_hardi/HARDI150.bval'
bvecs = 'data/diffusion/stanford_hardi/HARDI150.bvec'

from dipy.core.gradients import gradient_table
gtab = gradient_table(bvals, bvecs)
# [___CELL_SEPARATOR___]
print(gtab.info)
# [___CELL_SEPARATOR___]
print(gtab.bvals)
# [___CELL_SEPARATOR___]
print(gtab.bvecs[-10:, :])
# [___CELL_SEPARATOR___]
data = img.get_data()
print('data shape before masking: (%d, %d, %d, %d)' % data.shape)
# [___CELL_SEPARATOR___]
from dipy.segment.mask import median_otsu
maskdata, mask = median_otsu(data, 3, 1, True,
                             vol_idx=range(10, 50), dilate=2)
print('data shape after masking (%d, %d, %d, %d)' % maskdata.shape)
# [___CELL_SEPARATOR___]
import dipy.reconst.dti as dti
tenmodel = dti.TensorModel(gtab)
# [___CELL_SEPARATOR___]
tenfit = tenmodel.fit(maskdata)
# [___CELL_SEPARATOR___]
from dipy.reconst.dti import fractional_anisotropy, mean_diffusivity

FA = fractional_anisotropy(tenfit.evals)
MD = mean_diffusivity(tenfit.evals)
# [___CELL_SEPARATOR___]
plotting.plot_anat(nb.Nifti1Image(FA, img.affine, img.header), cut_coords=[0,-20,0],
                   dim=-1, draw_cross=False, cmap='magma', title='FA')
plotting.plot_anat(nb.Nifti1Image(MD, img.affine, img.header), cut_coords=[0,-20,0],
                   dim=-1, draw_cross=False, cmap='magma', title='MD', vmax=0.001)
# [___CELL_SEPARATOR___]
from dipy.reconst.dti import color_fa
RGB = color_fa(FA, tenfit.evecs)
# [___CELL_SEPARATOR___]
# Let's visualize this
plt.figure(figsize=(6, 6))
plt.imshow(RGB[:, :, 31,:])
plt.axis('off');
# [___CELL_SEPARATOR___]
from dipy.data import get_sphere
sphere = get_sphere('symmetric724')
# [___CELL_SEPARATOR___]
evals = tenfit.evals[13:43, 44:74, 28:29]
evecs = tenfit.evecs[13:43, 44:74, 28:29]
# [___CELL_SEPARATOR___]
cfa = RGB[13:43, 44:74, 28:29]
cfa /= cfa.max() * 0.5
# [___CELL_SEPARATOR___]
from dipy.viz import window, actor
ren = window.Renderer()
ren.add(actor.tensor_slicer(evals, evecs, scalar_colors=cfa, sphere=sphere, scale=0.3))
# [___CELL_SEPARATOR___]
if view_mode == 'create_plot':
    window.record(ren, n_frames=1, size=(600, 600),
                  out_path='data/diffusion/tensor_ellipsoids.png')
elif view_mode == 'interactive':
    window.show(ren)
# [___CELL_SEPARATOR___]
Image(filename='data/diffusion/tensor_ellipsoids.png')
# [___CELL_SEPARATOR___]
tensor_odfs = tenmodel.fit(data[20:50, 55:85, 38:39]).odf(sphere)
odf_actor = actor.odf_slicer(tensor_odfs, sphere=sphere, scale=0.5, colormap=None)
ren.add(odf_actor)
# [___CELL_SEPARATOR___]
if view_mode == 'create_plot':
    window.record(ren, n_frames=1, size=(600, 600),
                  out_path='data/diffusion/tensor_odfs.png')
elif view_mode == 'interactive':
    window.show(ren)
# [___CELL_SEPARATOR___]
Image(filename='data/diffusion/tensor_odfs.png')
# [___CELL_SEPARATOR___]
from dipy.reconst.csdeconv import auto_response
response, ratio = auto_response(gtab, data, roi_radius=10, fa_thr=0.7)
# [___CELL_SEPARATOR___]
print(response)
# [___CELL_SEPARATOR___]
from dipy.data import get_sphere
sphere = get_sphere('symmetric362')
# [___CELL_SEPARATOR___]
import dipy.reconst.sfm as sfm
sf_model = sfm.SparseFascicleModel(gtab, sphere=sphere,
                                   l1_ratio=0.5, alpha=0.001,
                                   response=response[0])
# [___CELL_SEPARATOR___]
data_small = data[20:50, 55:85, 38:39]
# [___CELL_SEPARATOR___]
sf_fit = sf_model.fit(data_small)
sf_odf = sf_fit.odf(sphere)
# [___CELL_SEPARATOR___]
from dipy.viz import window, actor
ren = window.Renderer()
fodf_spheres = actor.odf_slicer(sf_odf, sphere=sphere, scale=0.8, colormap='plasma')
ren.add(fodf_spheres)
# [___CELL_SEPARATOR___]
if view_mode == 'create_plot':
    window.record(ren, size=(600, 600),
                  out_path='data/diffusion/sf_odfs.png')
elif view_mode == 'interactive':
    window.show(ren)
# [___CELL_SEPARATOR___]
Image(filename='data/diffusion/sf_odfs.png')
# [___CELL_SEPARATOR___]
import dipy.direction.peaks as dpp
sf_peaks = dpp.peaks_from_model(sf_model,
                                data_small,
                                sphere,
                                relative_peak_threshold=.5,
                                min_separation_angle=25,
                                return_sh=False)
# [___CELL_SEPARATOR___]
# Let's render these peaks as well
window.clear(ren)
fodf_peaks = actor.peak_slicer(sf_peaks.peak_dirs, sf_peaks.peak_values)
ren.add(fodf_peaks)
# [___CELL_SEPARATOR___]
if view_mode == 'create_plot':
    window.record(ren, size=(600, 600),
                  out_path='data/diffusion/sf_peaks.png')
elif view_mode == 'interactive':
    window.show(ren)
# [___CELL_SEPARATOR___]
Image(filename='data/diffusion/sf_peaks.png')
# [___CELL_SEPARATOR___]
fodf_spheres.GetProperty().SetOpacity(0.4)
ren.add(fodf_spheres)
# [___CELL_SEPARATOR___]
if view_mode == 'create_plot':
    window.record(ren, size=(600, 600),
                  out_path='data/diffusion/sf_both.png')
elif view_mode == 'interactive':
    window.show(ren)
# [___CELL_SEPARATOR___]
Image(filename='data/diffusion/sf_both.png')
# [___CELL_SEPARATOR___]
from dipy.reconst.csdeconv import ConstrainedSphericalDeconvModel, auto_response

response, ratio = auto_response(gtab, data, roi_radius=10, fa_thr=0.7)

csd_model = ConstrainedSphericalDeconvModel(gtab, response)
# [___CELL_SEPARATOR___]
from dipy.data import get_sphere
sphere = get_sphere('symmetric724')
# [___CELL_SEPARATOR___]
from dipy.segment.mask import median_otsu
maskdata, mask = median_otsu(data, 3, 1, False, vol_idx=range(10, 50), dilate=2)
# [___CELL_SEPARATOR___]
%%time
from dipy.direction import peaks_from_model
csd_peaks = peaks_from_model(model=csd_model,
                             data=data,
                             sphere=sphere,
                             mask=mask,
                             relative_peak_threshold=.5,
                             min_separation_angle=25,
                             parallel=True)
# [___CELL_SEPARATOR___]
from dipy.reconst.dti import TensorModel
tensor_model = TensorModel(gtab, fit_method='WLS')
tensor_fit = tensor_model.fit(data, mask)
fa = tensor_fit.fa
# [___CELL_SEPARATOR___]
from dipy.tracking.local import ThresholdTissueClassifier
tissue_classifier = ThresholdTissueClassifier(fa, 0.25)
# [___CELL_SEPARATOR___]
from dipy.tracking.utils import random_seeds_from_mask
seeds = random_seeds_from_mask(fa > 0.5, seeds_count=1)
# [___CELL_SEPARATOR___]
from dipy.viz import window, actor
ren = window.Renderer()
ren.add(actor.peak_slicer(csd_peaks.peak_dirs,
                          csd_peaks.peak_values,
                          colors=None))
# [___CELL_SEPARATOR___]
if view_mode == 'create_plot':
    window.record(ren, size=(600, 600),
                  out_path='data/diffusion/csd_direction_field.png')
elif view_mode == 'interactive':
    window.show(ren)
# [___CELL_SEPARATOR___]
Image(filename='data/diffusion/csd_direction_field.png')
# [___CELL_SEPARATOR___]
from dipy.tracking.local import LocalTracking
streamline_generator = LocalTracking(csd_peaks, tissue_classifier,
                                     seeds, affine=np.eye(4),
                                     step_size=0.5)
# [___CELL_SEPARATOR___]
from dipy.tracking.streamline import Streamlines
streamlines = Streamlines(streamline_generator)
# [___CELL_SEPARATOR___]
print(len(streamlines))
# [___CELL_SEPARATOR___]
from dipy.viz import window, actor
ren = window.Renderer()
ren.add(actor.line(streamlines))
# [___CELL_SEPARATOR___]
if view_mode == 'create_plot':
    window.record(ren, size=(600, 600),
                  out_path='data/diffusion/det_streamlines.png')
elif view_mode == 'interactive':
    window.show(ren)
# [___CELL_SEPARATOR___]
Image(filename='data/diffusion/det_streamlines.png')
# [___CELL_SEPARATOR___]
plotting.plot_anat(labels_img, cut_coords=[0,-20,0], dim=-1,
                   draw_cross=False, cmap='nipy_spectral', title='labels')
# [___CELL_SEPARATOR___]
cc_mask = np.array(labels_img.get_data()==2, dtype='int')
plotting.plot_anat(nb.Nifti1Image(cc_mask, img.affine, img.header), cut_coords=[0,-20,0],
                   dim=-1, draw_cross=False, cmap='magma', title='Corpus callosum')
# [___CELL_SEPARATOR___]
from dipy.tracking import utils
seeds = utils.seeds_from_mask(cc_mask, density=2, affine=img.affine)
# [___CELL_SEPARATOR___]
from dipy.tracking.local import LocalTracking
streamline_generator = LocalTracking(csd_peaks,
                                     tissue_classifier,
                                     seeds,
                                     affine=img.affine,
                                     step_size=0.1)
# [___CELL_SEPARATOR___]
from dipy.tracking.streamline import Streamlines
streamlines = Streamlines(streamline_generator)
# [___CELL_SEPARATOR___]
from dipy.viz import window, actor
ren = window.Renderer()
ren.add(actor.line(streamlines))
# [___CELL_SEPARATOR___]
if view_mode == 'create_plot':
    window.record(ren, size=(600, 600),
                  out_path='data/diffusion/deterministic.png')
elif view_mode == 'interactive':
    window.show(ren)
# [___CELL_SEPARATOR___]
Image(filename='data/diffusion/deterministic.png')
# [___CELL_SEPARATOR___]
# White matter mask
labels = labels_img.get_data().astype('int')
white_matter = (labels == 1) | (labels == 2)
# [___CELL_SEPARATOR___]
# Reload the data
data = img.get_data()
# [___CELL_SEPARATOR___]
from dipy.reconst import shm
csamodel = shm.CsaOdfModel(gtab, 6)
# [___CELL_SEPARATOR___]
%%time
from dipy.reconst import peaks
csapeaks = peaks.peaks_from_model(model=csamodel,
                                  data=data,
                                  sphere=peaks.default_sphere,
                                  relative_peak_threshold=.8,
                                  min_separation_angle=45,
                                  mask=white_matter)
# [___CELL_SEPARATOR___]
from dipy.tracking import utils
from dipy.tracking.eudx import EuDX
seeds = utils.seeds_from_mask(white_matter, density=2)
streamline_generator = EuDX(csapeaks.peak_values, csapeaks.peak_indices,
                            odf_vertices=peaks.default_sphere.vertices,
                            a_low=.05, step_sz=.5, seeds=seeds)
affine = streamline_generator.affine
# [___CELL_SEPARATOR___]
%%time
from dipy.tracking.streamline import Streamlines
streamlines = Streamlines(streamline_generator, buffer_size=512)
# [___CELL_SEPARATOR___]
%%time
from dipy.tracking import utils
cc_slice = labels == 2
cc_streamlines = utils.target(streamlines, cc_slice, affine=affine)
cc_streamlines = Streamlines(cc_streamlines)
# [___CELL_SEPARATOR___]
%%time
other_streamlines = utils.target(streamlines, cc_slice, affine=affine,
                                 include=False)
other_streamlines = Streamlines(other_streamlines)
assert len(other_streamlines) + len(cc_streamlines) == len(streamlines)
# [___CELL_SEPARATOR___]
from dipy.viz import window, actor
from dipy.viz.colormap import line_colors

# Make display objects
color = line_colors(cc_streamlines)
cc_streamlines_actor = actor.line(cc_streamlines, line_colors(cc_streamlines))
cc_ROI_actor = actor.contour_from_roi(cc_slice, color=(1., 1., 0.), opacity=0.5)

vol_actor = actor.slicer(t1.get_data())

vol_actor.display(x=40)
vol_actor2 = vol_actor.copy()
vol_actor2.display(z=35)

# Add display objects to canvas
ren = window.Renderer()
ren.add(vol_actor)
ren.add(vol_actor2)
ren.add(cc_streamlines_actor)
ren.add(cc_ROI_actor)
# [___CELL_SEPARATOR___]
if view_mode == 'create_plot':
    window.record(ren, size=(600, 600),
                  out_path='data/diffusion/corpuscallosum_axial.png')
    ren.set_camera(position=[-1, 0, 0], focal_point=[0, 0, 0], view_up=[0, 0, 1])
    window.record(ren, size=(600, 600),
                  out_path='data/diffusion/corpuscallosum_sagittal.png')
elif view_mode == 'interactive':
    window.show(ren)
# [___CELL_SEPARATOR___]
Image(filename='data/diffusion/corpuscallosum_axial.png')
# [___CELL_SEPARATOR___]
Image(filename='data/diffusion/corpuscallosum_sagittal.png')
# [___CELL_SEPARATOR___]
M, grouping = utils.connectivity_matrix(cc_streamlines,
                                        labels,
                                        affine=affine,
                                        return_mapping=True,
                                        mapping_as_streamlines=True)
# [___CELL_SEPARATOR___]
M[:3, :] = 0
M[:, :3] = 0
# [___CELL_SEPARATOR___]
import numpy as np
import matplotlib.pyplot as plt
plt.figure(figsize=(8, 8))
plt.imshow(np.log1p(M), interpolation='nearest', cmap='coolwarm');
# [___CELL_SEPARATOR___]
lr_superiorfrontal_track = grouping[11, 54]
shape = labels.shape
dm = utils.density_map(lr_superiorfrontal_track, shape, affine=affine)
# [___CELL_SEPARATOR___]
# Save density map
dm_img = nb.Nifti1Image(dm.astype("int16"), img.affine)
# [___CELL_SEPARATOR___]
plotting.plot_anat(dm_img, cut_coords=[12,10,34], dim=-1, draw_cross=False,
                   cmap='magma', title='Density Map of Region 11 & 54')
# [___CELL_SEPARATOR___]
from dipy.data import two_cingulum_bundles
cb_subj1, cb_subj2 = two_cingulum_bundles()
# [___CELL_SEPARATOR___]
from dipy.tracking.streamline import set_number_of_points
cb_subj1 = set_number_of_points(cb_subj1, 20)
cb_subj2 = set_number_of_points(cb_subj2, 20)
# [___CELL_SEPARATOR___]
from dipy.align.streamlinear import StreamlineLinearRegistration
srr = StreamlineLinearRegistration()
# [___CELL_SEPARATOR___]
srm = srr.optimize(static=cb_subj1, moving=cb_subj2)
# [___CELL_SEPARATOR___]
cb_subj2_aligned = srm.transform(cb_subj2)
# [___CELL_SEPARATOR___]
from dipy.viz import window, actor
ren = window.Renderer()
ren.SetBackground(1, 1, 1)

bundles = [cb_subj1, cb_subj2]
colors = [window.colors.orange, window.colors.red]
for (i, bundle) in enumerate(bundles):
        color = colors[i]
        lines_actor = actor.streamtube(bundle, color, linewidth=0.3)
        lines_actor.RotateX(-90)
        lines_actor.RotateZ(90)
        ren.add(lines_actor)
# [___CELL_SEPARATOR___]
if view_mode == 'create_plot':
    window.record(ren, size=(600, 600),
                  out_path='data/diffusion/before_registration.png')
elif view_mode == 'interactive':
    window.show(ren)
Image(filename='data/diffusion/before_registration.png')
# [___CELL_SEPARATOR___]
from dipy.viz import window, actor
ren = window.Renderer()
ren.SetBackground(1, 1, 1)

bundles = [cb_subj1, cb_subj2_aligned]
colors = [window.colors.orange, window.colors.red]
for (i, bundle) in enumerate(bundles):
        color = colors[i]
        lines_actor = actor.streamtube(bundle, color, linewidth=0.3)
        lines_actor.RotateX(-90)
        lines_actor.RotateZ(90)
        ren.add(lines_actor)
# [___CELL_SEPARATOR___]
if view_mode == 'create_plot':
    window.record(ren, size=(600, 600),
                  out_path='data/diffusion/after_registration.png')
elif view_mode == 'interactive':
    window.show(ren)
Image(filename='data/diffusion/after_registration.png')