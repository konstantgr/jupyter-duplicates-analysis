import seaborn as sns
import seaborn_altair.pyplot as palt
tips = sns.load_dataset("tips")
# [___CELL_SEPARATOR___]
palt.scatter('tip', 'total_bill', data=tips).interactive()
# [___CELL_SEPARATOR___]
