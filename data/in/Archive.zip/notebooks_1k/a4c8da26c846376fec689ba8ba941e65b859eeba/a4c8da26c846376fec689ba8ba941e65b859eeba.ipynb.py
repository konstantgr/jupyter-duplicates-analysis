# -*- coding: UTF-8 -*-
from aip import AipOcr
from xugu import Pin
import time
# [___CELL_SEPARATOR___]
led = Pin(13, Pin.OUT)
led.write_digital(0) # 关闭连接 13 号引脚的 LED 灯
time.sleep(1)
# [___CELL_SEPARATOR___]
""" 你的 APPID AK SK """
APP_ID = '17592596'
API_KEY = 'WVIgzetjM6CZzN6kBcWf5MqS'
SECRET_KEY = '2Wz54qpEWQtIEFeBHWte6oplsiRTrcwP'
# [___CELL_SEPARATOR___]
aipOcr = AipOcr(APP_ID, API_KEY, SECRET_KEY)
# [___CELL_SEPARATOR___]
filePath = "num.png"
  
def get_file_content(filePath):
    with open(filePath, 'rb') as fp:
        return fp.read()

# [___CELL_SEPARATOR___]
options = {
 'recognize_granularity': 'big',
 'words_type': 'number',
}
# [___CELL_SEPARATOR___]
result = aipOcr.handwriting(get_file_content(filePath), options)
print(result)
words_result=result['words_result']
for i in range(len(words_result)):
    number = words_result[i]['words']
    print(number)
# [___CELL_SEPARATOR___]
num = int(number)
while num > 0:
    # #用循环实现持续地开灯关灯,到达闪烁的效果
    led.write_digital(1) # 点亮连接 13 号引脚的 LED 灯
    time.sleep(1) # 持续 1 秒
    led.write_digital(0) # 关闭 LED 灯
    time.sleep(0.5) # 持续 1 秒
    num -= 1
# [___CELL_SEPARATOR___]
