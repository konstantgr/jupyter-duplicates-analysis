import numpy as np
import pandas as pd
import plotnine as p9
from sklearn import svm
# [___CELL_SEPARATOR___]
n=1000
X = np.random.uniform(0,1,(n,2))
Z = np.sin(X*8) @ np.array([.5,-1])
mu = (Z > 0)
# [___CELL_SEPARATOR___]
X_df = pd.DataFrame(X,columns=["X1","X2"])
X_df['mu'] = mu
Y = np.random.binomial(1,.6*mu+.2,size=n) > 0
X_df['Y'] = Y
# [___CELL_SEPARATOR___]
p9.ggplot(X_df,p9.aes(x="X1",y="X2",color="mu")) + p9.geom_point()
# [___CELL_SEPARATOR___]
p9.ggplot(X_df,p9.aes(x="X1",y="X2",color="Y")) + p9.geom_point()
# [___CELL_SEPARATOR___]
svm_train = svm.SVC(kernel="linear")

svm_train.fit(X,Y)
# [___CELL_SEPARATOR___]
I = np.linspace(0,1,100)
grid = np.array([[i,j] for i in I for j in I])
mu_grid = svm_train.decision_function(grid) > 0

grid_df = pd.DataFrame(grid,columns=["X1","X2"])
grid_df["pred"] = mu_grid
# [___CELL_SEPARATOR___]
p9.ggplot(grid_df,p9.aes(x="X1",y="X2",color="pred")) \
+ p9.geom_point(alpha=.1)\
+ p9.geom_point(p9.aes(x="X1",y="X2",color="Y"),data=X_df)
# [___CELL_SEPARATOR___]
svm_train = svm.SVC(kernel="rbf", gamma=1.)
svm_train.fit(X,Y)
# [___CELL_SEPARATOR___]
mu_grid = svm_train.decision_function(grid) > 0

grid_df = pd.DataFrame(grid,columns=["X1","X2"])
grid_df["pred"] = mu_grid
# [___CELL_SEPARATOR___]
p9.ggplot(grid_df,p9.aes(x="X1",y="X2",color="pred")) \
+ p9.geom_point(alpha=.1)\
+ p9.geom_point(p9.aes(x="X1",y="X2",color="Y"),data=X_df)
# [___CELL_SEPARATOR___]
svm_train = svm.SVC(kernel="rbf", gamma=5.)
svm_train.fit(X,Y)

mu_grid = svm_train.decision_function(grid) > 0

grid_df = pd.DataFrame(grid,columns=["X1","X2"])
grid_df["pred"] = mu_grid
# [___CELL_SEPARATOR___]
p9.ggplot(grid_df,p9.aes(x="X1",y="X2",color="pred")) \
+ p9.geom_point(alpha=.1)\
+ p9.geom_point(p9.aes(x="X1",y="X2",color="Y"),data=X_df)
# [___CELL_SEPARATOR___]
svm_train = svm.SVC(kernel="rbf", gamma=5**2)
svm_train.fit(X,Y)

mu_grid = svm_train.decision_function(grid) > 0

grid_df = pd.DataFrame(grid,columns=["X1","X2"])
grid_df["pred"] = mu_grid
# [___CELL_SEPARATOR___]
p9.ggplot(grid_df,p9.aes(x="X1",y="X2",color="pred")) \
+ p9.geom_point(alpha=.1)\
+ p9.geom_point(p9.aes(x="X1",y="X2",color="Y"),data=X_df)
# [___CELL_SEPARATOR___]
svm_train = svm.SVC(kernel="rbf", gamma=5**3)
svm_train.fit(X,Y)

mu_grid = svm_train.decision_function(grid) > 0

grid_df = pd.DataFrame(grid,columns=["X1","X2"])
grid_df["pred"] = mu_grid
# [___CELL_SEPARATOR___]
p9.ggplot(grid_df,p9.aes(x="X1",y="X2",color="pred")) \
+ p9.geom_point(alpha=.1)\
+ p9.geom_point(p9.aes(x="X1",y="X2",color="Y"),data=X_df)
# [___CELL_SEPARATOR___]
svm_train = svm.SVC(kernel="rbf", gamma=5**4)
svm_train.fit(X,Y)

mu_grid = svm_train.decision_function(grid) > 0

grid_df = pd.DataFrame(grid,columns=["X1","X2"])
grid_df["pred"] = mu_grid
# [___CELL_SEPARATOR___]
p9.ggplot(grid_df,p9.aes(x="X1",y="X2",color="pred")) \
+ p9.geom_point(alpha=.1)\
+ p9.geom_point(p9.aes(x="X1",y="X2",color="Y"),data=X_df)
# [___CELL_SEPARATOR___]
svm_train = svm.SVC(kernel="rbf", gamma=5**5)
svm_train.fit(X,Y)

mu_grid = svm_train.decision_function(grid) > 0

grid_df = pd.DataFrame(grid,columns=["X1","X2"])
grid_df["pred"] = mu_grid
# [___CELL_SEPARATOR___]
p9.ggplot(grid_df,p9.aes(x="X1",y="X2",color="pred")) \
+ p9.geom_point(alpha=.1)\
+ p9.geom_point(p9.aes(x="X1",y="X2",color="Y"),data=X_df)