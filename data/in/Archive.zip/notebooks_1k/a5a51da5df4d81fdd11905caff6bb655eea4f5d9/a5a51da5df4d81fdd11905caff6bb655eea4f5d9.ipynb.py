import pandas as pd
bike = pd.read_csv('https://raw.githubusercontent.com/zacharski/ml-class/master/data/bike.csv')
bike = bike.set_index('Day')
bike

# [___CELL_SEPARATOR___]
from sklearn import tree
clf = tree.DecisionTreeClassifier(criterion='entropy')
clf.fit(bike[['Outlook', 'Temperature', 'Humidity', 'Wind']], bike['Bike'])
# [___CELL_SEPARATOR___]
one_hot = pd.get_dummies(bike['Outlook'])
one_hot
# [___CELL_SEPARATOR___]
bike = bike.drop('Outlook', axis=1)

# [___CELL_SEPARATOR___]
bike = bike.join(one_hot)
bike
# [___CELL_SEPARATOR___]
one_hot = pd.get_dummies(bike['Temperature'])
bike = bike.drop('Temperature', axis=1)
bike = bike.join(one_hot)
one_hot = pd.get_dummies(bike['Humidity'])
bike = bike.drop('Humidity', axis=1)
bike = bike.join(one_hot)
one_hot = pd.get_dummies(bike['Wind'])
bike = bike.drop('Wind', axis=1)
bike = bike.join(one_hot)

bike
# [___CELL_SEPARATOR___]
clf.fit(bike[['Outlook', 'Temperature', 'Humidity', 'Wind']], bike['Bike'])
# [___CELL_SEPARATOR___]
list(bike.columns)
# [___CELL_SEPARATOR___]
fColumns = list(bike.columns)
fColumns.remove('Bike')
bike_features = bike[fColumns]
bike_features
# [___CELL_SEPARATOR___]
bike_labels = bike[['Bike']]
bike_labels
# [___CELL_SEPARATOR___]
clf.fit(bike_features, bike_labels)
# [___CELL_SEPARATOR___]
from pandas import DataFrame
students = DataFrame({'name': ['Ann', 'Ben', 'Clara', 'Danielle', 'Eric', 'Akash'],
                     'sex':   ['f', 'm', 'f', 'f', 'm', 'm'],
                     'age': [21, 18, 23, 19, 20, 21]})
students
# [___CELL_SEPARATOR___]
students['female'] =  students['sex'].apply(lambda x: True if x == 'f' else False)
students  = students.drop('sex', axis=1) 
students
# [___CELL_SEPARATOR___]
students['under20'] =  students['age'].apply(lambda x: True if x < 20 else False)
students
# [___CELL_SEPARATOR___]
iris = pd.read_csv('https://raw.githubusercontent.com/zacharski/ml-class/master/data/iris.csv')
iris

# [___CELL_SEPARATOR___]
from sklearn.model_selection import train_test_split
iris_train, iris_test = train_test_split(iris, test_size = 0.2)
iris_train
# [___CELL_SEPARATOR___]
iris_train_features = iris_train[['Sepal Length', 'Sepal Width', 'Petal Length', 'Petal Width']]
iris_train_labels = iris_train[['Class']]
# [___CELL_SEPARATOR___]
from sklearn import tree
clf = tree.DecisionTreeClassifier(criterion='entropy')
# [___CELL_SEPARATOR___]
from sklearn.model_selection import cross_val_score
# [___CELL_SEPARATOR___]
scores = cross_val_score(clf, iris_train_features, iris_train_labels, cv=10)
# [___CELL_SEPARATOR___]
print(scores)
print("The average accuracy is %5.3f" % (scores.mean()))

# [___CELL_SEPARATOR___]
# TO DO
# [___CELL_SEPARATOR___]
# TO DO

# [___CELL_SEPARATOR___]
# TO DO
# [___CELL_SEPARATOR___]
# TO DO
# [___CELL_SEPARATOR___]
# TO DO
# [___CELL_SEPARATOR___]
# TO DO
# [___CELL_SEPARATOR___]
# TO DO
# [___CELL_SEPARATOR___]
from sklearn.model_selection import GridSearchCV
# [___CELL_SEPARATOR___]
hyperparam_grid = [
    {'max_depth': [3, 4, 5, 6, 7, 8, 9, 10, 11, 12], 
     'min_samples_split': [2,3,4, 5]}
  ]

# [___CELL_SEPARATOR___]

clf = tree.DecisionTreeClassifier(criterion='entropy')

# [___CELL_SEPARATOR___]
grid_search = GridSearchCV(clf, hyperparam_grid, cv=10)
# [___CELL_SEPARATOR___]
grid_search.fit(pima_train_features, pima_train_labels)
# [___CELL_SEPARATOR___]
grid_search.best_params_
# [___CELL_SEPARATOR___]
predictions = grid_search.best_estimator_.predict(pima_test_features)
# [___CELL_SEPARATOR___]

accuracy_score(pima_test_labels, predictions)
# [___CELL_SEPARATOR___]
