%matplotlib inline 
# [___CELL_SEPARATOR___]
"""Softmax"""
# [___CELL_SEPARATOR___]
scores = [3.0, 1.0, 0.2]
# [___CELL_SEPARATOR___]
import numpy as np
# [___CELL_SEPARATOR___]
def softmax(x):
    """Compute softmax values for x."""
    y = np.exp(x)/np.sum(np.exp(x), axis=0)
    return y
# [___CELL_SEPARATOR___]
print(softmax(scores))
# [___CELL_SEPARATOR___]
# Plot softmax curves
import matplotlib.pyplot as plt
x = np.arange(-2.0, 6.0,0.1)
scores = np.vstack([x, np.ones_like(x), 0.2 * np.ones_like(x)])
# [___CELL_SEPARATOR___]
plt.plot(x, softmax(scores).T, linewidth=2)
# [___CELL_SEPARATOR___]
plt.show()
# [___CELL_SEPARATOR___]
# Multiply the scores by 10.  What happens?
scores = np.array([3.0, 1.0, 0.2])
print(softmax(scores* 10))
# [___CELL_SEPARATOR___]
# Divide the scores by 10.  What happens?
scores = np.array([3.0, 1.0, 0.2])
print(softmax(scores/ 10))
# [___CELL_SEPARATOR___]
N = 1000000000
a = 0.000001
ITER_MAX = 1000000
# [___CELL_SEPARATOR___]
for iter in range(ITER_MAX):
    N += a
# [___CELL_SEPARATOR___]
print( N - 1000000000 )
# [___CELL_SEPARATOR___]
from decimal import Decimal
# [___CELL_SEPARATOR___]
N_Decimal = Decimal(N)
a_Decimal = Decimal(a)
for iter in range(ITER_MAX):
    N_Decimal += a_Decimal
# [___CELL_SEPARATOR___]
print( N_Decimal - Decimal( N))
# [___CELL_SEPARATOR___]
