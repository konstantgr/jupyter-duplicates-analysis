from simtk.openmm.app import PDBFile

from openforcefield.utils import get_data_file_path
from openforcefield.topology import Molecule, Topology
from openforcefield.typing.engines.smirnoff import ForceField
# [___CELL_SEPARATOR___]
# Create an OpenFF Topology of toluene from a pdb file.
toluene_pdb_file_path = get_data_file_path('molecules/toluene.pdb')
toluene_pdbfile = PDBFile(toluene_pdb_file_path)
toluene = Molecule.from_smiles('Cc1ccccc1')
off_topology = Topology.from_openmm(openmm_topology=toluene_pdbfile.topology,
                                    unique_molecules=[toluene])

# Load the Parsley force field from disk.
force_field = ForceField('openff_unconstrained-1.0.0.offxml')

# Parametrize the toluene molecule.
toluene_system = force_field.create_openmm_system(off_topology)
# [___CELL_SEPARATOR___]
import parmed

# Convert OpenMM System into a ParmEd Structure.
toluene_structure = parmed.openmm.load_topology(toluene_pdbfile.topology,
                                                toluene_system,
                                                xyz=toluene_pdbfile.positions)
# [___CELL_SEPARATOR___]
# Load the AMBER protein force field parameters through OpenMM.
from simtk.openmm import app
omm_forcefield = app.ForceField('amber99sbildn.xml', 'tip3pfb.xml')

# Load the solvated receptor from a PDB file.
t4_pdb_file_path = get_data_file_path('systems/test_systems/T4_lysozyme_water_ions.pdb')
t4_pdb_file = PDBFile(t4_pdb_file_path)

# Obtain the updated OpenMM Topology and positions.
omm_topology = t4_pdb_file.getTopology()
positions = t4_pdb_file.getPositions()
# [___CELL_SEPARATOR___]
# Parameterize the protein.
t4_system = omm_forcefield.createSystem(omm_topology, rigidWater=False)

# Convert the protein System into a ParmEd Structure.
t4_structure = parmed.openmm.load_topology(omm_topology,
                                           t4_system,
                                           xyz=positions)
# [___CELL_SEPARATOR___]
complex_structure = toluene_structure + t4_structure
# [___CELL_SEPARATOR___]
from simtk.openmm.app import NoCutoff, HBonds
from simtk import unit

# Convert the Structure to an OpenMM System in vacuum.
complex_system = complex_structure.createSystem(nonbondedMethod=NoCutoff,
                                                nonbondedCutoff=9.0*unit.angstrom,
                                                constraints=HBonds,
                                                removeCMMotion=False)