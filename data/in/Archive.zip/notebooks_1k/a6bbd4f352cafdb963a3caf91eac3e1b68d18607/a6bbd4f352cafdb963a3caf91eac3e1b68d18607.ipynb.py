import axon
# [___CELL_SEPARATOR___]
from decimal import Decimal
from datetime import datetime, time, date
text = axon.dumps([['abc абв', 1, 3.14, True], [datetime.now(), Decimal('3.14')]])
print(text)
# [___CELL_SEPARATOR___]
vals = [
    {'id':1, 'nickname':'nick', 'time':time(12, 31, 34), 'text':'hello!'},
    {'id':2, 'nickname':'mark', 'time':time(12, 32, 3), 'text':'hi!'}
]
# [___CELL_SEPARATOR___]
text = axon.dumps(vals)
print(text)
# [___CELL_SEPARATOR___]
text = axon.dumps(vals, pretty=1)
print(text)
# [___CELL_SEPARATOR___]
vals == axon.loads(text)
# [___CELL_SEPARATOR___]
vals = [[{'a':1, 'b':2, 'c':3}, {'a':[1,2,3], 'b':(1,2,3), 'c':{1,2,3}}]]
text = axon.dumps(vals)
print(text)
# [___CELL_SEPARATOR___]
text = axon.dumps(vals, pretty=1)
print(text)
# [___CELL_SEPARATOR___]
 vals == axon.loads(text)
# [___CELL_SEPARATOR___]
vals = axon.loads('person{name:"nick" age:32 email:"nail@example.com"}')
print(type(vals[0]))
print(vals[0])
# [___CELL_SEPARATOR___]
text = axon.dumps(vals)
print(text)
# [___CELL_SEPARATOR___]
text = axon.dumps(vals, pretty=1)
print(text)
# [___CELL_SEPARATOR___]
text = axon.dumps(vals, pretty=1, braces=1)
print(text)
# [___CELL_SEPARATOR___]
class Person:
    def __init__(self, name, age, email):
        self.name = name
        self.age = age
        self.email = email
        
    def __str__(self):
        return "Person(name=%r, age=%r, email=%r)" % (self.name, self.age, self.email)

@axon.reduce(Person)
def reduce_Person(p):
    return axon.node('person', {'name':p.name, 'age':p.age, 'email':p.email})

@axon.factory('person')
def factory_Person(attrs, vals):
    return Person(name=attrs['name'], age=attrs['age'], email=attrs['email'])
# [___CELL_SEPARATOR___]
p = Person('nick', 32, 'mail@example.com')
text = axon.dumps([p])
print(text)
# [___CELL_SEPARATOR___]
val = axon.loads(text, mode='strict')[0]
print(val)
# [___CELL_SEPARATOR___]
print(val.name==p.name, val.age==p.age, val.email==p.email)
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
