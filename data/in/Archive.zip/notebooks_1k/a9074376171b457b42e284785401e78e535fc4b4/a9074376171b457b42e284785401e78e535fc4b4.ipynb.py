import sys
# [___CELL_SEPARATOR___]
%%writefile print_args.py
import sys
print(sys.argv)
# [___CELL_SEPARATOR___]
%run print_args.py 1 foo
# [___CELL_SEPARATOR___]
import os
os.remove('print_args.py')
# [___CELL_SEPARATOR___]
try:
    x = 1/0
except Exception:
    print (sys.exc_info())
# [___CELL_SEPARATOR___]
sys.stdout.write('hello' + '\n')
# [___CELL_SEPARATOR___]
print('hello') # 等价
# [___CELL_SEPARATOR___]
sys.path
# [___CELL_SEPARATOR___]
sys.platform
# [___CELL_SEPARATOR___]
sys.getwindowsversion()
# [___CELL_SEPARATOR___]
sys.version
# [___CELL_SEPARATOR___]
sys.version_info