import json
import pandas as pd
from bs4 import BeautifulSoup
# [___CELL_SEPARATOR___]
with open('johor.json') as fopen:
    johor = json.load(fopen)
# [___CELL_SEPARATOR___]
res = []

for j in johor:
    s = BeautifulSoup(j)
    s.tbody.table.decompose()
    table_rows = s.tbody.find_all('tr')
    for tr in table_rows:
        td = tr.find_all('td')
        row = [tr.text.strip() for tr in td if tr.text.strip()]
        if row:
            res.append(row)
# [___CELL_SEPARATOR___]
df = pd.DataFrame(res)
df
# [___CELL_SEPARATOR___]
df.to_csv('johor.csv', index = False)