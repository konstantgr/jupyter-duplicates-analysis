R.version
# [___CELL_SEPARATOR___]
install.packages("https://cran.r-project.org/src/contrib/Archive/SparkR/SparkR_2.3.0.tar.gz", repos = NULL)
# [___CELL_SEPARATOR___]
library("SparkR")
sparkR.session(appName = "spark", master = "local[*]",
               sparkConfig = list(spark.driver.memory = "8g", spark.executor.memory = "8g", spark.python.worker.memory = "8g"))
# [___CELL_SEPARATOR___]
df <- read.json("/usr/local/spark/examples/src/main/resources/people.json")
showDF(df)
# [___CELL_SEPARATOR___]
sparkR.stop()
# [___CELL_SEPARATOR___]
