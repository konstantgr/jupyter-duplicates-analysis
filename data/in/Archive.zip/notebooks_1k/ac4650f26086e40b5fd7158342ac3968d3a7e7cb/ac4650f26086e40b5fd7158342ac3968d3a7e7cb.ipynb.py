import $ivy.`io.github.siddhartha-gadgil::provingground-core-jvm:0.1.0`
# [___CELL_SEPARATOR___]
import provingground._ , interface._, HoTT._
import learning._
import library._, MonoidSimple._
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
repl.pprinter.bind(translation.FansiShow.fansiPrint)
# [___CELL_SEPARATOR___]
val tg = TermGenParams()
tg.nodeCoeffSeq
# [___CELL_SEPARATOR___]
val mfd = MonixFiniteDistributionEq(tg.nodeCoeffSeq)
val ts = TermState(dist1, dist1.map(_.typ))
# [___CELL_SEPARATOR___]
import TermRandomVars._
val tsk = mfd.varDist(ts)(Terms, 0.001)
import monix.execution.Scheduler.Implicits.global
# [___CELL_SEPARATOR___]
val rp = tsk.runSyncUnsafe()
val eqs = rp._2
# [___CELL_SEPARATOR___]
eqs
# [___CELL_SEPARATOR___]
val lefts = eqs.map(_.lhs)
lefts.size
# [___CELL_SEPARATOR___]
import GeneratorVariables._, Expression._
val eqgs = Equation.group(eqs)
# [___CELL_SEPARATOR___]
eqgs.size
eqs.size
# [___CELL_SEPARATOR___]
eqgs.head
# [___CELL_SEPARATOR___]
eqgs.map(_.rhs)
# [___CELL_SEPARATOR___]
val rights = eqgs.map(_.rhs).flatMap(GeneratorVariables.Expression.varVals)
# [___CELL_SEPARATOR___]
val extras = rights -- lefts.flatMap(GeneratorVariables.Expression.varVals)
# [___CELL_SEPARATOR___]
extras.size
# [___CELL_SEPARATOR___]
lefts.size
rights.size
# [___CELL_SEPARATOR___]
lefts.take(20)
# [___CELL_SEPARATOR___]
import GeneratorVariables.Expression.varVals
val egEq = eqgs.find(eq => varVals(eq.rhs).intersect(extras).nonEmpty)
# [___CELL_SEPARATOR___]
egEq.get.lhs
# [___CELL_SEPARATOR___]
egEq.get.toString
# [___CELL_SEPARATOR___]
varVals(egEq.get.rhs)
varVals(egEq.get.rhs).intersect(extras)
# [___CELL_SEPARATOR___]
val initExtras = extras.filter(_.isInstanceOf[InitialVal[_]])
# [___CELL_SEPARATOR___]
initExtras.size
# [___CELL_SEPARATOR___]
extras.size
# [___CELL_SEPARATOR___]
lefts.filter(_.isInstanceOf[InitialVal[_]])
# [___CELL_SEPARATOR___]
val linits = eqgs.filter(_.lhs.isInstanceOf[InitialVal[_]])
# [___CELL_SEPARATOR___]
linits.size
# [___CELL_SEPARATOR___]
linits.head.toString
# [___CELL_SEPARATOR___]
linits.head.rhs
# [___CELL_SEPARATOR___]
linits.head.lhs
# [___CELL_SEPARATOR___]
val termEqs = eqgs.collect{case Equation(FinalVal(Elem(t : Term, Terms)), rhs) => t -> rhs}
# [___CELL_SEPARATOR___]
termEqs.size
# [___CELL_SEPARATOR___]
termEqs.map(_._1)
# [___CELL_SEPARATOR___]
termEqs.map(_._1.typ).filter(tp => !isUniv(tp))
# [___CELL_SEPARATOR___]
val eqid = termEqs.find(_._1.typ == eqM(l)(op(l)(r)))
# [___CELL_SEPARATOR___]
val eqid0 = termEqs.find(_._1.typ == eqM(op(l)(r))(l))
# [___CELL_SEPARATOR___]
eqgs.find(eq => varVals(eq.rhs).intersect(extras).nonEmpty)
# [___CELL_SEPARATOR___]
val finExtras = extras -- initExtras
# [___CELL_SEPARATOR___]
finExtras.size
# [___CELL_SEPARATOR___]
val ats = eqs.map(_.rhs).flatMap(Expression.atoms)
# [___CELL_SEPARATOR___]
val coeffs = ats.collect{case coeff @ Coeff(_, _) => coeff}
# [___CELL_SEPARATOR___]
val cs =  coeffs.toVector.map(c => c.get(tg.nodeCoeffSeq) -> c.rv)
# [___CELL_SEPARATOR___]
val initEls = extras.collect{case el @ InitialVal(Elem(_, _)) => el}
# [___CELL_SEPARATOR___]
extras -- initEls
# [___CELL_SEPARATOR___]
val sd = implicitly[StateDistribution[TermState, FiniteDistribution]]
# [___CELL_SEPARATOR___]
val zeroVals =  initEls.filter{case InitialVal(Elem(x, rv)) => sd.value(ts)(rv)(x) == 0}
# [___CELL_SEPARATOR___]
val withZero = eqs.filter(eq => varVals(eq.rhs).intersect(zeroVals.map(x => x : VarVal[_])).nonEmpty)
# [___CELL_SEPARATOR___]
val atoms = ats.union(lefts)
# [___CELL_SEPARATOR___]
import ExpressionEval._
# [___CELL_SEPARATOR___]
val init = initMap(atoms, tg, ts)
# [___CELL_SEPARATOR___]
init.size
# [___CELL_SEPARATOR___]
val m2 = nextMap(init, eqgs)
# [___CELL_SEPARATOR___]
m2.size
# [___CELL_SEPARATOR___]
val m3 = nextMap(m2, eqgs)
# [___CELL_SEPARATOR___]
m3.size
# [___CELL_SEPARATOR___]
atoms.size
# [___CELL_SEPARATOR___]
atoms -- m3.keys
# [___CELL_SEPARATOR___]
m2.values.toSet
# [___CELL_SEPARATOR___]
init.filter(_._1.isInstanceOf[Coeff[_]])
# [___CELL_SEPARATOR___]
val m4 = nextMap(m3, eqgs)
# [___CELL_SEPARATOR___]
m4.size
# [___CELL_SEPARATOR___]
val m5 = nextMap(m4, eqgs)
# [___CELL_SEPARATOR___]
m5.size
# [___CELL_SEPARATOR___]
atoms -- m5.keySet
# [___CELL_SEPARATOR___]
val zeroE = eqgs.filter(eq => !m5.keySet(eq.lhs))
# [___CELL_SEPARATOR___]
zeroE.head.rhs
# [___CELL_SEPARATOR___]
val x = Expression.atoms(zeroE.head.rhs).filter(exp => recExp(m4, exp) == 0).head
# [___CELL_SEPARATOR___]
eqgs.find(_.lhs == x)
# [___CELL_SEPARATOR___]
val ts = Expression.atoms(eqgs.find(_.lhs == x).get.rhs).toVector
# [___CELL_SEPARATOR___]
ts.map(m4.get(_))
# [___CELL_SEPARATOR___]
val eventEq = eqgs.find(_.lhs == ts(1)).get
# [___CELL_SEPARATOR___]
val m6 = nextMap(m5, eqgs)
# [___CELL_SEPARATOR___]
m6.size
# [___CELL_SEPARATOR___]
atoms -- m6.keySet
# [___CELL_SEPARATOR___]
val ms = stableSupportMap(init, eqgs)
# [___CELL_SEPARATOR___]
val m100 = iterateMap(ms, eqgs, 100)
# [___CELL_SEPARATOR___]
val m200 = iterateMap(m100, eqgs, 100)
# [___CELL_SEPARATOR___]
mapRatio(m100, m200)
# [___CELL_SEPARATOR___]
mapRatio(ms, m100)
# [___CELL_SEPARATOR___]
zeroVals
# [___CELL_SEPARATOR___]
zeroVals.map{case InitialVal(elem : Elem[_]) => isIsleVar(elem)}
# [___CELL_SEPARATOR___]
val ins = TermState(dist1, dist1.map(_.typ))
val fsT = tg.nextStateTask(ins, 0.001)
val fs = fsT.runSyncUnsafe()
# [___CELL_SEPARATOR___]
val expEv = ExpressionEval.fromStates(ins, fs, eqgs, tg)
# [___CELL_SEPARATOR___]
expEv.hExp
# [___CELL_SEPARATOR___]
val v = expEv.entropyProjection()(m200)
# [___CELL_SEPARATOR___]
val grad = expEv.variableIndex.mapValues(j => v(j))
# [___CELL_SEPARATOR___]
grad.toVector.sortBy{case (_, p) => - math.abs(p)}
# [___CELL_SEPARATOR___]
expEv.jet(m200)(expEv.hExp)
# [___CELL_SEPARATOR___]
expEv.jet(m200)(expEv.klExp)
# [___CELL_SEPARATOR___]
import spire.algebra._
import spire.implicits._
v.norm
# [___CELL_SEPARATOR___]
val vv = expEv.entropyProjection()(expEv.finalDist)
# [___CELL_SEPARATOR___]
vv.norm
# [___CELL_SEPARATOR___]
val best = expEv.vars.zipWithIndex.sortBy{case (v, n) => -vv(n)}.map{case (v, n) => (v, vv(n))}
# [___CELL_SEPARATOR___]
best.reverse
# [___CELL_SEPARATOR___]
