import sys,os

try:
    from localgraphclustering import *
except:
    # when the package is not installed, import the local version instead. 
    # the notebook must be placed in the original "notebooks/" folder
    sys.path.append("../")
    from localgraphclustering import *

import time
import numpy as np
import pickle

# Import the graph_tool module for visualization.
from graph_tool.all import * 

# Import matplotlib 
import matplotlib.pyplot as plt

# Just a useful function.
def diff(a, b):
        b = set(b)
        return np.asarray([aa for aa in a if aa not in b], dtype = 'int64')
# [___CELL_SEPARATOR___]
# Read John Hopkins graph.
g = GraphLocal('./datasets/usroads-cc.graphml','graphml')

# Load pre-computed coordinates for nodes.
ld_coord = np.loadtxt('./datasets/usroads-cc.xy', dtype = 'Float64')
ld_coord[:,0] = -ld_coord[:,0]

temp1 = np.multiply(ld_coord[:,0] < 95,ld_coord[:,0] > 92.0)
temp2 = np.multiply(ld_coord[:,1] > 44.0,ld_coord[:,1] < 45.9)
temp = np.multiply(temp1,temp2)

#ref_nodes = np.argwhere(ld_coord[:,0] < 79.)
ref_nodes = np.argwhere(temp)
ref_nodes = ref_nodes[:,0]
# [___CELL_SEPARATOR___]
## Add data to graphtool.
#g_gtool = Graph(directed=False)
#m = g._num_edges
#for i in range(m):
#    g_gtool.add_edge(g.edges[0][i], g.edges[1][i], add_missing=True)  
    
#remove_self_loops(g_gtool)

# Add data to graphtool.
g_gtool = load_graph("./datasets/usroads-cc.graphml")
    
remove_self_loops(g_gtool)

pos = g_gtool.new_vertex_property("vector<double>")
for i in range(g._num_vertices):
    pos[i] = -ld_coord[i,:]

temp = np.zeros(g._num_vertices) + 0.0001
temp[ref_nodes] = 1

node_size = g_gtool.new_vertex_property("double",temp)

temp = ["black" for x in range(g._num_vertices)]

for i in ref_nodes:
    temp[i] = "green"

node_colours = g_gtool.new_vertex_property("string",temp)

graph_draw(g_gtool, pos, output_size=(1000, 500),
           vertex_size=node_size, 
           vertex_fill_color=node_colours, 
           vorder=node_size,
           edge_pen_width=0.5)
# [___CELL_SEPARATOR___]
# Copy graph.
keep = np.zeros(g._num_vertices, dtype=bool)
keep[ref_nodes] = True
keep = g_gtool.new_vertex_property("bool",keep)

g2 = Graph(g_gtool)
g2.set_vertex_filter(keep)

g3 = Graph(g2,prune=True)

prop = g3.new_vertex_property("vector<double>")
for i in range(len(ref_nodes)):
    prop[i] = pos[g2.vertex(ref_nodes[i])]
    
temp = np.ones(len(ref_nodes)) + 1

node_size = g3.new_vertex_property("double",temp)

temp = ["black" for x in range(len(ref_nodes))]

node_colours = g3.new_vertex_property("string",temp)

graph_draw(g3, prop, output_size=(1000, 500),
           vertex_size=node_size, 
           vertex_fill_color=node_colours, 
           vorder=node_size,
           edge_pen_width=1)
# [___CELL_SEPARATOR___]
# Conductance before improvement
print("Conductance before improvement:",g.compute_conductance(ref_nodes))

# Start calling MQI
start = time.time()
output_MQI_fast = MQI(g,ref_nodes)
end = time.time()
print("running time:",str(end-start)+"s")

# Conductance after improvement
print("Conductance after improvement:",g.compute_conductance(output_MQI_fast[0]))

output_MQI = output_MQI_fast[0]
# [___CELL_SEPARATOR___]
# Plot solutions for Flow Improve
temp = np.zeros(len(ref_nodes))
temp = temp + 0.00001

only_seed = diff(ref_nodes, output_MQI)
# Find node indices in the sub-graph of original cluster after deletion of the complement.
ix = np.in1d(ref_nodes.ravel(), only_seed).reshape(ref_nodes.shape)
idx_only_seed = np.where(ix)[0]


only_mqi = diff(output_MQI, ref_nodes)
# Find node indices in the sub-graph of original cluster after deletion of the complement.
ix = np.in1d(ref_nodes.ravel(), only_mqi).reshape(ref_nodes.shape)
idx_only_mqi = np.where(ix)[0]

intsect = set(ref_nodes).intersection(set(output_MQI))
intsect = list(intsect)
# Find node indices in the sub-graph of original cluster after deletion of the complement.
ix = np.in1d(ref_nodes.ravel(), intsect).reshape(ref_nodes.shape)
idx_intsect = np.where(ix)[0]

temp[idx_only_seed] = 1
temp[idx_only_mqi] = 3
temp[idx_intsect] = 3

node_size = g3.new_vertex_property("double",temp)

temp = ["black" for x in range(len(ref_nodes))]

for i in idx_only_mqi:
    temp[i] = "red"
for i in idx_intsect:
    temp[i] = "red"

node_colours = g3.new_vertex_property("string",temp)

c_map = plt.get_cmap('autumn')

graph_draw(g3, prop, output_size=(1000, 500),
           vertex_size=node_size, 
           vertex_fill_color=node_colours, 
           vorder=node_size,
           edge_pen_width=1)
# [___CELL_SEPARATOR___]
# Conductance before improvement
print("Conductance before improvement:",g.compute_conductance(ref_nodes))

# Start calling SimpleLocal
start = time.time()
output_SL_fast = SimpleLocal(g,ref_nodes)
end = time.time()
print("running time:",str(end-start)+"s")

# Conductance after improvement
print("Conductance after improvement:",g.compute_conductance(output_SL_fast[0]))

output_SL = output_SL_fast[0]
# [___CELL_SEPARATOR___]
# Plot solutions for Flow Improve
temp = np.zeros(len(ref_nodes))
temp = temp + 0.00001

only_seed = diff(ref_nodes, output_SL)
# Find node indices in the sub-graph of original cluster after deletion of the complement.
ix = np.in1d(ref_nodes.ravel(), only_seed).reshape(ref_nodes.shape)
idx_only_seed = np.where(ix)[0]


only_SL = diff(output_SL, ref_nodes)
# Find node indices in the sub-graph of original cluster after deletion of the complement.
ix = np.in1d(ref_nodes.ravel(), only_SL).reshape(ref_nodes.shape)
idx_only_SL = np.where(ix)[0]

intsect = set(ref_nodes).intersection(set(output_SL))
intsect = list(intsect)
# Find node indices in the sub-graph of original cluster after deletion of the complement.
ix = np.in1d(ref_nodes.ravel(), intsect).reshape(ref_nodes.shape)
idx_intsect = np.where(ix)[0]

temp[idx_only_seed] = 1
temp[idx_only_SL] = 3
temp[idx_intsect] = 3

node_size = g3.new_vertex_property("double",temp)

temp = ["black" for x in range(len(ref_nodes))]

for i in idx_only_SL:
    temp[i] = "red"
for i in idx_intsect:
    temp[i] = "red"

node_colours = g3.new_vertex_property("string",temp)

c_map = plt.get_cmap('autumn')

graph_draw(g3, prop, output_size=(1000, 500),
           vertex_size=node_size, 
           vertex_fill_color=node_colours, 
           vorder=node_size,
           edge_pen_width=1)
# [___CELL_SEPARATOR___]
temp = np.zeros(g._num_vertices) + 0.00001
temp[output_SL] = 1

node_size = g_gtool.new_vertex_property("double",temp)

temp = ["black" for x in range(g._num_vertices)]

for i in output_SL:
    temp[i] = "red"

node_colours = g_gtool.new_vertex_property("string",temp)

graph_draw(g_gtool, pos, output_size=(1000, 500),
           vertex_size=node_size, 
           vertex_fill_color=node_colours, 
           vorder=node_size,
           edge_pen_width=0.1)
# [___CELL_SEPARATOR___]
# Read graph. This also supports gml and graphml format.
g = GraphLocal('./datasets/senate.graphml','graphml')

# Call the global spectral partitioning algorithm.
eig2 = fiedler(g)[0]

# Round the eigenvector
output_sc = sweep_cut(g,eig2)

# Extract the partition for g and store it.
eig2_rounded = output_sc[0]

# Add data to graphtool.
g_gtool = load_graph("./datasets/senate.graphml")
    
remove_self_loops(g_gtool)

# Compute a layout for the graph.
#pos = sfdp_layout(g_gtool, gamma=10.0, mu=10.0, mu_p=10.0, verbose = False)  

coordinates = pickle.load( open( "./datasets/senate_pos.p", "rb" ) )

pos = g_gtool.new_vertex_property("vector<double>")
for i in range(g._num_vertices):
    pos[i] = coordinates[g_gtool.vertex(i)]

# Plot solutions for rounded eigenvector
temp = np.zeros(g._num_vertices) + 0.00001

eig2_rounded_c = diff(range(g._num_vertices), eig2_rounded)

temp[eig2_rounded] = 6
temp[eig2_rounded_c] = 6

node_size = g_gtool.new_vertex_property("double",temp)

temp = ["black" for x in range(g._num_vertices)]

for i in eig2_rounded:
    temp[i] = "yellow"
for i in eig2_rounded_c:
    temp[i] = "red"

node_colours = g_gtool.new_vertex_property("string",temp)

graph_draw(g_gtool, pos, output_size=(1000, 500),
           vertex_size=node_size, 
           vertex_fill_color=node_colours, 
           vorder=node_size,
           edge_pen_width=0.1)
# [___CELL_SEPARATOR___]
# Conductance before improvement
print("Conductance before improvement:",g.compute_conductance(eig2_rounded))

# Start calling MQI
start = time.time()
output_MQI_fast = MQI(g,eig2_rounded)
end = time.time()
print("running time:",str(end-start)+"s")

# Conductance after improvement
print("Conductance after improvement:",g.compute_conductance(output_MQI_fast[0]))

output_MQI = output_MQI_fast[0]
# [___CELL_SEPARATOR___]
# Plot solutions for rounded eigenvector
temp = np.zeros(g._num_vertices) + 0.00001

temp[output_MQI] = 6

node_size = g_gtool.new_vertex_property("double",temp)

temp = ["black" for x in range(g._num_vertices)]

for i in output_MQI:
    temp[i] = "yellow"

node_colours = g_gtool.new_vertex_property("string",temp)

graph_draw(g_gtool, pos, output_size=(1000, 500),
           vertex_size=node_size, 
           vertex_fill_color=node_colours, 
           vorder=node_size,
           edge_pen_width=0.1)
# [___CELL_SEPARATOR___]
# Conductance before improvement
print("Conductance before improvement:",g.compute_conductance(eig2_rounded))

# Start calling SimpleLocal
start = time.time()
output_SL_fast = SimpleLocal(g,eig2_rounded)
end = time.time()
print("running time:",str(end-start)+"s")

# Conductance after improvement
print("Conductance after improvement:",g.compute_conductance(output_SL_fast[0]))

output_SL = output_SL_fast[0]
# [___CELL_SEPARATOR___]
# Plot solutions for rounded eigenvector
temp = np.zeros(g._num_vertices) + 0.00001

temp[output_SL] = 6

node_size = g_gtool.new_vertex_property("double",temp)

temp = ["black" for x in range(g._num_vertices)]

for i in output_SL:
    temp[i] = "yellow"

node_colours = g_gtool.new_vertex_property("string",temp)

graph_draw(g_gtool, pos, output_size=(1000, 500),
           vertex_size=node_size, 
           vertex_fill_color=node_colours, 
           vorder=node_size,
           edge_pen_width=0.1)
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
