from google_ngram import *
import re
import numpy as np
import pandas as pd
import time
from math import sqrt
import matplotlib.pyplot as plt
%matplotlib inline

redo_web_lookup = False
# [___CELL_SEPARATOR___]
poem = """Turning and turning in the widening gyre
The falcon cannot hear the falconer;
Things fall apart; the centre cannot hold;
Mere anarchy is loosed upon the world,
The blood-dimmed tide is loosed, and everywhere
The ceremony of innocence is drowned;
The best lack all conviction, while the worst
Are full of passionate intensity.
Surely some revelation is at hand;
Surely the Second Coming is at hand.
The Second Coming! Hardly are those words out
When a vast image out of Spiritus Mundi
Troubles my sight: somewhere in sands of the desert
A shape with lion body and the head of a man,
A gaze blank and pitiless as the sun,
Is moving its slow thighs, while all about it
Reel shadows of the indignant desert birds.
The darkness drops again; but now I know
That twenty centuries of stony sleep
Were vexed to nightmare by a rocking cradle,
And what rough beast, its hour come round at last,
Slouches towards Bethlehem to be born?"""
# [___CELL_SEPARATOR___]
if redo_web_lookup:
    text = re.sub('\r', '', poem)
    text = text.lower()
    text = re.sub('\-', ' ', text) # treat hyphen as space
    text = text.replace(';', '\n').replace('\.+', '\n').replace(':', '\n') # treat clause-breakers as line-breakers
    text = re.sub('[^a-z \n]', '', text)
    text = text.split('\n')
    for i in range(len(text)):
        text[i] = text[i].split(' ')
        text[i] = [x for x in text[i] if x != ''] # remove empty items
    text = [x for x in text if len(x) > 0] # remove empty lists
    print text
# [___CELL_SEPARATOR___]
if redo_web_lookup:
    # using exec and eval instead of nested lists because
    # lists have zero-based counting and n-grams have 1-based counting.

    for i in range(1, 6): #1-gram, 2-gram ... 5-gram
        exec "grams_" + str(i) + " = []" # creates lists grams_1, grams_2 ...
        for sentence in text:
            nwords = len(sentence)
            if i < nwords:
                for pos in range(len(sentence)-i+1):
                    exec "grams_" + str(i) + ".append(' '.join(sentence[pos:pos+i]))"
        exec "print grams_" + str(i)
# [___CELL_SEPARATOR___]
if redo_web_lookup:
    for i in [1, 2, 3, 4, 5]:
        exec("df_" + str(i) + "= pd.DataFrame()")
        for term in eval("grams_" + str(i)):
            try:
                g = Gngram([term], years=[1880,1980], case_insensitive=True)
                exec("df_" + str(i) + " = pd.concat([df_" + str(i) +", g.df_parents], axis=1)")
                print term, 'added; ',
            except SyntaxError: # unexpected EOF when parsing html if search term not found
                print '\n'+term, '################## skipped'
            time.sleep(10) # so Google doesn't deny access
        exec ("df_" + str(i) + ".to_csv('second_coming_" + str(i) + "_grams.csv')")
# [___CELL_SEPARATOR___]
redo_graphs = True
filenames = ['second_coming_1_grams.csv', 'second_coming_2_grams.csv', 'second_coming_3_grams.csv', 
             'second_coming_4_grams.csv', 'second_coming_5_grams.csv']
# [___CELL_SEPARATOR___]
if redo_graphs:
    # 1-grams
    ngram_number = 1
    df = pd.read_csv(filenames[ngram_number-1], index_col=0)
    max_y = sqrt(df.max().max())
    num_charts = len(df.columns)
    num_cols = 5
    num_rows = num_charts / num_cols
    if num_charts % num_cols != 0:
        num_rows += 1

    f, axarr = plt.subplots(num_rows, num_cols, figsize=(16, 58))
    plt.subplots_adjust(hspace = .25, wspace=.3)
    #plt.locator_params(axis = 'y', nbins = 2)
    #f.axes.get_xaxis().set_visible(False)
    c_row = 0
    c_col = 0
    for column in df.columns:
        alpha = sqrt(df[column].max()) / max_y
        axarr[c_row, c_col].plot(df.index, df[column])
        title = df[column].name.replace(' (All)', '')
        title = re.sub('\.[0-9]{,2}$', '', title)
        axarr[c_row, c_col].set_title(title, fontdict ={'fontsize': 10})
        axarr[c_row, c_col].set_ylim(0, df[column].max())
        axarr[c_row, c_col].set_xlim(1880, 1980)
        axarr[c_row, c_col].get_xaxis().set_visible(False)
        axarr[c_row, c_col].locator_params(axis = 'y', nbins=4)
        #axarr[c_row, c_col].yaxis.set_ticks(np.arange(0, df[column].max()))
        axarr[c_row, c_col].fill_between(df.index, df[column], color='b', alpha=alpha, interpolate=True)
        c_col = (c_col + 1) % num_cols
        if c_col == 0: # new row
            c_row += 1
# [___CELL_SEPARATOR___]
if redo_graphs:
    # 2-grams
    ngram_number = 2
    df = pd.read_csv(filenames[ngram_number-1], index_col=0)
    max_y = sqrt(df.max().max())
    num_charts = len(df.columns)
    num_cols = 5
    num_rows = num_charts / num_cols
    if num_charts % num_cols != 0:
        num_rows += 1

    f, axarr = plt.subplots(num_rows, num_cols, figsize=(16, num_rows * 2))
    plt.subplots_adjust(hspace = .25, wspace=.3)
    #plt.locator_params(axis = 'y', nbins = 2)
    #f.axes.get_xaxis().set_visible(False)
    c_row = 0
    c_col = 0
    for column in df.columns:
        alpha = sqrt(df[column].max()) / max_y
        axarr[c_row, c_col].plot(df.index, df[column])
        title = df[column].name.replace(' (All)', '')
        title = re.sub('\.[0-9]{,2}$', '', title)
        axarr[c_row, c_col].set_title(title, fontdict ={'fontsize': 10})
        axarr[c_row, c_col].set_ylim(0, df[column].max())
        axarr[c_row, c_col].set_xlim(1880, 1980)
        axarr[c_row, c_col].get_xaxis().set_visible(False)
        axarr[c_row, c_col].locator_params(axis = 'y', nbins=4)
        #axarr[c_row, c_col].yaxis.set_ticks(np.arange(0, df[column].max()))
        axarr[c_row, c_col].fill_between(df.index, df[column], color='b', alpha=alpha, interpolate=True)
        c_col = (c_col + 1) % num_cols
        if c_col == 0: # new row
            c_row += 1
# [___CELL_SEPARATOR___]
if redo_graphs:
    # 3-grams
    ngram_number = 3
    df = pd.read_csv(filenames[ngram_number - 1], index_col=0)
    max_y = sqrt(df.max().max())
    num_charts = len(df.columns)
    num_cols = 5
    num_rows = num_charts / num_cols
    if num_charts % num_cols != 0:
        num_rows += 1

    f, axarr = plt.subplots(num_rows, num_cols, figsize=(16, num_rows * 2))
    plt.subplots_adjust(hspace = .25, wspace=.3)
    #plt.locator_params(axis = 'y', nbins = 2)
    #f.axes.get_xaxis().set_visible(False)
    c_row = 0
    c_col = 0
    for column in df.columns:
        alpha = sqrt(df[column].max()) / max_y
        axarr[c_row, c_col].plot(df.index, df[column])
        title = df[column].name.replace(' (All)', '')
        title = re.sub('\.[0-9]{,2}$', '', title)
        axarr[c_row, c_col].set_title(title, fontdict ={'fontsize': 10})
        axarr[c_row, c_col].set_ylim(0, df[column].max())
        axarr[c_row, c_col].set_xlim(1880, 1980)
        axarr[c_row, c_col].get_xaxis().set_visible(False)
        axarr[c_row, c_col].locator_params(axis = 'y', nbins=4)
        #axarr[c_row, c_col].yaxis.set_ticks(np.arange(0, df[column].max()))
        axarr[c_row, c_col].fill_between(df.index, df[column], color='b', alpha=alpha, interpolate=True)
        c_col = (c_col + 1) % num_cols
        if c_col == 0: # new row
            c_row += 1
# [___CELL_SEPARATOR___]
if redo_graphs:
    # 4-grams
    ngram_number = 4
    df = pd.read_csv(filenames[ngram_number-1], index_col=0)
    max_y = sqrt(df.max().max())
    num_charts = len(df.columns)
    num_cols = 5
    num_rows = num_charts / num_cols
    if num_charts % num_cols != 0:
        num_rows += 1

    f, axarr = plt.subplots(num_rows, num_cols, figsize=(16, num_rows * 2))
    plt.subplots_adjust(hspace = .25, wspace=.3)
    #plt.locator_params(axis = 'y', nbins = 2)
    #f.axes.get_xaxis().set_visible(False)
    c_row = 0
    c_col = 0
    for column in df.columns:
        alpha = sqrt(df[column].max()) / max_y
        axarr[c_row, c_col].plot(df.index, df[column])
        title = df[column].name.replace(' (All)', '')
        title = re.sub('\.[0-9]{,2}$', '', title)
        axarr[c_row, c_col].set_title(title, fontdict ={'fontsize': 10})
        axarr[c_row, c_col].set_ylim(0, df[column].max())
        axarr[c_row, c_col].set_xlim(1880, 1980)
        axarr[c_row, c_col].get_xaxis().set_visible(False)
        axarr[c_row, c_col].locator_params(axis = 'y', nbins=4)
        #axarr[c_row, c_col].yaxis.set_ticks(np.arange(0, df[column].max()))
        axarr[c_row, c_col].fill_between(df.index, df[column], color='b', alpha=alpha, interpolate=True)
        c_col = (c_col + 1) % num_cols
        if c_col == 0: # new row
            c_row += 1
# [___CELL_SEPARATOR___]
if redo_graphs:
    # 5-grams
    ngram_number = 5
    df = pd.read_csv(filenames[ngram_number-1], index_col=0)
    max_y = sqrt(df.max().max())
    num_charts = len(df.columns)
    num_cols = 5
    num_rows = num_charts / num_cols
    if num_charts % num_cols != 0:
        num_rows += 1

    f, axarr = plt.subplots(num_rows, num_cols, figsize=(16, num_rows * 2))
    plt.subplots_adjust(hspace = .25, wspace=.3)
    #plt.locator_params(axis = 'y', nbins = 2)
    #f.axes.get_xaxis().set_visible(False)
    c_row = 0
    c_col = 0
    for column in df.columns:
        alpha = sqrt(df[column].max()) / max_y
        axarr[c_row, c_col].plot(df.index, df[column])
        title = df[column].name.replace(' (All)', '')
        title = re.sub('\.[0-9]{,2}$', '', title)
        axarr[c_row, c_col].set_title(title, fontdict ={'fontsize': 10})
        axarr[c_row, c_col].set_ylim(0, df[column].max())
        axarr[c_row, c_col].set_xlim(1880, 1980)
        axarr[c_row, c_col].get_xaxis().set_visible(False)
        axarr[c_row, c_col].locator_params(axis = 'y', nbins=4)
        #axarr[c_row, c_col].yaxis.set_ticks(np.arange(0, df[column].max()))
        axarr[c_row, c_col].fill_between(df.index, df[column], color='b', alpha=alpha, interpolate=True)
        c_col = (c_col + 1) % num_cols
        if c_col == 0: # new row
            c_row += 1
# [___CELL_SEPARATOR___]
