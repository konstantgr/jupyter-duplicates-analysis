import pandas as pd #Analysis 
import matplotlib.pyplot as plt #Visulization
import seaborn as sns #Visulization
import numpy as np #Analysis 
from scipy.stats import norm #Analysis 
from sklearn.preprocessing import StandardScaler #Analysis 
from scipy import stats #Analysis 
import warnings 
warnings.filterwarnings('ignore')
%matplotlib inline

from sklearn.model_selection import KFold
from sklearn.metrics import mean_absolute_error
import gc
import lightgbm as lgb
from sklearn.preprocessing import OneHotEncoder
from sklearn.metrics import mean_squared_error
# [___CELL_SEPARATOR___]
import os
print(os.listdir())
# [___CELL_SEPARATOR___]
public_info = pd.read_csv("latlng_seoul_busan_public.csv",encoding='UTF-8')
public_info.head()
# [___CELL_SEPARATOR___]
public_info = public_info[['상세분류','기관명','위도','경도']]
public_info.columns = ['type','name','latitude','longitude']
# [___CELL_SEPARATOR___]
train = pd.read_csv("train.csv")
test = pd.read_csv("test.csv")
df_all = pd.concat([train,test])

apartment = df_all.groupby(['apartment_id'])['latitude','longitude','address_by_law'].mean().reset_index()
apartment.head()
# [___CELL_SEPARATOR___]
from math import cos, asin, sqrt
# 단위는 km로 나옴.
def distance(lat1, lon1, lat2, lon2):
    p = 0.017453292519943295     #Pi/180
    a = 0.5 - cos((lat2 - lat1) * p)/2 + cos(lat1 * p) * cos(lat2 * p) * (1 - cos((lon2 - lon1) * p)) / 2
    return 12742 * asin(sqrt(a))
# [___CELL_SEPARATOR___]
public_info_seoul = public_info[public_info['latitude']//1 == 37].reset_index(drop=True)
public_info_busan = public_info[public_info['latitude']//1 == 35].reset_index(drop=True)
apartment_seoul = apartment[apartment['latitude']//1 == 37].reset_index(drop=True)
apartment_busan = apartment[apartment['latitude']//1 == 35].reset_index(drop=True)
# [___CELL_SEPARATOR___]
public_info_seoul['type'].unique()
# [___CELL_SEPARATOR___]
public_info_seoul_univ = public_info_seoul[public_info_seoul['type']=='대학']
public_info_busan_univ = public_info_busan[public_info_busan['type']=='대학']
# [___CELL_SEPARATOR___]
public_info_seoul_univ.head()
# [___CELL_SEPARATOR___]
public_info_seoul_univ['name'].unique()
# [___CELL_SEPARATOR___]
univ_list = ['중앙대학교','이화여자대학교','한국외국어대학교','한국체육대학교','한국폴리텍 I 대학 서울강서캠퍼스','한국폴리텍 I 대학 서울정수캠퍼스',
             '한성대학교','한양대학교','한양여자대학교','홍익대학교','가톨릭대학교','건국대학교','경기대학교','경희대학교','고려대학교','광운대학교',
            '국민대학교','덕성여자대학교','동국대학교','동덕여자대학교','명지대학교','배화여자대학교','상명대학교','서강대학교','서경대학교','서울과학기술대학교','서울교육대학교',
            '서울대학교','서울시립대학교','서울여자대학교','성균관대학교','성신여자대학교','세종대학교','숙명여자대학교','숭실대학교','연세대학교']
public_info_seoul_univ['name'] = public_info_seoul_univ['name'].apply(lambda x: x if x in univ_list else np.nan)
# [___CELL_SEPARATOR___]
public_info_seoul_univ = public_info_seoul_univ.dropna(axis=0)
public_info_seoul_univ.shape
# [___CELL_SEPARATOR___]
public_info_seoul_univ
# [___CELL_SEPARATOR___]
#서울 학교갯수
apartment_lat_lon = apartment_seoul[['latitude','longitude']].reset_index(drop=True)
public_info_seoul_univ_lat_lon = public_info_seoul_univ[['latitude','longitude']].reset_index(drop=True)

count_list1 = []


for i in range(0,apartment_lat_lon.shape[0]):    
    for lat1,lon1 in [apartment_lat_lon.loc[i].values]:
        count1 = 0


        for j in range(0,public_info_seoul_univ_lat_lon.shape[0]):
            for lat2,lon2 in [public_info_seoul_univ_lat_lon.loc[j].values]:
                if distance(lat1,lon1,lat2,lon2) <= 1.2:
                    count1 += 1
                else:
                    pass
        

                    
        count_list1.append(count1)
count_list1
# [___CELL_SEPARATOR___]
apartment_seoul['univ_1,2'] = count_list1
# [___CELL_SEPARATOR___]
#부산 학교갯수
apartment_lat_lon = apartment_busan[['latitude','longitude']].reset_index(drop=True)
public_info_busan_univ_lat_lon = public_info_busan_univ[['latitude','longitude']].reset_index(drop=True)

count_list1 = []


for i in range(0,apartment_lat_lon.shape[0]):    
    for lat1,lon1 in [apartment_lat_lon.loc[i].values]:
        count1 = 0


        for j in range(0,public_info_busan_univ_lat_lon.shape[0]):
            for lat2,lon2 in [public_info_busan_univ_lat_lon.loc[j].values]:
                if distance(lat1,lon1,lat2,lon2) <= 1.2:
                    count1 += 1
                else:
                    pass
        

                    
        count_list1.append(count1)
count_list1
# [___CELL_SEPARATOR___]
apartment_busan['univ_1,2'] = count_list1
# [___CELL_SEPARATOR___]
public_info_seoul['type'].unique()
# [___CELL_SEPARATOR___]
public_info_seoul[public_info_seoul['type']=='시군구']
# [___CELL_SEPARATOR___]
public_info_seoul_si = public_info_seoul[public_info_seoul['type']=='시군구']
public_info_busan_si = public_info_busan[public_info_busan['type']=='시군구']
# [___CELL_SEPARATOR___]
#서울 구청 거리
apartment_lat_lon = apartment_seoul[['latitude','longitude']].reset_index(drop=True)
public_info_seoul_univ_lat_lon = public_info_seoul_si[['latitude','longitude']].reset_index(drop=True)

count_list1 = []


for i in range(0,apartment_lat_lon.shape[0]):    
    for lat1,lon1 in [apartment_lat_lon.loc[i].values]:
        count1 = 0


        for j in range(0,public_info_seoul_univ_lat_lon.shape[0]):
            for lat2,lon2 in [public_info_seoul_univ_lat_lon.loc[j].values]:
                if distance(lat1,lon1,lat2,lon2) <= 1:
                    count1 += 1
                else:
                    pass
        

                    
        count_list1.append(count1)
count_list1
# [___CELL_SEPARATOR___]
apartment_seoul['public_1'] = count_list1
# [___CELL_SEPARATOR___]
#부산 학교갯수
apartment_lat_lon = apartment_busan[['latitude','longitude']].reset_index(drop=True)
public_info_busan_univ_lat_lon = public_info_busan_si[['latitude','longitude']].reset_index(drop=True)

count_list1 = []


for i in range(0,apartment_lat_lon.shape[0]):    
    for lat1,lon1 in [apartment_lat_lon.loc[i].values]:
        count1 = 0


        for j in range(0,public_info_busan_univ_lat_lon.shape[0]):
            for lat2,lon2 in [public_info_busan_univ_lat_lon.loc[j].values]:
                if distance(lat1,lon1,lat2,lon2) <= 1.2:
                    count1 += 1
                else:
                    pass
        

                    
        count_list1.append(count1)
count_list1
# [___CELL_SEPARATOR___]
apartment_busan['public_1'] = count_list1
apartment_busan['public_1'].describe()
# [___CELL_SEPARATOR___]
apartment = pd.concat([apartment_seoul,apartment_busan])
# [___CELL_SEPARATOR___]
apartment.to_csv("apartment_public.csv",index=False)