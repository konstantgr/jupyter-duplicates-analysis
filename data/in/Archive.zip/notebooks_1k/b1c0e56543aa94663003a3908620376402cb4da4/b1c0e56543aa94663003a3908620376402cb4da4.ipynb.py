import pandas as pd
# [___CELL_SEPARATOR___]
us_population_url = 'https://raw.githubusercontent.com/TrainingByPackt/Interactive-Data-Visualization-with-Python/master/datasets/us_state_population.tsv'
df = pd.read_csv(us_population_url, sep='\t')
df.head()

# [___CELL_SEPARATOR___]
#Use the melt function to convert the data in the desired format:
df = pd.melt(df, id_vars=['State', 'Code'], var_name="Year", value_name="Population")
df.head()

# [___CELL_SEPARATOR___]
#Import the graph_objects module.
import plotly.graph_objects as go
# [___CELL_SEPARATOR___]
#Initialize the figure with the Figure function in graph_objects. Specifically, the data argument needs to be an instance of the Choropleth class with the following parameters:
# initialize the figure
fig = go.Figure(
    data=go.Choropleth(
        locations=df['Code'], # Code for US states
        z = df['Population'].astype(int), # Data to be color-coded
        locationmode = 'USA-states', # set of locations match entries in `locations`
        colorscale = 'Blues',
        colorbar_title = "Population",
    )
)

# [___CELL_SEPARATOR___]
#Make changes to the layout with update_layout() - set title_text and geo_scope.
# update layout
fig.update_layout(
    title_text = 'US Population across states',
    geo_scope='usa', # limit map scope to USA
)

fig.show()

# [___CELL_SEPARATOR___]
