import tmpo
import matplotlib.pyplot as plt

%matplotlib inline
plt.rcParams['figure.figsize'] = 14,8
# [___CELL_SEPARATOR___]
s = tmpo.Session()
s.debug = False
# [___CELL_SEPARATOR___]
s.add('d209e2bbb35b82b83cc0de5e8b84a4ff','e16d9c9543572906a11649d92f902226')
# [___CELL_SEPARATOR___]
s.sync()
# [___CELL_SEPARATOR___]
ts = s.series('d209e2bbb35b82b83cc0de5e8b84a4ff')
print(ts)
# [___CELL_SEPARATOR___]
ts.ix[:1000].plot()
plt.show()
# [___CELL_SEPARATOR___]
tsmin = ts.resample(rule='H')
tsmin=tsmin.interpolate(method='linear')
tsmin=tsmin.diff()
tsmin.plot()
# [___CELL_SEPARATOR___]
tsmin.ix['20141016':'20141018'].plot()
# [___CELL_SEPARATOR___]
ts.name