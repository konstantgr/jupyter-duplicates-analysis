# IMPORTANDO BIBLIOTECAS

import pandas as pd
import glob
import re
import itertools
import numpy as np
import statsmodels.api as sm
import seaborn as sns
import squarify

import matplotlib.pyplot as plt
import matplotlib
plt.style.use('fivethirtyeight')

import plotly.offline as py 
py.init_notebook_mode(connected=True) # this code, allow us to work with offline plotly version
import plotly.graph_objs as go # it's like "plt" of matplot
import plotly.tools as tls # It's useful to we get some tools of plotly

from folium import Map
from folium.plugins import HeatMap
from folium.plugins import FastMarkerCluster

import warnings
warnings.filterwarnings("ignore")
# [___CELL_SEPARATOR___]
# FUNÇÃO PARA IMPORTAR DATASET

dir_path = "data/"

def importaData(files):
    
    data = dir_path + files
    allFiles = glob.glob('data/*.csv')

    list_ = []
    cols = ['ANO_BO', 'DATAOCORRENCIA', 'PERIDOOCORRENCIA', 'BAIRRO', 'CIDADE', 'LATITUDE', 'LONGITUDE', 'LOGRADOURO', \
           'DESCRICAOLOCAL', 'DESCR_TIPO_VEICULO']

    for file_ in allFiles:
        df = pd.read_csv(file_,index_col=None, header=0, delimiter=';', usecols=cols)
        list_.append(df)

    df = pd.concat(list_, axis = 0, ignore_index = True)
    
    return df

# IMPORTANDO DATASET

all_data = importaData('*.csv')
# [___CELL_SEPARATOR___]
# VISUALIZANDO DATAFRAME

all_data.tail()
# [___CELL_SEPARATOR___]
# DESCRIÇÃO ESTATÍSTICA

all_data.describe()
# [___CELL_SEPARATOR___]
print("Tipos de dados e valores 'missing': ")

all_data.info()
# [___CELL_SEPARATOR___]
# REMOVENDO DADOS DUPLICADOS

def removeDuplicados(df):
    
    print('Quantidade de dados duplicados: ', df.duplicated().sum())
    df.drop_duplicates(inplace=True)
    print('Quantidade de dados duplicados após remoção: ', df.duplicated().sum())
    
    return df

all_data = removeDuplicados(all_data)
# [___CELL_SEPARATOR___]
# FILTRANDO DADOS DE S.PAULO

def filtraSP(df):

    df.CIDADE.fillna('S.PAULO')
    df = df[df['CIDADE'] == 'S.PAULO']
    del df['CIDADE']
    
    return df

all_data = filtraSP(all_data)
# [___CELL_SEPARATOR___]
# TRANSFORMANDO STRINGS PARA LOWER CASE

def lowerCase(df, cols):
    for col in cols:
        df[col] = df[col].str.title()
    
    return df

colsToLower = ["PERIDOOCORRENCIA", "LOGRADOURO", "BAIRRO", "DESCR_TIPO_VEICULO"]

all_data = lowerCase(all_data, colsToLower)
# [___CELL_SEPARATOR___]
# PADRONIZANDO STRINGS

def correct_string(string):
        string = string.replace('Avenida ', 'Av. ').replace('Av ', 'Av. ').replace('Rua ', 'R. ').replace('R ', 'R. ') \
                    .replace('R ', 'R. ').replace(',', '.').replace('Praça ', 'Pr. ').replace('Pr ', 'Pr. ') \
                    .replace('Pública', 'pública').replace('Jardim', 'Jd.').replace('Jd ', 'Jd. ')
        return string

all_data.DESCRICAOLOCAL = all_data.astype(str).DESCRICAOLOCAL.apply(correct_string)  
all_data.LOGRADOURO = all_data.astype(str).LOGRADOURO.apply(correct_string)
all_data.LATITUDE = all_data.LATITUDE.astype(str).apply(correct_string).astype(float)
all_data.LONGITUDE = all_data.LONGITUDE.astype(str).apply(correct_string).astype(float)
# [___CELL_SEPARATOR___]
# TRANSFORMANDO DADOS TEMPORAIS

def tratarDatas(df, col = 'DATAOCORRENCIA'):
    df[col] = pd.to_datetime(df[col], format='%d/%m/%Y', errors='coerce')

    indexs = []

    for row in df[col].items():
        if row[1] < pd.datetime(2010, 1, 1):
            indexs.append(row[0])
        
    df.drop(index=indexs, axis=1, inplace=True)

    df['diasemana'] = df[col].dt.weekday_name
    df['mesano'] = df[col].dt.strftime('%Y-%m')
    df['mes'] = df[col].dt.month

    df.drop(index=df[df['mesano'] == 'NaT'].index, inplace=True, axis=0)
    
    return df
    
all_data = tratarDatas(all_data)
# [___CELL_SEPARATOR___]
# VISUALIZANDO DATAFRAME LIMPO

all_data.head()
# [___CELL_SEPARATOR___]
df_ts = all_data.groupby('DATAOCORRENCIA').count()["ANO_BO"].to_frame().rename(columns={"ANO_BO": "OCORRENCIAS"})

trace = [go.Scatter(x = df_ts.index, y = df_ts.OCORRENCIAS)]

layout = dict(
    title='Ocorrências de Roubo de Celular',
    xaxis=dict(
        rangeselector=dict(
            buttons=list([
                dict(count=12,
                     label='1yr',
                     step='month',
                     stepmode='backward'),
                dict(count=6,
                     label='6m',
                     step='month',
                     stepmode='backward'),
                dict(step='all')
            ])
        ),
        rangeslider=dict(
            visible = True
        ),
        type='date'
    )
)

fig = dict(data=trace, layout=layout)
py.iplot(fig)
# [___CELL_SEPARATOR___]
ocorrencias = all_data.groupby('mesano').count()['ANO_BO'].reset_index()
ocorrencias.rename(columns={'mesano': 'Data', 'ANO_BO':'Ocorrências de Roubo de Celular'}, inplace=True)

trace = [go.Scatter(x = ocorrencias.Data, y = ocorrencias['Ocorrências de Roubo de Celular'])]

layout = dict(
    title='Ocorrências de Roubo de Celular por Mês',
    yaxis=dict(
    title='Ocorrências'
    ),
    xaxis=dict(
        rangeselector=dict(
            buttons=list([
                dict(count=12,
                     label='1yr',
                     step='month',
                     stepmode='backward'),
                dict(count=6,
                     label='6m',
                     step='month',
                     stepmode='backward'),
                dict(step='all')
            ])
        ),
        rangeslider=dict(
            visible = True
        ),
        type='date'
    )
)

fig = dict(data=trace, layout=layout)
py.iplot(fig)
# [___CELL_SEPARATOR___]
# CALCULANDO VARIAÇÕES NO NÚMERO DE OCORRÊNCIAS POR ANO

all_data.ANO_BO = all_data.ANO_BO.astype(int)
ocorrencias_ano = all_data.groupby('ANO_BO').count()['DATAOCORRENCIA'].reset_index()
ocorrencias_ano['VARIACAO'] = 0
ocorrencias_ano['VARIACAO_ACUMULADA'] = 0

for i in range (0, 8):
    ocorrencias_ano.iloc[i+1, 2] = round((1 - (ocorrencias_ano.iloc[i, 1] / ocorrencias_ano.iloc[i+1, 1])) * 100, 2)
    ocorrencias_ano.iloc[i+1, 3] = round((ocorrencias_ano.iloc[i, 3] + ocorrencias_ano.iloc[i+1, 2]), 2)
    
ocorrencias_ano.VARIACAO = ocorrencias_ano.VARIACAO.astype(str) + ' %'
ocorrencias_ano.VARIACAO_ACUMULADA = ocorrencias_ano.VARIACAO_ACUMULADA.astype(str) + ' %'
    
ocorrencias_ano
# [___CELL_SEPARATOR___]
data = [
    go.Bar(
        x = ocorrencias_ano.ANO_BO.values[1:],
        y = ocorrencias_ano.VARIACAO.values[1:],
        marker = dict(
          color = ['green', 'green', 'green', 'green', 'red', 'green', 'red', 'red']
        ),
        name = 'Variação com ano anterior'
    ), 
    go.Scatter(
        x = ocorrencias_ano.ANO_BO.values[1:], 
        y = ocorrencias_ano.VARIACAO_ACUMULADA.values[1:],
        marker = dict(
          color = 'blue'
        ),        
        name = 'Variação acumulada'
    )
]

layout = dict(
    title='Variação do Número de Ocorrências de Roubo de Celular',
    yaxis=dict(
        title='Variação (%)',
        ),
    )

fig = dict(data=data, layout=layout)
py.iplot(fig)
# [___CELL_SEPARATOR___]
all_data['diasemana'] = pd.Categorical(all_data['diasemana'], categories=['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday', 'Sunday'], ordered=True)

trace = [go.Bar(
            x = all_data['diasemana'].value_counts().sort_index().index,
            y = all_data['diasemana'].value_counts().sort_index().values,
            textposition = 'auto',
            marker=dict(
                color='rgb(158,202,225)',
                line=dict(
                    color='rgb(8,48,107)',
                    width=1,
                    )
                ),
            opacity=0.8
)]
           
layout = go.Layout(
    title='Ocorrências de Roubo de Celular por Dia da Semana (2010 - 2018)',
    yaxis=dict(
        title='Ocorrências'
        ),
)

fig = go.Figure(data=trace, layout=layout)

py.iplot(fig)
# [___CELL_SEPARATOR___]
colors = ['#170B3B', '#A9D0F5', '#08088A', '#DBA901']

trace = [go.Pie(labels=all_data.PERIDOOCORRENCIA.unique(), values=all_data.PERIDOOCORRENCIA.value_counts().values,
               hoverinfo='label+percent', 
               textfont=dict(size=18),
               marker=dict(colors=colors, 
                           line=dict(color='#000000', width=2)))]

layout = go.Layout(
    title='Período das Ocorrências de Roubo de Celular (2010 - 2018)'
)

fig = go.Figure(data = trace, layout = layout)

py.iplot(fig)
# [___CELL_SEPARATOR___]
# FILTRANDO DADOS DE 2018

data = all_data[all_data["ANO_BO"] == 2018].copy()
# [___CELL_SEPARATOR___]
trace = [go.Bar(
            y = data['DESCRICAOLOCAL'].value_counts().index,
            x = data['DESCRICAOLOCAL'].value_counts().values,
            orientation='h',
            textposition = 'auto',
            marker=dict(
                color='rgb(158,202,225)',
                line=dict(
                    color='rgb(8,48,107)',
                    width=1,
                    )
                ),
            opacity=0.8
)]
           
layout = go.Layout(
    height=800,
    title='Locais das Ocorrências de Roubo de Celular em 2018',
    xaxis=dict(
        title = 'Ocorrências',
        type='log',
        ),
     yaxis=go.layout.YAxis(
     automargin=True
     )
)

fig = go.Figure(data=trace, layout=layout)

py.iplot(fig)
# [___CELL_SEPARATOR___]
data_ = data[(data['DESCR_TIPO_VEICULO'] != 'Inexist.') & (data['DESCR_TIPO_VEICULO'] != 'Não Informado')]

trace = [go.Bar(
            x = data_["DESCR_TIPO_VEICULO"].value_counts().index,
            y = data_["DESCR_TIPO_VEICULO"].value_counts().values,
            text=data_["DESCR_TIPO_VEICULO"].value_counts().values,
            textposition = 'auto',
            marker=dict(
                color='rgb(158,202,225)',
                line=dict(
                    color='rgb(8,48,107)',
                    width=1,
                    )
                ),
            opacity=0.8
)]
           
layout = go.Layout(
    title='Ocorrências de Roubo de Celular em Veículos (2018)',
    yaxis=dict(
        title='Ocorrências',
        ),
)

fig = go.Figure(data=trace, layout=layout)

py.iplot(fig)
# [___CELL_SEPARATOR___]
fig, ax = plt.subplots(figsize=(15,9))

cmap = matplotlib.cm.coolwarm
mini = data.LOGRADOURO.value_counts().values[19]
maxi = data.LOGRADOURO.value_counts().values[0]
norm = matplotlib.colors.Normalize(vmin=mini, vmax=maxi)
colors = [cmap(norm(value)) for value in data.LOGRADOURO.value_counts().iloc[:100].values]

squarify.plot(sizes=data.LOGRADOURO.value_counts().iloc[:20].values, label=data.LOGRADOURO.value_counts().iloc[:20].index, color=colors)

plt.axis('off')
plt.title("Locais com mais ocorrências de roubo de celular em 2018", fontsize=18)
ttl = ax.title
ttl.set_position([.5, 1.05])
# [___CELL_SEPARATOR___]
fig, ax = plt.subplots(figsize=(15,9))

cmap = matplotlib.cm.coolwarm
mini = data.BAIRRO.value_counts().values[49]
maxi = data.BAIRRO.value_counts().values[0]
norm = matplotlib.colors.Normalize(vmin=mini, vmax=maxi)
colors = [cmap(norm(value)) for value in data.BAIRRO.value_counts().iloc[:100].values]

squarify.plot(sizes=data.BAIRRO.value_counts().iloc[:50].values, label=data.BAIRRO.value_counts().iloc[:50].index, color=colors)

plt.axis('off')
plt.title("Bairros com mais ocorrências de roubo de celular em 2018", fontsize=18)
ttl = ax.title
ttl.set_position([.5, 1.05])
# [___CELL_SEPARATOR___]
# REMOVENDO NAs E CRIANDO COLUNA COORDENADAS

df = data.dropna(subset=['LATITUDE', 'LONGITUDE']).copy()
df = df[df['DATAOCORRENCIA'] > "2018-10-01"]
df['coord'] = df[['LATITUDE','LONGITUDE']].apply(tuple, axis=1)
# [___CELL_SEPARATOR___]
m = Map([-23.64992751, -46.62569322], zoom_start=10, width='100%', height='100%')
m.add_child(HeatMap(df['coord'], radius=8))
m
# [___CELL_SEPARATOR___]
pointMap = Map([-23.550, -46.620], zoom_start=10.5, width='100%', height='100%')
pointMap.add_child(FastMarkerCluster(df['coord']))
pointMap
# [___CELL_SEPARATOR___]
# TRANSFORMANDO SÉRIE TEMPORAL

ocorrencias.index =  ocorrencias.Data
ocorrencias.drop(columns='Data', inplace=True)
ocorrencias.index = pd.to_datetime(ocorrencias.index)
# [___CELL_SEPARATOR___]
# IMPORTANDO BIBLIOTECAS

from plotly.plotly import plot_mpl
from statsmodels.tsa.seasonal import seasonal_decompose

# DECOMPOSIÇÃO DA SÉRIE TEMPORAL

result = seasonal_decompose(ocorrencias, model='multiplicative')
g = result.plot()
g.set_figwidth(14)
g.set_figheight(14)
# [___CELL_SEPARATOR___]
# IMPORTANDO BIBLIOTECAS

from statsmodels.graphics.tsaplots import plot_acf
from statsmodels.graphics.tsaplots import plot_pacf

# PLOT DE CORRELAÇÃO ACF

g = plot_acf(ocorrencias, title="ACF Correlation")
g.set_figheight(8)
g.set_figwidth(14)
# [___CELL_SEPARATOR___]
# DIFERENCIANDO SÉRIE TEMPORAL

ocorrencias_diff = ocorrencias.diff(periods=1)
ocorrencias_diff = ocorrencias_diff[1:]
# [___CELL_SEPARATOR___]
# PLOT DA SÉRIE TEMPORAL DIFERENCIADA COM D = 1

g = ocorrencias_diff.plot(figsize=(14,8), title="Série Temporal Diferenciada", legend=False)
# [___CELL_SEPARATOR___]
# PLOT CORRELAÇÃO ACF

g = plot_acf(ocorrencias_diff, title="ACF Correlation (d = 1)")
g.set_figheight(8)
g.set_figwidth(14)
# [___CELL_SEPARATOR___]
# DEFINE COMBINAÇÕES ENTRE p DE 0 A 3, d = 1, e q = 13
pdq = [(p, 1, 13) for p in range(0, 4)]

# DEFINE P e Q ENTRE 0 e 3
P = Q = range(0, 4)

# DEFINE COMBINAÇÕES ENTRE P, D e Q
seasonal_pdq = [(x[0], 1, x[1], 12) for x in list(itertools.product(P, Q))]
# [___CELL_SEPARATOR___]
# CALCULANDO OS MELHORES PARÂMETROS PARA O MODELO

#scores = {}

#for param in pdq:
#    for param_seasonal in seasonal_pdq:
#        try:
#            mod = sm.tsa.statespace.SARIMAX(ocorrencias,
#                                            order=param,
#                                            seasonal_order=param_seasonal,
#                                            enforce_stationarity=False,
#                                            enforce_invertibility=False)
#
#            results = mod.fit()
#            scores[param, param_seasonal] = results.aic
#            
#        except:
#            continue
#            
#print("Melhores parâmetros: ", min(scores, key=scores.get)," AUC: ", min(scores.values()))
# [___CELL_SEPARATOR___]
# CRIANDO MODELO COM OS MELHOERS PARÂMETROS 

mod = sm.tsa.statespace.SARIMAX(ocorrencias,
                                order=(3, 1, 13),
                                seasonal_order=(3, 1, 0, 12),
                                enforce_stationarity=False,
                                enforce_invertibility=False)

results = mod.fit()
# [___CELL_SEPARATOR___]
# RESUMO DO MODELO

results.plot_diagnostics(figsize=(15, 12))
plt.show()
# [___CELL_SEPARATOR___]
# VALIDAÇÃO DO MODELO: PREVENDO OCORRÊNCIAS A PARTIR DE 2017

pred = results.get_prediction(start=pd.to_datetime('2017-01-01'), dynamic=False)
pred_ci = pred.conf_int()

ax = ocorrencias['2014':].plot(figsize=(14, 8))
pred.predicted_mean.plot(ax=ax, label='Previsão', alpha=.7)

ax.fill_between(pred_ci.index,
                pred_ci.iloc[:, 0],
                pred_ci.iloc[:, 1], color='k', alpha=.2)

ax.set_title("Previsão de Ocorrências de Roubo de Celular", fontsize=18)
ax.set_xlabel('Data')
ax.set_ylabel('Ocorrências de Roubo de Celular')
plt.legend()

plt.show()

# CALCULANDO MSE

y_forecasted = pred.predicted_mean
y_truth = ocorrencias["2017-01-01":].squeeze()

mse = ((y_forecasted - y_truth) ** 2).mean()

print('O Mean Squared Error da previsão foi {}'.format(round(mse)))
# [___CELL_SEPARATOR___]
# PREVENDO OCORRÊNCIAS PARA OS PRÓXIMOS TRÊS ANOS

pred_uc = results.get_forecast(steps=36)
pred_ci = pred_uc.conf_int()

ax = ocorrencias['2010':].plot(figsize=(14, 8))
pred_uc.predicted_mean.plot(ax=ax, label='Previsão')
ax.fill_between(pred_ci.index,
                pred_ci.iloc[:, 0],
                pred_ci.iloc[:, 1], color='k', alpha=.25)

ax.set_title("Previsão de Ocorrências de Roubo de Celular", fontsize=18)
ax.set_xlabel('Data')
ax.set_ylabel('Ocorrências de Roubo de Celular')

plt.legend()
plt.show()