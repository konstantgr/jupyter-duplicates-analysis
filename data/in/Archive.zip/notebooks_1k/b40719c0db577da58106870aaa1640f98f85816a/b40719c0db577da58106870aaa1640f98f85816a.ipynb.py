%matplotlib inline
import pandas as pd
import numpy as np
import scipy.stats as stats
import itertools
from math import exp
from IPython.core.pylabtools import figsize
from matplotlib import pyplot as plt
import seaborn as sns
figsize(12.5, 8)
pd.set_option("display.precision", 3)
# [___CELL_SEPARATOR___]
a = stats.truncnorm(a=0, b=100000, loc=3000, scale = 6000)

lower, upper = 0, 100000
mu, sigma = 5000, 6000
a = stats.truncnorm((lower - mu) / sigma, (upper - mu) / sigma, loc=mu, scale=sigma)
# [___CELL_SEPARATOR___]
x = np.linspace(0,15000,1000)
plt.plot(x, a.pdf(x))
# [___CELL_SEPARATOR___]
