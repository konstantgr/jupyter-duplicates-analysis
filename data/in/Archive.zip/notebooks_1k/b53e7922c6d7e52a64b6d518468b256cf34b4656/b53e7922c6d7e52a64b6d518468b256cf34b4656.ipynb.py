4380/20
# [___CELL_SEPARATOR___]
import urllib3, json
import pandas as pd  
from tqdm.notebook import  trange   
http = urllib3.PoolManager() 
pd.set_option("display.max.columns", None) 
pd.set_option("display.max.rows", None) 
urlbase ="http://data.riksdagen.se/dokumentlista/?sok=&doktyp=dir&utformat=json&a=s&start="

dftot = pd.DataFrame()
maxpages = int(4380/20) + 1
for i in trange(1,maxpages,i):
    url = urlbase + str(i)
    print(url)
    r = http.request('GET', url)
    try:
        data = json.loads(r.data)
        dftot = dftot.append(pd.DataFrame(data["dokumentlista"]["dokument"]),sort=False)
    except:
        pass
        #print("\tError in i=",i," can be html problem") 
        print(url)


# [___CELL_SEPARATOR___]

dftot.info()
# [___CELL_SEPARATOR___]
dftot.head()
# [___CELL_SEPARATOR___]
dftot[['rm','dok_id','nummer','titel','publicerad','datum']]

# [___CELL_SEPARATOR___]
dftot.rm.value_counts().sort_index()
# [___CELL_SEPARATOR___]
%matplotlib inline  
import matplotlib.pyplot as plt  
plot = dftot.rm.value_counts().sort_index().plot.bar(y='counts', figsize=(25, 5)) 
plt.show()
# [___CELL_SEPARATOR___]
dftot.datum.unique()
# [___CELL_SEPARATOR___]
 dftot.publicerad.value_counts().sort_index()
# [___CELL_SEPARATOR___]
 dftot.debattnamn.value_counts()
# [___CELL_SEPARATOR___]
dftot.datum.value_counts().sort_index()
# [___CELL_SEPARATOR___]
dftot.datum.value_counts().sort_index()
# [___CELL_SEPARATOR___]
dftot["datum"] = pd.to_datetime(dftot['datum'])  
dftot["publicerad"] = pd.to_datetime(dftot['publicerad'])  
dftot.info()
# [___CELL_SEPARATOR___]
plot = dftot.publicerad.value_counts()[:40].plot.bar(y='counts', figsize=(25, 5)) 
plt.show()
# [___CELL_SEPARATOR___]
dftot.debattnamn.value_counts()   

# [___CELL_SEPARATOR___]
dftot.undertitel.value_counts()
# [___CELL_SEPARATOR___]
dftot.doktyp.value_counts()
# [___CELL_SEPARATOR___]
dftot.typ.value_counts()
# [___CELL_SEPARATOR___]
dftot.rm.value_counts(sort=False).sort_index()
# [___CELL_SEPARATOR___]
plot = dftot.rm.value_counts().sort_index()[0:30].plot.bar(y='counts', figsize=(25, 5)) 
plt.show()  

# [___CELL_SEPARATOR___]
import seaborn as sns
%matplotlib inline
%config InlineBackend.figure_format = 'svg'
# [___CELL_SEPARATOR___]
#sns.heatmap(dftot.isnull(), 
#            yticklabels=False, 
#            cbar=False, 
#            cmap='viridis')
# [___CELL_SEPARATOR___]
plt.show()
# [___CELL_SEPARATOR___]
pub = dftot.publicerad.value_counts().sort_index()[0:30].plot.bar(y='counts', figsize=(25, 5)) 
plt.show()
# [___CELL_SEPARATOR___]
pub = dftot.publicerad.value_counts().sort_index()[31:60].plot.bar(y='counts', figsize=(25, 5)) 
plt.show()
# [___CELL_SEPARATOR___]
