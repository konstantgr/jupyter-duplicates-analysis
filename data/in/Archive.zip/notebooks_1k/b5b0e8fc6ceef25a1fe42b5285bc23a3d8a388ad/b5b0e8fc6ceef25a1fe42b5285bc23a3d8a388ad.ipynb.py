# In google collab, uncomment this:
# !wget https://bit.ly/2FMJP5K -O setup.py && bash setup.py

# XVFB will be launched if you run on a server
# import os
# if type(os.environ.get("DISPLAY")) is not str or len(os.environ.get("DISPLAY")) == 0:
#     !bash ../xvfb start
#     %env DISPLAY = : 1
# [___CELL_SEPARATOR___]
import gym

#create a single game instance
env = gym.make("FrozenLake-v0")

#start new game
env.reset();
# [___CELL_SEPARATOR___]
# display the game state
env.render()
# [___CELL_SEPARATOR___]
print("initial observation code:", env.reset())
print('printing observation:')
env.render()
print("observations:", env.observation_space, 'n=', env.observation_space.n)
print("actions:", env.action_space, 'n=', env.action_space.n)
# [___CELL_SEPARATOR___]
print("taking action 2 (right)")
new_obs, reward, is_done, _ = env.step(2)
print("new observation code:", new_obs)
print("reward:", reward)
print("is game over?:", is_done)
print("printing new state:")
env.render()
# [___CELL_SEPARATOR___]
action_to_i = {
    'left':0,
    'down':1,
    'right':2,
    'up':3
}
# [___CELL_SEPARATOR___]
env.step(action_to_i['up'])
env.render()
# [___CELL_SEPARATOR___]
import numpy as np
n_states = env.observation_space.n
n_actions = env.action_space.n
# [___CELL_SEPARATOR___]
def get_random_policy():
    """
    Build a numpy array representing agent policy.
    This array must have one element per each of 16 environment states.
    Element must be an integer from 0 to 3, representing action
    to take from that state.
    """
    # policy = ...
    return policy
# [___CELL_SEPARATOR___]
np.random.seed(1234)
policies = [get_random_policy() for i in range(10**4)]
assert all([len(p) == n_states for p in policies]), 'policy length should always be 16'
assert np.min(policies) == 0, 'minimal action id should be 0'
assert np.max(policies) == n_actions-1, 'maximal action id should match n_actions-1'
action_probas = np.unique(policies, return_counts=True)[-1] /10**4. /n_states
print("Action frequencies over 10^4 samples:",action_probas)
assert np.allclose(action_probas, [1. / n_actions] * n_actions, atol=0.05), "The policies aren't uniformly random (maybe it's just an extremely bad luck)"
print("Seems fine!")
# [___CELL_SEPARATOR___]
def sample_reward(env, policy, t_max=100):
    """
    Interact with an environment, return sum of all rewards.
    If game doesn't end on t_max (e.g. agent walks into a wall), 
    force end the game and return whatever reward you got so far.
    Tip: see signature of env.step(...) method above.
    """
    s = env.reset()
    total_reward = 0
    
    for i in range(t_max):
        # action = ...
        s, reward, done, info = env.step(action)
        total_reward += reward
        if done:
            break
    return total_reward
# [___CELL_SEPARATOR___]
print("generating 10^3 sessions...")
rewards = [sample_reward(env,get_random_policy()) for _ in range(10**3)]
assert all([type(r) in (int, float) for r in rewards]), 'sample_reward must return a single number'
assert all([0 <= r <= 1 for r in rewards]), 'total rewards should be between 0 and 1 for frozenlake (if solving taxi, delete this line)'
print("Looks good!")
# [___CELL_SEPARATOR___]
def evaluate(policy, n_times=100):
    """Run several evaluations and average the score the policy gets."""
    # avg_reward = ...
    return avg_reward
        
# [___CELL_SEPARATOR___]
def print_policy(policy):
    """a function that displays a policy in a human-readable way."""
    lake = "SFFFFHFHFFFHHFFG"
    assert env.spec.id == "FrozenLake-v0", "this function only works with frozenlake 4x4"
    
    # where to move from each tile
    arrows = ['<v>^'[a] for a in policy]
    
    #draw arrows above S and F only
    signs = [arrow if tile in "SF" else tile for arrow, tile in zip(arrows, lake)]
    
    for i in range(0, 16, 4):
        print(' '.join(signs[i:i+4]))

print("random policy:")
print_policy(get_random_policy())
# [___CELL_SEPARATOR___]
best_policy = None
best_score = -float('inf')

from tqdm import tqdm
tr = tqdm(range(int(1e4)))
for i in tr:
    policy = get_random_policy()
    score = evaluate(policy)
    if score > best_score:
        best_score = score
        best_policy = policy
    tr.set_postfix({"best score:": best_score})
# [___CELL_SEPARATOR___]
def crossover(policy1, policy2, p=0.5, prioritize=False):
    """
    for each state, with probability p take action from policy1, else policy2
    """
    if prioritize:
        # wait for part II - moar
        pass
    # policy = ...
    return policy

# [___CELL_SEPARATOR___]
def mutation(policy, p=0.1):
    """
    for each state, with probability p replace action with random action
    Tip: mutation can be written as crossover with random policy
    """
    # new_policy = ...
    return new_policy
# [___CELL_SEPARATOR___]
np.random.seed(1234)
policies = [
    crossover(get_random_policy(), get_random_policy()) 
    for i in range(10**4)]

assert all([len(p) == n_states for p in policies]), 'policy length should always be 16'
assert np.min(policies) == 0, 'minimal action id should be 0'
assert np.max(policies) == n_actions-1, 'maximal action id should be n_actions-1'

assert any([
    np.mean(crossover(np.zeros(n_states), np.ones(n_states))) not in (0, 1)
    for _ in range(100)]), "Make sure your crossover changes each action independently"
print("Seems fine!")
# [___CELL_SEPARATOR___]

n_epochs = 20 #how many cycles to make
pool_size = 100 #how many policies to maintain
n_crossovers = 50 #how many crossovers to make on each step
n_mutations = 50 #how many mutations to make on each tick

# [___CELL_SEPARATOR___]
print("initializing...")
pool = [get_random_policy() for _ in range(pool_size)]
pool_scores = list(map(evaluate, pool))

# [___CELL_SEPARATOR___]
assert type(pool) == type(pool_scores) == list
assert len(pool) == len(pool_scores) == pool_size
assert all([type(score) in (float, int) for score in pool_scores])
# [___CELL_SEPARATOR___]
import random
from tqdm import tqdm

tr = tqdm(range(n_epochs))
for epoch in tr:
#     print("Epoch %s:"%epoch)
    crossovered = [
        crossover(random.choice(pool), random.choice(pool)) 
        for _ in range(n_crossovers)]
    mutated = [
        mutation(random.choice(pool)) 
        for _ in range(n_mutations)]
    
    assert type(crossovered) == type(mutated) == list
    
    # add new policies to the pool
    # pool = ...
    # pool_scores = ...
    
    # select pool_size best policies
    # selected_indices = ...
    # pool = ...
    # pool_scores = ...

    # print the best policy so far (last in ascending score order)
    tr.set_postfix({"best score:": pool_scores[-1]})
# [___CELL_SEPARATOR___]
def crossover(policy1, policy2, p=0.5, prioritize=False):
    """
    for each state, with probability p take action from policy1, else policy2
    """
    if prioritize:
        # the time has come
        pass
    # policy = ...
    return policy

# [___CELL_SEPARATOR___]
import random
from tqdm import tqdm

tr = tqdm(range(n_epochs))
for epoch in tr:
#     print("Epoch %s:"%epoch)
    crossovered = [
        crossover(
            random.choice(pool), 
            random.choice(pool), 
            prioritize=True) 
        for _ in range(n_crossovers)]
    mutated = [
        mutation(random.choice(pool)) 
        for _ in range(n_mutations)]
    
    assert type(crossovered) == type(mutated) == list
    
    # add new policies to the pool
    # pool = ...
    # pool_scores = ...
    
    # select pool_size best policies
    # selected_indices = ...
    # pool = ...
    # pool_scores = ...

    # print the best policy so far (last in ascending score order)
    tr.set_postfix({"best score:": pool_scores[-1]})
# [___CELL_SEPARATOR___]
#create a single game instance
env = gym.make("FrozenLake8x8-v0")

#start new game
env.reset()

# display the game state
env.render()

n_states = env.observation_space.n
n_actions = env.action_space.n
# [___CELL_SEPARATOR___]
n_epochs = 20 #how many cycles to make
pool_size = 100 #how many policies to maintain
n_crossovers = 50 #how many crossovers to make on each step
n_mutations = 50 #how many mutations to make on each tick
# [___CELL_SEPARATOR___]
print("initializing...")
pool = [get_random_policy() for _ in range(pool_size)]
pool_scores = list(map(evaluate, pool))
# [___CELL_SEPARATOR___]
import random
from tqdm import tqdm

tr = tqdm(range(n_epochs))
for epoch in tr:
#     print("Epoch %s:"%epoch)
    crossovered = [
        crossover(
            random.choice(pool), 
            random.choice(pool), 
            prioritize=True) 
        for _ in range(n_crossovers)]
    mutated = [
        mutation(random.choice(pool)) 
        for _ in range(n_mutations)]
    
    assert type(crossovered) == type(mutated) == list
    
    # add new policies to the pool
    # pool = ...
    # pool_scores = ...
    
    # select pool_size best policies
    # selected_indices = ...
    # pool = ...
    # pool_scores = ...

    # print the best policy so far (last in ascending score order)
    tr.set_postfix({"best score:": pool_scores[-1]})
# [___CELL_SEPARATOR___]
def sample_reward(env, policy, t_max=200):
    """
    Interact with an environment, return sum of all rewards.
    If game doesn't end on t_max (e.g. agent walks into a wall), 
    force end the game and return whatever reward you got so far.
    Tip: see signature of env.step(...) method above.
    """
    s = env.reset()
    total_reward = 0
    
    for i in range(t_max):
        action = policy[s]
        s, reward, done, info = env.step(action)
        total_reward += reward
        if done:
            break
    return total_reward
# [___CELL_SEPARATOR___]
# create a single game instance
env = gym.make("FrozenLake8x8-v0")

# start new game
env.reset()

# display the game state
env.render()

n_states = env.observation_space.n
n_actions = env.action_space.n
# [___CELL_SEPARATOR___]
n_epochs = 50 #how many cycles to make
pool_size = 200 #how many policies to maintain
n_crossovers = 100 #how many crossovers to make on each step
n_mutations = 100 #how many mutations to make on each tick
# [___CELL_SEPARATOR___]
print("initializing...")
pool = [get_random_policy() for _ in range(pool_size)]
pool_scores = list(map(evaluate, pool))
# [___CELL_SEPARATOR___]
import random
from tqdm import tqdm

tr = tqdm(range(n_epochs))
for epoch in tr:
#     print("Epoch %s:"%epoch)
    crossovered = [
        crossover(
            random.choice(pool), 
            random.choice(pool), 
            prioritize=True) 
        for _ in range(n_crossovers)]
    mutated = [
        mutation(random.choice(pool)) 
        for _ in range(n_mutations)]
    
    assert type(crossovered) == type(mutated) == list
    
    # add new policies to the pool
    # pool = ...
    # pool_scores = ...
    
    # select pool_size best policies
    # selected_indices = ...
    # pool = ...
    # pool_scores = ...

    # print the best policy so far (last in ascending score order)
    tr.set_postfix({"best score:": pool_scores[-1]})
# [___CELL_SEPARATOR___]
