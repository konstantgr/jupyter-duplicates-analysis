from collections import defaultdict
import glob
import os

from astropy.io import fits
from astroquery.mast import Mast
# [___CELL_SEPARATOR___]
service = "Mast.Jwst.Filtered.Miri"
params = {"columns":"*","filters":[]}
response = Mast.service_request_async(service,params)
result = response[0].json()
# [___CELL_SEPARATOR___]
type(result)
# [___CELL_SEPARATOR___]
result.keys()
# [___CELL_SEPARATOR___]
result['fields']
# [___CELL_SEPARATOR___]
result['data']
# [___CELL_SEPARATOR___]
len(result['data'])
# [___CELL_SEPARATOR___]
filenames = [item['filename'] for item in result['data']]
print(filenames)
# [___CELL_SEPARATOR___]
print(len(filenames))
print(len(set(filenames)))
# [___CELL_SEPARATOR___]
result['status']
# [___CELL_SEPARATOR___]
result['paging']
# [___CELL_SEPARATOR___]
result['msg']
# [___CELL_SEPARATOR___]
services = ['Mast.Jwst.Filtered.Nircam', 'Mast.Jwst.Filtered.Nirspec',
            'Mast.Jwst.Filtered.Niriss', 'Mast.Jwst.Filtered.Miri', 
            'Mast.Jwst.Filtered.Fgs']
for service in services:
    params = {"columns":"*","filters":[]}
    response = Mast.service_request_async(service,params)
    result = response[0].json()
    print('{}: {} rows'.format(service, len(result['data'])))
# [___CELL_SEPARATOR___]
service = "Mast.Jwst.Filtered.Miri"
params = {"columns":"filename, expstart",
          "filters":[{"paramName":"expstart",
                      "values":[{"min":57404.04, "max":57404.07}],}]}
response = Mast.service_request_async(service,params)
result = response[0].json()
# [___CELL_SEPARATOR___]
result['data']
# [___CELL_SEPARATOR___]
service = "Mast.Jwst.Filtered.Miri"
params = {"columns":"filename, date_obs",
          "filters":[{"paramName":"date_obs",
                      "values":[{"min":'01-17-2016', "max":'01-18-2016'}],
                     }]}
response = Mast.service_request_async(service,params)
result = response[0].json()
# [___CELL_SEPARATOR___]
len(result['data'])
# [___CELL_SEPARATOR___]
result['data']
# [___CELL_SEPARATOR___]
service = "Mast.Jwst.Filtered.Miri"
params = {"columns":"filename, expstart, isRestricted, publicReleaseDate",
          "filters":[]}
response = Mast.service_request_async(service,params)
result = response[0].json()
# [___CELL_SEPARATOR___]
result['data']
# [___CELL_SEPARATOR___]
print(len(result['data']))
# [___CELL_SEPARATOR___]
instruments = ['Nircam', 'Niriss', 'Nirspec', 'Miri', 'Fgs']
services = ["Mast.Jwst.Filtered.{}".format(instrument) for instrument in instruments]
results = []
params = {"columns":"filename, expstart, isRestricted, publicReleaseDate",
          "filters":[]}
for service in services:
    response = Mast.service_request_async(service,params)
    result = response[0].json()
    results.extend(result['data'])
# [___CELL_SEPARATOR___]
results
# [___CELL_SEPARATOR___]
print(len(results))
# [___CELL_SEPARATOR___]
from collections import defaultdict
service = "Mast.Jwst.Filtered.Nircam"
params = {"columns":"filename, filter",
          "filters":[{"paramName":"date_obs",
                      "values":[{"min":'01-17-2016', "max":'01-18-2016'}],
                     }]}
response = Mast.service_request_async(service,params)
result = response[0].json()
results_dict = defaultdict(int)
for item in result['data']:
    results_dict[item['filter']] += 1
# [___CELL_SEPARATOR___]
for item in results_dict:
    print('{}: {}'.format(item, results_dict[item]))
# [___CELL_SEPARATOR___]
test_filename = '/our/test/file/base/directory/jw00329003001_02101_00001_nrca2_rate.fits' # Note the full path is excluded for security reasons
# [___CELL_SEPARATOR___]
# Get set of all header keywords that exist in PRIMARY and SCI extension of files
header0_keys_fits = set(list(fits.getheader(test_filename, 0).keys()))
header0_keys_fits = set([item.lower().replace('-', '_') for item in header0_keys_fits])
header1_keys_fits = set(list(fits.getheader(test_filename, 1).keys()))
header1_keys_fits = set([item.lower().replace('-', '_') for item in header1_keys_fits])
header_keys_fits = header0_keys_fits | header1_keys_fits
# [___CELL_SEPARATOR___]
# Get set of all keywords available in the MAST API
service = "Mast.Jwst.Filtered.Nircam"
params = {"columns":"*","filters":[{"paramName":"filename",
                          "values":[os.path.basename(test_filename)]}]}
response = Mast.service_request_async(service,params)
result = response[0].json()
header_keys_db = set(list(result['data'][0].keys()))
# [___CELL_SEPARATOR___]
# Keywords that are in the MAST API but not the FITS headers
header_keys_db - header_keys_fits
# [___CELL_SEPARATOR___]
# Keywords that are in the FITS headers but not the MAST API
header_keys_fits - header_keys_db
# [___CELL_SEPARATOR___]
local_filenames = glob.glob('/our/test/file/base/directory/*/*.fits')
# [___CELL_SEPARATOR___]
suffixes = []
for filename in local_filenames:
    fileonly = os.path.split(filename)[1]
    suff = fileonly.split('_')[-1]
    if suff not in suffixes:
        suffixes.append(suff)
# [___CELL_SEPARATOR___]
suffixes
# [___CELL_SEPARATOR___]
all_filenames = [f for f in local_filenames if 'trapsfilled' not in f]
# [___CELL_SEPARATOR___]
len(all_filenames)
# [___CELL_SEPARATOR___]
all_header_keys = set()
for infile in all_filenames:
    # Get set of all header keywords that exist in PRIMARY and SCI extension of files
    header0_keys_fits = set(list(fits.getheader(infile, 0).keys()))
    header0_keys_fits = set([item.lower().replace('-', '_') for item in header0_keys_fits])
    header1_keys_fits = set(list(fits.getheader(infile, 1).keys()))
    header1_keys_fits = set([item.lower().replace('-', '_') for item in header1_keys_fits])
    header_keys_fits = header0_keys_fits | header1_keys_fits
    all_header_keys = all_header_keys | header_keys_fits
# [___CELL_SEPARATOR___]
len(all_header_keys)
# [___CELL_SEPARATOR___]
# Get set of all keywords available in the MAST API across all services
services = ['Mast.Jwst.Filtered.Nircam', 'Mast.Jwst.Filtered.Nirspec',
            'Mast.Jwst.Filtered.Niriss', 'Mast.Jwst.Filtered.Miri', 
            'Mast.Jwst.Filtered.Fgs']
header_keys_db = []
for service in services:
    params = {"columns":"*","filters":[]}
    response = Mast.service_request_async(service,params)
    result = response[0].json()
    header_keys_db.extend(list(result['data'][0].keys()))

header_keys_db = set(header_keys_db)
# [___CELL_SEPARATOR___]
# Keywords that are in the MAST API but not the FITS headers
header_keys_db - all_header_keys
# [___CELL_SEPARATOR___]
# Keywords that are in the FITS headers but not the MAST API
all_header_keys - header_keys_db
# [___CELL_SEPARATOR___]
len(all_header_keys - header_keys_db)
# [___CELL_SEPARATOR___]
