import matplotlib
import matplotlib.pyplot as plt
import scipy
import scipy.ndimage
from keras.utils import np_utils

import numpy as np
from keras.datasets import mnist
# [___CELL_SEPARATOR___]
(X_train_base, y_train_base), (X_test_base, y_test_base) = mnist.load_data()

# [___CELL_SEPARATOR___]
print("nombre d'image en entrée ",X_train_base.shape,X_test_base.shape)
print("taille sortie",y_train_base.shape,y_test_base.shape)
print(y_train_base[0:10],"les sorties des 10 premieres images")


# [___CELL_SEPARATOR___]
plt.imshow(X_train_base[0])

# [___CELL_SEPARATOR___]
def plot_10_by_10_images(images):
    """ Plot 100 MNIST images in a 10 by 10 table. Note that we crop
    the images so that they appear reasonably close together.  The
    image is post-processed to give the appearance of being continued."""
    fig = plt.figure()
    images = [image[3:25, 3:25] for image in images]
    #image = np.concatenate(images, axis=1)
    for x in range(10):
        for y in range(10):
            ax = fig.add_subplot(10, 10, 10*y+x+1)
            ax.matshow(images[10*y+x+1], cmap = matplotlib.cm.binary)
            plt.xticks(np.array([]))
            plt.yticks(np.array([]))
    plt.show()

plot_10_by_10_images(X_train_base)
# [___CELL_SEPARATOR___]
nb_classes=10
X_train = X_train_base.reshape(60000, 784)
X_test = X_test_base.reshape(10000, 784)
X_train = X_train.astype("float32")
X_test = X_test.astype("float32")
X_train /= 255
X_test /= 255
y_train = y_train_base
y_test = y_test_base
# [___CELL_SEPARATOR___]
print(X_train_base.shape)
print(X_train.shape)
# [___CELL_SEPARATOR___]
from sklearn.linear_model import LogisticRegression

# A COMPLETER

# Créer un modèle de régression logistique
model=None

# Entraîner le modèle

# [___CELL_SEPARATOR___]
# A COMPLETER

# Prédire les chiffres correspondant aux images de X_test

predictions=None
predictions
# [___CELL_SEPARATOR___]
from sklearn.metrics import accuracy_score
accuracy=accuracy_score(predictions,y_test)
print(accuracy)
# [___CELL_SEPARATOR___]
from sklearn.ensemble import RandomForestClassifier
model=RandomForestClassifier(n_estimators=7,verbose=1,max_features=10)

# A COMPLETER

# Entraîner le modèle

# Prédire les chiffres correspondant aux images de X_test
predictions = None

# Calculer l'accuracy
accuracy = None
print(accuracy)
# [___CELL_SEPARATOR___]
from sklearn import svm
model=svm.SVC(C=1.0, kernel="rbf", degree=3)

# A COMPLETER

# Entraîner le modèle

# Prédire les chiffres correspondant aux images de X_test
predictions = None

# Calculer l'accuracy
accuracy = None
print(accuracy)
# [___CELL_SEPARATOR___]
