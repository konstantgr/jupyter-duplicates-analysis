# from sklearn.linear_model import LogisticRegression

# # In the multiclass case, the training algorithm uses the one-vs-rest (OvR) scheme 
# # if the ‘multi_class’ option is set to ‘ovr’
# # If the option chosen is ‘ovr’, then a binary problem is fit for each label. 
# clf = LogisticRegression(multi_class='ovr')
# [___CELL_SEPARATOR___]
from sklearn.multiclass import OneVsRestClassifier

OneVsRestClassifier??
# [___CELL_SEPARATOR___]
reset -fs
# [___CELL_SEPARATOR___]
# Load handwritten, then digitized digits
from sklearn import datasets

digits = datasets.load_digits()
X = digits.images.reshape((len(digits.images), -1))
y = digits.target
# [___CELL_SEPARATOR___]
# What is this digit?
import matplotlib.pyplot as plt
%matplotlib inline

i = -1
plt.imshow(digits.images[i], cmap=plt.cm.gray_r, interpolation='nearest');
# [___CELL_SEPARATOR___]
print(f"That digit is a {y[i]}")
# [___CELL_SEPARATOR___]
from sklearn.linear_model import LogisticRegression

clf = LogisticRegression(multi_class='multinomial',
                         solver='lbfgs',
                        max_iter=2)
clf.fit(X, y)
# [___CELL_SEPARATOR___]
import numpy as np
# [___CELL_SEPARATOR___]
# Select random digit
i = np.random.choice(X.shape[0])
plt.imshow(digits.images[i], cmap=plt.cm.gray_r, interpolation='nearest');
sample_train = X[i].reshape(1, -1)
# [___CELL_SEPARATOR___]
for k, v in enumerate(clf.predict_proba(sample_train)[0]):
    print(f"For class {k}, the probability is {v:.15f}")
# [___CELL_SEPARATOR___]
print(f"That digit is a {y[i]}") 
# [___CELL_SEPARATOR___]
# Print confusion matrix
from sklearn.metrics import confusion_matrix

y_pred = clf.predict(X)
cm = confusion_matrix(y, y_pred)
print(cm)
# [___CELL_SEPARATOR___]
from pprint_cm import pprint_cm

pprint_cm(cm, labels = [str(_) for _ in list(range(0, 10))])
# [___CELL_SEPARATOR___]
# Print classification_report
from sklearn.metrics import classification_report

print(classification_report(y, y_pred))