import tensorflow as tf; print(tf.__version__)
# [___CELL_SEPARATOR___]
import cv2; print(cv2.__version__)
# [___CELL_SEPARATOR___]
