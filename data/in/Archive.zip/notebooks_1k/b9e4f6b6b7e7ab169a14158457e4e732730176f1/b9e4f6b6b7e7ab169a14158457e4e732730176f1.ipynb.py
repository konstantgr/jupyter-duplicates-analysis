from time import sleep

def inc(x):
    from random import random
    sleep(random())
    return x + 1

def dec(x):
    from random import random
    sleep(random())
    return x - 1
    
def add(x, y):
    from random import random
    sleep(random())
    return x + y
# [___CELL_SEPARATOR___]
%%time
x = inc(1)
y = dec(2)
z = add(x, y)
z
# [___CELL_SEPARATOR___]
import dask
inc = dask.delayed(inc)
dec = dask.delayed(dec)
add = dask.delayed(add)
# [___CELL_SEPARATOR___]
%%time
x = inc(1)
y = dec(2)
z = add(x, y)
z
# [___CELL_SEPARATOR___]
z
# [___CELL_SEPARATOR___]
z.visualize(rankdir='LR')
# [___CELL_SEPARATOR___]
%%time
z.compute()
# [___CELL_SEPARATOR___]
from dask.distributed import Client, progress
c = Client()
c
# [___CELL_SEPARATOR___]
z.compute()
# [___CELL_SEPARATOR___]
%%time
zs = []
for i in range(256):
    x = inc(i)
    y = dec(x)
    z = add(x, y)
    zs.append(z)
    
zs = dask.persist(*zs)
total = dask.delayed(sum)(zs)
# [___CELL_SEPARATOR___]
total.compute()
# [___CELL_SEPARATOR___]
L = zs
while len(L) > 1:
    new_L = []
    for i in range(0, len(L), 2):
        lazy = add(L[i], L[i + 1])  # add neighbors
        new_L.append(lazy)
    L = new_L                       # swap old list for new
# [___CELL_SEPARATOR___]
dask.visualize(*L)
# [___CELL_SEPARATOR___]
dask.compute(L)