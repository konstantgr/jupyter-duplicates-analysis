suppressPackageStartupMessages(library(igraph))
# [___CELL_SEPARATOR___]
sif_data <- read.table("shared/pathway_commons.sif",
                       header=FALSE,
                       stringsAsFactors=FALSE,
                       col.names=c("species1",
                                   "interaction_type",
                                   "species2"),
                       quote="",
                       comment.char="")
# [___CELL_SEPARATOR___]
interac_grn <- sif_data[sif_data$interaction_type %in% c("controls-expression-of"), c(1,3)]
interac_grn_unique <- unique(interac_grn)
# [___CELL_SEPARATOR___]
grn_igraph <- graph_from_data_frame(interac_grn_unique, directed=TRUE)
# [___CELL_SEPARATOR___]
N <- length(V(grn_igraph))
harmonic_closeness_centralities <- sapply(V(grn_igraph),
                                            function(my_vertex) {
                                                my_dists <- distances(grn_igraph, v=my_vertex)
                                                sum(1/my_dists[my_dists > 0])/(N-1)
                                          })
# [___CELL_SEPARATOR___]
library(repr)
options(repr.plot.width=4, repr.plot.height=4)
hist(harmonic_closeness_centralities)
# [___CELL_SEPARATOR___]
plot(degree(grn_igraph), harmonic_closeness_centralities,
     xlab=expression(k[i]),
     ylab=expression("C'"[i]),
     log="x")
# [___CELL_SEPARATOR___]
harmonic_closeness_centralities[which.max(harmonic_closeness_centralities)]
# [___CELL_SEPARATOR___]
which.max(degree(grn_igraph))
# [___CELL_SEPARATOR___]
head(sort(round(harmonic_closeness_centralities, 3), decreasing=TRUE), n=10)
# [___CELL_SEPARATOR___]
