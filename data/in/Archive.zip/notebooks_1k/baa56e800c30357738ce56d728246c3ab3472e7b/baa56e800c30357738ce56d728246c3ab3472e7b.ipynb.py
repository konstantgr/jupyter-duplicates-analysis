text = '''
D'w. Nuss vo Bümpliz geit dür d'Strass
liecht u flüchtig, wie nes Gas
so unerreichbar höch

Bockstössigi Himbeerbuebe
schüüch u brav wie Schaf
schön föhnfrisiert
chöme tubetänzig nöch

U d'Spargle wachse i bluetjung Morge
d'Sunne chunnt 's wird langsam warm

Sie het meh als hundert ching
u jede Früehlig git 's es nöis
het d'Chiuchefänschterouge off
u macht se zue bi jedem Kuss
u we sie lachet wärde Bärge zu schtoub
u jedes zäihe Läderhärz wird weich

D'w. Nuss vo Bümpliz
isch schön win es Füür i dr Nacht
win e Rose im Schnee
we se gseh duss in Bümpliz
de schlat mir mis Härz hert i Hals
u i gseh win i ungergah

Si wohnt im ne Huus us Glas
hinger Türe ohni Schloss
gseht dür jedi Muur
dänkt wi nes Füürwärch
win e Zuckerstock
läbt win e Wasserfau
für si git's nüt, wo's nid git
u aus wo's git, git's nid für ging
si nimmt's wi's chunnt u lat's la gah

D'w. Nuss vo Bümpliz
isch schön win es Füür i dr Nacht
win e Rose im Schnee
we se gseh duss in Bümpliz
de schlat mir mis Härz hert i Hals
u i gseh win i ungergah
'''
# [___CELL_SEPARATOR___]
import re
# [___CELL_SEPARATOR___]
suchausdruck = r"n.ss"
# [___CELL_SEPARATOR___]
resultat = re.search(r"n.ss", text, re.IGNORECASE)
# [___CELL_SEPARATOR___]
resultat 
# [___CELL_SEPARATOR___]
resultat.group() #Der gefundene String
# [___CELL_SEPARATOR___]
resultat.start() #die Startposition des gefundenen Strings
# [___CELL_SEPARATOR___]
resultat.end() #die Endposition des gefundenen Strings
# [___CELL_SEPARATOR___]
re.search(r"^Bockstössigi", text, re.MULTILINE)
# [___CELL_SEPARATOR___]
re.match("a", "abcdef") #gibt ein Ergebnis
# [___CELL_SEPARATOR___]
re.match("b", "abcdef") #gibt kein Ergebnis
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
words = re.findall(r"\b[iu]\b", text, re.IGNORECASE) #Alle Wörter, die nur aus "i" oder "u" bestehen
# [___CELL_SEPARATOR___]
words
# [___CELL_SEPARATOR___]
len(words)
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
newlist = re.split(r"\b[iu]\b", text) #Wir splitten überall, wo i- und u-Wörter stehen
# [___CELL_SEPARATOR___]
for line in newlist:
    print(line)
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
neuer_text = re.sub(r"\bi\b", "çu", text) #Ersetzt alle i durch çu
neuer_text = re.sub(r"\bI\b", "çU", neuer_text) #Grossbuchstaben separat

neuer_text = re.sub(r"\bu\b", "i", neuer_text) #Ersetzt alle u durch i
neuer_text = re.sub(r"\bU\b", "I", neuer_text) #Grossbuchstaben separat

neuer_text = re.sub(r"\bçu\b", "u", neuer_text) #Ersetzt alle çu durch i
neuer_text = re.sub(r"\bçU\b", "U", neuer_text) #Grossbuchstaben separat

print(neuer_text)
# [___CELL_SEPARATOR___]
re.findall(r"\b\w*ü\w\b", text) # Zum Testen: Alle Wörter mit einem ü drin
# [___CELL_SEPARATOR___]
def replace(match): # Diese Funktion wollen wir drauf anwenden (wir kriegen das Resultat als Match-Objekt geliefert)
    word = match.group() + " - oh, yeah! - "
    return word
# [___CELL_SEPARATOR___]
neuer_text = re.sub(r"\b\w*ü\w\b", replace, text) #Hier rufen wir unsere replace-Funktion auf
# [___CELL_SEPARATOR___]
print (neuer_text)
# [___CELL_SEPARATOR___]
re.findall(r"\b\w*ss\w*\b ", text) #Hier suchen wir zuerst mal nur alle Wörter, die zwei ss drin haben
# [___CELL_SEPARATOR___]
re.findall(r"\b\w*ss\w*\b \w+", text) #Nun suchen wir alle Wörter, die zwei ss drin haben plus das nächste Wort
# [___CELL_SEPARATOR___]
re.findall(r"\b\w*ss\w*\b (\w+)", text) #Jetzt wollen wir nur das nächste Wort einfangen
# [___CELL_SEPARATOR___]
re.findall(r"(\b\w*ss\w*\b) (\w+)", text) #Jetzt fangen wir die beiden Wörter separat ein
# [___CELL_SEPARATOR___]
re.findall(r"w.(?= Nuss)", text) #Lookahead
# [___CELL_SEPARATOR___]
re.findall(r"(?<=w. )Nuss", text) #Lookbehind
# [___CELL_SEPARATOR___]
# Finde alle b's im Text (Liste erstellen)
re.findall(r"b", text)
# [___CELL_SEPARATOR___]
# Finde alle Wörter, die mit b beginnen, unabhängig von Gross-/Kleinschreibung
re.findall(r"\bb\w*", text, re.IGNORECASE)
# [___CELL_SEPARATOR___]
# Finde alle Wörter, die ein b enthalten, unabhängig von Gross-/Kleinschreibung
re.findall(r"\w*b\w*", text, re.IGNORECASE)
# [___CELL_SEPARATOR___]
# Erstelle eine Liste aller Zeilen im Text
re.findall(r"^.+$", text, re.MULTILINE)
# [___CELL_SEPARATOR___]
# eine Liste aller Wörter, die mit Grossbuchstaben beginnen
re.findall(r"\b[A-Z]\w*", text)
# [___CELL_SEPARATOR___]
# Eine Liste aller Wörter, die mehr als 8 Buchstaben haben
re.findall(r"\b\w{8,}\b", text)
# [___CELL_SEPARATOR___]
# Eine Liste aller Wörte, die einen Doppelvokal enthalten (z.B. "geit")
re.findall(r"\w*[aeiouäöü]{2}\w*", text)
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
# Welches Wort kommt im Text öfter vor: "w. Nuss" oder "Bümpliz"?
n_wnuss = len(re.findall(r"w. Nuss", text))
n_buempliz = len(re.findall(r"Bümpliz", text))
if n_wnuss > n_buempliz:
    print("w. Nuss")
elif n_wnuss == n_buempliz:
    print("gleich oft")
else:
    print("Bümpliz")
# [___CELL_SEPARATOR___]
# An welcher Position (Zeichen-Nr) steht das Wort "Zuckerstock"?
re.search(r"Zuckerstock", text).start()
# [___CELL_SEPARATOR___]
# Sortieren Sie die Liedzeilen nach der Länge der Zeile
lines = sorted(re.findall(r"^.+$", text, re.MULTILINE),key=len, reverse=True)
lines
# [___CELL_SEPARATOR___]
# Welches ist die längste Liedzeile?
max(lines, key=len)
# [___CELL_SEPARATOR___]
# Ersetzen Sie "v. Nuss" durch "Venus"
print(re.sub(r"w\. Nuss", "Venus", text))
# [___CELL_SEPARATOR___]
# Entfernen Sie alle Wörter, die weniger als 3 Buchstaben lang sind, aus dem Text
print(re.sub(r"\b\w{1,2}\b", "", text))
# [___CELL_SEPARATOR___]
# Entfernen Sie alle Wörter, die weniger als 3 Buchstaben lang sind, sowie alle Sonderzeichen aus dem Text
print(re.sub(r"\b\w{1,2}\b|[.,']", "", text))
# [___CELL_SEPARATOR___]
# Entfernen Sie alle Wörter, die weniger als 4 Buchstaben lang sind, sowie alle Sonderzeichen aus dem Text
# Dann reduzieren Sie alle doppelten und dreifachen Leerschläge auf einen Leerschlag (die Strophen intakt lassen)
# Dann entfernen Sie alle Leerschläge am Anfang von Zeilen. (Achtung, hier braucht es flags=re.MULTILINE)

newtext = re.sub(r"\b\w{1,3}\b|[.',]", "", text)
newtext = re.sub(r" {2,}", " ", newtext)
newtext = re.sub(r"^ ", "", newtext, flags=re.MULTILINE)
print(newtext)
# [___CELL_SEPARATOR___]
# Entfernen Sie den letzten Buchstaben aus jedem Wort
print(re.sub(r"(\w)\b", "", text))
# [___CELL_SEPARATOR___]
# Konvertieren Sie alles zu Kleinbuchstaben
# Dann erstellen Sie eine Liste aller Wörter im Text
# Dann sortieren Sie die Liste alphabetisch - jedes Wort soll nur einmal vorkommen
woerter = re.findall(r"\b\w+\b", text.lower())
set(sorted(woerter))
# [___CELL_SEPARATOR___]
# Wie viele unterschiedliche Wörter kommen im Text vor?
set(sorted(woerter))
# [___CELL_SEPARATOR___]
# Welcher Buchstabe steht am häufigsten vor einem "ä" (Gross/Kleinschreibung egal)?
buchstaben = re.findall(r"\w(?=ä)", text.lower())
max(buchstaben, key=buchstaben.count)
# [___CELL_SEPARATOR___]
# Liste aller Buchstaben, die nochmals vom selben Buchstaben gefolgt werden
re.findall(r"(\w)\1", text)
# [___CELL_SEPARATOR___]
# Ersetzen Sie sämtliche Doppelbuchstaben (zB "aa") durch einfache Buchstaben ("a)
# Achtung: Sie müssen eine separate (Lambda-)Funktion dafür schreiben

print(re.sub(r"(\w)\1", lambda m: m.group()[0], text))
# [___CELL_SEPARATOR___]
match = re.search(r"(\w)(\w+)(\w)", text) #Findet ein Wort, das mindestens 4 Buchstaben hat, fängt 3 Gruppen ein
# [___CELL_SEPARATOR___]
match.group() #Der ganze gematchte Inhalt
# [___CELL_SEPARATOR___]
match.group(1) #Nur der Inhalt der ersten Unterruppe
# [___CELL_SEPARATOR___]
match.group(3) #Nur der Inhalt der dritten Untergruppe
# [___CELL_SEPARATOR___]
# Vertauschen Sie in sämtlichen Wörtern mit mindestens 3 Buchstaben den ersten und letzten Buchstaben
# Achtung: Sie müssen eine separate (Lambda-)Funktion dafür schreiben
def replace(match):
    return match.group(3) + match.group(2) + match.group(1)
# [___CELL_SEPARATOR___]
print(re.sub(r"(\w)(\w+)(\w)", replace, text))
# [___CELL_SEPARATOR___]
# Wirbeln Sie die Wörter, die auf einer Zeile stehen, durcheinander. (Die Zeilen-Reihenfolge bleibt aber intakt)
# Bsp:
# w dür D Bümpliz d Nuss Strass vo geit
# flüchtig liecht u wie Gas nes
...
# [___CELL_SEPARATOR___]
#Tipp 1: Hier ist eine Shuffle-Funktion
from random import shuffle
my_list = ["a", "b", "c", "d", "e"]
shuffle(my_list)
my_list
# [___CELL_SEPARATOR___]
# Tipp 2: List comprehension (massiv) benutzen
[element.upper() for element in my_list]
# [___CELL_SEPARATOR___]
# Tipp 3: .join() benutzen
" ".join(my_list)
# [___CELL_SEPARATOR___]
#Braucht ca 3-5 Zeilen Code...
lines = re.findall(r"^.*$", text, re.MULTILINE)
word_lines = [re.findall(r"\b\w+\b", line) for line in lines]
[shuffle(word_line) for word_line in word_lines]
lines = [" ".join(word_line) for word_line in word_lines]
print("\n".join(lines))
# [___CELL_SEPARATOR___]
