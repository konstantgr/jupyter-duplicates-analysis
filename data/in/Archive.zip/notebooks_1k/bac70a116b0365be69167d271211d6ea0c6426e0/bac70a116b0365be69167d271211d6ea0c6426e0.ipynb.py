<a id="Change this into a code cell"></a>
# Great
## Wow
### Amazing
#### Super

1. Eat
2. _Sleep_
3. **Code**
> Build machine learning models  

`Write more code`

- double click this cell to edit  

Create fancy $functions$

<font color="red">Data Science.</font>  

<img src=https://api.apsportal.ibm.com/v2/nav/graphics/dsx-logo-lg.svg width=100 align=left> 
# [___CELL_SEPARATOR___]
from geopy.geocoders import Nominatim # module to convert an address into latitude and longitude values
import requests # library to handle requests
import pandas as pd # library for data analsysis
import numpy as np # library to handle data in a vectorized manner
import random # library for random number generation
 
# tranforming json file into a pandas dataframe library
from pandas.io.json import json_normalize

!pip install folium
import folium # plotting library

print "Folium installed"
print "Libraries imported."
# [___CELL_SEPARATOR___]
CLIENT_ID = "your-client_id-here"
CLIENT_SECRET = "your-client_secret-here"
VERSION = "20170511"
LIMIT = 30
print "Your credentails:"
print "CLIENT_ID: " + CLIENT_ID
print "CLIENT_SECRET:" + CLIENT_SECRET
# [___CELL_SEPARATOR___]
address = "315 Hudson Street New York, NY"

geolocator = Nominatim()
location = geolocator.geocode(address)
latitude = location.latitude
longitude = location.longitude
print latitude, longitude
# [___CELL_SEPARATOR___]
search_query = "Italian Restaurant"
print search_query + " ¯\_(ツ)_/¯ .... OK!"
# [___CELL_SEPARATOR___]
radius = 1000
url="https://api.foursquare.com/v2/venues/search?client_id={}&client_secret={}&ll={},{}&v={}&query={}&radius={}&limit={}".format(CLIENT_ID, CLIENT_SECRET, latitude, longitude, VERSION, search_query, radius, LIMIT)
url
# [___CELL_SEPARATOR___]
results = requests.get(url).json()
results
# [___CELL_SEPARATOR___]
# assign relevant part of JSON to venues
venues = results["response"]["venues"]

# tranform venues into a dataframe
dataframe = json_normalize(venues)
dataframe.head()
# [___CELL_SEPARATOR___]
# keep only columns that include venue name, url, and anything that is associated with location
filtered_columns = ['name', 'url', 'categories', 'verified'] + [col for col in dataframe.columns if col.startswith('location.')] + ['id']
dataframe_filtered = dataframe.ix[:, filtered_columns]

# function that extracts the category of the venue
def get_category_type(row):
    try:
        categories_list = row["categories"]
    except:
        categories_list = row["venue.categories"]
        
    if len(categories_list) == 0:
        return None
    else:
        return categories_list[0]["name"].encode('ascii',errors='ignore')

# filter the category for each row
dataframe_filtered['categories'] = dataframe_filtered.apply(get_category_type, axis=1)

# clean column names by keeping only last term
dataframe_filtered.columns = [column.split(".")[-1] for column in dataframe_filtered.columns]
dataframe_filtered.head(10)
# [___CELL_SEPARATOR___]
# define URL for categories
url = "https://api.foursquare.com/v2/venues/categories?client_id={}&client_secret={}&v={}".format(CLIENT_ID, CLIENT_SECRET, VERSION)

# send call request and get categories
results = requests.get(url).json()
categories = results["response"]["categories"]

# loop through categories and print them
total = 0
for i in range(len(categories)):
    main_category = categories[i]["name"]
    print "Main Category: " + main_category, categories[i]["id"]
    count = 0
    for category in categories[i]["categories"]:
        print category["name"], category["id"]
        count += 1
        total += 1
    print count
print total
# [___CELL_SEPARATOR___]
category_id = "4bf58dd8d48988d110941735" # ID for Italian restaurants 
url="https://api.foursquare.com/v2/venues/search?client_id={}&client_secret={}&ll={},{}&v={}&radius={}&query={}&categoryId={}&limit={}".format(CLIENT_ID, CLIENT_SECRET, latitude, longitude, VERSION, radius, search_query, category_id, LIMIT)
url
# [___CELL_SEPARATOR___]
# send GET request
results = requests.get(url).json()
results
# [___CELL_SEPARATOR___]
# send GET request
results = requests.get(url).json()

# assign relevant part of JSON to venues
venues = results["response"]["venues"]

# tranform venues into a dataframe
dataframe = json_normalize(venues)

# filter columns
dataframe_filtered = dataframe.ix[:, filtered_columns]

# filter the category for each row
dataframe_filtered['categories'] = dataframe_filtered.apply(get_category_type, axis=1)

# clean column names by keeping only last term
dataframe_filtered.columns = [column.split(".")[-1] for column in dataframe_filtered.columns]
dataframe_filtered.head(10)
# [___CELL_SEPARATOR___]
venues_map = folium.Map(location=[latitude, longitude], zoom_start=15) # generate map centred around Galvanize


# create a feature group for Galvanize and add it to the map
galvanize = folium.map.FeatureGroup()
galvanize.add_child(
    folium.features.CircleMarker(
        [latitude, longitude],
        radius = 10,
        color = "red",
        fill_color = "red",
        fill_opacity = 0.6
    )
)
venues_map.add_child(galvanize)


# create a feature group for the Italian restaurants around Galvanize and add it to the map
restaurants = folium.map.FeatureGroup()
for lat, lng, in zip(dataframe_filtered.lat, dataframe_filtered.lng):
    restaurants.add_child(
        folium.features.CircleMarker(
            [lat, lng],
            radius=5,
            color="blue",
            fill_color="blue",
            fill_opacity=0.6)
        )
venues_map.add_child(restaurants)


# add labels to each point on the map
latitudes_list = list(dataframe_filtered.lat) + [latitude]
longitudes_list = list(dataframe_filtered.lng) + [longitude]
labels = list(dataframe_filtered.name) + ["Galvanize"]

for lat, lng, label in zip(latitudes_list, longitudes_list, labels):
    folium.Marker([lat, lng], popup=label).add_to(venues_map)

# display map
venues_map
# [___CELL_SEPARATOR___]
venue_id = "5018507fe4b03a729d0b40f9" # ID of Galli Restaurant
url="https://api.foursquare.com/v2/venues/{}?client_id={}&client_secret={}&v={}".format(venue_id, CLIENT_ID, CLIENT_SECRET, VERSION)
url
# [___CELL_SEPARATOR___]
result = requests.get(url).json()
result["response"]["venue"].keys()
# [___CELL_SEPARATOR___]
result["response"]["venue"]["rating"]
# [___CELL_SEPARATOR___]
result["response"]["venue"]["tips"]["count"]
# [___CELL_SEPARATOR___]
## Galli Restaurant tips
limit = 150 # set limit to be greater than the total number of tips
url="https://api.foursquare.com/v2/venues/{}/tips?client_id={}&client_secret={}&v={}&limit={}".format(venue_id, CLIENT_ID, CLIENT_SECRET, VERSION, limit)

results = requests.get(url).json()
results
# [___CELL_SEPARATOR___]
tips = results["response"]["tips"]["items"]

tip = results["response"]["tips"]["items"][0]
tip.keys()
# [___CELL_SEPARATOR___]
pd.set_option('display.max_colwidth', -1)

tips_df = json_normalize(tips) # json normalize tips

# columns to keep
filtered_columns = ["text", "agreeCount", "disagreeCount", "id", "user.firstName", "user.lastName", "user.gender", "user.id"]
tips_filtered = tips_df.ix[:, filtered_columns]

# display tips
tips_filtered
# [___CELL_SEPARATOR___]
user_id="15149512" # user ID with most agree counts and complete profile

url="https://api.foursquare.com/v2/users/{}?client_id={}&client_secret={}&v={}".format(user_id, CLIENT_ID, CLIENT_SECRET, VERSION) # define URL

# send GET request
results = requests.get(url).json()
user_data = results["response"]["user"]

# display features associated with user
user_data.keys()
# [___CELL_SEPARATOR___]
print "First Name: " + user_data["firstName"]
print "Last Name: " + user_data["lastName"]
print "Home City: " + user_data["homeCity"]
# [___CELL_SEPARATOR___]
user_data["tips"]
# [___CELL_SEPARATOR___]
# define tips URL
url="https://api.foursquare.com/v2/users/{}/tips?client_id={}&client_secret={}&v={}&limit={}".format(user_id, CLIENT_ID, CLIENT_SECRET, VERSION, limit)

# send GET request and get user's tips
results = requests.get(url).json()
tips = results["response"]["tips"]["items"]

# format column width
pd.set_option('display.max_colwidth', -1)

tips_df = json_normalize(tips)

# filter columns
filtered_columns = ["text", "agreeCount", "disagreeCount", "id"]
tips_filtered = tips_df.ix[:, filtered_columns]

# display user's tips
tips_filtered
# [___CELL_SEPARATOR___]
tip_id = "56fc15bb498e44ba0b86da1a" # tip id

# define URL
url = "http://api.foursquare.com/v2/tips/{}?client_id={}&client_secret={}&v={}".format(tip_id, CLIENT_ID, CLIENT_SECRET, VERSION)

# send GET Request and examine results
result = requests.get(url).json()
print result["response"]["tip"]["venue"]["name"]
print result["response"]["tip"]["venue"]["location"]
# [___CELL_SEPARATOR___]
user_friends = json_normalize(user_data["friends"]["groups"][0]["items"])
user_friends
# [___CELL_SEPARATOR___]
latitude = 40.721628
longitude = -74.001227
# [___CELL_SEPARATOR___]
url="https://api.foursquare.com/v2/venues/explore?client_id={}&client_secret={}&ll={},{}&v={}&radius={}&limit={}".format(CLIENT_ID, CLIENT_SECRET, latitude, longitude, VERSION, radius, LIMIT)
url
# [___CELL_SEPARATOR___]
results = requests.get(url).json()
results
# [___CELL_SEPARATOR___]
items = results["response"]["groups"][0]["items"]
items[0]["venue"].keys()
# [___CELL_SEPARATOR___]
dataframe = json_normalize(items) # flatten JSON

# filter columns
filtered_columns = ['venue.name', 'venue.url', 'venue.categories'] + ["venue.rating"] + [col for col in dataframe.columns if col.startswith('venue.location.')] + ["venue.id"]
dataframe_filtered = dataframe.ix[:, filtered_columns]

# filter the category for each row
dataframe_filtered['venue.categories'] = dataframe_filtered.apply(get_category_type, axis=1)

# clean columns
dataframe_filtered.columns = [col.split(".")[-1] for col in dataframe_filtered.columns]

dataframe_filtered.head(10)
# [___CELL_SEPARATOR___]
venues_map = folium.Map(location=[latitude, longitude], zoom_start=15) # generate map centred around Galli Restaurant


# create a feature group for Galli Restaurant and add it to the map
galli = folium.map.FeatureGroup()
galli.add_child(
    folium.features.CircleMarker(
        [latitude, longitude],
        radius = 10,
        color = "red",
        fill_color = "red",
        fill_opacity = 0.6
    )
)
venues_map.add_child(galli)


# create a feature group for popular venues around Galli Restaurant and add it to the map
popular_venues = folium.map.FeatureGroup()
for lat, lng, in zip(dataframe_filtered.lat, dataframe_filtered.lng):
    popular_venues.add_child(
        folium.features.CircleMarker(
            [lat, lng],
            radius=5,
            color="blue",
            fill_color="blue",
            fill_opacity=0.6)
        )
venues_map.add_child(popular_venues)


# add labels to each point on the map
latitudes_list = list(dataframe_filtered.lat) + [latitude]
longitudes_list = list(dataframe_filtered.lng) + [longitude]
labels = list(dataframe_filtered.name) + ["Galli Restaurant"]
venue_categories = list(dataframe_filtered.categories) + [""]

for lat, lng, label, category in zip(latitudes_list, longitudes_list, labels, venue_categories):
    popup_text = label + ", " + category
    folium.Marker([lat, lng], popup=popup_text).add_to(venues_map)

# display map
venues_map
# [___CELL_SEPARATOR___]
# define URL
url="https://api.foursquare.com/v2/venues/trending?client_id={}&client_secret={}&ll={},{}&v={}".format(CLIENT_ID, CLIENT_SECRET, latitude, longitude, VERSION)

# send GET request and get trending venues
results = requests.get(url).json()
results
# [___CELL_SEPARATOR___]
if len(results["response"]["venues"]) == 0:
    print "No trending venues are available at the moment!"
    
else:
    trending_venues = results["response"]["venues"]
    trending_venues_df = json_normalize(trending_venues)

    # filter columns
    columns_filtered = ["name", "url", "categories"] + [col for col in trending_venues_df.columns if col.startswith("stats")] + ["location.distance", "location.address", "location.city", "location.postalCode", "location.state", "location.country", "location.lat", "location.lng"]
    trending_venues_df = trending_venues_df.ix[:, columns_filtered]

    # filter the category for each row
    trending_venues_df['categories'] = trending_venues_df.apply(get_category_type, axis=1)

    # display trending venues
    trending_venues_df
# [___CELL_SEPARATOR___]
if len(results["response"]["venues"]) == 0:
    print "Can't generate visual as no trending venues are available at the moment!"

else:
    venues_map = folium.Map(location=[latitude, longitude], zoom_start=15) # generate map centred around Galli Restaurant


    # create a feature group for Galli Restaurant and add it to the map
    galli = folium.map.FeatureGroup()
    galli.add_child(
        folium.features.CircleMarker(
            [latitude, longitude],
            radius = 10,
            color = "red",
            fill_color = "red",
            fill_opacity = 0.6
        )
    )
    venues_map.add_child(galli)


    # create a feature group for popular venues around Galli Restaurant and add it to the map
    trending_venues = folium.map.FeatureGroup()
    for lat, lng, in zip(trending_venues_df["location.lat"], trending_venues_df["location.lng"]):
        popular_venues.add_child(
            folium.features.CircleMarker(
                [lat, lng],
                radius=5,
                color="blue",
                fill_color="blue",
                fill_opacity=0.6
            )
        )
    venues_map.add_child(trending_venues)


    # add labels to each point on the map
    latitudes_list = list(trending_venues_df["location.lat"]) + [latitude]
    longitudes_list = list(trending_venues_df["location.lng"]) + [longitude]
    labels = list(trending_venues_df.name) + ["Galli Restaurant"]
    venue_categories = list(trending_venues_df.categories) + [""]

    for lat, lng, label, category in zip(latitudes_list, longitudes_list, labels, venue_categories):
        popup_text = label + ", " + category
        folium.Marker([lat, lng], popup=popup_text).add_to(venues_map)

    # display map
    venues_map
# [___CELL_SEPARATOR___]
!wget -O crime_data_SF.csv https://ibm.box.com/shared/static/z2rjkrelj9fc87d1lrw6gkm9sb91zu5h.csv
# [___CELL_SEPARATOR___]
crime_data = pd.read_csv('crime_data_SF.csv')
print "CSV file read into a pandas dataframe"
# [___CELL_SEPARATOR___]
crime_data.head(5)
# [___CELL_SEPARATOR___]
crime_data.shape
# [___CELL_SEPARATOR___]
crime_data_jun = crime_data[(crime_data["Date"] >= '2016-06-01') & (crime_data["Date"] <= '2016-06-30')]
crime_data_jun.reset_index(inplace=True, drop=True)
crime_data_jun.shape
# [___CELL_SEPARATOR___]
crime_data_jun.notnull().sum()
# [___CELL_SEPARATOR___]
jun_categories_count = crime_data_jun.Category.value_counts()
print "There at {} types of crimes. And the top 10 are:".format(len(jun_categories_count))
print jun_categories_count.head(10)
# [___CELL_SEPARATOR___]
# a function that returns the categories and the distances of the 10 closest venues to a crime scene
def get_nearby_venues(row):
    
    latitude = row["Y"]
    longitude = row["X"]
    
    # create the URL using the latitude and longitude of the crime scene
    url = "https://api.foursquare.com/v2/venues/explore?client_id={}&client_secret={}&ll={},{}&v={}".format(CLIENT_ID, CLIENT_SECRET, latitude, longitude, VERSION)
    
    # send the GET request and get the venues
    results = requests.get(url).json()
    venues = results["response"]["groups"][0]["items"]
    
    # convert the venues JSON into a dataframe for efficient processing
    dataframe = json_normalize(venues)
    
    # extract the categories and sort the venues by ascending order of distance and reset indices
    dataframe['venue.categories'] = dataframe.apply(get_category_type, axis=1)
    dataframe.sort_values(['venue.location.distance'], ascending=[True], inplace=True)
    dataframe.reset_index(inplace=True, drop=True)
    
    # return categories of the 10 closest venues
    num_venues = 10
    categories_nearby_venues = dataframe.loc[0:num_venues, "venue.categories"].str.cat(sep=', ')
    distances_nearby_venues = (dataframe.loc[0:num_venues, "venue.location.distance"].apply(str)).str.cat(sep=', ')
    return categories_nearby_venues, distances_nearby_venues

def get_nearby_venues_categories(row):
    return get_nearby_venues(row)[0]

def get_nearby_venues_distances(row):
    return get_nearby_venues(row)[1]
# [___CELL_SEPARATOR___]
def print_most_common_categories(crime):
    # filter data for the given crime
    crime_category_data = crime_data[crime_data["Category"] == crime]
    crime_category_data.reset_index(inplace=True, drop=True)

    # randomly select 10 crimes of this category
    random.seed(1234)
    num_crimes = 10
    sample_rows = np.arange(len(crime_category_data))
    np.random.shuffle(sample_rows)
    crime_category_data = crime_category_data.ix[sample_rows[0:num_crimes], :]
    crime_category_data.reset_index(inplace=True, drop=True)
    crime_category_data.head()
    
    # create columns of nearby venues categories and distances
    crime_category_data["nearby_categories"] = crime_category_data.apply(get_nearby_venues_categories, axis=1)
    crime_category_data["nearby_distances"] = crime_category_data.apply(get_nearby_venues_distances, axis=1)

    # process columns to compute mean distance
    most_common_categories = crime_category_data["nearby_categories"].str.cat(sep=', ')
    most_common_categories = most_common_categories.split(", ")
    most_common_categories_distances = crime_category_data["nearby_distances"].str.cat(sep=', ')
    most_common_categories_distances = map(int, most_common_categories_distances.split(", "))

    # print average distance for each category
    summary_dataframe = pd.DataFrame(columns = ['Category', 'Distance'])
    summary_dataframe["Category"] = pd.Series(most_common_categories)
    summary_dataframe["Distance"] = pd.Series(most_common_categories_distances)
    print summary_dataframe.groupby(["Category"])["Distance"].mean().sort_values()
# [___CELL_SEPARATOR___]
crime = "VEHICLE THEFT"
print_most_common_categories(crime)
# [___CELL_SEPARATOR___]
DUI = crime_data_jun.loc[crime_data_jun["Category"] == "DRIVING UNDER THE INFLUENCE"] # subset dataframe for driving under the influence crimes
DUI.head() # display the first five instances
# [___CELL_SEPARATOR___]
# get_closest_distance is a function that returns the distance between the crime scene and the closest bar
def get_closest_distance(row):
    
    latitude = row["Y"] # get latitude value of crime scene
    longitude = row["X"] # get longitude value of crime scence
    
    search_query = "bar" # define search query

    # define URL and send GET request
    url="https://api.foursquare.com/v2/venues/search?client_id={}&client_secret={}&ll={},{}&v={}&query={}&limit={}".format(CLIENT_ID, CLIENT_SECRET, latitude, longitude, VERSION, search_query, LIMIT)
    results = requests.get(url).json()

    # Get venues from returned results
    venues = results["response"]["venues"]
    bars_df = json_normalize(venues)

    # filter columns
    filtered_columns = ['name', 'url'] + [col for col in bars_df.columns if col.startswith('location')]
    bars_df = bars_df.ix[:, filtered_columns]

    # clean column names by keeping only last term
    bars_df.columns = [column.split(".")[-1] for column in bars_df.columns]

    # return distance
    bars_df.sort_values(['distance'], ascending=True, inplace=True)
    return bars_df["distance"][0] 
# [___CELL_SEPARATOR___]
DUI["closest_distance"] = DUI.apply(get_closest_distance, axis=1) # add column of distance to closest bar for each crime incident
# [___CELL_SEPARATOR___]
DUI.groupby(["Category"])["closest_distance"].mean() # compute the mean