# !wget https://object.pouta.csc.fi/OPUS-Tanzil/v1/raw/en.zip
# !wget https://object.pouta.csc.fi/OPUS-Tanzil/v1/raw/ms.zip
# !unzip -o en.zip
# !unzip -o ms.zip
# [___CELL_SEPARATOR___]
# !wget https://object.pouta.csc.fi/OPUS-Tanzil/v1/xml/en-ms.xml.gz
# !gzip -d en-ms.xml.gz
# [___CELL_SEPARATOR___]
from bs4 import BeautifulSoup
from tqdm import tqdm

with open('en-ms.xml') as fopen:
    xml = fopen.read().split('\n')
    
mapping, ids = {}, []
enable = False
for row in tqdm(xml):
    if '<linkGrp targType' in row:
        s = BeautifulSoup(row)
        r = 'Tanzil/raw/' + s.findAll('linkgrp')[0].get('fromdoc').replace('.gz','')
        l = 'Tanzil/raw/' + s.findAll('linkgrp')[0].get('todoc').replace('.gz','')
        enable = True
    if '<link ' in row and enable:
        s = BeautifulSoup(row)
        t = s.findAll('link')[0].get('xtargets')
        t = list(filter(None, t.split(';')))
        if len(t) != 2:
            continue
        ids.append([t[0].split(), t[1].split()])
    if '</linkGrp>' in row:
        label = f'{l} <> {r}'
        mapping[label] = ids
        enable = False
        ids = []
# [___CELL_SEPARATOR___]
results = []
for file in tqdm(mapping.keys()):
    l, r = file.split(' <> ')
    ids = mapping[file]
    try:
        with open(l) as fopen:
            left = fopen.read()
        soup_left = BeautifulSoup(left, 'html.parser')
        with open(r) as fopen:
            right = fopen.read()
        soup_right = BeautifulSoup(right, 'html.parser')
        left_dict = {}
        for s in soup_left.find_all('s'):
            i = s.get('id')
            text = s.get_text()
            left_dict[i] = text
        right_dict = {}
        for s in soup_right.find_all('s'):
            i = s.get('id')
            text = s.get_text()
            right_dict[i] = text
        combined = []
        for i in ids:
            try:
                r = ' '.join([right_dict[k] for k in i[0]])
                l = ' '.join([left_dict[k] for k in i[1]])
                combined.append((l, r))
            except:
                pass
        results.extend(combined)
    except Exception as e:
        print(e)
        pass
# [___CELL_SEPARATOR___]
len(results)
# [___CELL_SEPARATOR___]
results[:10]
# [___CELL_SEPARATOR___]
import json

with open('tanzil-ms-en.json', 'w') as fopen:
    json.dump(results, fopen)
# [___CELL_SEPARATOR___]
!rm -rf Tanzil
!rm -rf ms.zip en.zip
!rm -rf ms.zip en.zip en-ms.xml.gz en-ms.xml