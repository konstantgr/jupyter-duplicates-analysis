using Optim, Dates

include("printmat.jl")
# [___CELL_SEPARATOR___]
using Plots

#pyplot(size=(600,400))
gr(size=(480,320))
default(fmt = :svg)
# [___CELL_SEPARATOR___]
function fn1(x,c)                    #notice: the function has two arguments
  value = 2*(x - 1.1)^2 - c
  return value
end
# [___CELL_SEPARATOR___]
x = -1:0.1:3

p1 = plot( x,fn1.(x,0.5),
           linecolor = :red,
           linewidth = 2,
           legend = nothing,
           title = "the fn1(x,0.5) function",
           xlabel = "x",
           ylabel = "y" )
display(p1)
# [___CELL_SEPARATOR___]
Sol = optimize(x->fn1(x,0.5),-2.0,3.0)
println(Sol)

printlnPs("\nThe minimum is at: ", Optim.minimizer(Sol))     #the optimal x value
println("Compare with the plot above\n")
# [___CELL_SEPARATOR___]
Solb = optimize(x->fn1(x[],0.5),[0.1],LBFGS())

printlnPs("The minimum is at: ", Optim.minimizer(Solb))
# [___CELL_SEPARATOR___]
function fn2(p)
    (x,y) = (p[1],p[2])          #unpack the choice variables and get nicer names
     L    = (x-2)^2 + (4*y+3)^2
    return L
end
# [___CELL_SEPARATOR___]
nx = 2*41
ny = 2*61
x = range(1,stop=5,length=nx)
y = range(-1,stop=0,length=ny)

loss2d = fill(NaN,(nx,ny))      #matrix with loss fn values
for i = 1:nx, j = 1:ny
    loss2d[i,j] = fn2([x[i];y[j]])
end
# [___CELL_SEPARATOR___]
p1 = contour( x,y,loss2d',       #notice: loss2d'
              xlims = (1,5),
              ylims = (-1,0),
              legend = false,
              levels = 21,
              title = "Contour plot of loss function",
              xlabel = "x",
              ylabel = "y" )
scatter!([2],[-0.75],label="optimum",legend=true)
display(p1)
# [___CELL_SEPARATOR___]
Sol = optimize(fn2,[0.0;0.0])        #use p->lossfn(p,other arguments) if 
                                     #there are additional (non-choice) arguments
printlnPs("minimum at (x,y)= ",Optim.minimizer(Sol))
# [___CELL_SEPARATOR___]
p1 = contour( x,y,loss2d',
              xlims = (1,5),
              ylims = (-1,0),
              legend = false,
              levels = 21,
              title = "Contour plot of loss function",
              xlabel = "x",
              ylabel = "y",
              annotation = (3.5,-0.7,text("somewhere here",8)) )
plot!([2.75,2.75],[-1,0.5],color=:red,linewidth=2,label="2.75 < x",legend = true)
plot!([1,5],[-0.3,-0.3],color=:black,linewidth=2,label="y < -0.3")
scatter!([2.75],[-0.75],color=:red,label="optimum")
display(p1)
# [___CELL_SEPARATOR___]
lower = [2.75, -Inf]
upper = [Inf, -0.3]

Sol = optimize(fn2,lower,upper,[3.0,-0.5])
printlnPs("The optimum is at (x,y) = ",Optim.minimizer(Sol))
# [___CELL_SEPARATOR___]
function g2(x)                        #derivatives of fn2 wrt. x[1] and x[2]
    G = [2*(x[1]-2), 2*4(4*x[2]+3)]   #creates a new vector: use inplace = false in optimize()
    return G
end

Sol3 = optimize(fn2,g2,[1.0,-0.5],inplace=false)
println(Sol3)
# [___CELL_SEPARATOR___]
