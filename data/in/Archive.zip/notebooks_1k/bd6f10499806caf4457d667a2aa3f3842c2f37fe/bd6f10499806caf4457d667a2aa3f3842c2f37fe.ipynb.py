import oommfc as oc
import discretisedfield as df
import micromagneticmodel as mm
# [___CELL_SEPARATOR___]
import numpy as np

lx = ly = 120e-9  # x and y dimensions of the sample(m)
lz = 10e-9  # sample thickness (m)
dx = dy = dz = 5e-9  # discretisation in x, y, and z directions (m)

Ms = 8e5  # saturation magnetisation (A/m)
A = 1.3e-11  # exchange energy constant (J/m)
H = 8e4 * np.array([0.81345856316858023, 0.58162287266553481, 0.0])
alpha = 0.008  # Gilbert damping
gamma0 = 2.211e5
# [___CELL_SEPARATOR___]
mesh = df.Mesh(p1=(0, 0, 0), p2=(lx, ly, lz), cell=(dx, dy, dz))

system = mm.System(name='stdprobfmr')

system.energy = mm.Exchange(A=A) + mm.Demag() + mm.Zeeman(H=H)
system.dynamics = mm.Precession(gamma0=gamma0) + mm.Damping(alpha=alpha)
system.m = df.Field(mesh, dim=3, value=(0, 0, 1), norm=Ms)
# [___CELL_SEPARATOR___]
md = oc.MinDriver()
md.drive(system)
# [___CELL_SEPARATOR___]
%matplotlib inline
system.m.plane('z', n=(10, 10)).mpl()
# [___CELL_SEPARATOR___]
# Change external magnetic field.
H = 8e4 * np.array([0.81923192051904048, 0.57346234436332832, 0.0])
system.energy.zeeman.H = H
# [___CELL_SEPARATOR___]
T = 20e-9
n = 4000

td = oc.TimeDriver()
td.drive(system, t=T, n=n)
# [___CELL_SEPARATOR___]
import matplotlib.pyplot as plt

t = system.table.data['t'].values
my = system.table.data['mx'].values

# Plot <my> time evolution.
plt.figure(figsize=(8, 6))
plt.plot(t, my)
plt.xlabel('t (ns)')
plt.ylabel('my average')
plt.grid()
# [___CELL_SEPARATOR___]
import scipy.fftpack

psd = np.log10(np.abs(scipy.fftpack.fft(my))**2)
f_axis = scipy.fftpack.fftfreq(4000, d=20e-9/4000)

plt.plot(f_axis/1e9, psd)
plt.xlim([6, 12])
plt.xlabel('f (GHz)')
plt.ylabel('Psa (a.u.)')
plt.grid()