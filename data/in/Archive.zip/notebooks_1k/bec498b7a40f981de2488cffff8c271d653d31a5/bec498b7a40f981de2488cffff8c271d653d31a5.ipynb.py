import matplotlib.pyplot as plt
from matplotlib import colors, ticker
import pandas as pd
import numpy as np
import scipy as sp
from astropy.table import Table
import astropy.units as u
import astropy.coordinates as coord
import seaborn as sns
from astroquery.simbad import Simbad
from astroquery.vizier import Vizier

import kinesis as kn
import gapipes as gp
# [___CELL_SEPARATOR___]
Vizier.ROW_LIMIT = -1   # query the entire catalog

# Cantat-Gaudin2019
original = Vizier.get_catalogs("J/A+A/626/A17")[0]
# [___CELL_SEPARATOR___]
original[:3]
# [___CELL_SEPARATOR___]
table_fulldr2 = gp.gaia.query_sourceid(original[['Source']], 'Source')
# [___CELL_SEPARATOR___]
assert set(table_fulldr2['source_id']) == set(original['Source'])
# [___CELL_SEPARATOR___]
ct2019_columns = ["Prob", "Pop"]
table_fulldr2_ct2019 = table_fulldr2.merge(
    original[["Source"] + ct2019_columns]
    .to_pandas()
    .rename(columns={"Source": "source_id"}),
    on="source_id",
)
# [___CELL_SEPARATOR___]
table_fulldr2_ct2019['Pop'].value_counts().sort_index()
# [___CELL_SEPARATOR___]
grp = table_fulldr2_ct2019.groupby('Pop')
srcdf = grp.get_group(7)
# [___CELL_SEPARATOR___]
necessary_columns = [
    "ra",
    "dec",
    "phot_g_mean_mag",
    "parallax",
    "pmra",
    "pmdec",
    "parallax_error",
    "pmra_error",
    "pmdec_error",
    "parallax_pmra_corr",
    "parallax_pmdec_corr",
    "pmra_pmdec_corr",
]
data = srcdf[
    necessary_columns + ["radial_velocity", "radial_velocity_error"]
].copy()
b0 = data.g.icrs.cartesian.xyz.value.mean(axis=1)
print(f"{len(data)} rows")
print(f"b0 = {b0}")

N = len(data)
irv = np.arange(N)[data["radial_velocity"].notna()]
rv = data["radial_velocity"].values[irv]
rv_error = data["radial_velocity_error"].values[irv]
data_dict = {
    "N": N,
    "Nrv": data["radial_velocity"].notna().sum(),
    "ra": data["ra"].values,
    "dec": data["dec"].values,
    "a": data[["parallax", "pmra", "pmdec"]].values,
    "C": data.g.make_cov(),
    "irv": irv,
    "rv": rv,
    "rv_error": rv_error,
    "include_T": 1,
    "b0": b0,
}

def stan_init():
    return dict(
        d=1e3 / data["parallax"].values,
        sigv=[0.5, 0.5, 0.5],
        Omega=np.eye(3),
        v0=[-5, 45, -5],
        T=np.zeros(shape=(1, 3, 3)),
        v0_bg=[0, 0, 0],
        sigv_bg=50.0,
        f_mem=0.95,
    )

stanmodel = kn.get_model("allcombined")
fit = stanmodel.optimizing(
    data=data_dict,
    init=stan_init,
#     pars=[
#         "v0",
#         "sigv",
#         "Omega",
#         "T_param",
#         "v0_bg",
#         "sigv_bg",
#         "f_mem",
#         "probmem",
#         "a_model",
#         "rv_model",
#     ],
)
# kn.save_stanfit(fit, outfile)
# [___CELL_SEPARATOR___]
fit['v0']
# [___CELL_SEPARATOR___]
vxyz = srcdf.g.icrs.velocity.d_xyz.value
xyz = srcdf.g.icrs.cartesian.xyz.value
plt.scatter(vxyz[0],vxyz[1])
# [___CELL_SEPARATOR___]
fig, ax = plt.subplots(dpi=100)
for l, g in grp:
    vxyz = g.g.icrs.velocity.d_xyz.value

    ax.scatter(vxyz[0],vxyz[1], s=1)
# [___CELL_SEPARATOR___]
