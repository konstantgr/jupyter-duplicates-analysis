%matplotlib inline
# [___CELL_SEPARATOR___]
import rockhound as rh
import matplotlib.pyplot as plt
import cmocean

# Load a version of the topography grid
grid = rh.fetch_etopo1(version="bedrock")
print(grid)

# Select a subset that corresponds to Africa to make plotting faster given the
# size of the grid.
africa = grid.sel(latitude=slice(-40, 45), longitude=slice(-20, 60))

# Plot the age grid.
# We're not using a map projection to speed up the plotting but this NOT
# recommended.
plt.figure(figsize=(9, 8))
ax = plt.subplot(111)
africa.bedrock.plot.pcolormesh(
    cmap=cmocean.cm.topo, cbar_kwargs=dict(pad=0.01, aspect=30), ax=ax
)
ax.set_title("ETOPO1")
plt.tight_layout()
plt.show()