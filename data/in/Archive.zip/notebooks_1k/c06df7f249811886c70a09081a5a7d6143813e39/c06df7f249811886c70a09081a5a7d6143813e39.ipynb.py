import autotst
# [___CELL_SEPARATOR___]
"""
Getting some test reactions to use as examples.
"""

from autotst.reaction import Reaction
test_labels = [
    'C+[CH2]COC(=O)C(C)C_CCOC(=O)C(C)C+[CH3]',
    #'O+[CH2]C(C)CC(C)C(C)=O_CC(=O)C(C)CC(C)C+[OH]',
    #'O+[CH2]C(C)OC(CC)CC_CCC(CC)OC(C)C+[OH]',
    #'O+[CH2]COC(=O)C(C)C_CCOC(=O)C(C)C+[OH]',
    #'O+[CH]=CC(C)=CCCC(=C)C_C=CC(C)=CCCC(=C)C+[OH]',
    #'OO+[CH2]C(=C)C(=O)CC_C=C(C)C(=O)CC+[O]O',
    #'OO+[CH2]C(=C)CC(C)=O_C=C(C)CC(C)=O+[O]O',
    #'OO+[CH2]C(=C)CCC=C(C)C=C_C=CC(C)=CCCC(=C)C+[O]O',
    #'OO+[CH2]C(=O)C(=C)C_C=C(C)C(C)=O+[O]O',
    #'OO+[CH2]C(=O)C(C)(C)C_CC(=O)C(C)(C)C+[O]O'
]

test_reactions = [Reaction(label, reaction_family='H_Abstraction') for label in test_labels]
# [___CELL_SEPARATOR___]
# Getting the new stuff
import autotst.update as UPmethods

#Required
reaction = test_reactions[0] #Can be list of reactions or singular reaction
family = 'H_Abstraction'

# Optional
method = 'm062x/6-311+G(2df,2p)'
shortDesc = 'M06-2X/6-311+G(2df,2p) calculation via group additive TS generator.'


UPmethods.update_all(reaction, family, method=method, shortDesc=shortDesc)
UPmethods.update_all?
# [___CELL_SEPARATOR___]
#Some more sample work


"""
 Provide list of families you wish to update and get 
     using whatever dictionary.txt and reactions.py available
"""

families = ['H_Abstraction']

# Call this method to recieve a dictionary of Updater Instances (which themselves carry the updated databases and info)
family_instances = UPmethods.TS_Database_Update(families)
#updater_methods.TS_Database_Update?

h_ab_updater_instance = family_instances['H_Abstraction']
training_set = h_ab_updater_instance.training_set
database = h_ab_updater_instance.database


# [___CELL_SEPARATOR___]
database.groups.entries
# [___CELL_SEPARATOR___]
training_set
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
