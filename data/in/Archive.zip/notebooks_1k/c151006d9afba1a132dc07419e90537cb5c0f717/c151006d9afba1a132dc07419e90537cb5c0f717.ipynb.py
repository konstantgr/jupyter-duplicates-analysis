import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
# [___CELL_SEPARATOR___]
x = np.linspace(-10, 10)
y = np.sin(x)
# [___CELL_SEPARATOR___]
df = pd.DataFrame([x, y]).T
df.columns = ['x', 'y']
df.head()
# [___CELL_SEPARATOR___]
plt.plot(x, y);
# [___CELL_SEPARATOR___]
print("Python data stack is fully operational >:)")