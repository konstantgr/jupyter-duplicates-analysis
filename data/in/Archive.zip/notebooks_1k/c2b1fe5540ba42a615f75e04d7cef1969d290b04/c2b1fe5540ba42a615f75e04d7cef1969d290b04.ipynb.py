import csv
import os
from collections import defaultdict
import pandas as pd
from nltk.corpus import stopwords
from textblob import TextBlob, Word
from gensim.scripts.glove2word2vec import glove2word2vec
from nltk.stem import PorterStemmer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.feature_extraction.text import CountVectorizer
from gensim.models import KeyedVectors # load the Stanford GloVe model
import ftfy
#nltk.download()
# [___CELL_SEPARATOR___]
#reading csv
train = pd.read_csv('output.csv', encoding='ISO-8859-1',low_memory=False)
#train
# [___CELL_SEPARATOR___]
train = train[train.notnull()]
#train
# [___CELL_SEPARATOR___]
train = train.dropna(how='any') 
train
# [___CELL_SEPARATOR___]
heads = train['title']
heads
# [___CELL_SEPARATOR___]
descs = train['content']
descs
# [___CELL_SEPARATOR___]
heads = heads[:95]
descs = descs[:95]
# [___CELL_SEPARATOR___]
list_title = []
for i in heads:
    title = ftfy.fix_text(i)
    list_title.append(title)
    #print(title)
    #print('---------------')     
# [___CELL_SEPARATOR___]
list_title
# [___CELL_SEPARATOR___]
list_content = []
for i in descs:
    descs = ftfy.fix_text(i)
    list_content.append(descs)
    #print(descs)
    #print('---------------')    
# [___CELL_SEPARATOR___]
list_content
# [___CELL_SEPARATOR___]
percentile_list = pd.DataFrame(
    {'heads': list_title,
     'descs': list_content,
    })
# [___CELL_SEPARATOR___]
percentile_list.to_pickle('clean_data.pickle')
# [___CELL_SEPARATOR___]
df2 = pd.read_pickle('clean_data.pickle')
df2
# [___CELL_SEPARATOR___]
new_list = (zip(list_title[:95], list_content[:95]))
new_list
# [___CELL_SEPARATOR___]
print(len(list_content))
print(len(list_title))        
# [___CELL_SEPARATOR___]
with open('same.csv', 'w', newline='', encoding = 'utf-8') as fileN:
    writer = csv.writer(fileN)
    writer.writerows(new_list)
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
#Number of stopwords
stop = stopwords.words('english')
# [___CELL_SEPARATOR___]
train['stopwords_content'] = train['content'].apply(lambda x: len([x for x in x.split() if x in stop]))
train[['content','stopwords']].head()
# [___CELL_SEPARATOR___]
train = pd.read_csv('same.csv', encoding='ISO-8859-1',low_memory=False)

# [___CELL_SEPARATOR___]
print(type(train['content']))
# [___CELL_SEPARATOR___]
#transform title data into lower case
percentile_list = heads.apply(lambda x: " ".join(x.lower() for x in x.split()))
heads
# [___CELL_SEPARATOR___]
#transform content data into lower case
descs = descs.apply(lambda x: " ".join(x.lower() for x in x.split()))
descs
# [___CELL_SEPARATOR___]
#Removing Punctuation
train = train.str.replace('[^\w\s]','')
train
# [___CELL_SEPARATOR___]
train.to_csv('output_cleaned_title.csv', index=False)
# [___CELL_SEPARATOR___]
#Removal of Stop Words
#train['content'] = train['content'].apply(lambda x: " ".join(x for x in x.split() if x not in stop))
#train['content'].head()
# [___CELL_SEPARATOR___]
#Common word removal
#freq = pd.Series(' '.join(train['content']).split()).value_counts()[:10]
#freq
# [___CELL_SEPARATOR___]
#freq = list(freq.index)
#train['content'] = train['content'].apply(lambda x: " ".join(x for x in x.split() if x not in freq))
#train['content'].head()
# [___CELL_SEPARATOR___]
#Rare words removal
#rare = pd.Series(' '.join(train['content']).split()).value_counts()[-10:]
#rare
# [___CELL_SEPARATOR___]
#rare = list(rare.index)
#train['content'] = train['content'].apply(lambda x: " ".join(x for x in x.split() if x not in rare))
#train['content'].head()
# [___CELL_SEPARATOR___]
#Tokenization - dividing the text into a sequence of words or sentences
#we have used the textblob library to first transform our data into a blob and then converted them into a series of words
tokenized_words=[]
for i,x in enumerate(heads):
    if(len(x) > 1 ):
        tokenized_words = TextBlob(x).words
# [___CELL_SEPARATOR___]
heads
# [___CELL_SEPARATOR___]
#Tokenization - dividing the text into a sequence of words or sentences
#we have used the textblob library to first transform our data into a blob and then converted them into a series of words
tokenized_words=[]
for i,x in enumerate(descs):
    if(len(x) > 1 ):
        tokenized_words_descs = TextBlob(x).words
# [___CELL_SEPARATOR___]
#Stemming -  removal of suffices, like “ing”, “ly”, “s”
#st = PorterStemmer()
#train['content'].apply(lambda x: " ".join([st.stem(word) for word in x.split()]))
# [___CELL_SEPARATOR___]
#Lemmatization - it converts the word into its root word
#train['content'] = train['content'].apply(lambda x: " ".join([Word(word).lemmatize() for word in x.split()]))
#train['content'].head()
# [___CELL_SEPARATOR___]
#N-grams - combination of multiple words used together.
#j=[]
#for i,x in enumerate(train['content']):
    #j = TextBlob(x).ngrams(2)



# [___CELL_SEPARATOR___]
# Term frequency - ratio of the count of a word present in a sentence, to the length of the sentence
#tf1 = (train['content']).apply(lambda x: pd.value_counts(x.split(" "))).sum(axis = 0).reset_index()
#tf1.columns = ['words','tf']
#tf1
# [___CELL_SEPARATOR___]
#Inverse Document Frequency - log of the ratio of the total number of rows to the number of rows in which that word is present
#import numpy as np
#for i,word in enumerate(tf1['words']):
  #tf1.loc[i, 'idf'] = np.log(train.shape[0]/(len(train[train['content'].str.contains(word)])))

#tf1
# [___CELL_SEPARATOR___]
#Term Frequency – Inverse Document Frequency (TF-IDF) - multiplication of the TF and IDF 
#tf1['tfidf'] = tf1['tf'] * tf1['idf']
#tf1

# [___CELL_SEPARATOR___]
#tfidf = TfidfVectorizer(max_features=1000, lowercase=True, analyzer='word',
#stop_words= 'english',ngram_range=(1,1))
#train_vect = tfidf.fit_transform(train['content'])

#train_vect

# [___CELL_SEPARATOR___]
#Bag of Words - representation of text which describes the presence of words within the text data
#bow = CountVectorizer(max_features=1000, lowercase=True, ngram_range=(1,1),analyzer = "word")
#train_bow = bow.fit_transform(train['content'])
#train_bow

# [___CELL_SEPARATOR___]
# Word Embeddings
#glove_input_file = 'glove.6B.100d.txt'
#word2vec_output_file = 'glove.6B.100d.txt.word2vec'
# convert it into the word2vec format
#glove2word2vec(glove_input_file, word2vec_output_file)
# [___CELL_SEPARATOR___]
#load the above word2vec file as a model
#filename = 'glove.6B.100d.txt.word2vec'
#model = KeyedVectors.load_word2vec_format(filename, binary=False)
# [___CELL_SEPARATOR___]
# take the average to represent the string ‘go away’ in the form of vectors having 100 dimensions
#(model['music'] + model['family'])/2
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
