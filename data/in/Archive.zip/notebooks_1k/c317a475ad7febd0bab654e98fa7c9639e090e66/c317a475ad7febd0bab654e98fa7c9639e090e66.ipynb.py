import pandas as pd; pd.set_option('display.max_colwidth', -1)
# text
from spacy.lang.fr import French
from spacy.cli.download import download
from spacy.tokens import Span

# download('fr_core_news_sm')
spacy.util.is_package("fr_core_news_sm")
# [___CELL_SEPARATOR___]
input_filename = "../../data/processed/DPEFs/dpef_paragraphs_debug.csv"
output_filename = "../../data/processed/DPEFs/dpef_paragraphs_sentences.csv"
output_filename2 = "../../data/processed/DPEFs/dpef_paragraphs_sentences_long_format_debug.csv"
df = pd.read_csv(input_filename, sep=";")
print(df.shape)
df = df[df.paragraph.notna()] # nan created while saving/ removing header -> to correct
print(df.shape)
df = df.loc[5000:10000]
# [___CELL_SEPARATOR___]
def load_nlp_sententizer_object():
    """ Load french mspacy model, customize it, add custom nb_words attributes to Span."""
    Span.set_extension("nb_words", setter=get_nb_words, getter=get_nb_words, force=True)
    if not spacy.util.is_package("fr_core_news_sm"):
        print("Downloading fr_core_news_sm spacy model...")
        download('fr_core_news_sm')
        print("done.")
    nlp = spacy.load('fr_core_news_sm')
    nlp.add_pipe(custom_sentence_boundaries, before = "parser")  # add exception to sententizer
    nlp.add_pipe(nlp.create_pipe('sentencizer'))  # to add default sentencizer, AFTER custom rule
    return nlp
nlp = load_nlp_sententizer_object()
nlp.pipeline
# [___CELL_SEPARATOR___]
# params
MIN_NB_OF_TOKENS = 3
def get_nb_words(doc):
    """ Count numer of tokens in spacy Doc, ignoring NUM and ADP (e.g. for, at...) and not counting % as noun. """
    return len([token for token in doc if (token.pos_ in ["NOUN","PROPN","VERB"]) and (token.text!="%")])

Span.set_extension("nb_words", setter=get_nb_words, getter=get_nb_words, force=True)
# custom parser to split sentences while ignoring title section like cf. and splitting on "etc."
nlp =  spacy.load('fr_core_news_sm')

def exception_to_split(token):
    if 'cf' in token.nbor(-2).text and token.nbor(-1).text == ".":
        return True
    return False

def custom_sentence_boundaries(doc):
    for i, token in enumerate(doc[2:]):
        if exception_to_split(token):
            token.is_sent_start = False
#         if exception_to_not_split(token):
#             token.is_sent_start = True
    return doc

# def exception_to_not_split(token):
#     if 'etc' in token.nbor(-2).text and token.nbor(-1).text == ".":
#         return True
#     return False

nlp.add_pipe(nlp.create_pipe('sentencizer')) # to add default sentencizer
nlp.add_pipe(custom_sentence_boundaries) # add exception to sententizer

df_sent = df["paragraph"].apply(lambda x: [sent.text for sent in nlp(x).sents if sent._.nb_words>MIN_NB_OF_TOKENS])
# save
df["paragraph_sentences"] = df_sent.values
print(df.shape)
df = df[df["paragraph_sentences"].apply(lambda x : len(x)>0)]
print(df.shape)
# df.to_csv(output_filename, sep=";") # TODO: remove
# [___CELL_SEPARATOR___]
# reshaping following https://stackoverflow.com/questions/53860398/pandas-dataframe-how-do-i-split-one-row-into-multiple-rows-by-multi-value-colum/53860543
# convert list of pd.Series then stack it
df2 = (df
 .set_index(df.columns[:-1].values.tolist())['paragraph_sentences'] # all except last colname as index
 .apply(pd.Series)
 .stack()
 .reset_index()
 .drop('level_{}'.format(len(df.columns)-1), axis=1)
 .rename(columns={0:'sentence'}))
df2.to_csv(output_filename2, sep=";")
# [___CELL_SEPARATOR___]
df.paragraph
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
