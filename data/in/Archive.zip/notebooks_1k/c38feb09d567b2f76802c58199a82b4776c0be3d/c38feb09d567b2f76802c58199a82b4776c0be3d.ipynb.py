"""
Temperature Conversions
"""

# You're studying climate change, and over the last 3 years, you've recorded the temperature at noon every day in degrees Fahrenheit (F). The var sampleF holds a portion of those recordings. 

sampleF = [71.6, 82.4, 91.4, 107.6, 125.6]

# Convert each item in this list into degrees Celsius and add the results to a dict called sample_temps so that the conversion of each day's temperature is easily accessible. For reference, the conversion equation between F and C is:
# Celsius = (Fahrenheit - 32) * 5.0/9.0


# sample_temps = 

