%matplotlib inline
import matplotlib
import matplotlib.pyplot as plt


# [___CELL_SEPARATOR___]
import aqml.cheminfo.lo.dmml as cll
reload(cll)
import numpy as np
from aqml.cheminfo.lo.dmml import *
from aqml.cheminfo.lo.dmx import *
import ase.io as aio
# [___CELL_SEPARATOR___]
def get_dmxs(fs, objs, brs, bq):
    o1,o2 = objs

    #fs = [ 'test/'+fi+'.xyz' for fi in ['c06h14', 'c12h26'] ] #'c07h16', 'c08h18',
    ms = [ aio.read(f) for f in fs ]
    m1, m2 = ms

    mr,mq = m1,m2
    brsc = [] # BondS of Ref Chosen for training
    y1 = []
    dm2 = clb.get_dm_aa(o2,bq[0],bq[1])
    y2 = np.array([ dm2.ravel() ])
    for br in brs:
        dm1 = clb.get_dm_aa(o1,br[0],br[1])
        ots = clb.get_mapping(mr,br,mq,bq)
        if len(ots) == 0: continue
        i1, i2 = ots
        dm1u = dm1[i1][:,i2]
        y1.append(dm1u.ravel()); brsc.append(br)
        print( 'bond=(%3d,%3d)'%(br[0],br[1]), ' max deviation: %.5f'% np.max(np.abs(dm1u-dm2)) )
    y1 = np.array(y1)
    return brsc, y1, y2

# [___CELL_SEPARATOR___]
import ase.visualize as av
import ase
import numpy as np
import ase.io as aio

np.set_printoptions(precision=4,suppress=True)

fs = [ 'test/'+fi+'.xyz' for fi in ['c06h14', 'c07h16', 'c08h18','c12h26'] ]
ms = [ aio.read(f) for f in fs ]
m1, m2, m3, m4 = ms
#av.view(m4); av.view(m1)
# [___CELL_SEPARATOR___]
#from MDAnalysis.analysis import align
#R, rmsd = align.rotation_matrix(q.positions, ref.positions)
#ref_u = ref.copy()
#ref_u.positions = np.dot(ref.positions,R)
#av.view(ref_u)
#av.view(q)
# [___CELL_SEPARATOR___]
import aqml.cheminfo.lo.dmb as clb
reload(clb)
# [___CELL_SEPARATOR___]
fs = [ 'test/'+fi+'.xyz' for fi in ['c06h14', 'c12h26'] ] #'c07h16', 'c08h18',
objs = clb.ready_pyscf(fs)
# [___CELL_SEPARATOR___]
fs = [ 'test/'+fi+'.xyz' for fi in ['c06h14', 'c06h14'] ] #'c07h16', 'c08h18',
scales = [1., 0.9]
objs1 = clb.ready_pyscf(fs,scales)
# [___CELL_SEPARATOR___]
o1,o2 = objs1
clb.get_dm_aa(o2, 0, 1) - clb.get_dm_aa(o1, 0, 1)
# [___CELL_SEPARATOR___]
fs = [ 'test/'+fi+'.xyz' for fi in ['c06h14' ] ] #'c07h16', 'c08h18',
scales = [1.1]
objs2 = clb.ready_pyscf(fs,scales)
o3 = objs2[0]
# [___CELL_SEPARATOR___]
clb.get_dm_aa(o3, 0, 1) - clb.get_dm_aa(o1, 0, 1)
# [___CELL_SEPARATOR___]


np.set_printoptions(formatter={'float': '{: 0.8f}'.format})

basis='sto-3g'; meth='b3lyp'
spin=0; a=0.; verbose=3

zs = []; coords = []; nas = []
for fi in fs:
    mi = aio.read(fi)
    nas.append(len(mi)); zs += list(mi.numbers); coords += list(mi.positions)
nas = np.array(nas,np.int)
zs = np.array(zs,np.int)
coords = np.array(coords)


racut,rbcut = 1.6,4.8 # 4.8, 4.8
xd = XData(nas, zs, coords)
xd.get_x(param={'racut':racut,'rbcut':rbcut})
#yd = YData(nas, zs, coords, rc_dm=rbcut)
#obj = dmml(xd,yd)

# [___CELL_SEPARATOR___]
xs = np.array( xd.xsb )
assert not np.any(np.isnan(xs))
obj = dmml(xd)
# [___CELL_SEPARATOR___]

def get_lc(fs, objs, ims1, ims2, brs, bq):
    brsc, y1, y2 = get_dmxs(fs, objs, brs, bq)

    opt = 'ii'
    idxs_x1 = xd.get_idx(brsc, ims=ims1, opt=opt)
    idxs_x2 = xd.get_idx([bq], ims=ims2, opt=opt)
    x1, x2 = xs[idxs_x1], xs[idxs_x2]

    n2 = 1
    n1s = np.arange(1,len(brsc)+1)
    errs = []
    for n1 in n1s:
        ds2, y2_est = obj.krr(x1[:n1],y1[:n1],x2,kernel='g',c=1.0,l=1.e-8)
        dy2 = np.abs(y2_est-y2)
        denom = n2 * dy2.shape[1]
        mae, rmse, errmax = np.sum(dy2)/denom, np.sqrt(np.sum(dy2**2)/denom), np.max(dy2)
        errs.append([mae, rmse, errmax])
        print('  n1,  mae, rmse, delta_max = %d, %.5f %.5f %.5f'%(n1, mae, rmse, errmax) )
    return n1s, errs

# [___CELL_SEPARATOR___]
bq = [0,12]
brs = [[2,11],[1,9],[0,6],[0,7] ]
ims1, ims2 = [0], [1]
n1s, errs = get_lc(fs, objs, ims1, ims2, brs, bq)
ots = plt.loglog(n1s, errs, '-o')
#print( np.max(np.))
# [___CELL_SEPARATOR___]
bq = [1,17]
brs = [[0,9],[0,10],[1,6],[1,7],[1,11],[1,12],[2,9],[2,10],[2,13],[2,14] ]
ims1, ims2 = [0], [1]
n1s, errs = get_lc(fs, objs, ims1, ims2, brs, bq)
ots = plt.loglog(n1s, errs, '-o')
# [___CELL_SEPARATOR___]
bq = [1,2]
brs = [[0,1],[2,3],[1,2], ]
ims1, ims2 = [0], [1]
n1s, errs = get_lc(fs, objs, ims1, ims2, brs, bq)
ots = plt.loglog(n1s, errs, '-o')
# [___CELL_SEPARATOR___]
bq = [1,3]
brs = [[0,2],[2,4],[1,3], ]
ims1, ims2 = [0], [1]
n1s, errs = get_lc(fs, objs, ims1, ims2, brs, bq)
ots = plt.loglog(n1s, errs, '-o')
# [___CELL_SEPARATOR___]
bq = [2,5]
brs = [[0,3],[2,5],[1,4], ]
ims1, ims2 = [0], [1]
n1s, errs = get_lc(fs, objs, ims1, ims2, brs, bq)
ots = plt.loglog(n1s, errs, '-o')
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
