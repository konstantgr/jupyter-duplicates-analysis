import pandas as pd
from dimcli.shortcuts import dslquery_json as dslquery
# [___CELL_SEPARATOR___]
#pip (or pip3) install sparqlwrapper
#https://rdflib.github.io/sparqlwrapper/

from SPARQLWrapper import SPARQLWrapper, JSON
sparql = SPARQLWrapper("https://query.wikidata.org/sparql")
sparql.setQuery("""Select ?grid ?inception ?students
where {
    ?inst wdt:P2427 ?grid;
          wdt:P2196 ?students;
          wdt:P571 ?inception .
}""")
sparql.setReturnFormat(JSON)
results = sparql.query().convert()

cols = results['head']['vars']

out = []
for row in results['results']['bindings']:
    item = []
    for c in cols:
        item.append(row.get(c, {}).get('value'))
    out.append(item)
    
wddf = pd.DataFrame(out, columns=cols). \
           set_index('grid')

wddf.head()




# [___CELL_SEPARATOR___]
dsldf = pd.DataFrame(
        dslquery("""
            search publications
                where year > "2012"
                and count(research_orgs) = 1
            return research_orgs limit 200
        """)['research_orgs']
    ). \
    set_index('id')
dsldf.index.name = 'grid'
# [___CELL_SEPARATOR___]
dsldf.head()
# [___CELL_SEPARATOR___]
pd.merge(dsldf, wddf, on='grid', how='left')