tres = 3
cinco = 5
# [___CELL_SEPARATOR___]
tres>cinco
# [___CELL_SEPARATOR___]
tres>=cinco
# [___CELL_SEPARATOR___]
tres<cinco
# [___CELL_SEPARATOR___]
tres<=cinco
# [___CELL_SEPARATOR___]
tres == cinco # no confundir con tres = cinco
# [___CELL_SEPARATOR___]
"aa" is "a"*2
# [___CELL_SEPARATOR___]
letraA = "a"
"aa" is letraA * 2
# [___CELL_SEPARATOR___]
verdadero=True
falso=False
# [___CELL_SEPARATOR___]
verdadero and falso
# [___CELL_SEPARATOR___]
verdadero or falso
# [___CELL_SEPARATOR___]
not verdadero