import json, glob
from tweet_utility_scripts import *
from tweet_utility_preprocess_roberta_scripts import *
from transformers import TFRobertaModel, RobertaConfig
from tokenizers import ByteLevelBPETokenizer
from tensorflow.keras import layers
from tensorflow.keras.models import Model
# [___CELL_SEPARATOR___]
test = pd.read_csv('/kaggle/input/tweet-sentiment-extraction/test.csv')

print('Test samples: %s' % len(test))
display(test.head())
# [___CELL_SEPARATOR___]
input_base_path = '/kaggle/input/140roberta-base/'
with open(input_base_path + 'config.json') as json_file:
    config = json.load(json_file)

config
# [___CELL_SEPARATOR___]
# vocab_path = input_base_path + 'vocab.json'
# merges_path = input_base_path + 'merges.txt'
base_path = '/kaggle/input/qa-transformers/roberta/'

vocab_path = base_path + 'roberta-base-vocab.json'
merges_path = base_path + 'roberta-base-merges.txt'
config['base_model_path'] = base_path + 'roberta-base-tf_model.h5'
config['config_path'] = base_path + 'roberta-base-config.json'

model_path_list = glob.glob(input_base_path + '*.h5')
model_path_list.sort()
print('Models to predict:')
print(*model_path_list, sep = "\n")
# [___CELL_SEPARATOR___]
tokenizer = ByteLevelBPETokenizer(vocab_file=vocab_path, merges_file=merges_path, 
                                  lowercase=True, add_prefix_space=True)
# [___CELL_SEPARATOR___]
test['text'].fillna('', inplace=True)
test["text"] = test["text"].apply(lambda x: x.lower())
test["text"] = test["text"].apply(lambda x: x.strip())

x_test = get_data_test(test, tokenizer, config['MAX_LEN'], preprocess_fn=preprocess_roberta_test)
# [___CELL_SEPARATOR___]
module_config = RobertaConfig.from_pretrained(config['config_path'], output_hidden_states=True)

def model_fn(MAX_LEN):
    input_ids = layers.Input(shape=(MAX_LEN,), dtype=tf.int32, name='input_ids')
    attention_mask = layers.Input(shape=(MAX_LEN,), dtype=tf.int32, name='attention_mask')
    
    base_model = TFRobertaModel.from_pretrained(config['base_model_path'], config=module_config, name="base_model")
    _, _, hidden_states = base_model({'input_ids': input_ids, 'attention_mask': attention_mask})
    
    h12 = hidden_states[-1]
    h11 = hidden_states[-2]
    h10 = hidden_states[-3]
    h09 = hidden_states[-4]

    
    x_start_09 = layers.Dropout(.1)(h09) 
    x_start_09 = layers.Dense(1)(x_start_09)
    x_start_09 = layers.Flatten()(x_start_09)
    y_start_09 = layers.Activation('softmax', name='y_start_09')(x_start_09)
    
    x_start_10 = layers.Dropout(.1)(h10) 
    x_start_10 = layers.Dense(1)(x_start_10)
    x_start_10 = layers.Flatten()(x_start_10)
    y_start_10 = layers.Activation('softmax', name='y_start_10')(x_start_10)
    
    x_start_11 = layers.Dropout(.1)(h11) 
    x_start_11 = layers.Dense(1)(x_start_11)
    x_start_11 = layers.Flatten()(x_start_11)
    y_start_11 = layers.Activation('softmax', name='y_start_11')(x_start_11)
    
    x_start_12 = layers.Dropout(.1)(h12) 
    x_start_12 = layers.Dense(1)(x_start_12)
    x_start_12 = layers.Flatten()(x_start_12)
    y_start_12 = layers.Activation('softmax', name='y_start_12')(x_start_12)

    y_start = layers.Average(name='y_start')([y_start_12, y_start_11, y_start_10, y_start_09])


    x_end_09 = layers.Dropout(.1)(h09) 
    x_end_09 = layers.Dense(1)(x_end_09)
    x_end_09 = layers.Flatten()(x_end_09)
    y_end_09 = layers.Activation('softmax', name='y_end_09')(x_end_09)

    x_end_10 = layers.Dropout(.1)(h10) 
    x_end_10 = layers.Dense(1)(x_end_10)
    x_end_10 = layers.Flatten()(x_end_10)
    y_end_10 = layers.Activation('softmax', name='y_end_10')(x_end_10)

    x_end_11 = layers.Dropout(.1)(h11) 
    x_end_11 = layers.Dense(1)(x_end_11)
    x_end_11 = layers.Flatten()(x_end_11)
    y_end_11 = layers.Activation('softmax', name='y_end_11')(x_end_11)

    x_end_12 = layers.Dropout(.1)(h12) 
    x_end_12 = layers.Dense(1)(x_end_12)
    x_end_12 = layers.Flatten()(x_end_12)
    y_end_12 = layers.Activation('softmax', name='y_end_12')(x_end_12)

    y_end = layers.Average(name='y_end')([y_end_12, y_end_11, y_end_10, y_end_09])
    
    model = Model(inputs=[input_ids, attention_mask], outputs=[y_start, y_end])
    
    return model
# [___CELL_SEPARATOR___]
NUM_TEST_IMAGES = len(test)
test_start_preds = np.zeros((NUM_TEST_IMAGES, config['MAX_LEN']))
test_end_preds = np.zeros((NUM_TEST_IMAGES, config['MAX_LEN']))

for model_path in model_path_list:
    print(model_path)
    model = model_fn(config['MAX_LEN'])
    model.load_weights(model_path)
    
    test_preds = model.predict(x_test)  
    test_start_preds += test_preds[0]
    test_end_preds += test_preds[1]
# [___CELL_SEPARATOR___]
test['start'] = test_start_preds.argmax(axis=-1)
test['end'] = test_end_preds.argmax(axis=-1)

test['text_len'] = test['text'].apply(lambda x : len(x))
test['text_wordCnt'] = test['text'].apply(lambda x : len(x.split(' ')))
test["end"].clip(0, test["text_len"], inplace=True)
test["start"].clip(0, test["end"], inplace=True)

test['selected_text'] = test.apply(lambda x: decode(x['start'], x['end'], x['text'], config['question_size'], tokenizer), axis=1)
test["selected_text"].fillna(test["text"], inplace=True)
# [___CELL_SEPARATOR___]
display(test.head(10))
# [___CELL_SEPARATOR___]
submission = pd.read_csv('/kaggle/input/tweet-sentiment-extraction/sample_submission.csv')
submission['selected_text'] = test["selected_text"]
submission.to_csv('submission.csv', index=False)
submission.head(10)