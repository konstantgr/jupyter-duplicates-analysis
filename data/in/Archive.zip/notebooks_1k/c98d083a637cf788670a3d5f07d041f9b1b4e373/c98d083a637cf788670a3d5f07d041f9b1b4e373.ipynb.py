import pyvisa
from pylabnet.utils.logging.logger import LogClient
import pylabnet.hardware.spectrum_analyzer.agilent_e4405B as sa
from pylabnet.network.core.generic_server import GenericServer
from pylabnet.network.client_server.agilent_e4405B import Service
# [___CELL_SEPARATOR___]
# Instantiate
logger = LogClient(
    host='localhost',
    port=12351,
    module_tag='Spectrum Analyser'
)
# [___CELL_SEPARATOR___]
# List all connected VISA ressources 
rm = pyvisa.ResourceManager()
rm.list_resources()
# [___CELL_SEPARATOR___]
# Choose ID corresponding to the spectrum analyzer
gpib_address = 'GPIB0::18::INSTR'
# [___CELL_SEPARATOR___]
# Instanciate driver
spectrum_analyzer = sa.Driver(
    gpib_address=gpib_address,
    logger=logger
)
# [___CELL_SEPARATOR___]
# Spectrum analyzer server
sa_service = Service()
sa_service.assign_module(module=spectrum_analyzer)
sa_service.assign_logger(logger=logger)
sa_service_server = GenericServer(
    service=sa_service, 
    host='localhost', 
    port=12352
)
# [___CELL_SEPARATOR___]
# Start Server
sa_service_server.start()