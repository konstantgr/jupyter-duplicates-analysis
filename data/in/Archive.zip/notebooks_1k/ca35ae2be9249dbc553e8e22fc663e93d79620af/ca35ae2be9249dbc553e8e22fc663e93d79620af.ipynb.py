def guess(answer, small_int=0, large_int=100, verbose=False):
    '''computer returns number of guesses required to determine user-defined integer'''
    
    # error checking
    assert type(answer) == int, 'answer must be an integer'
    #assert -1 < answer < 101, 'enter an integer between 1-100 inclusive'
    
    # useful functions
    def new_guess(start, stop):
        '''returns binary search value as updated guess'''
        return (start+stop)//2
    def checker(guess, answer):
        '''check if guess equals answer'''
        return True if guess == answer else 'bigger' if guess < answer else 'smaller'
    
    # setup
    start = small_int
    stop = large_int
    guesses = 0
    
    # main logic
    while True:
        guesses += 1
        guess = new_guess(start, stop)
        check = checker(guess, answer)
        if verbose:
            print('guess: {}'.format(guess))
        if check == True:
            return print('{} guess'.format(guesses)) \
                if guesses == 1 else print('\n{} guesses'.format(guesses))
            break
        else:
            if check == 'smaller':
                stop = guess
            else:
                start = guess
# [___CELL_SEPARATOR___]
guess(50, verbose=False)
# [___CELL_SEPARATOR___]
guess(80, verbose=True)
# [___CELL_SEPARATOR___]
guess(0, verbose=False)
# [___CELL_SEPARATOR___]
guess(0, verbose=True)
# [___CELL_SEPARATOR___]
guess(120, small_int=0, large_int=1000, verbose=True)
# [___CELL_SEPARATOR___]
def howManyGuesses(start, stop):
    '''returns total number of guesses for binary search given start and stop values'''
    
    # inclusive of both ends
    how_many_numbers = stop - start + 1
    
    # main logic
    num_guesses = 1
    while 2**num_guesses < how_many_numbers:
        num_guesses += 1
    return num_guesses
# [___CELL_SEPARATOR___]
print('It will take no more than %d guesses' % howManyGuesses(0, 100))
# [___CELL_SEPARATOR___]
print('It will take no more than %d guesses' % howManyGuesses(0, int(1e6)))
# [___CELL_SEPARATOR___]
%matplotlib inline
import matplotlib.pyplot as plt
import numpy as np
# [___CELL_SEPARATOR___]
num_numbers = np.geomspace(1, 1e9, num=10)
num_numbers
# [___CELL_SEPARATOR___]
guesses = [howManyGuesses(0,numbers) for numbers in num_numbers]
guesses
# [___CELL_SEPARATOR___]
plt.plot(num_numbers, guesses)
plt.xlabel('how many numbers to guess')
plt.ylabel('# of actual guesses')
plt.title('Binary Search Guesses ~ Guess Space');
# [___CELL_SEPARATOR___]
# x-axis on log scale
plt.plot(num_numbers, guesses)
plt.xlabel('how many numbers to guess')
plt.ylabel('# of actual guesses')
plt.title('Binary Search Guesses ~ Guess Space')
plt.xscale('log');