import pandas as pd
# [___CELL_SEPARATOR___]
files_df = pd.read_pickle("data/clean/files_df.pkl")
# [___CELL_SEPARATOR___]
files_df.shape
# [___CELL_SEPARATOR___]
website_ids = files_df[files_df.tierafterorder.isin(['WEBSITE'])].index
api_ids = files_df[files_df.tierafterorder.isin(['API'])].index
# [___CELL_SEPARATOR___]
files_df = files_df[-files_df.tierafterorder.isin(['WEBSITE', 'API'])]
# [___CELL_SEPARATOR___]
files_df.shape
# [___CELL_SEPARATOR___]
files_df.tierafterorder.value_counts()
# [___CELL_SEPARATOR___]
scraped_df = pd.read_pickle('data/clean/scraped.pkl')
# [___CELL_SEPARATOR___]
scraped_df.shape
# [___CELL_SEPARATOR___]
scraped_df = scraped_df.loc[website_ids]
# [___CELL_SEPARATOR___]
scraped_df.shape
# [___CELL_SEPARATOR___]
scraped_df.head()
# [___CELL_SEPARATOR___]
targets_df = pd.read_pickle('data/clean/targets.pkl')
storeid_df = pd.read_pickle('data/clean/storeids.pkl')
# [___CELL_SEPARATOR___]
api_df = pd.read_pickle('data/clean/api_df.pickle')
# [___CELL_SEPARATOR___]
train_df = pd.concat(
    [
        pd.concat([files_df, api_df], sort=True),
        scraped_df
    ],
    sort=True
)
# [___CELL_SEPARATOR___]
train_df.shape
# [___CELL_SEPARATOR___]
train_df = train_df.drop(columns=['returned', 'storeid']).join(targets_df).join(storeid_df)
# [___CELL_SEPARATOR___]
train_df.shape
# [___CELL_SEPARATOR___]
train_df.to_pickle('data/clean/train_df_merged.pkl')