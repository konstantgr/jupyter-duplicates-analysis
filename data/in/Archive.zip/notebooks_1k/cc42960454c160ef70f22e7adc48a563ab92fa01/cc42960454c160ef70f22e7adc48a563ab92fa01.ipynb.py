iris
# [___CELL_SEPARATOR___]
# show iris data type
class(iris)
# [___CELL_SEPARATOR___]
# count rows
nrow(iris)
# [___CELL_SEPARATOR___]
# count columns
ncol(iris)
# [___CELL_SEPARATOR___]
# show first rows
head(iris)
# [___CELL_SEPARATOR___]
summary(iris)
# [___CELL_SEPARATOR___]
# ways to get a column (vector)
head(iris$Petal.Length)
head(iris[[3]])
head(iris[,3])
# [___CELL_SEPARATOR___]
class(iris[[3]])
# [___CELL_SEPARATOR___]
# get a data frame slice for columns
head(iris[3])
head(iris[3:4])
head(iris[-3])
head(iris["Petal.Length"])
head(iris[c("Petal.Length", "Petal.Width")])
# [___CELL_SEPARATOR___]
class(iris["Petal.Length"])
# [___CELL_SEPARATOR___]
# get a data frame slice for rows
iris[2,]
iris["10",]
# [___CELL_SEPARATOR___]
# get a single "cell"
iris[[1,2]]
# [___CELL_SEPARATOR___]
# plot some data
BG = c("red", "green", "blue")
plot(iris$Sepal.Length, iris$Sepal.Width, bg=BG[unclass(iris$Species)], pch=21)
# [___CELL_SEPARATOR___]
plot(iris[[3]], iris[[4]], bg=BG[unclass(iris$Species)], pch=21)
# [___CELL_SEPARATOR___]
plot(iris[1:4], bg=BG[unclass(iris$Species)], pch=21)