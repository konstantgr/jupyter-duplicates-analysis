# A list of desserts I like.
desserts = ['ice cream', 'chocolate', 'apple crisp', 'cookies']
favorite_dessert = 'apple crisp'

# Print the desserts out, but let everyone know my favorite dessert.
for dessert in desserts:
    if dessert == favorite_dessert:
        # This dessert is my favorite, let's let everyone know!
        print("%s is my favorite dessert!" % dessert.title())
    else:
        # I like these desserts, but they are not my favorite.
        print("I like %s." % dessert)
# [___CELL_SEPARATOR___]
5 == 5
# [___CELL_SEPARATOR___]
3 == 5 
# [___CELL_SEPARATOR___]
5 == 5.0
# [___CELL_SEPARATOR___]
'eric' == 'eric'
# [___CELL_SEPARATOR___]
'Eric' == 'eric'
# [___CELL_SEPARATOR___]
'Eric'.lower() == 'eric'.lower()
# [___CELL_SEPARATOR___]
'5' == 5
# [___CELL_SEPARATOR___]
'5' == str(5)
# [___CELL_SEPARATOR___]
3 != 5
# [___CELL_SEPARATOR___]
5 != 5
# [___CELL_SEPARATOR___]
'Eric' != 'eric'
# [___CELL_SEPARATOR___]
5 > 3
# [___CELL_SEPARATOR___]
5 >= 3
# [___CELL_SEPARATOR___]
3 >= 3
# [___CELL_SEPARATOR___]
3 < 5
# [___CELL_SEPARATOR___]
3 <= 5
# [___CELL_SEPARATOR___]
3 <= 3
# [___CELL_SEPARATOR___]
vowels = ['a', 'e', 'i', 'o', 'u']
'a' in vowels
# [___CELL_SEPARATOR___]
vowels = ['a', 'e', 'i', 'o', 'u']
'b' in vowels
# [___CELL_SEPARATOR___]
# Ex 5.1 : True and False

# put your code here
# [___CELL_SEPARATOR___]
dogs = ['willie', 'hootz', 'peso', 'juno']

if len(dogs) > 3:
    print("Wow, we have a lot of dogs here!")
# [___CELL_SEPARATOR___]
dogs = ['willie', 'hootz']

if len(dogs) > 3:
    print("Wow, we have a lot of dogs here!")
# [___CELL_SEPARATOR___]
dogs = ['willie', 'hootz', 'peso', 'juno']

if len(dogs) > 3:
    print("Wow, we have a lot of dogs here!")
else:
    print("Okay, this is a reasonable number of dogs.")
# [___CELL_SEPARATOR___]
dogs = ['willie', 'hootz']

if len(dogs) > 3:
    print("Wow, we have a lot of dogs here!")
else:
    print("Okay, this is a reasonable number of dogs.")
# [___CELL_SEPARATOR___]
dogs = ['willie', 'hootz', 'peso', 'monty', 'juno', 'turkey']

if len(dogs) >= 5:
    print("Holy mackerel, we might as well start a dog hostel!")
elif len(dogs) >= 3:
    print("Wow, we have a lot of dogs here!")
else:
    print("Okay, this is a reasonable number of dogs.")
# [___CELL_SEPARATOR___]
dogs = ['willie', 'hootz', 'peso', 'monty']

if len(dogs) >= 5:
    print("Holy mackerel, we might as well start a dog hostel!")
elif len(dogs) >= 3:
    print("Wow, we have a lot of dogs here!")
else:
    print("Okay, this is a reasonable number of dogs.")
# [___CELL_SEPARATOR___]
dogs = ['willie', 'hootz']

if len(dogs) >= 5:
    print("Holy mackerel, we might as well start a dog hostel!")
elif len(dogs) >= 3:
    print("Wow, we have a lot of dogs here!")
else:
    print("Okay, this is a reasonable number of dogs.")
# [___CELL_SEPARATOR___]
dogs = []

if len(dogs) >= 5:
    print("Holy mackerel, we might as well start a dog hostel!")
elif len(dogs) >= 3:
    print("Wow, we have a lot of dogs here!")
else:
    print("Okay, this is a reasonable number of dogs.")
# [___CELL_SEPARATOR___]
###highlight=[8]
dogs = []

if len(dogs) >= 5:
    print("Holy mackerel, we might as well start a dog hostel!")
elif len(dogs) >= 3:
    print("Wow, we have a lot of dogs here!")
elif len(dogs) >= 1:
    print("Okay, this is a reasonable number of dogs.")
# [___CELL_SEPARATOR___]
###highlight=[10,11]
dogs = []

if len(dogs) >= 5:
    print("Holy mackerel, we might as well start a dog hostel!")
elif len(dogs) >= 3:
    print("Wow, we have a lot of dogs here!")
elif len(dogs) >= 1:
    print("Okay, this is a reasonable number of dogs.")
else:
    print("I wish we had a dog here.")
# [___CELL_SEPARATOR___]
# Ex 5.2 : Three is a Crowd

# put your code here
# [___CELL_SEPARATOR___]
# Ex 5.3 : Three is a Crowd - Part 2

# put your code here
# [___CELL_SEPARATOR___]
# Ex 5.4 : Six is a Mob

# put your code here
# [___CELL_SEPARATOR___]
dogs = ['willie', 'hootz']

if 'willie' in dogs:
    print("Hello, Willie!")
if 'hootz' in dogs:
    print("Hello, Hootz!")
if 'peso' in dogs:
    print("Hello, Peso!")
if 'monty' in dogs:
    print("Hello, Monty!")
# [___CELL_SEPARATOR___]
###highlight=[6,7,8,9,10,11]
dogs = ['willie', 'hootz']

if 'willie' in dogs:
    print("Hello, Willie!")
elif 'hootz' in dogs:
    print("Hello, Hootz!")
elif 'peso' in dogs:
    print("Hello, Peso!")
elif 'monty' in dogs:
    print("Hello, Monty!")
# [___CELL_SEPARATOR___]
dogs_we_know = ['willie', 'hootz', 'peso', 'monty', 'juno', 'turkey']
dogs_present = ['willie', 'hootz']

# Go through all the dogs that are present, and greet the dogs we know.
for dog in dogs_present:
    if dog in dogs_we_know:
        print("Hello, %s!" % dog.title())
# [___CELL_SEPARATOR___]
if 0:
    print("This evaluates to True.")
else:
    print("This evaluates to False.")
# [___CELL_SEPARATOR___]
if 1:
    print("This evaluates to True.")
else:
    print("This evaluates to False.")
# [___CELL_SEPARATOR___]
# Arbitrary non-zero numbers evaluate to True.
if 1253756:
    print("This evaluates to True.")
else:
    print("This evaluates to False.")
# [___CELL_SEPARATOR___]
# Negative numbers are not zero, so they evaluate to True.
if -1:
    print("This evaluates to True.")
else:
    print("This evaluates to False.")
# [___CELL_SEPARATOR___]
# An empty string evaluates to False.
if '':
    print("This evaluates to True.")
else:
    print("This evaluates to False.")
# [___CELL_SEPARATOR___]
# Any other string, including a space, evaluates to True.
if ' ':
    print("This evaluates to True.")
else:
    print("This evaluates to False.")
# [___CELL_SEPARATOR___]
# Any other string, including a space, evaluates to True.
if 'hello':
    print("This evaluates to True.")
else:
    print("This evaluates to False.")
# [___CELL_SEPARATOR___]
# None is a special object in Python. It evaluates to False.
if None:
    print("This evaluates to True.")
else:
    print("This evaluates to False.")
# [___CELL_SEPARATOR___]
# Overall Challenge: Alien Points

# Put your code here