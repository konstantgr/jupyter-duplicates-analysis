import sys
sys.path.insert(0, '../betas')

# Display all of the results.
from IPython.core.interactiveshell import InteractiveShell
InteractiveShell.ast_node_interactivity = "all"

# Hide warnings
import warnings
warnings.filterwarnings('ignore')

import numpy as np
from sklearn.model_selection import train_test_split
import pca_evaluate
# [___CELL_SEPARATOR___]
# X1, X2 and X3 are data generated from different normal distributions and 
# they're all appended to for the feature-set called 'X'

X1 = np.random.normal(size=100)
X1 = X1.reshape(len(X1),1)
X = X1
for i in range(2,11):
    X = np.concatenate((X, X1**i),axis=1)

X2 = np.random.normal(loc=1,scale=0.1, size=100)
X2 = X2.reshape(len(X2),1)
for i in range(1,11):
    X = np.concatenate((X, X2**i),axis=1)
    
X3 = np.random.normal(loc=2,scale=1.5, size=100)
X3 = X3.reshape(len(X3),1)
for i in range(1,11):
    X = np.concatenate((X, X3**i),axis=1)

# y refers to the labels - we will only use two here for binary classification
y = np.random.randint(0,2, size=100)
y[y==0] = -1

print('Number of observation: %d' % X.shape[0])
print('Number of dimension: %d' % X.shape[1])
# [___CELL_SEPARATOR___]
train_features, test_features, train_labels, test_labels = train_test_split(X, y, random_state=0)
# [___CELL_SEPARATOR___]
fig, optimal_dimensions = pca_evaluate.pca_viz_and_opt_dimensions(train_features, train_labels,\
                                                                  test_features, test_labels)
print('The optimal dimension is %d' % optimal_dimensions)