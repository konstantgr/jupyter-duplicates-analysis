from build_docker import *
import unittest
import pprint

DEBUG_MODE = False

this_script_path = os.path.realpath('__file__')
# [___CELL_SEPARATOR___]
# example args for testing different scenarios
EXAMPLE_BUILD_TAG = "my.example"

# build from local files, and push to both Dockerhub and GCR
EXAMPLE_ARGS_LOCAL = ['--targets', 'all', 
                      '--image-tag', EXAMPLE_BUILD_TAG, 
                      '--dockerhub-root', 'shuangbroad',
                      '--gcr-project', 'broad-dsde-methods']

# build from remote (Github) files, but not pushing
EXAMPLE_ARGS_REMOTE = ['--targets', 'all', 
                       '--image-tag', EXAMPLE_BUILD_TAG, 
                       '--remote-git-hash', '72acbdce2660e7cc360aebcd71f47c4665a7002a', 
                       '--staging-dir', '/Users/shuang/Desktop/tmp',
                       '--use-ssh']

# build a single image, but
# it has dependencies that must be built first
EXAMPLE_ARGS_DEPENDENCY = ['--targets', 'sv-pipeline-rdtest', 
                           '--image-tag', EXAMPLE_BUILD_TAG]

# tells git to ignore untracked files and uncommitted changes
# (applies only when building from local files)
EXAMPLE_ARGS_TURNOFF_GIT_PROTECT = ['--targets', 'sv-pipeline-rdtest', 
                                    '--image-tag', EXAMPLE_BUILD_TAG, 
                                    '--disable-git-protect']
# [___CELL_SEPARATOR___]
# you can use the example args above, or provide your own args
actual_args = ['--targets', 'all', 
               '--image-tag', EXAMPLE_BUILD_TAG]

parse_and_build(CMD_line_args_parser(actual_args).project_args,
                this_script_path)