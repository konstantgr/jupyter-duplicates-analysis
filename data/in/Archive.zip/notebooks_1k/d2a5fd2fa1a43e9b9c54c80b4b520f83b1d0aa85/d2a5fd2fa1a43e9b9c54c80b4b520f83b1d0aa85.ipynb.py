import pylibsimba

# [___CELL_SEPARATOR___]
from pylibsimba.wallet import Wallet

# [___CELL_SEPARATOR___]
wallet = Wallet(None)
wallet.generate_wallet('test1234')
addr = wallet.get_address()
print(addr)

# [___CELL_SEPARATOR___]
from pylibsimba import get_simba_instance
import json

# [___CELL_SEPARATOR___]
simba = get_simba_instance(
    'https://api.simbachain.com/v1/libSimba-SimbaChat-Quorum/',
    wallet,
    '04d1729f7144873851a745d2ae85639f55c8e3de5aea626a2bcd0055c01ba6fc',
    '')

# [___CELL_SEPARATOR___]
balance = simba.get_balance()
print("Balance: {}".format(json.dumps(balance, indent=4)))

# [___CELL_SEPARATOR___]
method_params = {
    'assetId': "0xbad65ff688a28efdd17d979c12f0ab2e2de305dbc8a2aa6be45ed644da822cfb",
    'name': "A Test Room",
    'createdBy': "PyLibSIMBA",
}

# [___CELL_SEPARATOR___]
resp = simba.call_method('createRoom', method_params)
print("Successful submitting? {}".format(resp.transaction_id))

# [___CELL_SEPARATOR___]
try:
    final_resp = simba.wait_for_success_or_error(resp.transaction_id)
    print("Successful? {}".format(final_resp))

except Exception as e1:
    print("Failure! {}".format(e1))

# [___CELL_SEPARATOR___]
method_params = {
    'assetId': "A Test Room",
    'chatRoom': "A Test Room",
    'message': "Hello World",
    'sentBy': "PyLibSIMBA"
}

files =  ["../tests/test_files/test file 1.txt", "../tests/test_files/test file 2.txt"]

# [___CELL_SEPARATOR___]
try:
    resp = simba.call_method_with_file('sendMessage', method_params, files)
    print("Successful submitting? {}".format(resp.transaction_id))

    resp = simba.wait_for_success_or_error(resp.transaction_id)
    print("Successfully deployed? {}".format(resp))
except Exception as e1:
    print("Something went wrong: {}".format(e1))

# [___CELL_SEPARATOR___]
!ls ../tests

# [___CELL_SEPARATOR___]
method_params = {
    'createdBy_exact': "PyLibSIMBA"
}
result_pages = simba.get_method_transactions('createRoom', method_params)

print("Number of results for transaction {}: {}".format('createRoom', result_pages.count()))

print("Got data : \n{}".format(
    json.dumps(
        result_pages.data(), indent=4
    )
))

# [___CELL_SEPARATOR___]
transaction_id = "97b56a4dd3ff4fe7820f46a7101f72e2"
txn = simba.get_transaction(transaction_id)

print("Transaction : \n{}".format(
    json.dumps(txn, indent=4)
))

# [___CELL_SEPARATOR___]
transaction_hash = "0x7565461be84259d5e365c2c3225696a6d74245f1eca1ecc050b1fedd5a4a1f4d"
txn_metadata = simba.get_bundle_metadata_for_transaction(transaction_hash)
print("Transaction Metadata: \n{}".format(json.dumps(txn_metadata, indent=4)))

# [___CELL_SEPARATOR___]
transaction_hash = "0x7565461be84259d5e365c2c3225696a6d74245f1eca1ecc050b1fedd5a4a1f4d"
req = simba.get_bundle_for_transaction(transaction_hash, stream=True)
req.raise_for_status()

# [___CELL_SEPARATOR___]
output_file = 'the_bundle.zip'
with open('the_bundle.zip', 'wb') as f:
    for chunk in req.iter_content(chunk_size=8192):
        if chunk:  # filter out keep-alive new chunks
            f.write(chunk)

import os      
print("Wrote file {}: {}".format(
    output_file,
    os.path.isfile(os.path.abspath(output_file)))
)

# [___CELL_SEPARATOR___]
transaction_hash = "0x7565461be84259d5e365c2c3225696a6d74245f1eca1ecc050b1fedd5a4a1f4d"

req = simba.get_file_from_bundle_for_transaction(transaction_hash, 0, stream=True)
req.raise_for_status()

output_file = 'file_0.txt'
with open(output_file, 'wb') as f:
    for chunk in req.iter_content(chunk_size=8192):
        if chunk:  # filter out keep-alive new chunks
            f.write(chunk)
            
print("Wrote file {}: {}".format(
    output_file,
    os.path.isfile(os.path.abspath(output_file)))
)

# [___CELL_SEPARATOR___]
transaction_hash = "0x7565461be84259d5e365c2c3225696a6d74245f1eca1ecc050b1fedd5a4a1f4d"

filename = "File1.txt"
req = simba.get_file_from_bundle_by_name_for_transaction(transaction_hash, filename, stream=True)
req.raise_for_status()

output_file = 'File1.txt'
with open(output_file, 'wb') as f:
    for chunk in req.iter_content(chunk_size=8192):
        if chunk:  # filter out keep-alive new chunks
            f.write(chunk)
            
print("Wrote file \n{}: {}".format(
    output_file,
    os.path.isfile(os.path.abspath(output_file)))
)

# [___CELL_SEPARATOR___]
paged_response = simba.get_organisations()

for org in paged_response.data():
    print(org['id'])

# [___CELL_SEPARATOR___]
from _datetime import datetime
from pylibsimba import util

response = util.create_contract(
    simba,
    '../tests/example.sol',
    'example_contract_{}'.format(datetime.now().isoformat()),
    '5cd5cef4cabb4b009e00b6b3ff45ee08'
)
print("Wrote contract : \n{}".format(
    json.dumps(response.json(), indent=4)
))
