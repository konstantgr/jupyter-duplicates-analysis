linear_regression = lambda x, b0, b1: b0 + b1 * x
# [___CELL_SEPARATOR___]
%matplotlib inline
import numpy as np
import matplotlib.pyplot as plt

def plot_regression_simple(x, y, xlim, ylim):
    origin = (0, 0)

    plt.xlim(xlim)
    plt.ylim(ylim)

    # Plot axis for better visuzlization
    plt.plot(origin, ylim, 'g:', xlim, origin, 'g:', linewidth=0.4)

    # Plot linear model
    plt.plot(x, y, 'b')
    plt.show()

# Base independent data
x_lin = np.arange(-10, 10)

# Parameters
intercept = 0
coefficient = 2

# Dependent variable
y_lin = linear_regression(x_lin, intercept, coefficient)
plot_regression_simple(x_lin, y_lin, (-12, 12), (-25, 25))
# [___CELL_SEPARATOR___]
import pandas as pd 

df = pd.read_csv('data/linear-learning-notebook.csv')
df = df.sort_values('x')
x_lin_df = df['x'].values
y_lin_df = df['y'].values

plt.plot(x_lin_df, y_lin_df, 'b.')
# [___CELL_SEPARATOR___]
import numpy as np
import matplotlib.pyplot as plt
from ipywidgets import interact, interactive, fixed, interact_manual
from ipywidgets import FloatSlider, Dropdown
import ipywidgets as widgets

def plot_simple_regression(b0=0, b1=1, xlim=(-5, 5), ylim=(-5, 5)):
    y_pred = linear_regression(x_lin_df, b0, b1)
    plt.xlim(xlim)
    plt.ylim(ylim)
    plt.plot(x_lin_df, y_lin_df, 'b.')
    plt.plot(x_lin_df, y_pred, 'r-')
    plt.plot([0, 0], ylim, 'g-', xlim, [0, 0], 'g-', linewidth=0.4)


def simple_linear_regression_manual_demo_1(): 
    interact(plot_simple_regression, 
         b0=FloatSlider(min=-10, max=10, step=0.01, value=0), 
         b1=FloatSlider(min=-3, max=3, step=0.01, value=1), 
         xlim=fixed((-10, 10)), 
         ylim=fixed((-10, 10)));

simple_linear_regression_manual_demo_1()
# [___CELL_SEPARATOR___]
linear_regression_mse = lambda y, y_hat: ((y - y_hat)**2).mean()
# [___CELL_SEPARATOR___]
labels = np.array([0.2, 0.45])
close_estimates = np.array([0.25, 0.5])
far_estimates = np.array([10., 10.])

print('Small error measure for close inputs: {}'.format(linear_regression_mse(labels, close_estimates)))
print('Big error measure for distant inputs: {}'.format(linear_regression_mse(labels, far_estimates)))
print('Null error measure for equal inputs: {}'.format(linear_regression_mse(labels, labels)))
# [___CELL_SEPARATOR___]
import numpy as np
import matplotlib.pyplot as plt
from ipywidgets import interact, interactive, fixed, interact_manual
from ipywidgets import FloatSlider, Dropdown
import ipywidgets as widgets

def plot_regression(b0=0, b1=1, xlim=(-5, 5), ylim=(-5, 5)):
    y_pred = linear_regression(x_lin_df, b0, b1)
    plt.xlim(xlim)
    plt.ylim(ylim)
    plt.plot(x_lin_df, y_lin_df, 'b.')
    plt.plot(x_lin_df, y_pred, 'r-')
    plt.plot([0, 0], ylim, 'g-', xlim, [0, 0], 'g-', linewidth=0.4)
    return "Mean Squared Error (MSE): {}".format(linear_regression_mse(y_lin_df, y_pred))


def simple_linear_regression_manual_demo_2(): 
    interact(plot_regression, 
         b0=FloatSlider(min=-10, max=10, step=0.01, value=0), 
         b1=FloatSlider(min=-3, max=3, step=0.01, value=1), 
         xlim=fixed((-10, 10)), 
         ylim=fixed((-10, 10)));

simple_linear_regression_manual_demo_2()
# [___CELL_SEPARATOR___]
mse_derivative_b0 = lambda y, y_hat: (2*(y - y_hat)).mean()
mse_derivative_b1 = lambda y, y_hat, x: (2*(y - y_hat)*x).mean()
# [___CELL_SEPARATOR___]
import pandas as pd 

df = pd.read_csv('data/linear-learning-notebook.csv')
df = df.sort_values('x')
x_lin_df = df['x'].values
y_lin_df = df['y'].values
# [___CELL_SEPARATOR___]
x_mean = x_lin_df.mean()
y_mean = y_lin_df.mean()
# [___CELL_SEPARATOR___]
top = np.sum((x_lin_df - x_mean)*(y_lin_df - y_mean))
bottom = np.sum((x_lin_df - x_mean)**2)
beta_1 = top/bottom

print('Coefficient: {}'.format(beta_1))
# [___CELL_SEPARATOR___]
top = np.sum((x_lin_df - x_mean)*(y_lin_df - y_mean))
bottom = np.sum((x_lin_df - x_mean)**2)
beta_0 = y_mean - beta_1 * x_mean

print('Intercept: {}'.format(beta_0))
# [___CELL_SEPARATOR___]
import matplotlib.pyplot as plt

y_pred = linear_regression(x_lin_df, beta_0, beta_1)
plt.plot(x_lin_df, y_lin_df, 'b.')
plt.plot(x_lin_df, y_pred, 'r-')
plt.plot([0, 0], [-8, 8], 'g-', [-8, 8], [0, 0], 'g-', linewidth=0.4)

print("Mean Squared Error (MSE): {}".format(linear_regression_mse(y_lin_df, y_pred)))
# [___CELL_SEPARATOR___]
multiple_linear_regression = lambda x, betas: betas[0] + np.matmul(x, betas[1:])
# [___CELL_SEPARATOR___]
import numpy as np
import matplotlib.pyplot as plt

def plot_polynomial_regression_multiple(x, y, xlim, ylim):
    origin = (0, 0)

    plt.xlim(xlim)
    plt.ylim(ylim)

    # Plot axis for better visuzlization
    plt.plot(origin, ylim, 'g:', xlim, origin, 'g:', linewidth=0.4)

    # Plot linear model
    plt.plot(x, y, 'b')
    plt.show()

# Base independent variables
x_pln = np.arange(-10, 10, 0.1).reshape(-1, 1)
x_pln_2 = x_pln ** 2
x_pln_3 = x_pln ** 3

# Organize input in a matrix
X_pln = np.concatenate((x_pln, x_pln_2, x_pln_3), axis=1)

# Parameters
betas_pln = [1, -2, .025, .3]

# Dependent variable
y_pln = multiple_linear_regression(X_pln, np.array(betas_pln))
plot_regression_simple(x_pln.flatten(), y_pln, [-10, 10], [-10, 10])
# [___CELL_SEPARATOR___]
df = pd.read_csv('data/polynomial-learning-notebook.csv')
df = df.sort_values('x')

x_pln_df = df['x'].values
y_pln_df = df['y'].values
X_pln_df = df.drop(columns='y').values

plt.plot(x_pln_df, y_pln_df, 'b.')
# [___CELL_SEPARATOR___]
def plot_polynomial_regression(b0=0, b1=1, b2=0, b3=0, xlim=(-20, 20), ylim=(-20, 20)):
    betas = np.array([b0, b1, b2, b3])
    y_pred = multiple_linear_regression(X_pln_df, betas)
    plt.xlim(xlim)
    plt.ylim(ylim)
    plt.plot(x_pln_df, y_pln_df, 'b.')
    plt.plot(x_pln_df, y_pred, 'r-')
    plt.plot([0, 0], ylim, 'g-', xlim, [0, 0], 'g-', linewidth=0.4)

def polynomial_regression_manual_demo_1(): 
    interact(plot_polynomial_regression, 
         b0=FloatSlider(min=-10, max=10, step=0.01, value=0), 
         b1=FloatSlider(min=-5, max=5, step=0.01, value=1), 
         b2=FloatSlider(min=-1, max=1, step=0.01, value=0), 
         b3=FloatSlider(min=-1, max=1, step=0.01, value=0), 
         xlim=fixed((-20, 20)), 
         ylim=fixed((-20, 20)));

polynomial_regression_manual_demo_1()
# [___CELL_SEPARATOR___]
def plot_polynomial_regression(b0=0, b1=1, b2=0, b3=0, xlim=(-20, 20), ylim=(-20, 20)):
    betas = np.array([b0, b1, b2, b3])
    y_pred = multiple_linear_regression(X_pln_df, betas)
    plt.xlim(xlim)
    plt.ylim(ylim)
    plt.plot(x_pln_df, y_pln_df, 'b.')
    plt.plot(x_pln_df, y_pred, 'r-')
    plt.plot([0, 0], ylim, 'g-', xlim, [0, 0], 'g-', linewidth=0.4)
    return "Mean Squared Error (MSE): {}".format(linear_regression_mse(y_pln_df, y_pred))

def polynomial_regression_manual_demo_1(): 
    interact(plot_polynomial_regression, 
         b0=FloatSlider(min=-10, max=10, step=0.01, value=0), 
         b1=FloatSlider(min=-5, max=5, step=0.01, value=1), 
         b2=FloatSlider(min=-1, max=1, step=0.01, value=0), 
         b3=FloatSlider(min=-0.5, max=0.5, step=0.005, value=0), 
         xlim=fixed((-20, 20)), 
         ylim=fixed((-20, 20)));

polynomial_regression_manual_demo_1()
# [___CELL_SEPARATOR___]
mse_derivative_b0 = lambda y, y_hat: -(2*(y - y_hat)).mean()
mse_derivative_bk = lambda y, y_hat, x_k: -(2*(y - y_hat)*x_k).mean()
# [___CELL_SEPARATOR___]
df = pd.read_csv('data/polynomial-learning-notebook.csv')
df = df.sort_values('x')

x_pln_df = df['x'].values
y_pln_df = df['y'].values
X_pln_df = df.drop(columns='y').values
# [___CELL_SEPARATOR___]
X_extended = np.concatenate((np.ones((X_pln_df.shape[0], 1)), X_pln_df), axis=1)
# [___CELL_SEPARATOR___]
inv_xx = np.linalg.inv(np.matmul(X_extended.T, X_extended))
xy = np.matmul(X_extended.T, y_pln_df)
betas = np.matmul(inv_xx, xy)

print('Coefficients: {}'.format(betas))
# [___CELL_SEPARATOR___]
import numpy as np
import matplotlib.pyplot as plt

y_pred = multiple_linear_regression(X_pln_df, betas)
plt.plot(x_pln_df, y_pln_df, 'b.')
plt.plot(x_pln_df, y_pred, 'r-')
plt.plot([0, 0], [-21, 21], 'g-', [-16, 16], [0, 0], 'g-', linewidth=0.4)

print("Mean Squared Error (MSE): {}".format(linear_regression_mse(y_pln_df, y_pred)))
# [___CELL_SEPARATOR___]
import numpy as np
import pandas as pd
from sklearn.datasets import load_diabetes

data = load_diabetes()
print(data['DESCR'])

X_db = pd.DataFrame(data['data'], columns=data['feature_names'])
y_db = pd.Series(data['target'], name='medv')

pd.concat((X_db, y_db), axis=1).head(5)
# [___CELL_SEPARATOR___]
X_extended = np.concatenate((np.ones((X_db.values.shape[0], 1)), X_db.values), axis=1)

inv_xx = np.linalg.inv(np.matmul(X_extended.T, X_extended))
xy = np.matmul(X_extended.T, y_db.values)
betas = np.matmul(inv_xx, xy)

y_pred = multiple_linear_regression(X_db.values, betas)

print('Feature coefficients: ')
print(pd.Series(betas[1:], X_db.columns))
print('\n')

print('Intercept: {}'.format(betas[0]))
print('\n')

print('\nTargets for the first 5 rows: \n\n', y_db.head(5).values)
print('\nPredictions for the first 5 rows: \n\n', y_pred[:5])
print("Mean Squared Error (MSE): {}".format(linear_regression_mse(y_db.values, y_pred)))
# [___CELL_SEPARATOR___]
df = pd.read_csv('data/polynomial-learning-notebook.csv')
df = df.sort_values('x')

x_pln_df = df['x'].values
y_pln_df = df['y'].values
X_pln_df  = df.drop(columns='y').values
# [___CELL_SEPARATOR___]
from sklearn.linear_model import LinearRegression

lr = LinearRegression()
lr.fit(X_pln_df, y_pln_df)
coefficients = lr.coef_
intercept = lr.intercept_
betas = np.concatenate((np.array([intercept]), coefficients))
# [___CELL_SEPARATOR___]
import numpy as np
import matplotlib.pyplot as plt

y_pred = multiple_linear_regression(X_pln_df, betas)
plt.plot(x_pln_df, y_pln_df, 'b.')
plt.plot(x_pln_df, y_pred, 'r-')
plt.plot([0, 0], [-21, 21], 'g-', [-16, 16], [0, 0], 'g-', linewidth=0.4)

print("Mean Squared Error (MSE): {}".format(linear_regression_mse(y_pln_df, y_pred)))
# [___CELL_SEPARATOR___]
import numpy as np
import pandas as pd
from sklearn.datasets import load_diabetes

data = load_diabetes()

X_db = pd.DataFrame(data['data'], columns=data['feature_names'])
y_db = pd.Series(data['target'], name='medv')

pd.concat((X_db, y_db), axis=1).head(5)
# [___CELL_SEPARATOR___]
from sklearn.linear_model import LinearRegression

lr = LinearRegression()
lr.fit(X_db, y_db)
coefficients = lr.coef_
intercept = lr.intercept_

print('Feature coefficients: ')
print(pd.Series(coefficients, X_db.columns))
print('\n')

print('Intercept: {}'.format(intercept))
print('\n')

print('\nTargets for the first 5 rows: \n\n', y_db.head(5).values)
print('\nPredictions for the first 5 rows: \n\n', lr.predict(X_db.head(5)))
print("Mean Squared Error (MSE): {}".format(linear_regression_mse(y_db.values, lr.predict(X_db))))
# [___CELL_SEPARATOR___]
X_db.describe()
# [___CELL_SEPARATOR___]
mse_derivative_b0 = lambda y, y_hat: -(2*(y - y_hat)).mean()
mse_derivative_bk = lambda y, y_hat, x_k: -(2*(y - y_hat)*x_k).mean()
# [___CELL_SEPARATOR___]
def gradient_descent_multiple_linear_regression(x, y, betas, learning_rate, epochs, clip=False):
    
    betas_ = betas.copy().reshape(-1, 1)
    for epoch in range(epochs): 
        y_hat = multiple_linear_regression(x, betas_.flatten())
        dJ_dbetas = np.zeros((x.shape[1] + 1, 1))
        dJ_dbetas[0] = mse_derivative_b0(y, y_hat)
        
        for col in range(x.shape[1]): 
            dJ_dbetas[col+1] = mse_derivative_bk(y, y_hat, x[:, col])
        
        # We add this to avoid increasingly bigger derivatives
        if clip == True:
            dJ_dbetas = np.clip(dJ_dbetas, -1, 1)
            
        betas_ = betas_ - learning_rate * dJ_dbetas

    return betas_
# [___CELL_SEPARATOR___]
np.random.seed(42)

df = pd.read_csv('data/linear-learning-notebook.csv')
df = df.sort_values('x')
x_lin_df = df['x'].values
y_lin_df = df['y'].values

betas = gradient_descent_multiple_linear_regression(
    x_lin_df.reshape(-1, 1), 
    y_lin_df, 
    np.random.rand(2), 
    0.01, 
    100)
# [___CELL_SEPARATOR___]
y_pred = linear_regression(x_lin_df, betas[0], betas[1])
plt.plot(x_lin_df, y_lin_df, 'b.')
plt.plot(x_lin_df, y_pred, 'r-')
plt.plot([0, 0], [-8, 8], 'g-', [-8, 8], [0, 0], 'g-', linewidth=0.4)

print("Mean Squared Error (MSE): {}".format(linear_regression_mse(y_lin_df, y_pred)))
# [___CELL_SEPARATOR___]
np.random.seed(42)

df = pd.read_csv('data/polynomial-learning-notebook.csv')
df = df.sort_values('x')
x_pln_df = df['x'].values
X_pln_df = df.drop(columns='y').values
y_pln_df = df['y'].values

betas = gradient_descent_multiple_linear_regression(
    X_pln_df, 
    y_pln_df, 
    np.random.rand(4), 
    0.001, 
    5000, 
    clip=True)
# [___CELL_SEPARATOR___]
y_pred = multiple_linear_regression(X_pln_df, betas.flatten())
plt.plot(x_pln_df, y_pln_df, 'b.')
plt.plot(x_pln_df, y_pred, 'r-')
plt.plot([0, 0], [-8, 8], 'g-', [-8, 8], [0, 0], 'g-', linewidth=0.4)

print("Mean Squared Error (MSE): {}".format(linear_regression_mse(y_pln_df, y_pred)))
# [___CELL_SEPARATOR___]
import numpy as np
import pandas as pd
from sklearn.datasets import load_diabetes

data = load_diabetes()

X_db = pd.DataFrame(data['data'], columns=data['feature_names'])
y_db = pd.Series(data['target'], name='medv')

pd.concat((X_db, y_db), axis=1).head(5)

betas = gradient_descent_multiple_linear_regression(
    X_db.values, 
    y_db.values, 
    np.random.rand(X_db.shape[1]+1), 
    0.1, 
    5000)

# [___CELL_SEPARATOR___]
betas = betas.flatten()
y_pred = multiple_linear_regression(X_db.values, betas)

print('Feature coefficients: ')
print(pd.Series(betas[1:], X_db.columns))
print('\n')

print('Intercept: {}'.format(betas[0]))
print('\n')

print('\nTargets for the first 5 rows: \n\n', y_db.head(5).values)
print('\nPredictions for the first 5 rows: \n\n', y_pred[:5])
print("Mean Squared Error (MSE): {}".format(linear_regression_mse(y_db.values, y_pred)))