# Import all the libraries we need
import pandas as pd
import numpy as np
import matplotlib.pylab as plt
%matplotlib inline
from matplotlib.pylab import rcParams

#Change the size of the plot
rcParams['figure.figsize'] = 15, 6
# [___CELL_SEPARATOR___]
#Read our data using pandas
data = pd.read_csv("uber_lyft_March.csv")
# [___CELL_SEPARATOR___]
#Look first five lines in our data
data.head()
# [___CELL_SEPARATOR___]
#All the columns in our data
data.columns
# [___CELL_SEPARATOR___]
#Transfer the 'date-time' column to DatetimeIndex type and set this column as our index
data = data.set_index(pd.DatetimeIndex(data['date_time']))
# [___CELL_SEPARATOR___]
#Check the index of our dataset
data.index
# [___CELL_SEPARATOR___]
y_lyft=data['lyft_price_per_second'].resample('2H').mean()
# [___CELL_SEPARATOR___]
plt.plot(y_lyft)
# [___CELL_SEPARATOR___]
from statsmodels.tsa.stattools import adfuller

#Define a function to check the stationary of the timeseries
def test_stationarity(timeseries):
    
    #Determing rolling statistics
    #pandas.rolling_count(arg, window, freq=None, center=False, how=None)
    #The number of window means we calculate 12 numbers at each time 
    #We reample the data frequecy as 2 hour, so we select one day: 12*2 = 24 hours, set window = 12
    rolmean = pd.rolling_mean(timeseries, window=12)
    rolstd = pd.rolling_std(timeseries, window=12)

    #Plot rolling statistics of Orginal, mean and std:
    orig = plt.plot(timeseries, color='blue',label='Original')
    mean = plt.plot(rolmean, color='red', label='Rolling Mean')
    std = plt.plot(rolstd, color='black', label = 'Rolling Std')
    plt.legend(loc='best')
    plt.title('Rolling Mean & Standard Deviation')
    plt.show()
    
    #Perform Dickey-Fuller test:
    print('Results of Dickey-Fuller Test:')
    dftest = adfuller(timeseries, autolag='AIC')
    dfoutput = pd.Series(dftest[0:4], index=['Test Statistic','p-value','#Lags Used','Number of Observations Used'])
    for key,value in dftest[4].items():
        dfoutput['Critical Value (%s)'%key] = value
    print(dfoutput)
# [___CELL_SEPARATOR___]
#Now lets test the stationarity of the dataset and plot the result
plt.rcParams['figure.figsize'] = (15, 9)
test_stationarity(y_lyft)
# [___CELL_SEPARATOR___]
lyft_log = np.log(y_lyft)
plt.plot(lyft_log)
# [___CELL_SEPARATOR___]
moving_avg = pd.rolling_mean(lyft_log,12)
plt.plot(lyft_log)
plt.plot(moving_avg, color='red')
# [___CELL_SEPARATOR___]
lyft_log_moving_avg_diff = lyft_log - moving_avg
lyft_log_moving_avg_diff.head(12)
# [___CELL_SEPARATOR___]
lyft_log_moving_avg_diff.dropna(inplace=True)
test_stationarity(lyft_log_moving_avg_diff)
# [___CELL_SEPARATOR___]
expwighted_avg = pd.ewma(lyft_log, halflife=12)
plt.plot(lyft_log)
plt.plot(expwighted_avg, color='red')
# [___CELL_SEPARATOR___]
lyft_log_ewma_diff = lyft_log - expwighted_avg
test_stationarity(lyft_log_ewma_diff)
# [___CELL_SEPARATOR___]
lyft_log_diff = lyft_log - lyft_log.shift()
plt.plot(lyft_log_diff)
# [___CELL_SEPARATOR___]
lyft_log_diff.dropna(inplace=True)
test_stationarity(lyft_log_diff)
# [___CELL_SEPARATOR___]
from statsmodels.tsa.seasonal import seasonal_decompose
decomposition = seasonal_decompose(lyft_log)

trend = decomposition.trend
seasonal = decomposition.seasonal
residual = decomposition.resid

#These are subplot grid parameters encoded as a single integer. 
#For example, "111" means "1x1 grid, first subplot" and "234" means "2x3 grid, 4th subplot".

plt.subplot(411)
plt.plot(lyft_log, label='Original')
plt.legend(loc='best')
plt.subplot(412)
plt.plot(trend, label='Trend')
plt.legend(loc='best')
plt.subplot(413)
plt.plot(seasonal,label='Seasonality')
plt.legend(loc='best')
plt.subplot(414)
plt.plot(residual, label='Residuals')
plt.legend(loc='best')
plt.tight_layout()
# [___CELL_SEPARATOR___]
lyft_log_decompose = residual
lyft_log_decompose.dropna(inplace=True)
test_stationarity(lyft_log_decompose)
# [___CELL_SEPARATOR___]
#ACF and PACF plots:
from statsmodels.tsa.stattools import acf, pacf
# [___CELL_SEPARATOR___]
lag_acf = acf(lyft_log_diff, nlags=20)
lag_pacf = pacf(lyft_log_diff, nlags=20, method='ols')
# [___CELL_SEPARATOR___]
#Plot ACF: 
plt.subplot(121) 
plt.plot(lag_acf)
plt.axhline(y=0,linestyle='--',color='gray')
plt.axhline(y=-1.96/np.sqrt(len(lyft_log_diff)),linestyle='--',color='gray')
plt.axhline(y=1.96/np.sqrt(len(lyft_log_diff)),linestyle='--',color='gray')
plt.title('Autocorrelation Function')
# [___CELL_SEPARATOR___]
#Plot PACF:
plt.subplot(122)
plt.plot(lag_pacf)
plt.axhline(y=0,linestyle='--',color='gray')
plt.axhline(y=-1.96/np.sqrt(len(lyft_log_diff)),linestyle='--',color='gray')
plt.axhline(y=1.96/np.sqrt(len(lyft_log_diff)),linestyle='--',color='gray')
plt.title('Partial Autocorrelation Function')
plt.tight_layout()
# [___CELL_SEPARATOR___]
from statsmodels.tsa.arima_model import ARIMA
# [___CELL_SEPARATOR___]
model = ARIMA(lyft_log, order=(2, 1, 0))  
results_AR = model.fit(disp=-1)  
plt.plot(lyft_log_diff)
plt.plot(results_AR.fittedvalues, color='red')
plt.title('RSS: %.4f'% sum((results_AR.fittedvalues-lyft_log_diff)**2))
# [___CELL_SEPARATOR___]
model = ARIMA(lyft_log, order=(0, 1, 2))  
results_MA = model.fit(disp=-1)  
plt.plot(lyft_log_diff)
plt.plot(results_MA.fittedvalues, color='red')
plt.title('RSS: %.4f'% sum((results_MA.fittedvalues-lyft_log_diff)**2))
# [___CELL_SEPARATOR___]
model = ARIMA(lyft_log, order=(2, 1, 2))  
results_ARIMA = model.fit(disp=-1)  
plt.plot(lyft_log_diff)
plt.plot(results_ARIMA.fittedvalues, color='red')
plt.title('RSS: %.4f'% sum((results_ARIMA.fittedvalues-lyft_log_diff)**2))
# [___CELL_SEPARATOR___]
predictions_ARIMA_diff = pd.Series(results_ARIMA.fittedvalues, copy=True)
print(predictions_ARIMA_diff.head())
# [___CELL_SEPARATOR___]
predictions_ARIMA_diff_cumsum = predictions_ARIMA_diff.cumsum()
print(predictions_ARIMA_diff_cumsum.head())
# [___CELL_SEPARATOR___]
predictions_ARIMA_log = pd.Series(lyft_log.ix[0], index=lyft_log.index)
predictions_ARIMA_log = predictions_ARIMA_log.add(predictions_ARIMA_diff_cumsum,fill_value=0)
predictions_ARIMA_log.head()
# [___CELL_SEPARATOR___]
predictions_ARIMA = np.exp(predictions_ARIMA_log)
plt.plot(y_lyft)
plt.plot(predictions_ARIMA)
plt.title('RMSE: %.4f'% np.sqrt(sum((predictions_ARIMA-y_lyft)**2)/len(y_lyft)))