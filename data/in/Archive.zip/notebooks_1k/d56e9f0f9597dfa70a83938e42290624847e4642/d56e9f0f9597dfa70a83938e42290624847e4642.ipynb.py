import fsspec
import xarray as xr
import numpy as np
import hvplot
import hvplot.dask
import hvplot.pandas
import hvplot.xarray
# [___CELL_SEPARATOR___]
from intake import open_catalog
cat = open_catalog("https://raw.githubusercontent.com/pangeo-data/pangeo-datastore/master/intake-catalogs/ocean/altimetry.yaml")
print(list(cat))
ds = cat['j3'].to_dask()
ds
# [___CELL_SEPARATOR___]
ds_ll = ds[['latitude', 'longitude', 'sla_filtered']].reset_coords().astype('f4').load()
ds_ll
# [___CELL_SEPARATOR___]
df = ds_ll.to_dataframe()
df
# [___CELL_SEPARATOR___]
df.hvplot.scatter(x='longitude', y='latitude', datashade=True, )
# [___CELL_SEPARATOR___]
from xhistogram.xarray import histogram

lon_bins = np.arange(0, 361, 2)
lat_bins = np.arange(-70, 71, 2)

# helps with memory management
ds_ll_chunked = ds_ll.chunk({'time': '5MB'})

sla_variance = histogram(ds_ll_chunked.longitude, ds_ll_chunked.latitude,
                         bins=[lon_bins, lat_bins],
                         weights=ds_ll_chunked.sla_filtered.fillna(0.)**2)

norm = histogram(ds_ll_chunked.longitude, ds_ll_chunked.latitude,
                         bins=[lon_bins, lat_bins])


# let's get at least 200 points in a box for it to be unmasked
thresh = 200
sla_variance = sla_variance / norm.where(norm > thresh)
sla_variance
# [___CELL_SEPARATOR___]
sla_variance.load()
# [___CELL_SEPARATOR___]
sla_variance.plot(x='longitude_bin', figsize=(12, 6), vmax=0.2)
# [___CELL_SEPARATOR___]
