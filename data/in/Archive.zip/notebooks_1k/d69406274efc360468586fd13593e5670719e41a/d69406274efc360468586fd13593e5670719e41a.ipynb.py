import numpy as np
import lightgbm as lgb
from wideboost.wrappers import wlgb
from sklearn import datasets
# [___CELL_SEPARATOR___]
digits = datasets.load_digits()

train_idx = np.random.choice(np.arange(1797),round(1797*0.7),replace=False)
test_idx = np.setdiff1d(np.arange(1797),train_idx)


xtrain = digits['data']
ytrain = digits['target']


train_data = lgb.Dataset(xtrain[train_idx,:], label=ytrain[train_idx])
test_data = lgb.Dataset(xtrain[test_idx,:], label=ytrain[test_idx])
# [___CELL_SEPARATOR___]
from hyperopt import fmin, tpe, hp, STATUS_OK, space_eval

best_val = 1.0

def objective(param):
    global best_val
    #watchlist = [(dtrain,'train'),(dtest,'test')]
    ed1_results = dict()
    print(param)
    param['num_leaves'] = round(param['num_leaves']+1)
    param['min_data_in_leaf'] = round(param['min_data_in_leaf'])
    wbst = lgb.train(param,
                      train_data,
                      num_boost_round=100,
                      valid_sets=test_data,
                      evals_result=ed1_results)
    output = min(ed1_results['valid_0']['multi_error'])
    
    if output < best_val:
        print("NEW BEST VALUE!")
        best_val = output
    
    return {'loss': output, 'status': STATUS_OK }

spc = {
    'objective': hp.choice('objective',['multiclass']),
    'metric':hp.choice('metric',['multi_error']),
    'num_class':hp.choice('num_class',[10]),
    'learning_rate': hp.loguniform('learning_rate', -7, 0),
    'num_leaves' : hp.qloguniform('num_leaves', 0, 7, 1),
    'feature_fraction': hp.uniform('feature_fraction', 0.5, 1),
    'bagging_fraction': hp.uniform('bagging_fraction', 0.5, 1),
    'min_data_in_leaf': hp.qloguniform('min_data_in_leaf', 0, 6, 1),
    'min_sum_hessian_in_leaf': hp.loguniform('min_sum_hessian_in_leaf', -16, 5),
    'lambda_l1': hp.choice('lambda_l1', [0, hp.loguniform('lambda_l1_positive', -16, 2)]),
    'lambda_l2': hp.choice('lambda_l2', [0, hp.loguniform('lambda_l2_positive', -16, 2)])
}


best = fmin(objective,
    space=spc,
    algo=tpe.suggest,
    max_evals=100)
# [___CELL_SEPARATOR___]
print(best_val)
print(space_eval(spc, best))
# [___CELL_SEPARATOR___]
1 - 0.0037 / 0.01669