import json

with open('indon-words-socialmedia.json') as fopen:
    indon_words_socialmedia = set(json.load(fopen))
    
len(indon_words_socialmedia)
# [___CELL_SEPARATOR___]
with open('ms-socialmedia.json') as fopen:
    socialmedia = json.load(fopen)
    
len(socialmedia)
# [___CELL_SEPARATOR___]
with open('en-socialmedia.json') as fopen:
    en_socialmedia = json.load(fopen)
    
len(en_socialmedia)
# [___CELL_SEPARATOR___]
from tqdm import tqdm

def filter_strings(strings):
    filtered = []
    for i in tqdm(range(len(strings))):
        if len(set(strings[i].split()) & indon_words_socialmedia):
            filtered.append(strings[i])
    return filtered
# [___CELL_SEPARATOR___]
import cleaning
# [___CELL_SEPARATOR___]
%%time

filtered = cleaning.multiprocessing(socialmedia, filter_strings)
# [___CELL_SEPARATOR___]
def filter_strings_notin(strings):
    filtered = []
    for i in tqdm(range(len(strings))):
        if not len(set(strings[i].split()) & indon_words_socialmedia):
            filtered.append(strings[i])
    return filtered
# [___CELL_SEPARATOR___]
%%time

filtered_notin = cleaning.multiprocessing(socialmedia, filter_strings_notin)
# [___CELL_SEPARATOR___]
len(filtered), len(filtered_notin)
# [___CELL_SEPARATOR___]
filtered = list(filter(None, filtered))
filtered_notin = list(filter(None, filtered_notin))
# [___CELL_SEPARATOR___]
filtered[:100]
# [___CELL_SEPARATOR___]
filtered_notin[:100]
# [___CELL_SEPARATOR___]
with open('filtered.json', 'w') as fopen:
    json.dump(filtered, fopen)
# [___CELL_SEPARATOR___]
with open('filtered_notin.json', 'w') as fopen:
    json.dump(filtered_notin, fopen)