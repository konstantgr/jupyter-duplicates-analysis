try:
    from textaugment import EDA
except ModuleNotFoundError:
    !pip install textaugment
    from textaugment import EDA
# [___CELL_SEPARATOR___]
t = EDA(random_state=1)
# [___CELL_SEPARATOR___]
output = t.synonym_replacement("John is going to town")
print(output)
# [___CELL_SEPARATOR___]
output = t.random_insertion("John is going to town")
print(output)
# [___CELL_SEPARATOR___]
output = t.random_swap("John is going to town")
print(output)
# [___CELL_SEPARATOR___]
output = t.random_deletion("John is going to town", p=0.2)
print(output)
# [___CELL_SEPARATOR___]
