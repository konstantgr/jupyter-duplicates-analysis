from protos import review_set_pb2, review_pb2
review_set = review_set_pb2.ReviewSet()
with open("data/yelpZip", 'rb') as f:
  review_set.ParseFromString(f.read())
print(len(review_set.reviews))
# [___CELL_SEPARATOR___]
from sklearn.utils import shuffle

fake_reviews = list(filter(lambda x: x.label, review_set.reviews))
count_fake = len(fake_reviews)
genuine_reviews = []
unused_genuine_reviews = []
counter_genuine = 0
for review in shuffle(review_set.reviews):
  if review.label == True:
    continue
  if counter_genuine <= count_fake:
    genuine_reviews.append(review)
    counter_genuine += 1
  else:
    unused_genuine_reviews.append(review)
  
concatted_reviews = fake_reviews + genuine_reviews
print("fake:", len(fake_reviews))
print("real:", len(genuine_reviews))
print("all:", len(concatted_reviews))
print("unused real:", len(unused_genuine_reviews))
# [___CELL_SEPARATOR___]
from scripts.feature_extraction import get_balanced_dataset
concatted_reviews = get_balanced_dataset()
# [___CELL_SEPARATOR___]
targets = [x.label for x in concatted_reviews]
# [___CELL_SEPARATOR___]
from exp4_data_feature_extraction import get_features_maker
get_features = get_features_maker(concatted_reviews)
# [___CELL_SEPARATOR___]
scoring = {
    'acc': 'accuracy',
    'auroc': 'roc_auc',
    'f1': 'f1'
}
# [___CELL_SEPARATOR___]
from sklearn.naive_bayes import MultinomialNB
from sklearn.model_selection import cross_validate

predictor_features = get_features(concatted_reviews)
naive_bayes = MultinomialNB()
fold = 10
results = cross_validate(naive_bayes, predictor_features, targets, cv=fold, scoring=scoring, return_train_score=False)
#print("Average accuracy:", sum([x for x in results['test_acc']])/fold)
# [___CELL_SEPARATOR___]
results