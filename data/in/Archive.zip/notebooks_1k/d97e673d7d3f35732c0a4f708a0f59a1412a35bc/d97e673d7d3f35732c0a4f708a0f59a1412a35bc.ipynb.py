!pip install scdeep
# [___CELL_SEPARATOR___]
!pip install -q scanpy
!pip install -q phenograph
# [___CELL_SEPARATOR___]
from google.colab import drive
drive.mount('/content/drive')
# [___CELL_SEPARATOR___]
cd 'drive/My Drive/BL uploads'
# [___CELL_SEPARATOR___]
import numpy as np
import pandas as pd
import scanpy as sc
import matplotlib.pyplot as plt
import torch
from sklearn.cluster import KMeans
import seaborn as sns
%matplotlib inline 
import scdeep 
# [___CELL_SEPARATOR___]
adata= sc.datasets.ebi_expression_atlas("E-GEOD-81547")
# [___CELL_SEPARATOR___]
z=(adata.X).toarray()
adata.X=z
# [___CELL_SEPARATOR___]
adata.shape
# [___CELL_SEPARATOR___]
adata1=adata.copy()
# [___CELL_SEPARATOR___]
#import phenograph
from sklearn.manifold import TSNE
from sklearn.metrics import adjusted_rand_score
# [___CELL_SEPARATOR___]
sc.pp.log1p(adata1)
sc.pp.highly_variable_genes(adata1, n_top_genes=1000, subset=True)
# [___CELL_SEPARATOR___]
adata1.X
# [___CELL_SEPARATOR___]
adata1.shape
# [___CELL_SEPARATOR___]
gene_expression = adata1.copy()
gene_expression = gene_expression.X
# [___CELL_SEPARATOR___]
from scdeep import scScope
# [___CELL_SEPARATOR___]
gene_expression_dataset = scdeep.dataset.GeneExpressionDataset()
gene_expression_dataset.from_data(gene_expression)
# [___CELL_SEPARATOR___]
model = scScope.scScope(gene_expression_dataset.data, [], [], 50, exp_batch_input=[])
trainer = scScope.scScopeTrainer(model, gene_expression_dataset, batch_size=64)
# [___CELL_SEPARATOR___]
trainer.train(num_epochs=100, lr=0.0008)
output_layer_numpy, latent_layer_numpy, batch_effect_layer = trainer.predict(gene_expression_dataset.data, gene_expression_dataset.batch_indices)
latent_code = np.concatenate(latent_layer_numpy, axis=1)
# [___CELL_SEPARATOR___]
output_layer_numpy, latent_layer_numpy, batch_effect_layer = trainer.predict(gene_expression_dataset.data, gene_expression_dataset.batch_indices)
latent_code = np.concatenate(latent_layer_numpy, axis=1)
oln1=output_layer_numpy[1]
l1=latent_layer_numpy[1]
# [___CELL_SEPARATOR___]
adata_sc=adata1.copy()
oln1 = np.array(oln1, dtype=float)
adata_sc.X = oln1
# [___CELL_SEPARATOR___]
adata_sc1=adata_sc.copy()
# [___CELL_SEPARATOR___]
a1=adata1.copy()
a2=adata_sc1.copy()
sc.pp.calculate_qc_metrics(a1, percent_top=None, log1p=False, inplace=True)
sc.pp.calculate_qc_metrics(a2, percent_top=None, log1p=False, inplace=True)
# [___CELL_SEPARATOR___]
sc.pl.violin(a1, ['n_genes_by_counts', 'total_counts'],jitter=0.7, multi_panel=True)
sc.pl.violin(a2, ['n_genes_by_counts', 'total_counts'], jitter=0.7, multi_panel=True)
# [___CELL_SEPARATOR___]
fig, axs = plt.subplots(3, 2, figsize=(10,10))
sns.distplot(a1.obs["total_counts"], kde=False, ax=axs[0,0])
sns.distplot(a1.obs["total_counts"], kde=False, bins=60, color= 'red', ax=axs[0,1])
sns.distplot(a2.obs["n_genes_by_counts"], kde=False, ax=axs[1,0])
sns.distplot(a2.obs["n_genes_by_counts"], kde=False, bins=60, color= 'red', ax=axs[1,1])
sns.distplot(a1.var["n_cells_by_counts"], kde=False,bins=100,  ax=axs[2,0])
plt.yscale('log') 
sns.distplot(a2.var["n_cells_by_counts"], kde=False, color= 'red',bins=100, ax=axs[2,1])
plt.yscale('log') 
# [___CELL_SEPARATOR___]
sc.pp.log1p(adata1)#normalise
sc.pp.scale(adata1)#scale
sc.pp.pca(adata1) 
sc.pl.pca_overview(adata1,color='Sample Characteristic[inferred cell type]')
# [___CELL_SEPARATOR___]
sc.pp.log1p(adata_sc1)#normalise
sc.pp.scale(adata_sc1)#scale
sc.pp.pca(adata_sc1) 
sc.pl.pca_overview(adata_sc1, color='Sample Characteristic[inferred cell type]')
# [___CELL_SEPARATOR___]
q1=adata1.copy()
q2=adata_sc1.copy()
# [___CELL_SEPARATOR___]
sc.tl.tsne(q1, perplexity=30, learning_rate=1000, random_state=0)
sc.tl.tsne(q2, perplexity=30, learning_rate=1000, random_state=0)
sc.pl.tsne(q1, color='Sample Characteristic[inferred cell type]')
sc.pl.tsne(q2, color='Sample Characteristic[inferred cell type]')
# [___CELL_SEPARATOR___]
sc.pp.neighbors(adata1)
sc.tl.umap(adata1, min_dist=0.5, spread=1.0, random_state=1, n_components=2)

sc.pp.neighbors(adata_sc1)
sc.tl.umap(adata_sc1, min_dist=0.5, spread=1.0, random_state=1, n_components=2)

sc.pl.umap(adata1, color='Sample Characteristic[inferred cell type]')
sc.pl.umap(adata_sc1, color='Sample Characteristic[inferred cell type]')
# [___CELL_SEPARATOR___]
umap_coordinates = adata1.obsm['X_umap'] 
kmeans = KMeans(n_clusters=6, random_state=0).fit(umap_coordinates) 

adata1.obs['kmeans'] = kmeans.labels_ 
adata1.obs['kmeans'] = adata1.obs['kmeans'].astype(str)

sc.pl.umap(adata1, color='kmeans') 
# [___CELL_SEPARATOR___]
rand_index = adjusted_rand_score(labels_true = adata1.obs['Sample Characteristic[inferred cell type]'], labels_pred = adata1.obs['kmeans'])
print('The Rand index is', round(rand_index, 2))
# [___CELL_SEPARATOR___]
umap_coordinates = adata_sc1.obsm['X_umap'] 
kmeans = KMeans(n_clusters=6, random_state=0).fit(umap_coordinates) 

adata_sc1.obs['kmeans'] = kmeans.labels_ 
adata_sc1.obs['kmeans'] = adata_sc1.obs['kmeans'].astype(str)

sc.pl.umap(adata_sc1, color='kmeans') 
# [___CELL_SEPARATOR___]
rand_index = adjusted_rand_score(labels_true = adata1.obs['Sample Characteristic[inferred cell type]'], labels_pred = adata_sc1.obs['kmeans'])
print('The Rand index is', round(rand_index, 2))
# [___CELL_SEPARATOR___]
sc.tl.rank_genes_groups(adata1, groupby='Sample Characteristic[inferred cell type]', use_raw=True, method='t-test_overestim_var', n_genes=10) # compute differential expression
sc.pl.rank_genes_groups_tracksplot(adata1, groupby='Sample Characteristic[inferred cell type]') # plot the result
# [___CELL_SEPARATOR___]
sc.tl.rank_genes_groups(adata_sc1, groupby='Sample Characteristic[inferred cell type]', use_raw=True, method='t-test_overestim_var', n_genes=10) # compute differential expression
sc.pl.rank_genes_groups_tracksplot(adata_sc1, groupby='Sample Characteristic[inferred cell type]') # plot the result
# [___CELL_SEPARATOR___]
sc.pl.rank_genes_groups_heatmap(adata1, n_genes=3, standard_scale='var')
sc.pl.rank_genes_groups_heatmap(adata_sc1, n_genes=3, standard_scale='var')