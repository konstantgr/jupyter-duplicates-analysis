"""
Weather II - Precipitation
"""

# Repeat the same process as p1, using this new set of variables.

sunny = True
raining = True
snowing = False

is_it_sunny = None
is_there_precipitation = None
is_it_sleeting = None
is_there_rainbow = None