%load_ext autoreload
%autoreload 2
# [___CELL_SEPARATOR___]
%matplotlib inline
from cbrain.imports import *
from cbrain.utils import *
import matplotlib as mpl
from matplotlib.animation import FuncAnimation
from mpl_toolkits.axes_grid1.inset_locator import inset_axes
from IPython.display import SVG, HTML, FileLink
# [___CELL_SEPARATOR___]
FIG_DIR = './figures/'
TMP_DIR = '/beegfs/DATA/pritchard/srasp/tmp/'
#DATA_DIR = '/beegfs/DATA/pritchard/srasp/'
DATA_DIR = '/scratch/05488/tg847872/'
#%ls -t {DATA_DIR}
# [___CELL_SEPARATOR___]
# Set colors for line plots
# $yellow:    #b58900;
# $orange:    #cb4b16;
# $red:       #dc322f;
# $magenta:   #d33682;
# $violet:    #6c71c4;
# $blue:      #268bd2;
# $cyan:      #2aa198;
# $green:     #859900;
colors = ['#268bd2', '#dc322f', '#859900']
#colors = ['#6c71c4', '#cb4b16', '#2aa198']

colors2 = ['#8da0cb', '#fc8d62', '#66c2a5']
# [___CELL_SEPARATOR___]
def save_tmp(name, obj):
    with open(f'{TMP_DIR}{name}.pkl', 'wb') as f:
        pickle.dump(obj, f)
def load_tmp(name):
    with open(f'{TMP_DIR}{name}.pkl', 'rb') as f:
        obj = pickle.load(f)
    return obj
# [___CELL_SEPARATOR___]
def savefigs(fig, name):
    fig.savefig(FIG_DIR + name + '.pdf')
    fig.savefig(FIG_DIR + name + '.png', dpi=500, bbox_inches='tight')
# [___CELL_SEPARATOR___]
exps_ak = ['sp8fbp_andkua', 'nnatmonly_fbp8_D025_andkua_nofix_betafix35', 
           'nnatmonly_fbp8_D024_andkua_nofix_betafix35',
           'nnatmonly_fbp8_D032_andkua_nofix_betafix35', 'nonsp_andkua']
exps_ak_D024 = ['sp8fbp_andkua', 'nnatmonly_fbp8_D024_andkua_nofix_betafix35', 'nonsp_andkua']
exps_ak_D025 = ['sp8fbp_andkua', 'nnatmonly_fbp8_D025_andkua_nofix_betafix35', 'nonsp_andkua']
#exps_ak_nf = ['nnatmonly_fbp8_D024_andkua_nofix_betafix35', 'nnatmonly_fbp8_D025_andkua_nofix_betafix35']
# exps_length = ['nnatmonly_fbp8_D018_andkua_nofix_betafix35', 'nnatmonly_fbp8_D019_andkua_nofix_betafix35', 
#                'nnatmonly_fbp8_D020_andkua_nofix_betafix35', 'nnatmonly_fbp8_D021_andkua_nofix_betafix35']
# exps_betafix = ['nnatmonly_fbp8_D004_andkua_nofix', 'nnatmonly_fbp8_D004_andkua_nofix_betafix25', 
#                 'nnatmonly_fbp8_D004_andkua_nofix_betafix35',  'nnatmonly_fbp8_D004_andkua_nofix_betafix5']
exps_1k = ['sp8fbp_1k', 'nnatmonly_fbp8_D025_1k_nofix_betafix35', 
           'nnatmonly_fbp8_D024_1k_nofix_betafix35', 'nnatmonly_fbp8_D032_1k_nofix_betafix35', 'nonsp_1k']
exps_2k = ['sp8fbp_2k', 'nnatmonly_fbp8_D025_2k_nofix_betafix35', 
           'nnatmonly_fbp8_D024_2k_nofix_betafix35',
           'nnatmonly_fbp8_D032_2k_nofix_betafix35', 'nonsp_2k']
exps_3k = ['sp8fbp_3k', 'nnatmonly_fbp8_D025_3k_nofix_betafix35', 
           'nnatmonly_fbp8_D024_3k_nofix_betafix35',
           'nnatmonly_fbp8_D032_3k_nofix_betafix35', 'nonsp_3k']
exps_4k = ['sp8fbp_4k', 'nnatmonly_fbp8_D025_4k_nofix_betafix35', 
           'nnatmonly_fbp8_D024_4k_nofix_betafix35',
           'nnatmonly_fbp8_D032_4k_nofix_betafix35', 'nonsp_4k']
exps_1k_D024 = ['sp8fbp_1k', 'nnatmonly_fbp8_D024_1k_nofix_betafix35', 'nonsp_1k']
exps_2k_D024 = ['sp8fbp_2k', 'nnatmonly_fbp8_D024_2k_nofix_betafix35', 'nonsp_2k']
exps_3k_D024 = ['sp8fbp_3k', 'nnatmonly_fbp8_D024_3k_nofix_betafix35', 'nonsp_3k']
exps_4k_D024 = ['sp8fbp_4k', 'nnatmonly_fbp8_D024_4k_nofix_betafix35', 'nonsp_4k']
exps_1k_D025 = ['sp8fbp_1k', 'nnatmonly_fbp8_D025_1k_nofix_betafix35', 'nonsp_1k']
exps_2k_D025 = ['sp8fbp_2k', 'nnatmonly_fbp8_D025_2k_nofix_betafix35', 'nonsp_2k']
exps_3k_D025 = ['sp8fbp_3k', 'nnatmonly_fbp8_D025_3k_nofix_betafix35', 'nonsp_3k']
exps_4k_D025 = ['sp8fbp_4k', 'nnatmonly_fbp8_D025_4k_nofix_betafix35', 'nonsp_4k']
exps_3kw1 = ['sp8fbp_3kw1', 'nnatmonly_fbp8_D025_3kw1_nofix_betafix35', 
           'nnatmonly_fbp8_D024_3kw1_nofix_betafix35',  
           'nnatmonly_fbp8_D032_3kw1_nofix_betafix35', 'nonsp_3kw1']
exps_3kw1_D024 = ['sp8fbp_3kw1', 'nnatmonly_fbp8_D024_3kw1_nofix_betafix35', 'nonsp_3kw1']
exps_3kw1_D025 = ['sp8fbp_3kw1', 'nnatmonly_fbp8_D025_3kw1_nofix_betafix35', 'nonsp_3kw1']
# exps_3kw1 = ['sp8fbp_3kw1', 'nnatmonly_fbp8_D004_3kw1_nofix', 'nonsp_3kw1']
exps = exps_ak + exps_1k + exps_2k + exps_3k + exps_4k + exps_3kw1

exps_sp = ['sp8fbp_andkua', 'sp8fbp_1k', 'sp8fbp_2k', 'sp8fbp_3k', 'sp8fbp_4k']
exps_D024 = ['nnatmonly_fbp8_D024_andkua_nofix_betafix35', 'nnatmonly_fbp8_D024_1k_nofix_betafix35', 
           'nnatmonly_fbp8_D024_2k_nofix_betafix35', 'nnatmonly_fbp8_D024_3k_nofix_betafix35', 
           'nnatmonly_fbp8_D024_4k_nofix_betafix35']
exps_D025 = ['nnatmonly_fbp8_D025_andkua_nofix_betafix35', 'nnatmonly_fbp8_D025_1k_nofix_betafix35', 
           'nnatmonly_fbp8_D025_2k_nofix_betafix35', 'nnatmonly_fbp8_D025_3k_nofix_betafix35', 
           'nnatmonly_fbp8_D025_4k_nofix_betafix35']
exps_D031 = ['nnatmonly_fbp8_D031_andkua_nofix_betafix35', 'nnatmonly_fbp8_D031_1k_nofix_betafix35', 
           'nnatmonly_fbp8_D031_2k_nofix_betafix35', 'nnatmonly_fbp8_D031_3k_nofix_betafix35', 
           'nnatmonly_fbp8_D031_4k_nofix_betafix35']
exps_D032 = ['nnatmonly_fbp8_D032_andkua_nofix_betafix35', 'nnatmonly_fbp8_D032_1k_nofix_betafix35', 
           'nnatmonly_fbp8_D032_2k_nofix_betafix35', 'nnatmonly_fbp8_D032_3k_nofix_betafix35', 
           'nnatmonly_fbp8_D032_4k_nofix_betafix35']
exps_nonsp = ['nonsp_andkua', 'nonsp_1k', 'nonsp_2k', 'nonsp_3k', 'nonsp_4k']
exps_review = ['nnatmonly_fbp8_D033_andkua_nofix_betafix35', 'nnatmonly_fbp8_D034_andkua_nofix_betafix35',
               'nnatmonly_fbp8_D035_andkua_nofix_betafix35', 'nnatmonly_fbp8_D037_andkua_nofix_betafix35',
               'nnatmonly_fbp8_D038_andkua_nofix_betafix35', 'nnatmonly_fbp8_D039_andkua_nofix_betafix35',
               'nnatmonly_fbp8_D040_andkua_nofix_betafix35']
# [___CELL_SEPARATOR___]
variables = ['TAP', 'QAP', 'UAP', 'VAP', 'TPHYSTND', 'PHQ', 'PRECT', 'FSNS', 'FSNT', 'FLNS', 'FLNT', 'TS', 'TW', 'TE',
            'PS', 'P0', 'hyai', 'hybi', 'NNDQ', 'NNDT', 'gw', 'LHFLX', 'SHFLX', 'NNLHF', 'NNSHF', 
            'NNFSNT', 'NNFSNS', 'NNFLNT', 'NNFLNS']
# [___CELL_SEPARATOR___]
year = '[1-5]'
#year = '1'
# [___CELL_SEPARATOR___]
%%time
h0s = {e : xr.open_mfdataset(f'{DATA_DIR}{e}/*.h0.000{year}-*', decode_times=False) for e in list(set(exps))}
# [___CELL_SEPARATOR___]
for e in exps_review[-2:]:
    h0s[e] = xr.open_mfdataset(f'{DATA_DIR}{e}/*.h0.0*', decode_times=False)
# [___CELL_SEPARATOR___]
for e, d in h0s.items():
    if not 'PRECT' in d.data_vars:
        d['PRECT'] = d['PRECC'] + d['PRECL']
# [___CELL_SEPARATOR___]
#save_tmp('saved_h0s', h0s)
h0s = load_tmp('saved_h0s')
# [___CELL_SEPARATOR___]
for ds in h0s.values():
    tmp = list(ds.data_vars)
    for v in tmp:
        if v not in variables:
            del ds[v]
# [___CELL_SEPARATOR___]
%%time
h0means = {e: h.mean('time').compute() for e, h in h0s.items()}
# [___CELL_SEPARATOR___]
for e in exps_review[-2:]:
    h0means[e] = h0s[e].mean('time').compute()
# [___CELL_SEPARATOR___]
for e in exps_review[-2:]:
    h0means[e]['PRECT'] *= 1e3*24*3600
# [___CELL_SEPARATOR___]
for e, d in h0means.items():
    d['PRECT'] *= 1e3*24*3600
# [___CELL_SEPARATOR___]
#save_tmp('saved_h0means', h0means)
h0means = load_tmp('saved_h0means')
# [___CELL_SEPARATOR___]
%%time
h1s = {e : xr.open_mfdataset(f'{DATA_DIR}{e}/*.h1.0001-01*', decode_times=False, decode_cf=False) 
       for e in exps_ak}
# [___CELL_SEPARATOR___]
#save_tmp('saved_h1s', h1s)
h1s = load_tmp('saved_h1s')
# [___CELL_SEPARATOR___]
for e in exps_norm:
    h1s[e] = xr.open_mfdataset(f'{DATA_DIR}{e}/*.h1.0001-01*', decode_times=False, decode_cf=False)
# [___CELL_SEPARATOR___]
for ds in h1s.values():
    tmp = list(ds.data_vars)
    for v in tmp:
        if v not in variables:
            del ds[v]
# [___CELL_SEPARATOR___]
%%time
h1stds = {e: h.isel(time=slice(0, None, 8)).std('time').compute() for e, h in h1s.items()}
# [___CELL_SEPARATOR___]
#save_tmp('h1stds', h1stds)
h1stds = load_tmp('h1stds')
# [___CELL_SEPARATOR___]
def compare(func, exps, ref=None, title=None, hs=h0means, **kwargs):
    npanels = len(exps) if ref is None else len(exps) + 1
    ncols=min(3, npanels); nrows=int(np.ceil(npanels/ncols))
    fig, axs = plt.subplots(nrows, ncols, figsize=(13.5, 4*nrows));
    if ref is None:
        [func(hs[e]).plot(ax=ax, **kwargs) for e, ax in zip(exps, axs.flat)]
        [ax.set_title(e) for e, ax in zip(exps, axs.flat)]
    else:
        yi = kwargs['yincrease'] if 'yincrease' in kwargs.keys() else None
        func(hs[ref]).plot(ax=axs.flat[0], yincrease=yi); axs.flat[0].set_title(ref)
        [(func(hs[e])-func(hs[ref]).values).plot(ax=ax, **kwargs) for e, ax in zip(exps, axs.flat[1:])]
        [ax.set_title(f'{e} - {ref}'[-50:]) for e, ax in zip(exps, axs.flat[1:])]
    if title is None: plt.tight_layout()
    else: fig.suptitle(title); plt.tight_layout(rect=(0, 0, 1, 0.95))
    return fig, axs
# [___CELL_SEPARATOR___]
def compare_line(func, exps, hs, ax=None, legend=True, **kwargs):
    if ax is None: fig, ax = plt.subplots(figsize=(6, 5))
    [func(hs[e]).plot(ax=ax, label=e, **kwargs) for e in exps]
    if legend: ax.legend()
# [___CELL_SEPARATOR___]
def climate_error(meanf, errf, ref, exps):
    means = [meanf(h0s[e]) for e in [ref] + exps]
    err = [errf(means[0], means[i]) for i in range(1, len(means))]
    stats = [vint(means[0], da, 1) for da in err]
    stats = [gw_avg(means[0], '', da).compute() for da in stats]
    return stats
# [___CELL_SEPARATOR___]
inchincm = 2.45
twocols = 17.8/inchincm # Inches
onecol = twocols*0.95*0.5
onecol, twocols
# [___CELL_SEPARATOR___]
FONTSIZE = 6
plt.rc('font', size=FONTSIZE)          # controls default text sizes
plt.rc('axes', titlesize=FONTSIZE)     # fontsize of the axes title
plt.rc('axes', labelsize=FONTSIZE)    # fontsize of the x and y labels
plt.rc('xtick', labelsize=FONTSIZE)    # fontsize of the tick labels
plt.rc('ytick', labelsize=FONTSIZE)    # fontsize of the tick labels
plt.rc('legend', fontsize=FONTSIZE)    # legend fontsize
plt.rc('figure', titlesize=FONTSIZE)  # fontsize of the figure title
# [___CELL_SEPARATOR___]
levs = h0s[exps_ak[0]].lev; levs
# [___CELL_SEPARATOR___]
# Gaussian latitudes
lats = h0s[exps_ak[0]].lat.values
gw = h0s[exps_ak[0]].gw.isel(time=1)
gwsum = np.cumsum(gw.values)
# [___CELL_SEPARATOR___]
label_lats = [-90, -45, -20, 0, 20, 45, 90]
#label_lats = [-60, -30, 0, 30, 60]
gw_lats = [np.interp(l, lats, gwsum) for l in label_lats]
# [___CELL_SEPARATOR___]
def mean_panels(hdict, func, exps, exp_ref=None, vmin=-5, vmax=5, cm_ref='plasma', cm='RdBu_r', unit='Temperature [K]', 
                contourf=False, levels_ref=None, levels=None, clevels=None, clabel_locs=[], clabel_fmt='%.0f', 
                clev_color='white', width=twocols*0.6, height=1.7, titles=None, cbar_ticks=None, gw=True):
    has_ref = int(exp_ref is not None)
    npanels = len(exps) + has_ref
    fig, axs = plt.subplots(1, npanels, figsize=(width, height))
    
    if has_ref:
        da_ref = func(hdict[exp_ref]) 
        if gw: da_ref['lat'] = gwsum
        if contourf:
            da_ref.plot.contourf(ax=axs[0], yincrease=False, add_colorbar=False, cmap=cm_ref, levels=levels_ref)
            if clevels is not None:
                cs = da_ref.plot.contour(ax=axs[0], yincrease=False, add_colorbar=False, levels=clevels, 
                                         colors=clev_color, linewidths=1)
                plt.clabel(cs, fmt=clabel_fmt, manual=clabel_locs)
        else:
            da_ref.plot(ax=axs[0], yincrease=False, add_colorbar=False, cmap=cm_ref)
    
    for ax, exp in zip(axs.flat[has_ref:], exps):
        da = func(hdict[exp])
        if gw: da['lat'] = gwsum
        if has_ref: da -= da_ref
        if contourf:
            im = da.plot.contourf(ax=ax, yincrease=False, add_colorbar=False, cmap=cm, levels=levels)
        else:
            im = da.plot(ax=ax, yincrease=False, add_colorbar=False, vmin=vmin, vmax=vmax, cmap=cm)
            
    if gw: 
        [ax.set_xticks(gw_lats) for ax in axs.flat]
    else:
        [ax.set_xticks(label_lats) for ax in axs.flat]
    [ax.set_xticklabels(label_lats) for ax in axs.flat]; 
    [ax.set_yticks([]) for ax in axs.flat[1:]]; [ax.set_ylabel('') for ax in axs.flat[1:]];
    axs[0].set_ylabel('Pressure [hPa]'); [ax.set_xlabel('Latitude') for ax in axs.flat]
    if titles is not None: [ax.set_title(titles[i], pad=3) for i, ax in enumerate(axs.flat)]
    
    plt.subplots_adjust(wspace=0.03, left=0.13, right=1.0, bottom=0.22, top=0.9)
    cb = fig.colorbar(im, ax=axs.flat, pad=0.01, extend='both', use_gridspec=False); cb.set_label(unit)
    if cbar_ticks is not None: cb.set_ticks(cbar_ticks)
    cb.formatter.set_powerlimits((-2, 2)); cb.update_ticks()
    cb.ax.yaxis.set_offset_position('left')
    
    return fig, axs
# [___CELL_SEPARATOR___]
titles=['SPCAM', 'NNCAM_paper', 'NNCAM_larger', 'NNCAM_smaller', 'NNCAM_tiny', 'NNCAM_big_fluxes', 
                       'NNCAM_shallow']
# [___CELL_SEPARATOR___]
exps_tmp = exps_ak[:2] + exps_review; exps_tmp
# [___CELL_SEPARATOR___]
exps_nnsize = ['sp8fbp_andkua', 'nnatmonly_fbp8_D033_andkua_nofix_betafix35', 
               'nnatmonly_fbp8_D025_andkua_nofix_betafix35', 'nnatmonly_fbp8_D034_andkua_nofix_betafix35',
               'nnatmonly_fbp8_D037_andkua_nofix_betafix35', 'nnatmonly_fbp8_D038_andkua_nofix_betafix35']
# [___CELL_SEPARATOR___]
titles_nnsize = ['SPCAM', 'NNCAM 8x512', 'NNCAM 9x256 (ours)', 'NNCAM 4x256', 
                 'NNCAM 2x256', 'NNCAM 1x256']
# [___CELL_SEPARATOR___]
clabel_locs = [(1, 150), (1, 200), (1, 300), (1, 500), (1, 900)]
# [___CELL_SEPARATOR___]
f, axs = mean_panels(h0means, lambda d: d['TAP'].isel(lev=slice(5, None)).mean('lon'), 
                exps_nnsize[1:], exps_nnsize[0], 
                    contourf=True, width=twocols, 
               titles=titles_nnsize,
                    clevels=np.arange(190, 310, 20), levels_ref=np.arange(180, 305, 5), 
                    levels=np.arange(-5, 6, 0.5), clabel_locs=clabel_locs)
# [___CELL_SEPARATOR___]
savefigs(f, 'mean_T_review_nnsize')
# [___CELL_SEPARATOR___]
f, axs = mean_panels(h0means, lambda d: d['TPHYSTND'].isel(lev=slice(3, None)).mean('lon'), exps_nnsize, 
                contourf=True, width=twocols,
                     titles=titles_nnsize,
                levels=np.arange(-7.5e-5, 8.25e-5, 7.5e-6), unit='$\Delta$T$_{\mathrm{phy}}$ [K s$^{-1}$]',
                cbar_ticks=np.arange(-6e-5, 8e-5, 2e-5))
# [___CELL_SEPARATOR___]
savefigs(f, 'mean_TPHY_review_nnsize')
# [___CELL_SEPARATOR___]
ctmp = sns.color_palette("hls", 6)
# [___CELL_SEPARATOR___]
f = mean_panels_line(h0means, ['FSNT','FLNT', 'PRECT'], exps_nnsize, ctmp, 
                     labels=titles_nnsize, zorders=range(7), #width=2*twocols, height=5,
                     ylabels=['TOA solar \n' r'[W m$^{-2}$]', 'TOA thermal \n' r'[W m$^{-2}$]',
                              'Precipitation \n' r'[mm d$^{-1}$]'])
# [___CELL_SEPARATOR___]
savefigs(f, 'mean_flux_prec_review_nnsize')
# [___CELL_SEPARATOR___]
climerr_nnsize = climate_error(h0means,
    lambda d: d.isel(lev=slice(5, None), ilev=slice(5, None)),
    lambda ref, d: np.fabs(ref['TAP'] - d['TAP']), exps_nnsize[0], exps_nnsize[1:])
# [___CELL_SEPARATOR___]
f, ax=plt.subplots()
sns.barplot(data=climerr_nnsize, ax=ax)
plt.xticks(range(5), titles_nnsize[1:], rotation=45)
plt.ylabel('Climate error')
# [___CELL_SEPARATOR___]
f.savefig(FIG_DIR + 'climerr_nnsize' + '.png', dpi=500, bbox_inches='tight')
# [___CELL_SEPARATOR___]
for var in ['FSNT','FLNT', 'PRECT']:
    h0means['nnatmonly_fbp8_D040_andkua_nofix_betafix35'][var] /= 5
    #h0means['nnatmonly_fbp8_D039_andkua_nofix_betafix35'][var] *= 5
# [___CELL_SEPARATOR___]
exps_norm = ['sp8fbp_andkua', 'nnatmonly_fbp8_D025_andkua_nofix_betafix35', 
             'nnatmonly_fbp8_D040_andkua_nofix_betafix35', 'nnatmonly_fbp8_D039_andkua_nofix_betafix35']
# [___CELL_SEPARATOR___]
titles_norm = ['SPCAM', 'NNCAM ref (this paper)', 'NNCAM fluxes * 5', 'NNCAM fluxes / 5']
# [___CELL_SEPARATOR___]
clabel_locs = [(1, 150), (1, 200), (1, 300), (1, 500), (1, 900)]
# [___CELL_SEPARATOR___]
f, axs = mean_panels(h0means, lambda d: d['TAP'].isel(lev=slice(5, None)).mean('lon'), 
                exps_norm[1:], exps_norm[0], 
                    contourf=True, width=twocols*0.8, 
               titles=titles_norm,
                    clevels=np.arange(190, 310, 20), levels_ref=np.arange(180, 305, 5), 
                    levels=np.arange(-5, 6, 0.5), clabel_locs=clabel_locs)
# [___CELL_SEPARATOR___]
#savefigs(f, 'mean_T_review_nnsize')
f.savefig(FIG_DIR + 'mean_T_review_norm' + '.png', dpi=500, bbox_inches='tight')
# [___CELL_SEPARATOR___]
f, axs = mean_panels(h0means, lambda d: d['TPHYSTND'].isel(lev=slice(3, None)).mean('lon'), exps_norm, 
                contourf=True, width=twocols*0.8,
                     titles=titles_norm,
                levels=np.arange(-7.5e-5, 8.25e-5, 7.5e-6), unit='$\Delta$T$_{\mathrm{phy}}$ [K s$^{-1}$]',
                cbar_ticks=np.arange(-6e-5, 8e-5, 2e-5))
# [___CELL_SEPARATOR___]
#savefigs(f, 'mean_TPHY_review_nnsize')
f.savefig(FIG_DIR + 'mean_TPHY_review_norm' + '.png', dpi=500, bbox_inches='tight')
# [___CELL_SEPARATOR___]
ctmp = sns.color_palette("hls", 4)
# [___CELL_SEPARATOR___]
f = mean_panels_line(h0means, ['FSNT','FLNT', 'PRECT'], exps_norm, ctmp, 
                     labels=titles_norm, zorders=range(7), #width=2*twocols, height=5,
                     ylabels=['TOA solar \n' r'[W m$^{-2}$]', 'TOA thermal \n' r'[W m$^{-2}$]',
                              'Precipitation \n' r'[mm d$^{-1}$]'])
# [___CELL_SEPARATOR___]
#savefigs(f, 'mean_flux_prec_review_nnsize')
f.savefig(FIG_DIR + 'mean_flux_prec_review_norm' + '.png', dpi=500, bbox_inches='tight')
# [___CELL_SEPARATOR___]
climerr_norm = climate_error(h0means,
    lambda d: d.isel(lev=slice(5, None), ilev=slice(5, None)),
    lambda ref, d: np.fabs(ref['TAP'] - d['TAP']), exps_norm[0], exps_norm[1:])
# [___CELL_SEPARATOR___]
f, ax=plt.subplots()
sns.barplot(data=climerr_norm, ax=ax)
plt.xticks(range(3), titles_norm[1:], rotation=45)
plt.ylabel('Climate error')
# [___CELL_SEPARATOR___]
f.savefig(FIG_DIR + 'climerr_norm' + '.png', dpi=500, bbox_inches='tight')
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
h1s['nnatmonly_fbp8_D040_andkua_nofix_betafix35']['PRECT'] /= 10
h1s['nnatmonly_fbp8_D039_andkua_nofix_betafix35']['PRECT'] *= 5
# [___CELL_SEPARATOR___]
for e in exps_norm:
    prects[e] = h1s[e]['PRECT'].plot(range=(0, 4.5e-6), bins=100, label=e)
# [___CELL_SEPARATOR___]
fig, ax = plt.subplots(figsize=(twocols*0.4, 1.7))
plt.subplots_adjust(wspace=0.03, left=0.13, right=0.9, bottom=0.22, top=0.9)
[ax.plot(prects[e][1][:-1]*1e3*24*3600, prects[e][0]/prects[e][0].sum(), label=titles_norm[i], 
         ) for i, e in enumerate(exps_norm)]
ax.set_yscale('log')
ax.legend(ncol=2)
sns.despine()
ax.set_xlabel(r'Precipitation [mm d$^{-1}$]'); ax.set_ylabel(r'Frequency')
#ax.set_title('Precipitation distribution')
#ax.ticklabel_format(axis='x', scilimits=(0, 0))
ax.set_ylim(1e-6, 1); 
ax.set_xlim(0, 350);
#prects[exps[0]][1][-1]*1e3*24*3600
# [___CELL_SEPARATOR___]
savefigs(fig, 'prec_hist_norm')
# [___CELL_SEPARATOR___]
fig.savefig(FIG_DIR + 'prec_hist_norm' + '.png', dpi=500, bbox_inches='tight')
# [___CELL_SEPARATOR___]
exps_norm
# [___CELL_SEPARATOR___]
WK_DATA = '/beegfs/DATA/pritchard/srasp/wkdata/'
!ls {WK_DATA}
# [___CELL_SEPARATOR___]
wks = [xr.open_dataset(f'{WK_DATA}SpaceTime.PRECT.{e}.nc') 
              for e in exps_norm]
# [___CELL_SEPARATOR___]
wks = [wk.isel(freq=slice(1, None)) for wk in wks]
# [___CELL_SEPARATOR___]
freq_days = 1/wks[0].freq
# [___CELL_SEPARATOR___]
labels_days = [30, 10, 5]
labels_freq = 1/np.array(labels_days)
# [___CELL_SEPARATOR___]
hs = [12, 25, 50]
g = 9.81
# [___CELL_SEPARATOR___]
def ER(k, h):
    n = 1; lat = 0.
    Beta = 2. * 7.292E-5 * np.cos(abs(lat)) / 6.37E6
    t4 = (Beta / np.ma.sqrt(g * h)) * (2 * n + 1.)
    return -Beta * k / (k * k + t4)
# [___CELL_SEPARATOR___]
lat = 0.
ll = 2. * np.pi * 6.37E6 * np.cos(abs(lat))
# [___CELL_SEPARATOR___]
k = 2 * np.pi * wks[0].wave / ll
# [___CELL_SEPARATOR___]
wks[0].freq
# [___CELL_SEPARATOR___]
def tofreq(x): return 1/(2 * np.pi / (x * 24 * 60 * 60))
# [___CELL_SEPARATOR___]
def wk_panel(ax, data, title, add_text=True, ref=None, label_color='white', 
             field='FIG_3_SYM', **kwargs):
    d = data[field] if ref is None else data[field] - ref
    im = ax.contourf(data.wave, data.freq, d, **kwargs)
    ax.set_yticks(labels_freq); ax.set_yticklabels(labels_days);
    [ax.axhline(y, linestyle='--', c='gray', zorder=1.1, linewidth=0.75, alpha=0.5) for y in labels_freq]
    [ax.plot(data.wave, tofreq(k*np.sqrt(g * h)), c='gray', lw=0.7, alpha=0.5) for h in hs];
    [ax.plot(data.wave, tofreq(ER(k, h)), c='gray', lw=0.7, alpha=0.5) for h in hs];
    #ax.set_xlim(data.wave[0], data.wave[-1]); ax.set_ylim(data.freq[0], data.freq[-1]);
    ax.set_xlim(-10, 10); ax.set_ylim(data.freq[0], 0.3);
    if add_text:
        ax.text(5, 1/4, 'Kelvin', color=label_color, weight='bold', fontsize=5, zorder=2);
        ax.text(-9, 1/15, 'n=1 ER', color=label_color, weight='bold', fontsize=5, zorder=2);
        ax.text(4, 1/30, 'MJO', color=label_color, weight='bold', fontsize=5, zorder=2);
    ax.set_xlabel(r'Zonal $k$'); ax.set_ylabel('Period [days]')
    ax.set_title(title, pad=4)
    ax.set_xticks([-10, -5, 0, 5, 10])
    return im
# [___CELL_SEPARATOR___]
titles_norm
# [___CELL_SEPARATOR___]
def wk_panels(data, levels=np.arange(1.2, 3.1, 0.1), ref=None, cmap='nipy_spectral', 
              label_color='white', field='FIG_3_SYM'):
    fig, axs = plt.subplots(1, 4, figsize=(twocols*0.9, 1.7))
    for i, (ax, wk) in enumerate(zip(axs.flat, data)):
        im = wk_panel(ax, wk, titles_norm[i], True if i == 0 else False, cmap=cmap, 
                      levels=levels, extend='both', ref=ref if ref is None else ref[i]['FIG_3_SYM'],
                      label_color=label_color, field=field)
        if i > 0: ax.set_ylabel(''); ax.set_yticks([])
    plt.subplots_adjust(wspace=0.03, left=0.13, right=1.0, bottom=0.22, top=0.9)
    cb = fig.colorbar(im, ax=axs, pad=0.01); #cb.set_label('Log power spectrum')
    cb.set_ticks(np.arange(-20, 20, 0.5))
    return fig
# [___CELL_SEPARATOR___]
f = wk_panels(wks)
# [___CELL_SEPARATOR___]
savefigs(f, 'wk_norm')
# [___CELL_SEPARATOR___]
f = mean_panels(h0means, lambda d: d['TAP'].isel(lev=slice(5, None)).mean('lon'), 
                exps_ak_nf + [exps_ak_D024[1]] + [exps_ak_D025[1]], exps_ak[0], 
                    contourf=True, width=pagewidth, 
               titles=['ref'] + exps_ak_nf + [exps_ak_D024[1]] + [exps_ak_D025[1]],
                    clevels=np.arange(190, 310, 20), levels_ref=np.arange(180, 305, 5), 
                    levels=np.arange(-5, 6, 0.5), clabel_locs=clabel_locs)
# [___CELL_SEPARATOR___]
sst_titles = ['+0K', '+1K', '+2K', '+3K', '+4K']
# [___CELL_SEPARATOR___]
clabel_locs = [(1, 180), (1, 200), (1, 400), (1, 600), (1, 900)]
# [___CELL_SEPARATOR___]
for name, exps in zip(['SPCAM', 'NNCAM-ref', 'NNCAM-ref+4K', 'NNCAM-ref+1k', 'NNCAM-4K', 'CTRLCAM'], 
                      [exps_sp, exps_D025, exps_D024, exps_D031, exps_D032, exps_nonsp]):
    f = mean_panels(h0means, lambda d: d['TAP'].isel(lev=slice(5, None)).mean('lon'), exps[1:], exps[0], 
                    contourf=True, width=twocols*0.8, titles=[name] + sst_titles[1:], 
                    clevels=np.arange(190, 310, 20), levels_ref=np.arange(180, 305, 5), 
                    levels=np.arange(-10, 11, 1), clabel_locs=clabel_locs)
    f.savefig(f'{FIG_DIR}warming_T_{name}.pdf')
    plt.show()
# [___CELL_SEPARATOR___]
clabel_locs = [(0.2, 900), (0.7, 900)]
# [___CELL_SEPARATOR___]
for name, exps in zip(['SPCAM', 'NNCAM-ref', 'NNCAM-ref+4K', 'NNCAM-ref+1k', 'NNCAM-4K', 'CTRLCAM'], 
                      [exps_sp, exps_D025, exps_D024, exps_D031, exps_D032, exps_nonsp]):
    f = mean_panels(h0means, lambda d: d['QAP'].isel(lev=slice(5, None)).mean('lon'), exps[1:], exps[0], 
                    contourf=True, width=twocols*0.8, titles=[name] + sst_titles[1:], 
                    clevels=np.arange(0, 0.024, 0.004), levels_ref=np.arange(0, 0.021, 0.001), clabel_fmt='%.3f',
                    levels=np.arange(-0.005, 0.0055, 0.0005), clabel_locs=clabel_locs, unit=r'Specific humidity [kg kg$^{-1}$]')
    f.savefig(f'{FIG_DIR}warming_Q_{name}.pdf')
    plt.show()
# [___CELL_SEPARATOR___]
for name, exps in zip(['SPCAM', 'NNCAM-ref', 'NNCAM-ref+4K', 'NNCAM-ref+1k', 'NNCAM+4K', 'CTRLCAM'], 
                      [exps_sp, exps_D025, exps_D024, exps_D031, exps_D032, exps_nonsp]):
    f, axs = mean_panels(h0means, lambda d: d['TPHYSTND'].isel(lev=slice(5, None)).mean('lon'), exps[1:], exps[0], 
                    contourf=True, width=twocols, titles=[name] + sst_titles[1:], 
                    levels_ref=np.arange(-5e-5, 5.5e-5, 5e-6), unit='$\Delta$T$_{phys}$ [K s$^{-1}$]',
                    levels=np.arange(-4e-5, 4e-5, 4e-6), cm_ref='PRGn', cbar_ticks=np.arange(-4e-5, 5e-5, 1e-5))
    savefigs(f, f'warming_TPHY_{name}')
    plt.show()
# [___CELL_SEPARATOR___]
for name, exps in zip(['SPCAM', 'NNCAM-ref', 'NNCAM-ref+4K', 'NNCAM-ref+1k', 'NNCAM-4K', 'CTRLCAM'], 
                      [exps_sp, exps_D025, exps_D024, exps_D031, exps_D032, exps_nonsp]):
    f = mean_panels(h0means, lambda d: d['PHQ'].isel(lev=slice(5, None)).mean('lon'), exps[1:], exps[0], 
                    contourf=True, width=twocols*0.8, titles=[name] + sst_titles[1:], 
                    levels_ref=np.arange(-3e-8, 3.3e-8, 3e-9), unit='$\Delta$Q$_{phys}$ [kg kg$^{-1}$ s$^{-1}$]',
                    levels=np.arange(-2e-8, 2.2e-8, 2e-9), cm_ref='PRGn')
    f.savefig(f'{FIG_DIR}warming_PHQ_{name}.pdf')
    plt.show()
# [___CELL_SEPARATOR___]
compare(lambda d: d['TAP'].sel(time=slice(30, None)).mean(('time', 'lon')), 
        exps_length + ['nnatmonly_fbp8_D004_andkua_nofix_betafix35'], ref=exps_ak[0], 
        yincrease=False, vmin=-5, vmax=5, cmap='RdBu_r', title='Mean Temperature');
# [___CELL_SEPARATOR___]
compare(lambda d: d['QAP'].sel(time=slice(30, None)).mean(('time', 'lon')), 
        exps_length + ['nnatmonly_fbp8_D004_andkua_nofix_betafix35'], ref=exps_ak[0], 
        yincrease=False, vmin=-0.002, vmax=0.002, cmap='RdBu_r', title='Mean Humidity');
# [___CELL_SEPARATOR___]
climerr = climate_error(
    lambda d: d.sel(time=slice(30, None)).isel(lev=slice(5, None), ilev=slice(5, None)).mean(('time')),
    lambda ref, d: np.fabs(ref['TAP'] - d['TAP']), exps_ak[0], 
    exps_length + ['nnatmonly_fbp8_D004_andkua_nofix_betafix35'])
# [___CELL_SEPARATOR___]
plt.plot(climerr)
# [___CELL_SEPARATOR___]
climerr = climate_error(
    lambda d: d.sel(time=slice(30, None)).isel(lev=slice(5, None), ilev=slice(5, None)).mean(('time')),
    lambda ref, d: np.fabs(ref['QAP'] - d['QAP']), exps_ak[0], 
    exps_length + ['nnatmonly_fbp8_D004_andkua_nofix_betafix35'])
# [___CELL_SEPARATOR___]
plt.plot(climerr)
# [___CELL_SEPARATOR___]
clabel_locs = [(1, 150), (1, 200), (1, 300), (1, 500), (1, 900)]
# [___CELL_SEPARATOR___]
f = mean_panels(h0means, lambda d: d['TAP'].isel(lev=slice(3, None)).mean('lon'), exps_ak_D025[1:], exps_ak_D025[0], 
                contourf=True, titles=['SPCAM', 'NNCAM - SPCAM', 'CTRLCAM - SPCAM'], 
                clevels=np.arange(190, 310, 20), levels_ref=np.arange(180, 305, 5),
                levels=np.arange(-5, 5.5, 0.5), clabel_locs=clabel_locs, cbar_ticks=[-4, -2, 0, 2, 4])
# [___CELL_SEPARATOR___]
f = mean_panels(h0means, lambda d: d['TAP'].isel(lev=slice(3, None)).mean('lon'), exps_ak_D025[1:], exps_ak_D025[0], 
                contourf=True, titles=['SPCAM', 'NNCAM - SPCAM', 'CTRLCAM - SPCAM'], 
                clevels=np.arange(190, 310, 20), levels_ref=np.arange(180, 305, 5),
                levels=np.arange(-5, 5.5, 0.5), clabel_locs=clabel_locs, cbar_ticks=[-4, -2, 0, 2, 4], gw=False)
# [___CELL_SEPARATOR___]
TAP = h0means[exps_ak_D025[0]]['TAP'].isel(lev=slice(2, None)).mean('lon')
P = get_P_from_ds(h0means[exps_ak_D025[0]])
THETA = TAP * (1e5/P.isel(ilev=slice(3, None)).mean('lon').values) ** 0.286
dTHETA = THETA.diff('lev')
dTHETA['lat'] = gwsum
# [___CELL_SEPARATOR___]
f, axs = mean_panels(h0means, lambda d: d['TAP'].isel(lev=slice(3, None)).mean('lon'), exps_ak_D025[1:], exps_ak_D025[0], 
                contourf=True, titles=['SPCAM', 'NNCAM - SPCAM', 'CTRLCAM - SPCAM'], 
                clevels=np.arange(190, 310, 20), levels_ref=np.arange(180, 305, 5),
                levels=np.arange(-5, 5.5, 0.5), clabel_locs=clabel_locs, cbar_ticks=[-4, -2, 0, 2, 4])
[ax.contour(dTHETA.lat, dTHETA.lev, dTHETA.values, levels=[-10], colors='k') for ax in axs];
# [___CELL_SEPARATOR___]
savefigs(f, 'mean_temperature')
# [___CELL_SEPARATOR___]
TAP = h0means[exps_3kw1_D025[0]]['TAP'].isel(lev=slice(2, None)).mean('lon')
P = get_P_from_ds(h0means[exps_3kw1_D025[0]])
THETA = TAP * (1e5/P.isel(ilev=slice(3, None)).mean('lon').values) ** 0.286
dTHETA = THETA.diff('lev')
dTHETA['lat'] = gwsum
# [___CELL_SEPARATOR___]
f, axs = mean_panels(h0means, lambda d: d['TAP'].isel(lev=slice(3, None), lon=slice(32,98)).mean('lon'), exps_3kw1_D025[1:], exps_3kw1_D025[0], 
                contourf=True, titles=['SPCAM', 'NNCAM - SPCAM', 'CTRLCAM - SPCAM'], 
                clevels=np.arange(190, 310, 20), levels_ref=np.arange(180, 305, 5),
                levels=np.arange(-5, 5.5, 0.5), clabel_locs=clabel_locs, cbar_ticks=[-4, -2, 0, 2, 4])
[ax.contour(dTHETA.lat, dTHETA.lev, dTHETA.values, levels=[-10], colors='k') for ax in axs];
# [___CELL_SEPARATOR___]
savefigs(f, 'mean_temperature_3kw1')
# [___CELL_SEPARATOR___]
for name, exps in zip(['+0K', '+1K', '+2K', '+3K', '+4K'], 
                      [exps_ak, exps_1k, exps_2k, exps_3k, exps_4k]):
    f, axs = mean_panels(h0means, lambda d: d['TAP'].isel(lev=slice(3, None)).mean('lon'), exps[1:], exps[0], 
                    contourf=True, width=twocols, 
                    titles=['SPCAM ' + name, 'NNCAM', 'NNCAM-ref+4k', 'NNCAM+4K', 'CTRLCAM'], 
                    clevels=np.arange(190, 310, 20), levels_ref=np.arange(180, 305, 5),
                    levels=np.arange(-5, 5.5, 0.5), clabel_locs=clabel_locs, cbar_ticks=[-4, -2, 0, 2, 4])
    [ax.contour(dTHETA.lat, dTHETA.lev, dTHETA.values, levels=[-10], colors='k') for ax in axs];
    savefigs(f, f'comp_T_{name}')
    plt.show()
# [___CELL_SEPARATOR___]
clabel_locs = [(0.2, 800), (1, 800)]
# [___CELL_SEPARATOR___]
f, axs = mean_panels(h0means, lambda d: d['QAP'].isel(lev=slice(5, None)).mean('lon'), exps_ak_D025[1:], exps_ak_D025[0], 
                contourf=True, titles=['SPCAM', 'NNCAM - SPCAM', 'CTRLCAM - SPCAM'], 
                clevels=np.arange(0, 0.024, 0.004), levels_ref=np.arange(0, 0.021, 0.001), clabel_fmt='%.3f',
                levels=np.arange(-0.002, 0.0022, 0.0002), clabel_locs=clabel_locs, 
                unit=r'Specific humidity [kg kg$^{-1}$]', cbar_ticks=np.arange(-2e-3, 3e-3, 1e-3))
# [___CELL_SEPARATOR___]
savefigs(f, 'mean_humidity')
# [___CELL_SEPARATOR___]
for name, exps in zip(['+0K', '+1K', '+2K', '+3K', '+4K'], 
                      [exps_ak_D024, exps_1k_D024, exps_2k_D024, exps_3k_D024, exps_4k_D024]):
    f = mean_panels(h0means, lambda d: d['QAP'].isel(lev=slice(5, None)).mean('lon'), exps[1:], exps[0], 
                    contourf=True, width=twocols, titles=['SPCAM ' + name, 'NNCAM - SPCAM', 'CTRLCAM - SPCAM'], 
                    clevels=np.arange(0, 0.024, 0.004), levels_ref=np.arange(0, 0.021, 0.001), clabel_fmt='%.3f',
                    levels=np.arange(-0.002, 0.0022, 0.0002), clabel_locs=clabel_locs, unit=r'Specific humidity [kg kg$^{-1}$]')
    f.savefig(f'{FIG_DIR}comp_Q_{name}.pdf')
    plt.show()
# [___CELL_SEPARATOR___]
clabel_locs = [(1, 700), (0.75, 450), (0.6, 300)]
# [___CELL_SEPARATOR___]
f, axs = mean_panels(h0means, lambda d: d['UAP'].isel(lev=slice(5, None)).mean('lon'), exps_ak_D025[1:], exps_ak_D025[0], 
                contourf=True, titles=['SPCAM', 'NNCAM - SPCAM', 'CTRLCAM - SPCAM'], 
                clevels=[-10, 0, 10, 30], levels_ref=np.arange(-80, 85, 5), cm_ref='PRGn', clev_color='k',
                levels=np.arange(-20, 22, 2), clabel_locs=clabel_locs, unit=r'Zonal wind [m s$^{-1}$]',
                cbar_ticks=np.arange(-20, 30, 10))
# [___CELL_SEPARATOR___]
savefigs(f, 'mean_wind')
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
for name, exps in zip(['+0K', '+1K', '+2K', '+3K', '+4K'], 
                      [exps_ak_D024, exps_1k_D024, exps_2k_D024, exps_3k_D024, exps_4k_D024]):
    f = mean_panels(h0means, lambda d: d['UAP'].isel(lev=slice(5, None)).mean('lon'), exps[1:], exps[0], 
                    contourf=True, width=twocols, titles=['SPCAM ' + name, 'NNCAM - SPCAM', 'CTRLCAM - SPCAM'], 
                    clevels=[-10, 0, 10, 30], levels_ref=np.arange(-80, 85, 5), cm_ref='PRGn', clev_color='k',
                    levels=np.arange(-20, 22, 2), clabel_locs=clabel_locs, unit=r'Zonal wind [m s$^{-1}$]')
    f.savefig(f'{FIG_DIR}comp_U_{name}.pdf')
    plt.show()
# [___CELL_SEPARATOR___]
f, axs = mean_panels(h0means, lambda d: d['TPHYSTND'].isel(lev=slice(3, None)).mean('lon'), exps_ak_D025, 
                contourf=True, titles=['SPCAM', 'NNCAM', 'CTRLCAM'],
                levels=np.arange(-7.5e-5, 8.25e-5, 7.5e-6), unit='$\Delta$T$_{\mathrm{phy}}$ [K s$^{-1}$]',
                cbar_ticks=np.arange(-6e-5, 8e-5, 2e-5))
# [___CELL_SEPARATOR___]
savefigs(f, 'mean_heating')
# [___CELL_SEPARATOR___]
for name, exps in zip(['+0K', '+1K', '+2K', '+3K', '+4K'], 
                      [exps_ak, exps_1k, exps_2k, exps_3k, exps_4k]):
    f, axs = mean_panels(h0means, lambda d: d['TPHYSTND'].isel(lev=slice(3, None)).mean('lon'), exps, 
                    contourf=True, width=twocols, 
                    titles=['SPCAM ' + name, 'NNCAM', 'NNCAM-ref+4k', 'NNCAM+4K', 'CTRLCAM'],
                    levels=np.arange(-7.5e-5, 8.25e-5, 7.5e-6), unit='$\Delta$T$_{\mathrm{phy}}$ [K s$^{-1}$]',
                    cbar_ticks=np.arange(-6e-5, 8e-5, 2e-5))
    savefigs(f, f'comp_TPHY_{name}')
    plt.show()
# [___CELL_SEPARATOR___]
f, axs = mean_panels(h1stds, lambda d: d['TPHYSTND'].isel(lev=slice(5, None)).mean('lon'), exps_ak_D025, 
                contourf=True, titles=['SPCAM', 'NNCAM', 'CTRLCAM'],
                levels=np.arange(0, 2.1e-4, 1e-5), cm='nipy_spectral', unit='Std $\Delta$T$_{\mathrm{phy}}$ [K s$^{-1}$]',
                cbar_ticks=np.arange(0, 3e-4, 0.5e-4))
# [___CELL_SEPARATOR___]
savefigs(f, 'std_heating')
# [___CELL_SEPARATOR___]
for name, exps in zip(['+0K', '+1K', '+2K', '+3K', '+4K'], 
                      [exps_ak_D024, exps_1k_D024, exps_2k_D024, exps_3k_D024, exps_4k_D024]):
    f = mean_panels(h1stds, lambda d: d['TPHYSTND'].isel(lev=slice(5, None)).mean('lon'), exps, 
                    contourf=True, width=twocols, titles=['SPCAM ' + name, 'NNCAM', 'CTRLCAM'],
                    levels=np.arange(0, 2e-4, 2e-5), cm='inferno', unit='Std $\Delta$T$_{\mathrm{phy}}$ [K s$^{-1}$]')
    f.savefig(f'{FIG_DIR}comp_stdTPHY_{name}.pdf')
    plt.show()
# [___CELL_SEPARATOR___]
f, axs = mean_panels(h0means, lambda d: d['PHQ'].isel(lev=slice(5, None)).mean('lon'), exps_ak_D025, 
                contourf=True, titles=['SPCAM', 'NNCAM', 'CTRLCAM'],
                levels=np.arange(-3e-8, 3.3e-8, 3e-9), unit='$\Delta$Q$_{\mathrm{phy}}$ [kg kg$^{-1}$ s$^{-1}$]',
                cbar_ticks=np.arange(-3e-8, 4e-8, 1e-8))
# [___CELL_SEPARATOR___]
savefigs(f, 'mean_moistening')
# [___CELL_SEPARATOR___]
for name, exps in zip(['+0K', '+1K', '+2K', '+3K', '+4K'], 
                      [exps_ak_D024, exps_1k_D024, exps_2k_D024, exps_3k_D024, exps_4k_D024]):
    f = mean_panels(h0means, lambda d: d['PHQ'].isel(lev=slice(5, None)).mean('lon'), exps, 
                    contourf=True, width=twocols, titles=['SPCAM ' + name, 'NNCAM', 'CTRLCAM'],
                    levels=np.arange(-3e-8, 3.3e-8, 3e-9), unit='$\Delta$Q$_{\mathrm{phy}}$ [kg kg$^{-1}$ s$^{-1}$]')
    f.savefig(f'{FIG_DIR}comp_PHQ_{name}.pdf')
    plt.show()
# [___CELL_SEPARATOR___]
f, axs = mean_panels(h1stds, lambda d: d['PHQ'].isel(lev=slice(5, None)).mean('lon'), exps_ak_D025, 
                contourf=True, titles=['SPCAM', 'NNCAM', 'CTRLCAM'],
                levels=np.arange(0, 2.1e-7, 1e-8), cm='nipy_spectral',
                unit=r'Std $\Delta$Q$_{\mathrm{phy}}$ [kg kg$^{-1}$ s$^{-1}$]',
                cbar_ticks=np.arange(0, 3e-7, 0.5e-7))
# [___CELL_SEPARATOR___]
savefigs(f, 'std_moistening')
# [___CELL_SEPARATOR___]
for name, exps in zip(['+0K', '+1K', '+2K', '+3K', '+4K'], 
                      [exps_ak_D024, exps_1k_D024, exps_2k_D024, exps_3k_D024, exps_4k_D024]):
    f = mean_panels(h1stds, lambda d: d['PHQ'].isel(lev=slice(5, None)).mean('lon'), exps, 
                    contourf=True, width=twocols, titles=['SPCAM ' + name, 'NNCAM', 'CTRLCAM'],
                    levels=np.arange(0, 2e-7, 2e-8), cm='inferno',
                    unit=r'Std $\Delta$Q$_{\mathrm{phy}}$ [kg kg$^{-1}$ s$^{-1}$]')
    f.savefig(f'{FIG_DIR}comp_stdPHQ_{name}.pdf')
    plt.show()
# [___CELL_SEPARATOR___]
def climate_error(hdict, meanf, errf, ref, exps):
    means = [meanf(hdict[e]) for e in [ref] + exps]
    err = [errf(means[0], means[i]) for i in range(1, len(means))]
    stats = [vavg(means[0], da, 1) for da in err]
    stats = [gw_avg(means[0], '', da).compute() for da in stats]
    return stats
# [___CELL_SEPARATOR___]
climerr = {v: [climate_error(h0means,
    lambda d: d.isel(lev=slice(5, None), ilev=slice(5, None)),
    lambda ref, d: np.fabs(ref[v] - d[v]), e[0], e[1:]) 
           for e in [exps_ak, exps_1k, exps_2k, exps_3k, exps_4k]] for v in ['TAP', 'QAP', 'TPHYSTND', 'PHQ']}
# [___CELL_SEPARATOR___]
np.array(climerr['TAP']).shape
# [___CELL_SEPARATOR___]
def plot_climerr(data, var=r'$T$ difference [K]', legend=True):
    fig, ax = plt.subplots(figsize=(twocols*0.3, 1.7)); 
    plt.subplots_adjust(left=0.3, right=0.95, bottom=0.22, top=0.9)
    data = np.array(data); data /= data[0, 2]
    x = np.arange(5)
    sns.despine()
    plt.scatter(x, data[:, 0], label='NNCAM', c=colors[1], s=15)
    plt.scatter(x, data[:, 1], label='NNCAM-ref+4K', 
                edgecolors='#cb4b16', marker='D', c=(1, 1, 0, 0.), s=15)
    plt.scatter(x, data[:, 2], label='NNCAM+4K', zorder=2.,
                edgecolors=colors[1], marker='x', c='#d33682', s=15)
    plt.scatter(x, data[:, 3], label='CTRLCAM', c=(1, 1, 0, 0.), 
                edgecolors=colors[2], zorder=1.5, s=15)
    if legend: plt.legend(frameon=False);
    plt.ylabel(var)
    plt.xlabel('SST increase [K]');
    return fig
# [___CELL_SEPARATOR___]
f = plot_climerr(climerr['TAP']); savefigs(f, 'climerr_TAP')
# [___CELL_SEPARATOR___]
f = plot_climerr(climerr['QAP'], 'humidity', legend=False); savefigs(f, 'climerr_QAP')
# [___CELL_SEPARATOR___]
f = plot_climerr(climerr['TPHYSTND'], 'heating rate', False); savefigs(f, 'climerr_TPHYSTND')
# [___CELL_SEPARATOR___]
f = plot_climerr(climerr['PHQ'], 'moistening rate', False); savefigs(f, 'climerr_PHQ')
# [___CELL_SEPARATOR___]
f, axs = mean_panels(h1s, lambda d: d['TPHYSTND'].isel(lev=slice(5, None), lon=35, time=7), exps_ak_D025,
                contourf=False, titles=['SPCAM', 'NNCAM', 'CTRLCAM'], 
                vmin=-5e-4, vmax=5e-4, unit='$\Delta$T$_{\mathrm{phy}}$ [K s$^{-1}$]')
# [___CELL_SEPARATOR___]
savefigs(f, 'snapshot_heating')
# [___CELL_SEPARATOR___]
f, axs = mean_panels(h1s, lambda d: d['PHQ'].isel(lev=slice(5, None), lon=35, time=7), exps_ak_D025,
                contourf=False, titles=['SPCAM', 'NNCAM', 'CTRLCAM'], 
                vmin=-3e-7, vmax=3e-7, unit='$\Delta$Q$_{\mathrm{phy}}$ [kg kg$^{-1}$ s$^{-1}$]')
# [___CELL_SEPARATOR___]
savefigs(f, 'snapshot_moistening')
# [___CELL_SEPARATOR___]
def mean_panels_line(hdict, vars, exps, colors, width=twocols*0.4, height=2.95, labels=None, ylabels=None, 
                     bottom_space=0.12, zorders=[2, 3, 1]):
    npanels = len(vars)
    fig, axs = plt.subplots(npanels, 1, figsize=(width, height))
    if labels is None: labels = exps
    for iax, ax in enumerate(axs.flat):
        if ylabels is not None: ax.set_ylabel(ylabels[iax])
        for ie, e in enumerate(exps):
            ax.plot(gwsum, hdict[e][vars[iax]].mean('lon'), c=colors[ie], lw=2, label=labels[ie], zorder=zorders[ie])
            
    [ax.set_xticks(gw_lats) for ax in axs.flat]; [ax.set_xticklabels(label_lats) for ax in axs.flat]; 
    [ax.set_xlim(0, 2) for ax in axs.flat]
    axs[-1].set_xlabel('Latitude')
    [ax.set_xticklabels([]) for ax in axs.flat[:-1]]
    [ax.yaxis.tick_right() for ax in axs.flat]
    [ax.yaxis.set_label_position("right") for ax in axs.flat]
    
    if labels is not None: axs[0].legend()
    
    plt.subplots_adjust(wspace=0.03, hspace=0.15, left=0.1, right=0.90, bottom=bottom_space, top=0.98)    
    return fig
# [___CELL_SEPARATOR___]
f = mean_panels_line(h0means, ['FSNT','FLNT', 'PRECT'], exps_ak_D025, colors, 
                     labels=['SPCAM', 'NNCAM', 'CTRLCAM'],
                     ylabels=['TOA solar \n' r'[W m$^{-2}$]', 'TOA thermal \n' r'[W m$^{-2}$]',
                              'Precipitation \n' r'[mm d$^{-1}$]'])
# [___CELL_SEPARATOR___]
savefigs(f, 'TOA_precip')
# [___CELL_SEPARATOR___]
f = mean_panels_line(h0means, ['FSNS','FLNS'], exps_ak_D025, colors, 
                     labels=['SPCAM', 'NNCAM', 'CTRLCAM'], height=2.1, bottom_space=0.2,
                     ylabels=['Surface solar \n' r'[W m$^{-2}$]', 'Surface thermal \n' r'[W m$^{-2}$]'])
# [___CELL_SEPARATOR___]
savefigs(f, 'surface_radiation')
# [___CELL_SEPARATOR___]
for e in exps_3kw1:
    h0means[e]['vintTPHYSTND'] = vint(h0means[e], 'TPHYSTND', C_P).compute()
# [___CELL_SEPARATOR___]
for e in exps_3kw1:
    h0means[e]['vavgTAP'] = vavg(h0means[e], 'TAP', 1, lev_sl=slice(16, None)).compute()
# [___CELL_SEPARATOR___]
import cartopy.crs as ccrs
import matplotlib.ticker as mticker
from cartopy.mpl.gridliner import LONGITUDE_FORMATTER, LATITUDE_FORMATTER
# [___CELL_SEPARATOR___]
def latlon_panels(hdict, func, exps, exp_ref=None, cm_ref='plasma', cm='RdBu_r', unit='Temperature [K]', 
                levels_ref=None, levels=None, clevels=None, clabel_locs=[], clabel_fmt='%.0f', 
                clev_color='white', width=twocols*0.7, height=1.7, titles=None, cbar_ticks=None, unit_ref='',
                 cbar_ticks_ref=None, no_diff=False):
    has_ref = int(exp_ref is not None)
    npanels = len(exps) + has_ref
    fig, axs = plt.subplots(1,npanels, figsize=(width, height), subplot_kw=dict(projection=ccrs.Robinson()))
    
    if has_ref:
        da_ref = func(hdict[exp_ref])
        da_ref = xr.DataArray(
            np.concatenate([da_ref.values, da_ref.values[:, -1][:, None]], 1), 
            dims={'lat': da_ref.lat, 'lon': list(da_ref.lon) + [360.]}, 
            coords={'lat': da_ref.lat, 'lon': list(da_ref.lon) + [360.]})
        im = da_ref.plot.contourf(ax=axs[0], add_colorbar=False, cmap=cm_ref, levels=levels_ref,
                             transform=ccrs.PlateCarree())
        cb = fig.colorbar(im, ax=axs[0], pad=0.01, extend='both', orientation='horizontal'); 
        cb.set_label(unit_ref)
        if cbar_ticks is not None: cb.set_ticks(cbar_ticks_ref)
        cb.formatter.set_powerlimits((-3, 3)); cb.update_ticks()
        cb.ax.yaxis.set_offset_position('left')

    for ax, exp in zip(axs.flat[has_ref:], exps):
        da = func(hdict[exp]).copy() 
        da = xr.DataArray(
            np.concatenate([da.values, da.values[:, -1][:, None]], 1), 
            dims={'lat': da.lat, 'lon': list(da.lon) + [360.]}, 
            coords={'lat': da.lat, 'lon': list(da.lon) + [360.]})
        if has_ref and not no_diff: 
            da -= da_ref
        im = da.plot.contourf(ax=ax, add_colorbar=False, cmap=cm, levels=levels, transform=ccrs.PlateCarree())
        cb = fig.colorbar(im, ax=ax, pad=0.01, extend='both', orientation='horizontal'); 
        cb.set_label(unit)
        if cbar_ticks is not None: cb.set_ticks(cbar_ticks)
        cb.formatter.set_powerlimits((-2, 2)); cb.update_ticks()
        cb.ax.yaxis.set_offset_position('left')
            
#     [ax.set_xticks(gw_lats) for ax in axs.flat]; [ax.set_xticklabels(label_lats) for ax in axs.flat]; 
#     [ax.set_yticks([]) for ax in axs.flat[1:]]; [ax.set_ylabel('') for ax in axs.flat[1:]];
#     axs[0].set_ylabel('Pressure [hPa]'); [ax.set_xlabel('Latitude') for ax in axs.flat]
    if titles is not None: [ax.set_title(titles[i], pad=4) for i, ax in enumerate(axs.flat)]
    
    plt.subplots_adjust(wspace=0.01, hspace=0.3, left=0.0, right=1, bottom=0.22, top=0.9)
    
    
    return fig, axs
# [___CELL_SEPARATOR___]
pert = h0means[exps_3kw1_D024[0]]['TS'] - h0means[exps_ak[0]]['TS']
# [___CELL_SEPARATOR___]
tmp = xr.DataArray(np.concatenate([pert.values, pert.values[:, -1][:, None]], 1), 
                   dims={'lat': pert.lat, 'lon': list(pert.lon) + [360.]}, 
                   coords={'lat': pert.lat, 'lon': list(pert.lon) + [360.]})
# [___CELL_SEPARATOR___]
fig, axs = latlon_panels(h0means, lambda d: d['vintTPHYSTND'], exps_3kw1_D025, 
                         unit=r'$^{C_p}/_G \int \Delta T_{\mathrm{phy}} \mathrm{d}p$ [W m$^{-2}$]', 
                         levels=np.arange(-800, 880, 80), cbar_ticks=np.arange(-1000, 1000, 250));
[tmp.plot.contour(ax=ax, colors='k', linestyles='-', levels=[0.5, 1.5, 2.5], transform=ccrs.PlateCarree(),
                   linewidths=0.75, alpha=0.5) for ax in axs.flat]
[tmp.plot.contour(ax=ax, colors='k', linestyles='--', levels=[-2.5, -1.5, -0.5], transform=ccrs.PlateCarree(),
                   linewidths=0.75, alpha=0.5) for ax in axs.flat];
titles=['SPCAM', 'NNCAM', 'CTRLCAM']
[ax.set_title(titles[i], pad=4) for i, ax in enumerate(axs.flat)];
# [___CELL_SEPARATOR___]
savefigs(fig, '3kw1_tphys')
# [___CELL_SEPARATOR___]
??vavg
# [___CELL_SEPARATOR___]
h0means[exps_3kw1_D025[0]]['vintTAP'].plot()
# [___CELL_SEPARATOR___]
for e in exps_3kw1_D025[1:]:
    d = h0means[e]
    d['dTAP'] = np.fabs(d['TAP'] - h0means[exps_3kw1_D025[0]]['TAP'])
    d['vavgdTAP'] = vavg(d, 'dTAP', 1, lev_sl=slice(20, None)).compute()
# [___CELL_SEPARATOR___]
h0means[exps_3kw1_D025[0]]['vavgdTAP'] = h0means[exps_3kw1_D025[0]]['vavgTAP']
# [___CELL_SEPARATOR___]
fig, axs = latlon_panels(h0means, lambda d: d['vavgdTAP'], exps_3kw1_D025[1:], exp_ref=exps_3kw1_D025[0],
                         unit_ref=r'$(p_0 - p_t)^{-1} \int_{p_0}^{p_t} T \mathrm{d}p$ [K]', 
                         unit=r'$(p_0 - p_t)^{-1} \int_{p_0}^{p_t} T \mathrm{d}p$ [K]',
                         levels=np.arange(-3, 3, 0.1), levels_ref=np.arange(240, 285, 2),
                         cbar_ticks=np.arange(-4, 4, 1), cbar_ticks_ref=np.arange(240, 300, 10), no_diff=True);
[tmp.plot.contour(ax=ax, colors='k', linestyles='-', levels=[0.5, 1.5, 2.5], transform=ccrs.PlateCarree(),
                   linewidths=0.75, alpha=0.5) for ax in axs.flat]
[tmp.plot.contour(ax=ax, colors='k', linestyles='--', levels=[-2.5, -1.5, -0.5], transform=ccrs.PlateCarree(),
                   linewidths=0.75, alpha=0.5) for ax in axs.flat];
titles=['SPCAM', 'NNCAM - SPCAM', 'CTRLCAM - SPCAM']
[ax.set_title(titles[i], pad=4) for i, ax in enumerate(axs.flat)];
# [___CELL_SEPARATOR___]
savefigs(fig, '3kw1_vavgT')
# [___CELL_SEPARATOR___]
fig, axs = latlon_panels(h0means, lambda d: d['PRECT'], exps_ak_D025, 
                         unit=r'Std Prec [mm d$^{-1}$]', levels=np.arange(0, 21, 1), width=twocols*0.75,
                         titles=['SPCAM', 'NNCAM', 'CTRLCAM'], height=1, cbar_ticks=[0, 5, 10, 15, 20]);
# [___CELL_SEPARATOR___]
savefigs(fig, 'prec_var_global')
# [___CELL_SEPARATOR___]
for name, exps in zip(['+0K', '+1K', '+2K', '+3K', '+4K'], 
                      [exps_ak_D024, exps_1k_D024, exps_2k_D024, exps_3k_D024, exps_4k_D024]):
    fig, axs = latlon_panels(h0means, lambda d: d['FSNS'], exps[1:], exps[0], 
                             titles=['SPCAM ' + name, 'NNCAM - SPCAM', 'CTRLCAM - SPCAM'],
                             levels_ref=np.arange(0, 300, 20),
                             levels=np.arange(-50, 55, 5),
                             unit=r'Surface shortwave flux [W m$^{-2}$]');
    fig.savefig(f'{FIG_DIR}globe_FSNS_{name}.pdf')
    plt.show()
# [___CELL_SEPARATOR___]
for name, exps in zip(['+0K', '+1K', '+2K', '+3K', '+4K'], 
                      [exps_ak_D024, exps_1k_D024, exps_2k_D024, exps_3k_D024, exps_4k_D024]):
    fig, axs = latlon_panels(h0means, lambda d: d['FSNT'], exps[1:], exps[0], 
                             titles=['SPCAM ' + name, 'NNCAM - SPCAM', 'CTRLCAM - SPCAM'],
                             levels_ref=np.arange(0, 400, 20),
                             levels=np.arange(-50, 55, 5),
                             unit=r'TOA shortwave flux [W m$^{-2}$]');
    fig.savefig(f'{FIG_DIR}globe_FSNT_{name}.pdf')
    plt.show()
# [___CELL_SEPARATOR___]
for name, exps in zip(['+0K', '+1K', '+2K', '+3K', '+4K'], 
                      [exps_ak_D024, exps_1k_D024, exps_2k_D024, exps_3k_D024, exps_4k_D024]):
    fig, axs = latlon_panels(h0means, lambda d: d['FLNS'], exps[1:], exps[0], 
                             titles=['SPCAM ' + name, 'NNCAM - SPCAM', 'CTRLCAM - SPCAM'],
                             levels_ref=np.arange(0, 100, 10),
                             levels=np.arange(-25, 30, 5),
                             unit=r'Surface longwave flux [W m$^{-2}$]');
    fig.savefig(f'{FIG_DIR}globe_FLNS_{name}.pdf')
    plt.show()
# [___CELL_SEPARATOR___]
for name, exps in zip(['+0K', '+1K', '+2K', '+3K', '+4K'], 
                      [exps_ak_D024, exps_1k_D024, exps_2k_D024, exps_3k_D024, exps_4k_D024]):
    fig, axs = latlon_panels(h0means, lambda d: d['FLNT'], exps[1:], exps[0], 
                             titles=['SPCAM ' + name, 'NNCAM - SPCAM', 'CTRLCAM - SPCAM'],
                             levels_ref=np.arange(100, 300, 20),
                             levels=np.arange(-50, 55, 5),
                             unit=r'TOA longwave flux [W m$^{-2}$]');
    fig.savefig(f'{FIG_DIR}globe_FLNT_{name}.pdf')
    plt.show()
# [___CELL_SEPARATOR___]
minlev = 3
# [___CELL_SEPARATOR___]
levs = h1s[exps_ak[0]].lev[minlev:].values
# [___CELL_SEPARATOR___]
def std_panel(hdict, func, exps, xlabel, xlims):
    fig, ax = plt.subplots(figsize=(onecol, 2.2))
    plt.subplots_adjust(left=0.3, right=0.95, bottom=0.2, top=0.95)
    [plt.plot(func(hdict[exps[i]]), levs, label=e, c=colors[i], lw=2) 
     for i, e in enumerate(['SPCAM', 'NNCAM', 'CTRLCAM'])]
    ax.legend()
    sns.despine()
    ax.set_xlabel(xlabel); ax.set_ylabel(r'Pressure [hPa]')
    ax.ticklabel_format(axis='x', scilimits=(0, 0))
    ax.set_ylim(0, 1000); ax.set_xlim(xlims)
    ax.invert_yaxis()
    return fig
# [___CELL_SEPARATOR___]
f = std_panel(h1stds, lambda d: d['TPHYSTND'].isel(lev=slice(minlev, None)).mean(('lat', 'lon')), exps_ak_D024,
              r'Std $\Delta$T$_{phys}$ [K s$^{-1}$]', (0, 0.8e-4))
# [___CELL_SEPARATOR___]
f.savefig(f'{FIG_DIR}std_tphys.pdf')
# [___CELL_SEPARATOR___]
f = std_panel(h1stds, lambda d: d['PHQ'].isel(lev=slice(minlev, None)).mean(('lat', 'lon')), exps_ak_D024,
              r'Std $\Delta$Q$_{phys}$ [ kg kg$^{-1}$ s$^{-1}$]', (0, 0.8e-7))
# [___CELL_SEPARATOR___]
f.savefig(f'{FIG_DIR}std_phq.pdf')
# [___CELL_SEPARATOR___]

prects = {e: h1s[e]['PRECT'].plot(range=(0, 4.5e-6), bins=100, label=e) 
          for e in exps_ak +exps_4k};
plt.close('all')
# [___CELL_SEPARATOR___]
#save_tmp('prects', prects)
prects = load_tmp('prects')
# [___CELL_SEPARATOR___]
for e in exps_review:
    prects[e] = h1s[e]['PRECT'].plot(range=(0, 4.5e-6), bins=100, label=e)
# [___CELL_SEPARATOR___]
labels = ['SPCAM', 'NNCAM', 'CTRLCAM', 'SPCAM+4K', 'NNCAM-ref+4K', 'CTRLCAM+4K']
zorders = [2, 3, 1, 1.5, 2.5, 0.5]
# [___CELL_SEPARATOR___]
fig, ax = plt.subplots(figsize=(twocols*0.4, 1.7))
plt.subplots_adjust(wspace=0.03, left=0.13, right=0.9, bottom=0.22, top=0.9)
[ax.plot(prects[e][1][:-1]*1e3*24*3600, prects[e][0]/prects[e][0].sum(), label=exps_review[i], 
         ) for i, e in enumerate(exps_review)]
ax.set_yscale('log')
ax.legend(ncol=2)
sns.despine()
ax.set_xlabel(r'Precipitation [mm d$^{-1}$]'); ax.set_ylabel(r'Frequency')
#ax.set_title('Precipitation distribution')
#ax.ticklabel_format(axis='x', scilimits=(0, 0))
ax.set_ylim(1e-6, 1); 
ax.set_xlim(0, 350);
#prects[exps[0]][1][-1]*1e3*24*3600
# [___CELL_SEPARATOR___]
fig, ax = plt.subplots(figsize=(twocols*0.4, 1.7))
plt.subplots_adjust(wspace=0.03, left=0.13, right=0.9, bottom=0.22, top=0.9)
[ax.plot(prects[e][1][:-1]*1e3*24*3600, prects[e][0]/prects[e][0].sum(), c=(colors + colors2)[i], label='+4K',
         ls='--', zorder=zorders[i]) for i, e in enumerate(exps_4k_D024)]
[ax.plot(prects[e][1][:-1]*1e3*24*3600, prects[e][0]/prects[e][0].sum(), label=labels[i], c=(colors + colors2)[i], 
         zorder=zorders[i]) for i, e in enumerate(exps_ak_D025)]
ax.set_yscale('log')
ax.legend(ncol=2)
sns.despine()
ax.set_xlabel(r'Precipitation [mm d$^{-1}$]'); ax.set_ylabel(r'Frequency')
#ax.set_title('Precipitation distribution')
#ax.ticklabel_format(axis='x', scilimits=(0, 0))
ax.set_ylim(1e-6, 1); 
ax.set_xlim(0, 350);
#prects[exps[0]][1][-1]*1e3*24*3600
# [___CELL_SEPARATOR___]
savefigs(fig, 'prec_hist')
# [___CELL_SEPARATOR___]
log_bins = np.logspace(-10, -5, 100)
# [___CELL_SEPARATOR___]
%%time
log_prects = {e: h1s[e]['PRECT'].isel(time=slice(0, 10000)).plot(bins=log_bins, label=e) 
          for e in exps_ak_D025 + exps_4k_D024};
plt.close('all')
# [___CELL_SEPARATOR___]
save_tmp('log_prects', log_prects)
#log_prects = load_tmp('log_prects')
# [___CELL_SEPARATOR___]
log_prects[exps_ak_D025[0]][1].shape
# [___CELL_SEPARATOR___]
bin_mean = (log_bins[1:] + log_bins[:-1]) / 2
# [___CELL_SEPARATOR___]
fig, ax = plt.subplots(figsize=(twocols*0.4, 1.7))
plt.subplots_adjust(wspace=0.03, left=0.13, right=0.9, bottom=0.22, top=0.9)
[ax.plot(log_prects[e][1][:-1]*1e3*24*3600, (log_prects[e][0]*bin_mean), c=colors[i], 
         ls='--', zorder=zorders[i]) for i, e in enumerate(exps_4k_D024)]
[ax.plot(log_prects[e][1][:-1]*1e3*24*3600, (log_prects[e][0]*bin_mean), c=colors[i], 
         zorder=zorders[i], label=labels[i]) for i, e in enumerate(exps_ak_D025)]
#ax.set_yscale('log')
ax.set_xscale('log')
ax.legend(ncol=1)
sns.despine()
ax.set_xlabel(r'Precipitation [mm d$^{-1}$]'); 
ax.set_ylabel(r'Amount distribution');
#ax.set_title('Precipitation distribution')
#ax.ticklabel_format(axis='x', scilimits=(0, 0))
#ax.set_ylim(1e-6, 1); 
#ax.set_xlim(0, prects[exps[0]][1][-1]*1e3*24*3600);
# [___CELL_SEPARATOR___]
savefigs(fig, 'prec_amount')
# [___CELL_SEPARATOR___]
exps_ak_D025[1]
# [___CELL_SEPARATOR___]
%%time
h1s = {e : xr.open_mfdataset(f'{DATA_DIR}{e}/*.h1.0001-01*', decode_times=False, decode_cf=False) 
       for e in [exps_ak_D025[1]]}
# [___CELL_SEPARATOR___]
d = h1s[exps_ak_D025[1]]
# [___CELL_SEPARATOR___]
NNQatm = vint(d, 'NNDQ', 1)
NNQsurf = d['NNLHF'] / L_V - d['NNPRECT'] * 1e3
NNSE = vint(d, 'NNDT', C_P) - d['NNSHF'] - d['NNFSNT'] + d['NNFSNS'] + d['NNFLNT'] - d['NNFLNS']
NNME = d['NNLHF'] - vint(d, 'NNDQ', L_V)
# [___CELL_SEPARATOR___]
dsp = h1s[exps_ak_D025[0]]
# [___CELL_SEPARATOR___]
SPSE = vint(d, 'TPHYSTND', C_P) - d['SHFLX'] - d['FSNT'] + d['FSNS'] + d['FLNT'] - d['FLNS']
SPME = d['LHFLX'] - vint(d, 'PHQ', L_V)
# [___CELL_SEPARATOR___]
xs = [d.isel(time=slice(0, 10)).values.flat for d in [SPSE, NNSE]]
ys = [d.isel(time=slice(0, 10)).values.flat for d in [SPME, NNME]]
# [___CELL_SEPARATOR___]
diffs = [np.array(x)-np.array(y) for x, y, in zip(xs, ys)]
# [___CELL_SEPARATOR___]
np.sqrt(np.square(diffs[0]).mean()), np.sqrt(np.square(diffs[1]).mean())
# [___CELL_SEPARATOR___]
np.abs(diffs[0]).mean(), np.abs(diffs[1]).mean()
# [___CELL_SEPARATOR___]
diffs[0].mean()
# [___CELL_SEPARATOR___]
fig, axs = plt.subplots(1, 2, figsize=(twocols*0.5, 1.7))
plt.subplots_adjust(wspace=0.2, left=0.15, right=0.95,  bottom=0.22, top=0.9)
[axs[i].scatter(xs[i], ys[i], alpha=0.5, s=7, color=colors[i], linewidths=0, label=l) 
 for i, l in enumerate(['SPCAM', 'NNCAM'])]
sns.despine()
for ax in axs:
    ax.legend()
    ax.set_xlabel(
        r'$^{C_p}/_G \int \Delta T_{\mathrm{phy}} \mathrm{d}p$ - SHF - $\sum F_{\mathrm{rad}}$ [W m$^{2}$]',
        labelpad=2);
    ax.set_ylim(-1e3, 6.5e3); ax.set_xlim(-1e3, 6.5e3)
    ax.plot([-1e3, 6.5e3], [-1e3, 6.5e3], zorder=0.1, c='gray');
formatter = mpl.ticker.ScalarFormatter(useOffset=False); formatter.set_powerlimits((-2,2))
[ax.yaxis.set_major_formatter(formatter) for ax in axs]; [ax.xaxis.set_major_formatter(formatter) for ax in axs]

axs[1].set_yticklabels([])
axs[0].set_ylabel(r'LHF - $^{L_v}/_G \int \Delta Q_{\mathrm{phy}} \mathrm{d}p$ [W m$^{2}$]', labelpad=2)
iaxs = [inset_axes(ax, width=0.5, height=0.3, loc=4, borderpad=0.5) for ax in axs]
hists = [iax.hist(diffs[i], bins=50, range=(-250, 250), color=colors[i]) for i, iax in enumerate(iaxs)];
[iax.set_yticks([]) for iax in iaxs]; [ax.xaxis.tick_top() for ax in iaxs]
[ax.set_xlim(-250, 250) for ax in iaxs]; [ax.xaxis.set_tick_params(direction='in', width=1) for ax in iaxs];
# [___CELL_SEPARATOR___]
savefigs(fig, 'engy_scatter')
# [___CELL_SEPARATOR___]
fig, axs = plt.subplots(1, 2, figsize=(twocols*0.5, 1.7))
plt.subplots_adjust(wspace=0.2, left=0.15, right=0.95,  bottom=0.22, top=0.9)
[axs[i].scatter(xs[i], ys[i], alpha=0.5, s=7, color=colors[i], linewidths=0, label=l) 
 for i, l in enumerate(['SPCAM', 'NNCAM'])]
sns.despine()
for ax in axs:

    ax.set_ylim(-1e3, 6.5e3); ax.set_xlim(-1e3, 6.5e3)
    ax.plot([-1e3, 6.5e3], [-1e3, 6.5e3], zorder=0.1, c='gray');
    plt.sca(ax)
    plt.axis('off')


# [___CELL_SEPARATOR___]
fig.savefig(FIG_DIR + 'engy_scatter_bare' + '.png', dpi=600, transparent=True)
# [___CELL_SEPARATOR___]
fig, axs = plt.subplots(1, 2, figsize=(twocols*0.5, 1.7))
plt.subplots_adjust(wspace=0.2, left=0.15, right=0.95,  bottom=0.22, top=0.9)
[axs[i].scatter(xs[i][0], ys[i][0], alpha=1, s=7, color=colors[i], linewidths=0, label=l) 
 for i, l in enumerate(['SPCAM', 'NNCAM'])]
sns.despine()
for ax in axs:
    ax.legend()
    ax.set_xlabel(
        r'$^{C_p}/_G \int \Delta T_{\mathrm{phy}} \mathrm{d}p$ - SHF - $\sum F_{\mathrm{rad}}$ [W m$^{2}$]',
        labelpad=2);
    ax.set_ylim(-1e3, 6.5e3); ax.set_xlim(-1e3, 6.5e3)
    ax.plot([-1e3, 6.5e3], [-1e3, 6.5e3], zorder=0.1, c='gray');
formatter = mpl.ticker.ScalarFormatter(useOffset=False); formatter.set_powerlimits((-2,2))
[ax.yaxis.set_major_formatter(formatter) for ax in axs]; [ax.xaxis.set_major_formatter(formatter) for ax in axs]

axs[1].set_yticklabels([])
axs[0].set_ylabel(r'LHF - $^{L_v}/_G \int \Delta Q_{\mathrm{phy}} \mathrm{d}p$ [W m$^{2}$]', labelpad=2)
iaxs = [inset_axes(ax, width=0.5, height=0.3, loc=4, borderpad=0.5) for ax in axs]
hists = [iax.hist(diffs[i], bins=50, range=(-250, 250), color=colors[i]) for i, iax in enumerate(iaxs)];
[iax.set_yticks([]) for iax in iaxs]; [ax.xaxis.tick_top() for ax in iaxs]
[ax.set_xlim(-250, 250) for ax in iaxs]; [ax.xaxis.set_tick_params(direction='in', width=1) for ax in iaxs];
# [___CELL_SEPARATOR___]
fig.savefig(FIG_DIR + 'engy_scatter_frame' + '.pdf')
# [___CELL_SEPARATOR___]
a = NNQsurf.isel(time=slice(0, None, 50)).values.flat
b = NNQatm.isel(time=slice(0, None, 50)).values.flat
# [___CELL_SEPARATOR___]
fig, ax = plt.subplots(figsize=(onecol, 2.2))
plt.subplots_adjust(left=0.3, right=0.95, bottom=0.2, top=0.95)
ax.scatter(a, b, alpha=0.5, s=7, color=colors[1], linewidths=0, 
           label='Before post-processing')
sns.despine()
ax.legend()
ax.set_xlabel(r'LHFLX / L_V - PREC [kg kg$^{-1}$ s$^{-1}$]'); ax.set_ylabel(r'vint(dQ) [kg kg$^{-1}$ s$^{-1}$]')
#ax.set_title('Heating rate variability')
#ax.ticklabel_format(axis='x', scilimits=(0, 0))
ax.set_ylim(-2e-3, 1e-3); ax.set_xlim(-2e-3, 1e-3)
ax.plot([-2e-3, 1e-3], [-2e-3, 1e-3], zorder=0.1, c='gray');
# [___CELL_SEPARATOR___]
fig.savefig(f'{FIG_DIR}moisture_scatter.pdf')
# [___CELL_SEPARATOR___]
TEs = {e: gw_avg(d, 'TE').compute() for e, d in h0s.items()}
TWs = {e: gw_avg(d, 'TW').compute() for e, d in h0s.items()}
# [___CELL_SEPARATOR___]
save_tmp('TEs', TEs); save_tmp('TWs', TWs)
TEs, TWs = load_tmp('TEs'), load_tmp('TWs')
# [___CELL_SEPARATOR___]
def plot_ts(TE, TW, func, exps, labels, colors, ylabel):
    fig, ax = plt.subplots(1, 1, figsize=(twocols*0.5, 1.7))
    ax2 = ax.twinx()
    axs=[ax, ax2]
    plt.subplots_adjust(wspace=0.2, left=0.15, right=0.85, bottom=0.22, top=0.9)
    t = np.arange(len(func(TE[exps[0]]).time.values))
    t = t / 12
    for ax, T, title, ls in zip(axs, [TE, TW], [r'Global energy [J m$^{2}$]', r'Global moisture [kg m$^{2}$]'], ['-', '--']):
        [ax.plot(t, func(T[e]), label=labels[i], c=colors[i], ls=ls) for i, e in enumerate(exps)]
        ax.set_xlabel('Time [y]'); ax.set_ylabel(title)
        ax.set_xlim((0, 5)); ax.set_xticks(np.arange(6))
    axs[0].legend(ncol=3, frameon=False, bbox_to_anchor=(0.1,1.00,0.85,0.2), loc="lower left",mode="expand")
    axs[0].set_ylim(3.275e9, 3.32e9)
    axs[1].set_ylim(24, 30)
    return fig
# [___CELL_SEPARATOR___]
f = plot_ts(TEs, TWs, lambda d: d, exps_ak_D025, labels,
        colors, 'Globally integrated energy')
# [___CELL_SEPARATOR___]
savefigs(f, 'global_engy')
# [___CELL_SEPARATOR___]
f = plot_ts(TWs, lambda d: d, exps_ak_D024 + exps_4k_D024, labels,
        colors + colors2, ylabel='Globally integrated moisture')
# [___CELL_SEPARATOR___]
f.savefig(f'{FIG_DIR}TW_timeseries.pdf')
# [___CELL_SEPARATOR___]
def plot_polar(TE, TW, func, exps, colors):
    fig, axs = plt.subplots(1, 2, figsize=(onecol, 1.5), subplot_kw={'projection': 'polar'})
    plt.subplots_adjust(wspace=0.2, left=0.13, right=1.0, bottom=0.22, top=0.9)
    t = np.arange(len(func(TE[exps[0]]).time.values))
    t = t / 12
    for ax, T, title in zip(axs, [TE, TW], ['Global energy', 'Global water']):
        [ax.plot(t, func(T[e]), label=labels[i], c=colors[i]) for i, e in enumerate(exps)]
    axs[0].set_ylim(1.05e8, 1.08e8)
    return fig
# [___CELL_SEPARATOR___]
f = plot_polar(TEs, TWs, lambda d: d, exps_ak_D025, colors)
# [___CELL_SEPARATOR___]
WK_DATA = '/beegfs/DATA/pritchard/srasp/wkdata/'
!ls {WK_DATA}
# [___CELL_SEPARATOR___]
wks = [xr.open_dataset(f'{WK_DATA}SpaceTime.PRECT.{e}.nc') for e in exps_ak_D025 + exps_4k_D024]
# [___CELL_SEPARATOR___]
wks = [wk.isel(freq=slice(1, None)) for wk in wks]
# [___CELL_SEPARATOR___]
freq_days = 1/wks[0].freq
# [___CELL_SEPARATOR___]
labels_days = [30, 10, 5]
labels_freq = 1/np.array(labels_days)
# [___CELL_SEPARATOR___]
hs = [12, 25, 50]
g = 9.81
# [___CELL_SEPARATOR___]
def ER(k, h):
    n = 1; lat = 0.
    Beta = 2. * 7.292E-5 * np.cos(abs(lat)) / 6.37E6
    t4 = (Beta / np.ma.sqrt(g * h)) * (2 * n + 1.)
    return -Beta * k / (k * k + t4)
# [___CELL_SEPARATOR___]
lat = 0.
ll = 2. * np.pi * 6.37E6 * np.cos(abs(lat))
# [___CELL_SEPARATOR___]
k = 2 * np.pi * wks[0].wave / ll
# [___CELL_SEPARATOR___]
wks[0].freq
# [___CELL_SEPARATOR___]
def tofreq(x): return 1/(2 * np.pi / (x * 24 * 60 * 60))
# [___CELL_SEPARATOR___]
def wk_panel(ax, data, title, add_text=True, ref=None, label_color='white', 
             field='FIG_3_SYM', **kwargs):
    d = data[field] if ref is None else data[field] - ref
    im = ax.contourf(data.wave, data.freq, d, **kwargs)
    ax.set_yticks(labels_freq); ax.set_yticklabels(labels_days);
    [ax.axhline(y, linestyle='--', c='gray', zorder=1.1, linewidth=0.75, alpha=0.5) for y in labels_freq]
    [ax.plot(data.wave, tofreq(k*np.sqrt(g * h)), c='gray', lw=0.7, alpha=0.5) for h in hs];
    [ax.plot(data.wave, tofreq(ER(k, h)), c='gray', lw=0.7, alpha=0.5) for h in hs];
    #ax.set_xlim(data.wave[0], data.wave[-1]); ax.set_ylim(data.freq[0], data.freq[-1]);
    ax.set_xlim(-10, 10); ax.set_ylim(data.freq[0], 0.3);
    if add_text:
        ax.text(5, 1/4, 'Kelvin', color=label_color, weight='bold', fontsize=5, zorder=2);
        ax.text(-9, 1/15, 'n=1 ER', color=label_color, weight='bold', fontsize=5, zorder=2);
        ax.text(4, 1/30, 'MJO', color=label_color, weight='bold', fontsize=5, zorder=2);
    ax.set_xlabel(r'Zonal $k$'); ax.set_ylabel('Period [days]')
    ax.set_title(title, pad=4)
    ax.set_xticks([-10, -5, 0, 5, 10])
    return im
# [___CELL_SEPARATOR___]
titles = ['SPCAM', 'NNCAM', 'CTRLCAM']
# [___CELL_SEPARATOR___]
def wk_panels(data, levels=np.arange(1.2, 3.1, 0.1), ref=None, cmap='nipy_spectral', 
              label_color='white', field='FIG_3_SYM'):
    fig, axs = plt.subplots(1, 3, figsize=(twocols*0.6, 1.7))
    for i, (ax, wk) in enumerate(zip(axs.flat, data)):
        im = wk_panel(ax, wk, titles[i], True if i == 0 else False, cmap=cmap, 
                      levels=levels, extend='both', ref=ref if ref is None else ref[i]['FIG_3_SYM'],
                      label_color=label_color, field=field)
        if i > 0: ax.set_ylabel(''); ax.set_yticks([])
    plt.subplots_adjust(wspace=0.03, left=0.13, right=1.0, bottom=0.22, top=0.9)
    cb = fig.colorbar(im, ax=axs, pad=0.01); #cb.set_label('Log power spectrum')
    cb.set_ticks(np.arange(-20, 20, 0.5))
    return fig
# [___CELL_SEPARATOR___]
f = wk_panels(wks[:3], field='FIG_3_BACK', levels=np.arange(-17.5, -15, 0.1))
# [___CELL_SEPARATOR___]
f = wk_panels(wks[:3], field='FIG_1_SYM', levels=np.arange(-17.5, -15, 0.1))
# [___CELL_SEPARATOR___]
savefigs(f, 'wk_back')
# [___CELL_SEPARATOR___]
wks[0]['FIG_1_SYM'].plot()
# [___CELL_SEPARATOR___]
f = wk_panels(wks[:3])
# [___CELL_SEPARATOR___]
savefigs(f, 'wk_ref')
# [___CELL_SEPARATOR___]
f = wk_panels(wks[:3], levels=np.arange(1.2, 4.1, 0.1))
# [___CELL_SEPARATOR___]
savefigs(f, 'wk_ref_2')
# [___CELL_SEPARATOR___]
titles = ['SPCAM+4K', 'NNCAM-ref+4K', 'CTRLCAM+4K']
# [___CELL_SEPARATOR___]
f = wk_panels(wks[3:], levels=np.arange(1.2, 4.1, 0.1))
# [___CELL_SEPARATOR___]
savefigs(f, 'wk_4k')
# [___CELL_SEPARATOR___]
f = wk_panels(wks[3:], levels=np.arange(-2, 2.1, 0.1), ref=wks[:3], cmap='RdBu_r', label_color='k')
# [___CELL_SEPARATOR___]
savefigs(f, 'wk_4k_diff')
# [___CELL_SEPARATOR___]
from matplotlib import animation, rc
import types
# [___CELL_SEPARATOR___]
da = h1s[exps_ak_D025[1]]['PRECT'].isel(time=slice(0, 200)).copy().load()
# [___CELL_SEPARATOR___]
t=100
cm='Blues'
levels= [2**i for i in range(1, 9)]
# [___CELL_SEPARATOR___]
levels
# [___CELL_SEPARATOR___]
def animate_globe(frames=200):
    fig, ax = plt.subplots(figsize=(5, 3), subplot_kw=dict(projection=ccrs.Orthographic(-80, 35)))
    data = da.isel(time=0).copy() * 1e3*24*3600
    im = data.plot.contourf(ax=ax, add_colorbar=False, cmap=cm, levels=levels, transform=ccrs.PlateCarree())
    ax.gridlines();
    def animate(i):
        data = da.isel(time=i).copy() * 1e3*24*3600
        im = data.plot.contourf(ax=ax, add_colorbar=False, cmap=cm, levels=levels, transform=ccrs.PlateCarree())
        return im,
    plt.close()
    return animation.FuncAnimation(fig, animate, frames=frames, interval=150, blit=False)

# [___CELL_SEPARATOR___]
%%time
anim = animate_globe(10)
# [___CELL_SEPARATOR___]
%%time
HTML(anim.to_html5_video())
# [___CELL_SEPARATOR___]
def plot_globe(t, lon):
    fig, ax = plt.subplots(figsize=(5, 3), subplot_kw=dict(projection=ccrs.Orthographic(lon, 25)))
    data = da.isel(time=t).copy() * 1e3*24*3600
    data = xr.DataArray(
            np.concatenate([data.values, data.values[:, -1][:, None]], 1), 
            dims={'lat': data.lat, 'lon': list(data.lon) + [360.]}, 
            coords={'lat': data.lat, 'lon': list(data.lon) + [360.]})
    im = data.plot.contourf(ax=ax, add_colorbar=False, cmap=cm, levels=levels, transform=ccrs.PlateCarree())
    ax.gridlines(alpha=0.5); ax.set_title('')
    return fig
# [___CELL_SEPARATOR___]
for i in tqdm(range(199)):
    f = plot_globe(i, i)
    f.savefig(f'{FIG_DIR}anim/{str(i).zfill(3)}.png', dpi=300)
# [___CELL_SEPARATOR___]
