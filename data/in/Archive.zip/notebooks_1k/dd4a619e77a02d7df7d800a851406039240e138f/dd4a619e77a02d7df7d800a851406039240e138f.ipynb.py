install.packages("IRISSeismic")
install.packages("maps")
# [___CELL_SEPARATOR___]
#library(help = "IRISSeismic")
# [___CELL_SEPARATOR___]
library(IRISSeismic)
library(maps)
#Near real time
nrt <- new('IrisClient', site = 'https://service-nrt.geonet.org.nz')
#Archive
acr <- new('IrisClient', site = 'https://service.geonet.org.nz')
# [___CELL_SEPARATOR___]
starttime <- as.POSIXct("2010-10-01",tz="GMT")
endtime <- as.POSIXct("2011-02-23",tz="GMT")
# [___CELL_SEPARATOR___]
lat <- -43.5321
lon <- 172.6362
# [___CELL_SEPARATOR___]
station<- getStation(acr,"NZ", "*","*", "?H?",starttime ,endtime, latitude= lat, longitude= lon ,maxradius = 1)
# [___CELL_SEPARATOR___]
xhigh <- max(station$longitude)+ .3
xlow <- min(station$longitude)- .3
yhigh <- max(station$latitude)+ .3
ylow <- min(station$latitude)- .3
# [___CELL_SEPARATOR___]
map("nz",xlim=c(xlow,xhigh),ylim=c(ylow,yhigh), fill=TRUE, col="lightgreen")
points(station$longitude, station$latitude, pch=17, cex=2, col='red')
labels <- paste(station$station)
text(station$longitude, station$latitude, labels=labels, cex=1, pos=4)
map.axes()
# [___CELL_SEPARATOR___]
station
# [___CELL_SEPARATOR___]
channels<-getChannel(acr,"NZ", "*","*", "?H?",starttime ,endtime, latitude= lat, longitude= lon ,maxradius = 1)
# [___CELL_SEPARATOR___]
channels