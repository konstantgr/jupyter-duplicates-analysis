import numpy as np
import matplotlib.pyplot as plt
from sklearn import datasets

iris = datasets.load_iris()
# [___CELL_SEPARATOR___]
X = iris.data
y = iris.target
# [___CELL_SEPARATOR___]
X = X[y<2, :2]
y = y[y<2]
# [___CELL_SEPARATOR___]
plt.scatter(X[y==0, 0], X[y==0, 1], color="green")
plt.scatter(X[y==1, 0], X[y==1, 1], color="red")
# [___CELL_SEPARATOR___]
from sklearn.model_selection import train_test_split

X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=500)
# [___CELL_SEPARATOR___]
from LogisticRegression import LogisticRegression
# [___CELL_SEPARATOR___]
log_reg = LogisticRegression()
# [___CELL_SEPARATOR___]
log_reg.fit(X_train, y_train)
# [___CELL_SEPARATOR___]
log_reg.score(X_test, y_test)
# [___CELL_SEPARATOR___]
log_reg.predict_proba(X_test)
# [___CELL_SEPARATOR___]
