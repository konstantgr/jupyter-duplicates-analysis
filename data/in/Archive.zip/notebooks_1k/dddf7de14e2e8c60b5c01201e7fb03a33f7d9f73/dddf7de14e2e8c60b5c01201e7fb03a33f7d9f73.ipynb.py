# 必要ライブラリの導入
!pip install -U ibm_watson | tail -n 1
# [___CELL_SEPARATOR___]
# リスト4.2.1 NLU呼び出し用インスタンス生成

# NLUの資格情報 2つの値は巻末付録3の手順で取得したものに置き換えて下さい 
nlu_credentials = {
  "apikey": "xxxx",
  "url": "xxxx"
}

# 必要なライブラリのimport
import json
from ibm_watson import NaturalLanguageUnderstandingV1
from ibm_watson.natural_language_understanding_v1 import *
from ibm_cloud_sdk_core.authenticators import IAMAuthenticator

# API呼び出し用インスタンスの生成
authenticator = IAMAuthenticator(nlu_credentials['apikey'])
nlu = NaturalLanguageUnderstandingV1(
    version='2019-07-12',
    authenticator=authenticator
)
nlu.set_service_url(nlu_credentials['url'])

# [___CELL_SEPARATOR___]
# リスト 4.2.2 NLU呼び出し用共通関数

# text: 対象テキスト
# feature: 機能を意味するObject
# key: 結果jsonをfilterするためのキー
def call_nlu(text, features, key):
    response = nlu.analyze(text=text, features=features).get_result()
    return response[key]
# [___CELL_SEPARATOR___]
# リスト 4.2.3 エンティティ抽出機能の呼び出し

# 対象テキスト
text = "安倍首相はトランプ氏と昨日、大阪の国際会議場で会談した。"

# 機能として「エンティティ抽出機能」を利用
features=Features(entities=EntitiesOptions())

# 共通関数呼び出し
ret = call_nlu(text, features, "entities")

# 結果の表示
print(json.dumps(ret, indent=2, ensure_ascii=False))
# [___CELL_SEPARATOR___]
# リスト 4.2.4 関係抽出機能の呼び出し

# 対象テキスト
text = "このイベントは東京の国立競技場で開催されました。"

# 機能として「関係抽出機能」を利用
features=Features(relations=RelationsOptions())

# 共通関数呼び出し
ret = call_nlu(text, features, "relations")

# 結果の表示
print(json.dumps(ret, indent=2, ensure_ascii=False))
# [___CELL_SEPARATOR___]
# リスト 4.2.5 評判分析機能の呼び出し

# テキスト1 (いい評判の例)
text1 = 'さすがはソニーです。写真の写りもいいですし、音がまた良いです。'

# テキスト2 (悪い評判の例)
text2 = '利用したかったアプリケーションは、残念ながらバージョン、性能が合わず、利用できませんでした。'


# テキスト1を評判分析
features=Features(sentiment=SentimentOptions())
ret = call_nlu(text1, features, "sentiment")
print(json.dumps(ret, indent=2, ensure_ascii=False))

# テキスト2を評判分析
features=Features(sentiment=SentimentOptions())
ret = call_nlu(text2, features, "sentiment")
print(json.dumps(ret, indent=2, ensure_ascii=False))
# [___CELL_SEPARATOR___]
# リスト 4.2.6 キーワード抽出機能の呼び出し

# 対象テキスト
text = "ながぬま温泉は北海道でも屈指の湯量を誇り、\
加水・加温はせずに100%源泉掛け流しで、\
保温効果が高く湯冷めしにくい塩化物泉であり、\
「熱の湯」とも呼ばれ、保養や療養を目的として多くの方が訪れている。"


# 機能として「キーワード抽出機能」を利用
features=Features(keywords=KeywordsOptions(limit=5))

# 共通関数呼び出し
ret = call_nlu(text, features, "keywords")

# 結果の表示
print(json.dumps(ret, indent=2, ensure_ascii=False))
# [___CELL_SEPARATOR___]
# リスト 4.2.7 概念分析機能の呼び出し

# 対象テキスト
text = "ながぬま温泉は北海道でも屈指の湯量を誇り、\
加水・加温はせずに100%源泉 掛け流しで、\
保温効果が高く湯冷めしにくい塩化物泉であり、\
「熱の湯」とも呼ば れ、保養や療養を目的として多くの方が訪れている。"

# 機能として「概念分析機能」を利用
features=Features(concepts=ConceptsOptions(limit=3))

# 共通関数呼び出し
ret = call_nlu(text, features, "concepts")

# 結果の表示
print(json.dumps(ret, indent=2, ensure_ascii=False))
# [___CELL_SEPARATOR___]
# リスト 4.2.8 カテゴリ分類機能の呼び出し

# 対象テキスト
text = "自然環境の保護を図るとともに、地域に調和した温泉利用施設を維持整備し、\
豊かさとふれあいのある保養の場とする。"

# 機能として「カテゴリ分類機能」を利用
features=Features(categories=CategoriesOptions())

# 共通関数呼び出し
ret = call_nlu(text, features, "categories")

# 結果の表示
print(json.dumps(ret, indent=2, ensure_ascii=False))
# [___CELL_SEPARATOR___]
# リスト 4.2.9 意味役割分析機能の呼び出し

# 対象テキスト
text = 'IBMは毎年、多くの特許を取得しています。'

# 機能として「意味役割分析機能」を利用
features=Features(semantic_roles=SemanticRolesOptions())

# 共通関数呼び出し
ret = call_nlu(text, features, "semantic_roles")

# 結果の表示
print(json.dumps(ret, indent=2, ensure_ascii=False))
# [___CELL_SEPARATOR___]
