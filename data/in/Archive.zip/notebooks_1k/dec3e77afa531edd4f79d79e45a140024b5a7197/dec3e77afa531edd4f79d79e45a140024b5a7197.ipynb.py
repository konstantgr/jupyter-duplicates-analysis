import sys
import numpy as np
import matplotlib.pyplot as plt

sys.path.append('../..')

from seismicpro.batchflow import V
from seismicpro.src import (SeismicDataset, FieldIndex, seismic_plot,
                            gain_plot, calculate_sdc_quality)
from seismicpro.models import calc_derivative_diff
# [___CELL_SEPARATOR___]
path_raw = '/data/SD/dataset_1/2_TAR_raw.sgy'
path_corr = '/data/SD/dataset_1/2_TAR_v2_t1.sgy'

field_index = (FieldIndex(name='raw', extra_headers=['offset'], path=path_raw).
               merge(FieldIndex(name='target', path=path_corr)))
field_index.head()
# [___CELL_SEPARATOR___]
speed = np.array([1524]*700 + [1924.5]*300 + [2184.0]*400 +  [2339.6]*400 + 
                 [2676]*150 + [2889.5]*2250 + [3566]*2800 + [4785.3]*1000)
# [___CELL_SEPARATOR___]
%%time
manual_batch = (SeismicDataset(field_index).next_batch(1)
                .load(fmt='segy', components=('raw', 'target'), tslice=slice(3000))
                .sort_traces(src=('raw', 'target'), dst=('raw', 'target'), sort_by='offset')
                .correct_spherical_divergence(src='raw', dst='corrected',
                                              speed=speed, params=(2, 1))
)
# [___CELL_SEPARATOR___]
cv = 0.1
seismic_plot([manual_batch.raw[0], manual_batch.corrected[0]], vmin=-cv, vmax=cv,
             cmap='gray', figsize=(15, 5), names=['Raw field', 'Corrected field'])
# [___CELL_SEPARATOR___]
gain_plot([manual_batch.raw[0], manual_batch.corrected[0]], 51, names=['Raw', 'Corrected'],
          figsize=(14, 5), xlim=(0, -20))
# [___CELL_SEPARATOR___]
gain_plot([manual_batch.corrected[0], manual_batch.target[0]], 51, names=['Corrected', 'Target'],
          figsize=(14, 5), xlim=(0, -20))
# [___CELL_SEPARATOR___]
dataset = SeismicDataset(field_index)
# [___CELL_SEPARATOR___]
pipeline = (dataset.pipeline()
            .load(fmt='segy', components='raw', tslice=slice(3000))
            .sort_traces(src='raw', dst='raw', sort_by='offset')
            .correct_spherical_divergence(src='raw', dst='corrected',
                                          speed=speed, params=V('sdc_params'))
            .run_later(1, n_iters=1)
)
# [___CELL_SEPARATOR___]
(pipeline.before
         .find_sdc_params(component='raw', speed=speed, 
                          loss=calculate_sdc_quality, initial_point=(2, 1),
                          save_to=V('sdc_params'))
);
# [___CELL_SEPARATOR___]
%%time
optimal_batch = pipeline.next_batch()
# [___CELL_SEPARATOR___]
print("Optimal parameters for v_pow is {:.3}, for t_pow is {:.3}.".format(*pipeline.v('sdc_params')))
# [___CELL_SEPARATOR___]
seismic_plot([optimal_batch.raw[0], optimal_batch.corrected[0]], vmin=-cv, vmax=cv,
              cmap='gray', figsize=(15, 5), names=['Raw field', 'Corrected field'])
# [___CELL_SEPARATOR___]
gain_plot([optimal_batch.raw[0], optimal_batch.corrected[0]], 51, names=['Raw', 'Corrected'],
          figsize=(14, 5), xlim=(0, -20))
# [___CELL_SEPARATOR___]
manual = manual_batch.corrected[0]
target = manual_batch.target[0]
raw = manual_batch.raw[0]

print('L1 measure: {:.3}'.format(np.mean(np.abs(manual - target))))
print('DM for raw field: {:.3}'.format(calc_derivative_diff(raw)))
print('DM for manual corr: {:.3}'.format(calc_derivative_diff(manual)))
print('DM for target corr: {:.3}'.format(calc_derivative_diff(target)))
# [___CELL_SEPARATOR___]
manual_corr = np.concatenate(optimal_batch.corrected)
raw_corr = np.concatenate(optimal_batch.raw)
print('DM for raw field: {:.3}'.format(calc_derivative_diff(raw_corr)))
print('DM for corrected field with'\
      ' optimal parameters: {:.3}'.format(calc_derivative_diff(manual_corr)))