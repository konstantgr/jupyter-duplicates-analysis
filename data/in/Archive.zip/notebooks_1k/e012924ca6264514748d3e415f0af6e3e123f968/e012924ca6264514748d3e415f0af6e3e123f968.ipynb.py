#linear_model.LarsCV([fit_intercept, …]) 

from sklearn.datasets import load_boston
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn import linear_model 
from sklearn.metrics import mean_squared_error
import matplotlib.pyplot as plt

boston = load_boston()
X=boston.data
y=boston.target

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=0)
modelo=linear_model.LarsCV(cv=5).fit(X,y)


plt.figure(figsize=(10,10))
for i in range((modelo.mse_path_.shape[1])):
    plt.plot(modelo.mse_path_[:,i],label=r'Fold: %d'%i)
plt.ylabel("MSE")
plt.xlabel(r"$path$")
plt.legend()    
plt.show()    
y_pred=modelo.predict(X_test)

print("Los coeficientes son:",modelo.coef_)
print("MSE: %.3f"%mean_squared_error(y_pred,y_test))

# [___CELL_SEPARATOR___]
from sklearn.datasets import load_boston
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn import linear_model 
from sklearn.metrics import mean_squared_error
import matplotlib.pyplot as plt

boston = load_boston()
X=boston.data
y=boston.target

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=0)
modelo=linear_model.LassoCV(cv=5).fit(X,y)

plt.figure(figsize=(10,10))
for i in range((modelo.mse_path_.shape[1])):
    plt.plot(modelo.mse_path_[:,i],label=r'Fold: %d'%i)
plt.ylabel("MSE")
plt.xlabel(r"$path$")
plt.legend()    
plt.show()
    
y_pred=modelo.predict(X_test)

print("Los coeficientes son:",modelo.coef_)
print("MSE: %.3f"%mean_squared_error(y_pred,y_test))

# [___CELL_SEPARATOR___]
#linear_model.LassoLarsCV([fit_intercept, …])


from sklearn.datasets import load_boston
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn import linear_model 
from sklearn.metrics import mean_squared_error
import matplotlib.pyplot as plt

boston = load_boston()
X=boston.data
y=boston.target

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=0)
modelo=linear_model.LassoLarsCV(cv=5).fit(X,y)


plt.figure(figsize=(10,10))
for i in range((modelo.mse_path_.shape[1])):
    plt.plot(modelo.mse_path_[:,i],label=r'Fold: %d'%i)
plt.ylabel("MSE")
plt.xlabel(r"$path$")
plt.legend()    
plt.show()
    
y_pred=modelo.predict(X_test)
print("Los coeficientes son:",modelo.coef_)
print("MSE: %.3f"%mean_squared_error(y_pred,y_test))

# [___CELL_SEPARATOR___]
#linear_model.RidgeCV([alphas, …])

# [___CELL_SEPARATOR___]
#linear_model.RidgeClassifierCV([alphas, …])

# [___CELL_SEPARATOR___]
# linear_model.LassoLarsIC([criterion, …])

import numpy as np
import matplotlib.pyplot as plt

from sklearn.linear_model import LassoCV, LassoLarsCV, LassoLarsIC
from sklearn import datasets

EPSILON=1e-4

diabetes=datasets.load_breast_cancer()
X=diabetes.data
y=diabetes.target

rng=np.random.RandomState(42)
X=np.c_[X,rng.randn(X.shape[0],14)]

X /= np.sqrt(np.sum(X**2,axis=0))

model_bic=LassoLarsIC(criterion='bic')
model_bic.fit(X,y)
alphla_bic_=model_bic.alpha_

model_aic=LassoLarsIC(criterion='aic')
model_aic.fit(X,y)
alphla_aic_=model_aic.alpha_

def plot_ic_criterion(model,name,color):
    alpha_=model.alpha_+EPSILON
    alphas_=model.alphas_+EPSILON
    
    criterion_=model.criterion_
    plt.plot(-np.log10(alphas_),criterion_,'--',color=color,linewidth=3,label='Criterio %s'%name)
    plt.axvline(-np.log10(alpha_),color=color,linewidth=3,label='alpha: estimado %s'%name)

    plt.xlabel('-log(alpha)')
    plt.ylabel('criterion')

plt.figure()
plot_ic_criterion(model_aic,'AIC','b')
plot_ic_criterion(model_bic,'BIC','r')
plt.legend()
plt.title('Information criterion para selección de modelo')
plt.show()
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
import numpy as np
import matplotlib.pyplot as plt

from sklearn import ensemble
from sklearn.model_selection import KFold
from sklearn.model_selection import train_test_split

from scipy.special import expit

# Generate data (adapted from G. Ridgeway's gbm example)
n_samples = 1000
random_state = np.random.RandomState(13)
x1 = random_state.uniform(size=n_samples)
x2 = random_state.uniform(size=n_samples)
x3 = random_state.randint(0, 4, size=n_samples)

p = expit(np.sin(3 * x1) - 4 * x2 + x3)
y = random_state.binomial(1, p, size=n_samples)

X = np.c_[x1, x2, x3]

X = X.astype(np.float32)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.5,
                                                    random_state=9)

# Fit classifier with out-of-bag estimates
params = {'n_estimators': 1200, 'max_depth': 3, 'subsample': 0.5,
          'learning_rate': 0.01, 'min_samples_leaf': 1, 'random_state': 3}

clf = ensemble.GradientBoostingClassifier(**params)


clf.fit(X_train, y_train)
acc = clf.score(X_test, y_test)
print("Accuracy: {:.4f}".format(acc))

n_estimators = params['n_estimators']
x = np.arange(n_estimators) + 1


def heldout_score(clf, X_test, y_test):
    """compute deviance scores on ``X_test`` and ``y_test``. """
    score = np.zeros((n_estimators,), dtype=np.float64)
    for i, y_pred in enumerate(clf.staged_decision_function(X_test)):
        score[i] = clf.loss_(y_test, y_pred)
    return score


def cv_estimate(n_splits=None):
    cv = KFold(n_splits=n_splits)
    cv_clf = ensemble.GradientBoostingClassifier(**params)
    val_scores = np.zeros((n_estimators,), dtype=np.float64)
    for train, test in cv.split(X_train, y_train):
        cv_clf.fit(X_train[train], y_train[train])
        val_scores += heldout_score(cv_clf, X_train[test], y_train[test])
    val_scores /= n_splits
    return val_scores


# Estimate best n_estimator using cross-validation
cv_score = cv_estimate(2)

# Compute best n_estimator for test data
test_score = heldout_score(clf, X_test, y_test)

# negative cumulative sum of oob improvements
cumsum = -np.cumsum(clf.oob_improvement_)

# min loss according to OOB
oob_best_iter = x[np.argmin(cumsum)]

# min loss according to test (normalize such that first loss is 0)
test_score -= test_score[0]
test_best_iter = x[np.argmin(test_score)]

# min loss according to cv (normalize such that first loss is 0)
cv_score -= cv_score[0]
cv_best_iter = x[np.argmin(cv_score)]

# color brew for the three curves
oob_color = list(map(lambda x: x / 256.0, (190, 174, 212)))
test_color = list(map(lambda x: x / 256.0, (127, 201, 127)))
cv_color = list(map(lambda x: x / 256.0, (253, 192, 134)))

# plot curves and vertical lines for best iterations
plt.figure(figsize=(18,10))
plt.plot(x, cumsum, label='OOB loss', color=oob_color)
plt.plot(x, test_score, label='Test loss', color=test_color)
plt.plot(x, cv_score, label='CV loss', color=cv_color)
plt.axvline(x=oob_best_iter, color=oob_color)
plt.axvline(x=test_best_iter, color=test_color)
plt.axvline(x=cv_best_iter, color=cv_color)

# add three vertical lines to xticks
xticks = plt.xticks()
xticks_pos = np.array(xticks[0].tolist() +
                      [oob_best_iter, cv_best_iter, test_best_iter])
xticks_label = np.array(list(map(lambda t: int(t), xticks[0])) +
                        ['OOB', 'CV', 'Test'])
ind = np.argsort(xticks_pos)
xticks_pos = xticks_pos[ind]
xticks_label = xticks_label[ind]
plt.xticks(xticks_pos, xticks_label)

plt.legend(loc='upper right')
plt.ylabel('normalized loss')
plt.xlabel('number of iterations')

plt.show()

# [___CELL_SEPARATOR___]
import numpy as np
import matplotlib.pyplot as plt

from sklearn import ensemble
from sklearn import datasets
from sklearn.utils import shuffle
from sklearn.metrics import mean_squared_error

# #############################################################################
# Load data
boston = datasets.load_boston()
X, y = shuffle(boston.data, boston.target, random_state=13)
X = X.astype(np.float32)
offset = int(X.shape[0] * 0.9)
X_train, y_train = X[:offset], y[:offset]
X_test, y_test = X[offset:], y[offset:]

# #############################################################################
# Fit regression model
params = {'n_estimators': 500, 'max_depth': 4, 'min_samples_split': 2,
          'learning_rate': 0.01, 'loss': 'ls'}
clf = ensemble.GradientBoostingRegressor(**params)

clf.fit(X_train, y_train)
mse = mean_squared_error(y_test, clf.predict(X_test))
print("MSE: %.4f" % mse)

# #############################################################################
# Plot training deviance

# compute test set deviance
test_score = np.zeros((params['n_estimators'],), dtype=np.float64)

for i, y_pred in enumerate(clf.staged_predict(X_test)):
    test_score[i] = clf.loss_(y_test, y_pred)

plt.figure(figsize=(12, 6))
plt.subplot(1, 2, 1)
plt.title('Deviance')
plt.plot(np.arange(params['n_estimators']) + 1, clf.train_score_, 'b-',
         label='Training Set Deviance')
plt.plot(np.arange(params['n_estimators']) + 1, test_score, 'r-',
         label='Test Set Deviance')
plt.legend(loc='upper right')
plt.xlabel('Boosting Iterations')
plt.ylabel('Deviance')

# #############################################################################
# Plot feature importance
feature_importance = clf.feature_importances_
# make importances relative to max importance
feature_importance = 100.0 * (feature_importance / feature_importance.max())
sorted_idx = np.argsort(feature_importance)
pos = np.arange(sorted_idx.shape[0]) + .5
plt.subplot(1, 2, 2)
plt.barh(pos, feature_importance[sorted_idx], align='center')
plt.yticks(pos, boston.feature_names[sorted_idx])
plt.xlabel('Relative Importance')
plt.title('Variable Importance')
plt.show()
# [___CELL_SEPARATOR___]
#brier_score_loss(y_true, y_prob)
#matthews_corrcoef(y_true, y_pred)  
import numpy as np
from sklearn import datasets
from sklearn.model_selection import train_test_split
from sklearn import svm
from sklearn.model_selection import cross_val_score
from sklearn.metrics import brier_score_loss,matthews_corrcoef
iris=datasets.load_iris()


X=iris.data
y=iris.target

X_train, X_test, y_train, y_test = train_test_split(X,y , test_size=0.3, random_state=0)
clf = svm.SVC(kernel='linear', C=1 , probability = True)
clf.fit(X_train,y_train)
y_prob=clf.predict_proba(X_test)
y_prob1=y_prob[:,2]
y_prob2=y_prob[:,1]
y_prob0=y_prob[:,0]

y_true0=y_test
y_true0[y_true0==0]=1
y_true0[y_true0!=0]=0

y_true1=y_test
y_true1[y_true0==1]=1
y_true1[y_true0!=1]=0

y_true2=y_test
y_true2[y_true0==2]=1
y_true2[y_true0!=2]=0


brier_score_loss(y_true0, y_prob0)
brier_score_loss(y_true1 ,y_prob1)
brier_score_loss(y_true2 ,y_prob2)

# [___CELL_SEPARATOR___]
#mean_squared_error
#r2_score
#mean_squared_log_error

# [___CELL_SEPARATOR___]

import numpy as np
import matplotlib.pyplot as plt

from sklearn import svm, datasets
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix
from sklearn.utils.multiclass import unique_labels

# import some data to play with
iris = datasets.load_iris()
X = iris.data
y = iris.target
class_names = iris.target_names

# Split the data into a training set and a test set
X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=0)

# Run classifier, using a model that is too regularized (C too low) to see
# the impact on the results
classifier = svm.SVC(kernel='linear', C=0.01)
y_pred = classifier.fit(X_train, y_train).predict(X_test)

# Compute confusion matrix
cm = confusion_matrix(y_test, y_pred)

print(cm)
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
