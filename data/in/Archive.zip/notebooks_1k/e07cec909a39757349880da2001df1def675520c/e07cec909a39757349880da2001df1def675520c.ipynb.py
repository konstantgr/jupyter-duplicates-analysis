import requests
from tqdm import tqdm

# https://curl.trillworks.com/

headers = {
    'authority': 'www.ticket2u.com.my',
    'accept': 'application/json, text/javascript, */*; q=0.01',
    'sec-fetch-dest': 'empty',
    'x-requested-with': 'XMLHttpRequest',
    'user-agent': 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Mobile Safari/537.36',
    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'origin': 'https://www.ticket2u.com.my',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-mode': 'cors',
    'referer': 'https://www.ticket2u.com.my/event/list/?most=views&ex=1&currentpage=2',
    'accept-language': 'en-MY,en;q=0.9,en-US;q=0.8,ms;q=0.7',
    'cookie': '__cfduid=d177b4a65606756508942d4b30a26c7761586009694; ASP.NET_SessionId=i50pia15zlbt0d2bx1oeqk4x; ARRAffinity=962880a44b3c948dcdf487dfb529377adbd3199c49fc6e34b01e1a66c48ac6b9; _ga=GA1.3.1083977511.1586009700; _gid=GA1.3.429410572.1586009700; freshworks-s360-vid=fb39aa08-3f9e-43cf-8595-79ce9db835a1; _gat_UA-46018390-3=1',
}
# [___CELL_SEPARATOR___]
results = []

for i in tqdm(range(1, 239, 1)):
    data = '{"method":"eventlisting","data":{"most":"views","ex":"1","currentpage":%d,"stateid":""}}'%(i)
    try:
        response = requests.post('https://www.ticket2u.com.my/api/api2.ashx', headers=headers, data=data)
        results.extend(response.json()['data'])
    except Exception as e:
        print(e, i)
# [___CELL_SEPARATOR___]
import json

with open('ticketui.json', 'w') as fopen:
    json.dump(results, fopen)