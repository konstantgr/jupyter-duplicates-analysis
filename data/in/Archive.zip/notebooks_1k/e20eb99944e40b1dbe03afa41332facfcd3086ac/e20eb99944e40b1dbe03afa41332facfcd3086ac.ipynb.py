import numpy as np
np.random.seed(100) # Set the seed for reproducibility 

import matplotlib.pyplot as plt
from matplotlib import rcParams
rcParams["font.family"] = "serif"
rcParams["font.serif"] = "Times New Roman"
%matplotlib inline
rcParams['text.usetex'] = True
rcParams['text.latex.preamble'] = [r'\usepackage{amsmath} \usepackage{bm} \usepackage{physics}']
%config InlineBackend.figure_format = 'retina' # For high quality figures
# [___CELL_SEPARATOR___]
import numpy as np
import matplotlib.pyplot as plt

# Generate the measurement data
mu_key    = 6.0  # cm. The *actual* length of the key (unknown to us)
sigma_key = 0.05 # cm. Uncertainty on each measurement, based on the tick marks on our ruler
n_measure = 100  # Take 100 measurements
X = np.random.normal(mu_key, sigma_key, n_measure) # Generate the "measurements"
# [___CELL_SEPARATOR___]
# Plot the data
plt.plot(np.arange(n_measure), X, '.', label='Measured value')
plt.plot(np.arange(n_measure), mu_key * np.ones(n_measure), '--', alpha=0.5, label='True value')

plt.xlabel('Measurement number', fontsize=14)
plt.ylabel('Length [cm]', fontsize=14)
plt.legend(fontsize=14, framealpha=0.3)

plt.show()
# [___CELL_SEPARATOR___]
X = np.random.normal(mu_key, sigma_key, n_measure) # Generate the "measurements"
# [___CELL_SEPARATOR___]
def gaussian_pdf(x, mu=0, sigma=1):
    '''
    A gaussian pdf. Units of 1/x.
    
    Args
    ----------
    x (float): Location to evaluate the gaussian pdf.
    mu (float): Optional, default = 0. Mean of the gaussian.
    sigma (float): Optional, default = 1. Standard deviation.
    
    Returns
    ----------
    float: N(mu, sigma) evaluated at x.
    '''
    assert sigma > 0, "Standard deviation must be positive."
    return (1 / np.sqrt(2 * np.pi) / sigma) * np.exp(-0.5 * ((x - mu)/sigma)**2)
# [___CELL_SEPARATOR___]
x = np.linspace(5.75, 6.25, 100)
pdf = gaussian_pdf(x, mu = mu_key, sigma = sigma_key)

fig, ax = plt.subplots()
pdf_label = '$\mu = \:$' + f'{mu_key} cm' + '\n' + '$\sigma = \:$' + f'{sigma_key} cm'
pdf_line = ax.plot(x, pdf, '--', label=pdf_label)
ax1 = ax.twinx() # Different y-axes but same x-axis for pdf plot and histogram
hist_label = 'Data'
hist = ax1.hist(X, label=hist_label, color='orange', alpha=0.6, bins=15)

ax.set_xlabel('Length [cm]', fontsize=14)
ax.set_ylabel('PDF [cm$^{-1}$]', fontsize=14)
ax1.set_ylabel('N', fontsize=14)
ax.legend(fontsize=14, loc='upper left')
ax1.legend(fontsize=14, loc='upper right')
plt.show()
# [___CELL_SEPARATOR___]
# If we didn't do all of this analysis by hand, and just wanted to minimize chi^2 in code, what would that look like?
from scipy.optimize import minimize

def chi_squared(mu, sigma, data):
    '''
    Args
    ----------
    mu (float): Underlying mean of distribution (unknown to us).
    sigma (float): Measurement error.
    data (ndarray): Vector of observed data
    
    Returns
    ----------
    float: chi-squared value
    '''
    return np.sum(((data - mu)/sigma)**2)

mu_0 = 4.0 # cm. Our initial guess at the true length of the key, just from eye-balling it.
min_results = minimize(chi_squared, mu_0, args=(sigma_key, X)) # Minimize chi-squared with respect to mu

print(f"Best-fitting value of mu_key from chi-squared minimization = {min_results.x[0]:.3f} cm")
print(f"Average of the data = {np.average(X):.3f} cm")
# [___CELL_SEPARATOR___]
