import nltk
# [___CELL_SEPARATOR___]
# let's explore its contents:

nltk.corpus.gutenberg.fileids()
# [___CELL_SEPARATOR___]
# "Emma" by Jane Austen

emma = nltk.corpus.gutenberg.words('austen-emma.txt')

print(emma)
# [___CELL_SEPARATOR___]
# you can access corpus texts as characters, words (tokens) or sentences:

file_id = 'austen-emma.txt'

print("\nSentences:")
print( nltk.corpus.gutenberg.sents(file_id)[:3] )

print("\nWords:")
print( nltk.corpus.gutenberg.words(file_id)[:10] )

print("\nChars:")
print( nltk.corpus.gutenberg.raw(file_id)[:50] )
# [___CELL_SEPARATOR___]
# Brown corpus categories list:

from nltk.corpus import brown
brown.categories()
# [___CELL_SEPARATOR___]
# We can filter the corpus by (a) one or more categories or (b) file IDs:

print(brown.sents(categories='science_fiction')[:2])
# [___CELL_SEPARATOR___]
print(brown.sents(categories=['news', 'editorial', 'reviews']))
# [___CELL_SEPARATOR___]
print(brown.words(fileids=['cg22']))
# [___CELL_SEPARATOR___]
cfd = nltk.ConditionalFreqDist(
           (genre, word)
           for genre in brown.categories()
           for word in brown.words(categories=genre))

genres = ['news', 'religion', 'hobbies', 'science_fiction', 'romance', 'humor']
modals = ['can', 'could', 'may', 'might', 'must', 'will']

cfd.tabulate(conditions=genres, samples=modals)
# [___CELL_SEPARATOR___]
words = nltk.corpus.brown.tagged_words(tagset='universal')
words
# [___CELL_SEPARATOR___]
# islice() lets us read a part of the corpus

from itertools import islice
words = islice(words, 300)

# let's convert it to a list
word_list = list(words)
word_list
# [___CELL_SEPARATOR___]
# find all words with POS tag "ADJ"

tag = 'ADJ'

[item[0] for item in word_list if item[1] == tag]
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
from nltk.corpus import wordnet as wn
# [___CELL_SEPARATOR___]
# a collection of synonym sets related to "wind"

wn.synsets('wind')
# [___CELL_SEPARATOR___]
# words (lemmas) in one of synsets:

wn.synset('wind.n.08').lemma_names()
# [___CELL_SEPARATOR___]
wn.synset('wind.n.08').definition()
# [___CELL_SEPARATOR___]
wn.synset('wind.n.08').examples()
# [___CELL_SEPARATOR___]
# let's explore all the synsets for this word

for synset in wn.synsets('wind'):
    print(synset.lemma_names())
# [___CELL_SEPARATOR___]
# see all synsets that contain a given word

wn.lemmas('curve')
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
