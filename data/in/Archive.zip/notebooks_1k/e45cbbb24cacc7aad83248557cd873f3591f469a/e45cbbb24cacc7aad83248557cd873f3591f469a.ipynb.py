%matplotlib inline
import numpy as np
from scipy import stats
import matplotlib.pyplot as plt

# [___CELL_SEPARATOR___]


def pol2cart(deg,r):
    """
    convert angle from deg, r to x, y
    """
    x = r * np.sin(np.deg2rad(deg))
    y = r * np.cos(np.deg2rad(deg))
    return x, y
    
# [___CELL_SEPARATOR___]

deg, lag = np.meshgrid(np.linspace(-180,180,91),
                       np.arange(-10*2,11*2,4).astype(int))
positions = np.vstack((deg.ravel(),lag.ravel()))
values = positions
kernel = stats.gaussian_kde(values)
Z = np.reshape(kernel(positions).T,deg.shape)
# [___CELL_SEPARATOR___]
xmin=lag.min()
xmax=lag.max()
ymin=deg.min()
ymax=deg.max()

import matplotlib.pyplot as plt
fig, ax = plt.subplots()
ax.imshow(np.rot90(Z), cmap='viridis',extent=[xmin, xmax, ymin, ymax])
# ax.plot(lag, deg, 'k.', markersize=2)
# ax.set_xlim([xmin, xmax])
# ax.set_ylim([ymin, ymax])
plt.show()

# [___CELL_SEPARATOR___]
x,y = pol2cart(2*deg,lag)

xmin=x.min()
xmax=x.max()
ymin=y.min()
ymax=y.max()

positions = np.vstack((x.ravel(),y.ravel()))
values = positions
kernel = stats.gaussian_kde(values)
Z = np.reshape(kernel(positions),x.shape)

fig, ax = plt.subplots()
plt.contourf(x,y,Z, cmap='viridis',extent=[xmin, xmax, ymin, ymax])
# ax.plot(x, y, 'k.', markersize=2)
# ax.set_xlim([xmin, xmax])
# ax.set_ylim([ymin, ymax])
plt.show()
# [___CELL_SEPARATOR___]
plt.plot(x.ravel(),y.ravel(),'ro',ms=.5)
# [___CELL_SEPARATOR___]
lag.ravel().shape
# [___CELL_SEPARATOR___]
lag
# [___CELL_SEPARATOR___]
lag.size
# [___CELL_SEPARATOR___]
plt.plot(x[0,:],Z[0,:],'ro')
# [___CELL_SEPARATOR___]
def rho(n,step):
    if n == 0:
        return 1 / (np.pi/4 * step**2)
    elif n > 0:
        return 1 / (2 * np.pi * n * step)
    else:
        raise Exception('n not valid')
        
rho = np.vectorize(rho)
# [___CELL_SEPARATOR___]
lags = np.arange(50)
rhos = rho(lags,1)
plt.plot(lags,rhos)
# [___CELL_SEPARATOR___]
