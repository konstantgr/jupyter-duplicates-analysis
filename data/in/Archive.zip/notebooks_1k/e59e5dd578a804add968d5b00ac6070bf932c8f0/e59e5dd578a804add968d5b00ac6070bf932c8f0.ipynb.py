from xugu import Servo
# [___CELL_SEPARATOR___]
servo = Servo(4)
# [___CELL_SEPARATOR___]
servo. write_angle(150)
# [___CELL_SEPARATOR___]
