using Hadamard

# convenience (type /otimes<tab>) - <tab> is the "tab" key.
⊗ = kron
# type /oplus<tab>
⊕ = (x,y)->mod.(x+y,2)


# [___CELL_SEPARATOR___]
# TO demonstrate the peeling decoder we are going to set up a sparse (fake) distribution.
# This is going to mirror the example shown above - 
# NOTE Julia indexing starts at 1, so we add 1 to the integers in the above table
# TO demonstrate the peeling decoder we are going to set up a sparse (fake) distribution.
# This is going to be a 4 qubit (so 4^4 = 256 possible probabilities)

dist = zeros(16)
cl = zeros(2,4)

# Qubit 1
cl[1,2] = 0.01 #y1
cl[1,3] = 0.004 #x1
cl[1,4] = 0.001 #z1
cl[1,1] = 1-sum(cl[1,:])

# Qubit 2
cl[2,2] = 0.03
cl[2,3] = 0.02
cl[2,4]=  0.005
cl[2,1] = 1-sum(cl[2,:])

for q1 in 1:4
    for q2 in 1:4
      dist[(q2-1)*4+q1] = cl[1,q1]*cl[2,q2]
    end
end

# rounding to 10 digits just to get rid of some annoying numerical instability
dist = round.(dist,digits=10)
basicSuperOpDiagonal = round.(ifwht_natural(dist),digits=10)
print("Basic SuperOperator (diagonal): $basicSuperOpDiagonal\n")
print("Distribution: $(dist)\n")
# [___CELL_SEPARATOR___]
zs = 
 [[1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1],
 [1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, -1],
 [1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, -1],
 [1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 1]]
# [___CELL_SEPARATOR___]
# Side note if you have installed my Juqst package (see https://github.com/rharper2/Juqst.jl), then
# You can generate these for any size using Juqst.genZs(2) (for 2 qubits).
# [___CELL_SEPARATOR___]
using LinearAlgebra

superOperatorNoise = diagm(0=>basicSuperOpDiagonal)

# [___CELL_SEPARATOR___]
# The measurement outcomes are then:
print("M_00 = ↑↑ = $(round(0.25*zs[1]'*superOperatorNoise*zs[1],digits=10))\n")
print("M_01 = ↑↓ = $(round(0.25*zs[2]'*superOperatorNoise*zs[1],digits=10))\n")
print("M_10 = ↓↑ = $(round(0.25*zs[3]'*superOperatorNoise*zs[1],digits=10))\n")
print("M_11 = ↓↓ = $(round(0.25*zs[4]'*superOperatorNoise*zs[1],digits=10))\n")
outcomes = 0.25.*[x'*superOperatorNoise*zs[1] for x in zs]
print("total probability = $(sum(outcomes))\n")

# [___CELL_SEPARATOR___]
# Some function to give us labels:
function probabilityLabels(x;qubits=2)
    str = string(x,base=4,pad=qubits)
    paulis = ['I','Y','X','Z']
    return map(x->paulis[parse(Int,x)+1],str)
end

function fidelityLabels(x;qubits=2)
    str = string(x,base=4,pad=qubits)
    paulis = ['I','X','Y','Z']
    return map(x->paulis[parse(Int,x)+1],str)
end
# [___CELL_SEPARATOR___]

# Print label and probability
for i in 1:16
    print("$i: $(probabilityLabels(i-1)): $(dist[i])\n")
end
# [___CELL_SEPARATOR___]
print("Sum of relevant probabilities: $(dist[2]+dist[3]+dist[14]+dist[15])\n")
print("Expected measurement outcome: M_01 = ↑↓ = $(round(0.25*zs[2]'*superOperatorNoise*zs[1],digits=10))\n")
# [___CELL_SEPARATOR___]
print("Sum of relevant probabilities: $(round(dist[9]+dist[5]+dist[8]+dist[12],digits=10))\n")
print("Expected measurement outcome: M_10 = ↓↑ = $(round(0.25*zs[3]'*superOperatorNoise*zs[1],digits=10))\n")
# [___CELL_SEPARATOR___]
print("Sum of relevant probabilities: $(round(dist[7]+dist[6]+dist[11]+dist[10],digits=10))\n")
print("Expected measurement outcome: M_11 = ↓↓ = $(round(0.25*zs[4]'*superOperatorNoise*zs[1],digits=10))\n")
# [___CELL_SEPARATOR___]
round.(Hadamard.hadamard(4)*[0.9367, 0.0133, 0.0493, 0.0007],digits=10)
# [___CELL_SEPARATOR___]
# Print label and probability
for i in 1:16
    print("$i: $(fidelityLabels(i-1)): $(basicSuperOpDiagonal[i])\n")
end
# [___CELL_SEPARATOR___]
req = [1,0,0,0,0,0,1,0,0,0,0,1,0,1,0,0]
for i in 1:16
    print("$(string(i,pad=2)) $(fidelityLabels(i-1)): $(req[i])\n")
end
# [___CELL_SEPARATOR___]
using Juqst
# Set up the relevant gates
cnot21 = [1 0;0 1]⊗[1 0;0 0]+ [0 1;1 0]⊗[0 0;0 1]
superCnot21 = makeSuper(cnot21)
superPI = makeSuper([1 0;0 im]⊗[1 0;0 1])
superIP = makeSuper([1 0;0 1]⊗[1 0;0 im])
superHH = makeSuper((1/sqrt(2)*[1 1;1 -1])⊗(1/sqrt(2)*[1 1;1 -1]));
# [___CELL_SEPARATOR___]
# Circuit (a) is then just these gates applied (here circuit is from left to right, but matrices the other way!)

circuit = superCnot21*superPI*superCnot21*superIP*superHH
# [___CELL_SEPARATOR___]
newB = circuit*zs[1]
for i in 1:16
    print("$(string(i,pad=2)) $(fidelityLabels(i-1)): $(newB[i])\n")
end
# [___CELL_SEPARATOR___]
Rcircuit = superHH*superIP*superIP*superIP * superCnot21*superPI*superPI*superPI*superCnot21
# [___CELL_SEPARATOR___]
Rcircuit *circuit 
# [___CELL_SEPARATOR___]
# And just a little sanity check, that the transpose of superoperator is indeed its inverse
Rcircuit == transpose(circuit)
# [___CELL_SEPARATOR___]
# The measurement outcomes are then:
print("M_00 = ↑↑ = $(round(0.25*zs[1]'*Rcircuit*superOperatorNoise*circuit*zs[1],digits=10))\n")
print("M_01 = ↑↓ = $(round(0.25*zs[2]'*Rcircuit*superOperatorNoise*circuit*zs[1],digits=10))\n")
print("M_10 = ↓↑ = $(round(0.25*zs[3]'*Rcircuit*superOperatorNoise*circuit*zs[1],digits=10))\n")
print("M_11 = ↓↓ = $(round(0.25*zs[4]'*Rcircuit*superOperatorNoise*circuit*zs[1],digits=10))\n")
outcomes = 0.25.*[x'*Rcircuit*superOperatorNoise*circuit*zs[1] for x in zs]
print("total probability = $(sum(outcomes))\n")
# [___CELL_SEPARATOR___]
round.(Hadamard.hadamard(4)*outcomes,digits=10)
# [___CELL_SEPARATOR___]
# Recall the eigenvalues:
# Print label and probability
for i in 1:16
    print("$i: $(fidelityLabels(i-1)): $(basicSuperOpDiagonal[i])\n")
end
# [___CELL_SEPARATOR___]
