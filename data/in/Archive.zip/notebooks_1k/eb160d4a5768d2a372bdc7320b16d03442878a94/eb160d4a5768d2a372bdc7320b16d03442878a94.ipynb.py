using ForwardDiff
using Statistics
using SpecialFunctions
using Plots
plotly()
# [___CELL_SEPARATOR___]
plot(x->x^2-1,label="x^2-1")
hline!([0],label="")
plot!(xlims=(-2,2),ylims=(-2,5))
# [___CELL_SEPARATOR___]
plot(x->x^2,label="x^2")
hline!([0],label="")
plot!(xlims=(-2,2),ylims=(-2,5))
# [___CELL_SEPARATOR___]
plot(x->x^3,label="x^3")
plot!(x->x^3-2x,label="x^3-2x")
hline!([0],label="")
plot!(xlims=(-2,2),ylims=(-2,5))
# [___CELL_SEPARATOR___]
plot(x->x^4,label="x^4")
plot!(x->x^4-3x^2+1,label="x^4-3x^2+1")
hline!([0],label="")
plot!(xlims=(-2,2),ylims=(-2,5))
# [___CELL_SEPARATOR___]
f(x) = 2*cos(x)-x+x^2/10
x2(x)=x^2
recip(x)=1/x
loop(x)=x^3-2x+2
cubert(x)=cbrt(x)
n_roots(x)=cos(2*pi*x)-0.4*x
# [___CELL_SEPARATOR___]
xh=collect(0.01:0.01:5)

plot(f,label="Transcendental Function"
    ,ylims=(-1,1),legend=:topleft)
plot!(x2,label="Multiplicity 2")
plot!(n_roots,label="Many roots")
plot!(vcat(xh,-xh),vcat(recip.(xh),recip.(-xh)),label="Divergence")
hline!([0],label="Zero")
# [___CELL_SEPARATOR___]
function Zero_Iterator(f::Function,Method::Function,
        iterated_values0::Array{Float64},params,N)
    
    n_values=zeros(Float64,length(iterated_values0),N)
    n_values[:,1]=iterated_values0;
    
    for ii in 2:N
        n_values[:,ii] = Method(f,n_values[:,(ii-1)],params)
    end
    return n_values
end
# [___CELL_SEPARATOR___]
function Midpoint(f::Function,endpoints::Array{Float64},params)
    if f(endpoints[1])*f(endpoints[2])>0
        println("Endpoints must bracket a zero.  Please pick better endpoints.")
        error()
    end
    c=mean(endpoints)
    if f(endpoints[1])*f(c)<0
        return [ endpoints[1],c]
    elseif f(c)*f(endpoints[2])<0
        return [c, endpoints[2]]
    elseif f(c) ==0 
        print("midpoint is zero")
        return [c,c]
    else   
        println("Mid point doesn't bracket a zero... something weird...")
        print(c,"\t",f(c))
    end
end
# [___CELL_SEPARATOR___]
N_M=10
# [___CELL_SEPARATOR___]
endpoints_M_f=Zero_Iterator(f,Midpoint,[-1.0,2.0],["null"],N_M)
dx_M_f=endpoints_M_f[2,:]-endpoints_M_f[1,:]
# [___CELL_SEPARATOR___]
plot(f,xlims=endpoints_M_f[:,1])
for ii in 1:N_M
    vline!(endpoints_M_f[:,ii],color=cgrad(:viridis)[ii/N_M],label="")
end
hline!([0],label="")
plot!(title="Bracketing the zero of f",xlabel="x",ylabel="y")
# [___CELL_SEPARATOR___]
plot(transpose(endpoints_M_f),label=["Right Boundary","Left Boundary"])
plot!(title="Boundary Positions over steps"
    ,xlabel="steps",ylabel="Boundary Position")
# [___CELL_SEPARATOR___]
endpoints_M_recip=Zero_Iterator(recip,Midpoint,[-1.4,1.0],["null"],N_M)
dx_M_recip=endpoints_M_recip[2,:]-endpoints_M_recip[1,:]
# [___CELL_SEPARATOR___]
plot(recip,xlims=endpoints_M_recip[:,1],ylims=(-5,5))
for ii in 1:N_M
    vline!(endpoints_M_recip[:,ii],color=cgrad(:viridis)[ii/N_M],label="")
end
hline!([0],label="")
plot!(title="Bracketing a divergence",xlabel="x",ylabel="y")
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
endpoints_M_n_roots_1=Zero_Iterator(n_roots,Midpoint,[-5.,5.],["null"],N_M)
endpoints_M_n_roots_2=Zero_Iterator(n_roots,Midpoint,[-5.,4.5],["null"],N_M)
endpoints_M_n_roots_3=Zero_Iterator(n_roots,Midpoint,[-4.5,5],["null"],N_M)
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
plot(transpose(endpoints_M_n_roots_1),label=["1st Right","1st Left"],color=:black)
plot!(transpose(endpoints_M_n_roots_2),label=["2nd Right","2nd Left"],color=:blue)
plot!(transpose(endpoints_M_n_roots_3),label=["3rd Right","3rd Left"],color=:red)
plot!(title="Many Root function dependence on endpoints"
    ,xlabel="steps",ylabel="Boundary Position")
# [___CELL_SEPARATOR___]
function Newtons(f::Function,x::Array,fp::Array)
    return [ x[1]- f(x[1])/fp[1](x[1]) ]
end
# [___CELL_SEPARATOR___]
fp(x)=-2*sin(x)-1+1/5*x
dx2(x)=2*x
drecip(x)=-1/x^2
dloop(x)=3x^2-2
dcubert(x)=(1.0/3.0)*cbrt(x^(-2))
# [___CELL_SEPARATOR___]
x_NR_f=Zero_Iterator(f,Newtons,[2.0],[fp],10)[1,:]
dx_NR_f=x_NR_f.-x_NR_f[end]

println("ii \t Guess \t\t\t dx")
for ii in 1:length(x_NR_f)
    println(ii,"\t",x_NR_f[ii],"\t",dx_NR_f[ii])
end
# [___CELL_SEPARATOR___]
x_NR_x2=Zero_Iterator(x2,Newtons,[1.0],[dx2],10)[1,:]
dx_NR_x2=x_NR_x2.-x_NR_x2[end]

println("ii \t Guess \t\t dx")
for ii in 1:length(x_NR_x2)
    println(ii,"\t",x_NR_x2[ii],"\t",dx_NR_x2[ii])
end
# [___CELL_SEPARATOR___]
plot(x2,
    xlims=(-.5,1.5),ylims=(-.5,2),legend=false)
hline!([0])

for ii in 1:5
    plot!(x_NR_x2[(0:1).+ii],
        x2(x_NR_x2[ii]).+dx2(x_NR_x2[ii]).*(x_NR_x2[(0:1).+ii]
            .-x_NR_x2[ii])
        ,linewidth=3,color=cgrad(:inferno)[ii/5])
    plot!([x_NR_x2[1+ii],x_NR_x2[1+ii]],[0,x2(x_NR_x2[1+ii])]
        ,linewidth=3,color=cgrad(:inferno)[ii/5])
end
plot!(title="Visual Newton-Raphson",
    xlabel="x",ylabel="y")

# [___CELL_SEPARATOR___]
x_NR_recip=Zero_Iterator(recip,Newtons,[2.0],[drecip],10)[1,:]
# [___CELL_SEPARATOR___]
# a loop where the iteration gets stuck between two points
x_NR_loop=Zero_Iterator(loop,Newtons,[1.0],[dloop],10)[1,:]
# [___CELL_SEPARATOR___]
# perturb the starting point, and we still don't really go anywhere...
x_NR_loop2=Zero_Iterator(loop,Newtons,[1.05],[dloop],30)[1,:]
# [___CELL_SEPARATOR___]
xloop=collect(-.5:.01:3)
plot(xloop,loop.(xloop),
    xlims=(-.5,3),ylims=(-1,5),legend=false)
hline!([0])

for ii in 1:29
    plot!(x_NR_loop2[(0:1).+ii],
        loop(x_NR_loop2[ii]).+dloop(x_NR_loop2[ii]).*(x_NR_loop2[(0:1).+ii]
            .-x_NR_loop2[ii])
        ,linewidth=2,color=cgrad(:inferno)[ii/30])
    plot!([x_NR_loop2[1+ii],x_NR_loop2[1+ii]],[0,loop(x_NR_loop2[1+ii])]
        ,linewidth=2,color=cgrad(:inferno)[ii/30])
end


for ii in 1:9
    plot!(x_NR_loop[(0:1).+ii],
        loop(x_NR_loop[ii]).+dloop(x_NR_loop[ii]).*(x_NR_loop[(0:1).+ii]
            .-x_NR_loop[ii])
        ,linewidth=5,color=:black)
    plot!([x_NR_loop[1+ii],x_NR_loop[1+ii]],[0,loop(x_NR_loop[1+ii])]
        ,linewidth=5,color=:black)
end

plot!(title="Newton-Raphson Cycle",
    xlabel="x",ylabel="y")
# [___CELL_SEPARATOR___]
x_NR_cubert=Zero_Iterator(cubert,Newtons,[1.0],[dcubert],10)[1,:]
# [___CELL_SEPARATOR___]
x_cubert=collect(-30:0.01:30)

plot(x_cubert,cubert.(x_cubert),linewidth=5
    ,xlims=(-30,30),legend=false)
hline!([0])

for ii in 1:9
    plot!(x_NR_cubert[(0:1).+ii],
        cubert(x_NR_cubert[ii]).+dcubert(x_NR_cubert[ii]).*(x_NR_cubert[(0:1).+ii]
            .-x_NR_cubert[ii])
        ,linewidth=1,color=cgrad(:inferno)[ii/10])
    plot!([x_NR_cubert[1+ii],x_NR_cubert[1+ii]],[0,cubert(x_NR_cubert[1+ii])]
        ,linewidth=1,color=cgrad(:inferno)[ii/10])
end
plot!(title="Runaway Argument",
    xlabel="x",ylabel="y")
# [___CELL_SEPARATOR___]
# x[1:2] are last two points
# x[2] more recent and x[1] older
# x[3:4] are f values of last two points
function Secant(f::Function,x::Array,params::Array)
    xnew= x[2] - x[4]*(x[2]-x[1])/(x[4]-x[3])
    return [x[2], xnew, x[4], f(xnew)]
end
# [___CELL_SEPARATOR___]
x_S_f=Zero_Iterator(f,Secant,[2.,1.5,f(2.0),f(1.5)],["null"],10)
dx_S_f=x_S_f[2,:]-x_S_f[1,:]
# [___CELL_SEPARATOR___]
x_S_x2=Zero_Iterator(x2,Secant,[-1,.8,x2(-1.),x2(.8)],["null"],10)
dx_S_x2=x_S_x2[2,:].-x_S_x2[2,end]

println("ii \t Guess \t\t\t dx")
for ii in 1:length(x_S_x2[1,:])
    println(ii,"\t",x_S_x2[2,ii],"\t",dx_S_x2[ii])
end
# [___CELL_SEPARATOR___]
Zero_Iterator(x2,Secant,[-1.,1.,x2(-1.),x2(1.)],["null"],10)
# [___CELL_SEPARATOR___]
function RegulaFalsi(f::Function, x::Array{Float64},params)
    if f(x[1])*f(x[2])>0
        println("Endpoints must bracket a zero.  Please pick better endpoints.")
        error()
    end
    
    c= x[2] - x[4]*(x[2]-x[1])/(x[4]-x[3])
    
    if f(x[1])*f(c)<0
        return [ x[1],c,x[3],f(c) , c]
        
    elseif f(c)*f(x[2])<0
        return [c, x[2], f(c) , x[4] , c]
        
    elseif f(c) ==0 
        print("midpoint is zero")
        return [x,x,f(c),f(c) , c]
    else   
        println("Mid point doesn't bracket a zero... somethign weird...")
        print(c,"\t",f(c))
    end
end
# [___CELL_SEPARATOR___]
x_RF_f=Zero_Iterator(f,RegulaFalsi,[-1.,2.,f(-1.),f(2.),-1.],["null"],10)
dx_RF_f=x_RF_f[5,:].-x_RF_f[end]
# [___CELL_SEPARATOR___]
plot(f
    ,xlims=(-1.5,2.5),ylims=(-2.5,3),legend=false)
hline!([0])
plot!(x_RF_f[1:2,:],x_RF_f[3:4,:],linewidth=3)

plot!(xlabel="x",ylabel="y",title="Regula Falsi Method")
# [___CELL_SEPARATOR___]
x_RF_cubert=Zero_Iterator(cubert,RegulaFalsi,[-1.,2.,cubert(-1.),cubert(2.),-1.],["null"],10)
# [___CELL_SEPARATOR___]
plot(abs.(dx_M_f/dx_M_f[1]).+1e-10,label="Midpoint Method")
plot!(abs.(dx_NR_f/dx_NR_f[1]).+1e-10,label="Newton-Raphson")
plot!(abs.(dx_S_f/dx_S_f[1]).+1e-10,label="Secant")
plot!(abs.(dx_RF_f/dx_RF_f[1]).+1e-10,label="Regula Falsi")

plot!(yscale=:log,legend=:bottomleft,xlabel="Iterations",ylabel="Difference from Final",
    title="Comparison of Root Finding Methods")
# [___CELL_SEPARATOR___]
