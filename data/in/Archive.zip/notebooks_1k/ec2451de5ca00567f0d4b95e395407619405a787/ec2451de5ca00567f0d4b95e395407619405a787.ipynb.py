import numpy as np
np.__version__
# [___CELL_SEPARATOR___]
L = list(range(10))
L
# [___CELL_SEPARATOR___]
# integer array:
a = np.array([1, 4, 2, 5, 3])
print(a)
# [___CELL_SEPARATOR___]
l = [1, 4, 3, 5, 3]
print(l)
a = np.array(l)
print(a)
a.dtype
# [___CELL_SEPARATOR___]
a = np.array([3.14, 4, 2, 3])
a.dtype
# [___CELL_SEPARATOR___]
a = np.array([1.3, 2, 3, 4], dtype='int32')
# [___CELL_SEPARATOR___]
a
# [___CELL_SEPARATOR___]
# nested lists result in multi-dimensional arrays
np.array([range(i, i + 3) for i in [2, 4, 6]])
# [___CELL_SEPARATOR___]
l = [[1,2,3],[4,5,6]]
a = np.array(l)
print(a)
a.dtype
# [___CELL_SEPARATOR___]
a.shape
# [___CELL_SEPARATOR___]
# Create a length-10 integer array filled with zeros
z1d = np.zeros((10))
print(z1d)
z1d.shape
# [___CELL_SEPARATOR___]
z2d = np.zeros((10,1))
print(z2d)
z2d.shape
# [___CELL_SEPARATOR___]
z1d[::2,np.newaxis,np.newaxis]
# [___CELL_SEPARATOR___]
# Create a 3x5 floating-point array filled with ones
np.ones((3, 5), dtype=float)
# [___CELL_SEPARATOR___]
# Create a 3x5 array filled with 3.14
np.full((3, 5), 3.14)
# [___CELL_SEPARATOR___]
np.arange(5)
# [___CELL_SEPARATOR___]
# Create an array filled with a linear sequence
# Starting at 0, ending at 20, stepping by 2
# (this is similar to the built-in range() function)
np.arange(0, 20, 2)
# [___CELL_SEPARATOR___]
# Create an array of five values evenly spaced between 0 and 1
np.linspace(0, 1, 5)
# [___CELL_SEPARATOR___]
# Create a 3x3 array of uniformly distributed
# random values between 0 and 1
np.random.random((3, 3))
# [___CELL_SEPARATOR___]
# Create a 3x3 array of normally distributed random values
# with mean 0 and standard deviation 1
np.random.normal(0, 1, (3, 3))
# [___CELL_SEPARATOR___]
# Create a 3x3 array of random integers in the interval [0, 10)
np.random.randint(0, 10, (3, 3))
# [___CELL_SEPARATOR___]
# Create a 3x3 identity matrix
np.eye(3)
# [___CELL_SEPARATOR___]
# Create an uninitialized array of three integers
# The values will be whatever happens to already exist at that memory location
np.empty((3,8))
# [___CELL_SEPARATOR___]
import numpy as np
np.random.seed(0)  # seed for reproducibility

x1 = np.random.randint(10, size=6)  # One-dimensional array
x2 = np.random.randint(10, size=(3, 4))  # Two-dimensional array
x3 = np.random.randint(10, size=(3, 4, 5))  # Three-dimensional array
# [___CELL_SEPARATOR___]
x3
# [___CELL_SEPARATOR___]
print("x3 ndim: ", x3.ndim)
print("x3 shape:", x3.shape)
print("x3 size: ", x3.size)
# [___CELL_SEPARATOR___]
print("dtype:", x3.dtype)
# [___CELL_SEPARATOR___]
print("itemsize:", x3.itemsize, "bytes")
print("nbytes:", x3.nbytes, "bytes")
# [___CELL_SEPARATOR___]
x1
# [___CELL_SEPARATOR___]
x1[0]
# [___CELL_SEPARATOR___]
x1[4]
# [___CELL_SEPARATOR___]
x1[-1]
# [___CELL_SEPARATOR___]
x2
# [___CELL_SEPARATOR___]
x2[0:2,1]
# [___CELL_SEPARATOR___]
x2[0, 0]
# [___CELL_SEPARATOR___]
x2[2]
# [___CELL_SEPARATOR___]
#You can modify the values using the index notation (numpy arrays are obviously mutable)
x2[0, 0] = 12
x2.dtype
# [___CELL_SEPARATOR___]
x2[0,0] = 3.14159  # this will be truncated! Remember, numpy arrays have a fixed type
x2
# [___CELL_SEPARATOR___]
x1[1] = 'c'
x1
# [___CELL_SEPARATOR___]
x2
# [___CELL_SEPARATOR___]
x2[:2, :3]  # two rows, three columns
# [___CELL_SEPARATOR___]
x2[:3, ::2]  # all rows, every other column
# [___CELL_SEPARATOR___]
x2[::-1, ::-1]
# [___CELL_SEPARATOR___]
print(x2[:, 0])  # first column of x2
# [___CELL_SEPARATOR___]
print(x2[0, :])  # first row of x2
# [___CELL_SEPARATOR___]
print(x2[0])  # equivalent to x2[0, :]
# [___CELL_SEPARATOR___]
print(x2)
# [___CELL_SEPARATOR___]
x2_sub = x2[:2, :2]
print(x2_sub)
# [___CELL_SEPARATOR___]
x2_sub[0,0] = 900
print(x2_sub)
# [___CELL_SEPARATOR___]
print(x2)
# [___CELL_SEPARATOR___]
print(x2)
x2_in = x2[::-1,::-1]
print(x2_in)
# [___CELL_SEPARATOR___]
x2_in[0,0] = 100
print(x2)
# [___CELL_SEPARATOR___]
x2_sub[0, 0] = 99
print(x2_sub)
# [___CELL_SEPARATOR___]
print(x2)
# [___CELL_SEPARATOR___]
x2_sub_copy = x2[:2, :2].copy()
print(x2_sub_copy)
# [___CELL_SEPARATOR___]
x2_sub_copy[0, 0] = 42
print(x2_sub_copy)
# [___CELL_SEPARATOR___]
print(x2)
# [___CELL_SEPARATOR___]
x3 = np.copy(x2)
x3 = x2.copy()
# [___CELL_SEPARATOR___]
g = np.arange(1, 10)
print(g)
grid = g.reshape((3, 3))
print(grid)
# [___CELL_SEPARATOR___]
one = np.array([1,2,3])
print(one)
print(one.shape)
# [___CELL_SEPARATOR___]
one_r = one.reshape((3,1))
one_r.shape
# [___CELL_SEPARATOR___]
print(one_r.reshape((3,)))
# [___CELL_SEPARATOR___]
two = np.array([[1,2,3]])
print(two)
print(two.shape)
# [___CELL_SEPARATOR___]
x = np.array([1, 2, 3])

# row vector via reshape
x.reshape((1, 3))
# [___CELL_SEPARATOR___]
# row vector via newaxis
x[np.newaxis, :]
# [___CELL_SEPARATOR___]
# column vector via reshape
x.reshape((3, 1))
# [___CELL_SEPARATOR___]
# column vector via newaxis
x[:, np.newaxis]
# [___CELL_SEPARATOR___]
x = np.array([1, 2, 3])
y = np.array([3, 2, 1])
np.concatenate([x, y])
# [___CELL_SEPARATOR___]
z = [99, 99, 99]
print(np.concatenate([x, y, z]))
# [___CELL_SEPARATOR___]
grid1 = np.array([[1, 2, 3],
                 [4, 5, 6]])
grid2 = np.array([[1, 2, 3,4],
                 [4, 5, 6,8]])

# [___CELL_SEPARATOR___]
# concatenate along the first axis
np.concatenate([grid1, grid2])
# [___CELL_SEPARATOR___]
# concatenate along the second axis (zero-indexed)
np.concatenate([grid1, grid2], axis=1)
# [___CELL_SEPARATOR___]
x = np.array([1, 2, 3])
grid = np.array([[9, 8, 7],
                 [6, 5, 4]])

# vertically stack the arrays
np.vstack([x, grid])
# [___CELL_SEPARATOR___]
# horizontally stack the arrays
y = np.array([[99],
              [99]])
np.hstack([grid, y])
# [___CELL_SEPARATOR___]
x = np.array([1, 2, 3, 99, 99, 3, 2, 1])
x1, x2, x3 = np.split(x, [3, 5])
print(x1, x2, x3)
# [___CELL_SEPARATOR___]
grid = np.arange(16).reshape((4, 4))
grid
# [___CELL_SEPARATOR___]
upper, lower = np.vsplit(grid, [2])
print(upper)
print(lower)
# [___CELL_SEPARATOR___]
left, right = np.hsplit(grid, [2])
print(left)
print(right)
# [___CELL_SEPARATOR___]
import numpy as np
import time
np.random.seed(0)

def compute_reciprocals(values):
    output = np.empty(len(values))
    for i in range(len(values)):
        output[i] = 1.0 / values[i]
    return output
        
values = np.random.randint(1, 10, size=5)
compute_reciprocals(values)
# [___CELL_SEPARATOR___]
big_array = np.random.randint(1, 100, size=1000000)
# [___CELL_SEPARATOR___]
#s = time.time()
%timeit v = compute_reciprocals(big_array)
#e = time.time()
#print("%f"%(e-s))
# [___CELL_SEPARATOR___]
print(compute_reciprocals(values))
print(1.0 / values)
# [___CELL_SEPARATOR___]
#s = time.time()
%timeit v = (1.0 / big_array)
#e = time.time()
#print("%f"%(e-s))
# [___CELL_SEPARATOR___]
np.arange(1,6)
# [___CELL_SEPARATOR___]
np.arange(5) / np.arange(1, 6)
# [___CELL_SEPARATOR___]
x = np.arange(9).reshape((3, 3))
2 ** x
# [___CELL_SEPARATOR___]
x = np.arange(4)
print("x     =", x)
print("x + 5 =", x + 5)
print("x - 5 =", x - 5)
print("x * 2 =", x * 2)
print("x / 2 =", x / 2)
print("x // 2 =", x // 2)  # floor division
# [___CELL_SEPARATOR___]
print("-x     = ", -x)
print("x ** 2 = ", x ** 2)
print("x % 2  = ", x % 2)
# [___CELL_SEPARATOR___]
-(0.5*x + 1) ** 2
# [___CELL_SEPARATOR___]
x + 2
# [___CELL_SEPARATOR___]
y = np.add(x, 2)
# [___CELL_SEPARATOR___]
np.add(x,2,out=y)
# [___CELL_SEPARATOR___]
x = np.arange(5)
y = np.empty(5)
np.multiply(x, 10, out=y)
print(y)
# [___CELL_SEPARATOR___]
y = np.zeros(10)
np.power(2, x, out=y[::2])
print(y)
# [___CELL_SEPARATOR___]
x + 2
# [___CELL_SEPARATOR___]
list(map(lambda _x: 2+_x,x))
# [___CELL_SEPARATOR___]
for _x in x:
    print(2+_x)
# [___CELL_SEPARATOR___]
# using python for loops
x = np.array([1,2,3,4])
y = np.empty(4)
for i in range(len(x)):
    y[i] = 1/x[i]
print(y)  
# [___CELL_SEPARATOR___]
# using ufunc
print(np.reciprocal(x))
# [___CELL_SEPARATOR___]
import numpy as np
# [___CELL_SEPARATOR___]
x = np.arange(1, 6)
print(x)
np.add(x,2)
# [___CELL_SEPARATOR___]
x = np.arange(1, 6)
np.add.reduce(x)
# [___CELL_SEPARATOR___]
np.multiply.reduce(x)
# [___CELL_SEPARATOR___]
np.add.accumulate(x)
# [___CELL_SEPARATOR___]
np.multiply.accumulate(x)
# [___CELL_SEPARATOR___]
x = np.arange(1,6)
print(x)
print(np.add.reduce(x))
print(np.sum(x))
print(np.add.accumulate(x))
print(np.cumsum(x))
# [___CELL_SEPARATOR___]
x = np.arange(1, 6)
y = np.arange(1,3)
np.multiply.outer(x, y)
# [___CELL_SEPARATOR___]
L = np.random.random(100)
sum(L)
# [___CELL_SEPARATOR___]
np.sum(L)
# [___CELL_SEPARATOR___]
big_array = np.random.rand(1000000)
%timeit sum(big_array)
%timeit np.sum(big_array)
# [___CELL_SEPARATOR___]
x = np.random.rand(3,4)
print(x)
# [___CELL_SEPARATOR___]
sum(x)
# [___CELL_SEPARATOR___]
np.sum(x)
# [___CELL_SEPARATOR___]
np.sum(x,axis=1)
# [___CELL_SEPARATOR___]
min(big_array), max(big_array)
# [___CELL_SEPARATOR___]
np.min(big_array), np.max(big_array)
# [___CELL_SEPARATOR___]
%timeit min(big_array)
%timeit np.min(big_array)
# [___CELL_SEPARATOR___]
print(big_array.min(), big_array.max(), big_array.sum())
# [___CELL_SEPARATOR___]
M = np.random.random((3, 4))
print(M)
# [___CELL_SEPARATOR___]
M.sum()
# [___CELL_SEPARATOR___]
M.min(axis=0)
# [___CELL_SEPARATOR___]
M.max(axis=1)
# [___CELL_SEPARATOR___]
x1 = np.array([4,3,2])
x2 = np.array([2,1,0])
x1/x2
# [___CELL_SEPARATOR___]
print(np.nanargmin(x,axis=1))
print(x)
# [___CELL_SEPARATOR___]
print(x)
print(np.min(x,axis=1))
print(np.argmin(x,axis=1))
# [___CELL_SEPARATOR___]
import csv
heights = []
names = []
with open('president_heights.csv','r') as f:
    rd = csv.reader(f)
    next(rd)
    for row in rd:
        heights.append(int(row[2]))
        names.append(row[1])
heights = np.array(heights)
# [___CELL_SEPARATOR___]
print("Mean height:       ", heights.mean())
print("Standard deviation:", heights.std())
print("Minimum height:    ", heights.min())
print("Maximum height:    ", heights.max())
# [___CELL_SEPARATOR___]
print("25th percentile:   ", np.percentile(heights, 25))
print("Median:            ", np.median(heights))
print("75th percentile:   ", np.percentile(heights, 75))
# [___CELL_SEPARATOR___]
#what happens if we do not do this
%matplotlib inline 
import matplotlib.pyplot as plt
import seaborn; seaborn.set()  # set plot style
# [___CELL_SEPARATOR___]
plt.hist(heights)
plt.title('Height Distribution of US Presidents')
plt.xlabel('height (cm)')
plt.ylabel('number');
# [___CELL_SEPARATOR___]
a = np.array([0, 1, 2])
b = np.array([5, 5])
a + b
# [___CELL_SEPARATOR___]
a + 5
# [___CELL_SEPARATOR___]
M = np.ones((3, 3))
M
# [___CELL_SEPARATOR___]
a = np.arange(0,4)
print(a)
# [___CELL_SEPARATOR___]
M + a
# [___CELL_SEPARATOR___]
a = np.arange(3)
b = np.arange(3)[:, np.newaxis]

print(a)
print(b)
print(a.shape)
print(b.shape)
# [___CELL_SEPARATOR___]
a + b
# [___CELL_SEPARATOR___]
M = np.ones((2, 3))
a = np.arange(3)
# [___CELL_SEPARATOR___]
M + a
# [___CELL_SEPARATOR___]
a = np.arange(3).reshape((3, 1))
b = np.arange(3)
# [___CELL_SEPARATOR___]
a + b
# [___CELL_SEPARATOR___]
M = np.ones((3, 2))
a = np.arange(3)
# [___CELL_SEPARATOR___]
M
# [___CELL_SEPARATOR___]
a
# [___CELL_SEPARATOR___]
M + a
# [___CELL_SEPARATOR___]
a[:, np.newaxis].shape
# [___CELL_SEPARATOR___]
M + a[:, np.newaxis]
# [___CELL_SEPARATOR___]
np.logaddexp(M, a[:, np.newaxis])
# [___CELL_SEPARATOR___]
a = np.arange(1,4)
b = np.arange(1,4)[:,np.newaxis]
a*b
# [___CELL_SEPARATOR___]
np.multiply.outer(a, a)
# [___CELL_SEPARATOR___]
X = np.random.random((10, 3))
# [___CELL_SEPARATOR___]
Xmean = X.mean(0)
Xmean
# [___CELL_SEPARATOR___]
X_centered = X - Xmean
# [___CELL_SEPARATOR___]
X_centered.mean(0)
# [___CELL_SEPARATOR___]
a = np.arange(6)
a.shape
# [___CELL_SEPARATOR___]
b = np.arange(6)[:,np.newaxis]
b.shape
# [___CELL_SEPARATOR___]
np.dot(a,b.transpose())
# [___CELL_SEPARATOR___]
# x and y have 50 steps from 0 to 5
x = np.linspace(0, 5, 50)
y = np.linspace(0, 5, 50)[:, np.newaxis]

z = np.sin(x) ** 10 + np.cos(10 + y * x) * np.cos(x)
# [___CELL_SEPARATOR___]
import matplotlib.pyplot as plt
%matplotlib inline
# [___CELL_SEPARATOR___]
plt.imshow(z, cmap='viridis')
plt.colorbar();
# [___CELL_SEPARATOR___]
import numpy as np
import csv

rainfall = []
with open('data/Seattle2014.csv') as f:
    rd = csv.reader(f)
    next(f)
    for row in rd:
        rainfall.append(float(row[3]))
rainfall = np.array(rainfall)
    
inches = rainfall / 254.0  # 1/10mm -> inches
inches.shape
# [___CELL_SEPARATOR___]
%matplotlib inline
import matplotlib.pyplot as plt
import seaborn; seaborn.set()  # set plot styles
# [___CELL_SEPARATOR___]
plt.hist(inches, 40);
# [___CELL_SEPARATOR___]
x = np.array([1, 2, 3, 4, 5])
# [___CELL_SEPARATOR___]
x < 3  # less than
# [___CELL_SEPARATOR___]
x > 3  # greater than
# [___CELL_SEPARATOR___]
x <= 3  # less than or equal
# [___CELL_SEPARATOR___]
x >= 3  # greater than or equal
# [___CELL_SEPARATOR___]
x != 3  # not equal
# [___CELL_SEPARATOR___]
x == 3  # equal
# [___CELL_SEPARATOR___]
(2 * x) == (x ** 2)
# [___CELL_SEPARATOR___]
rng = np.random.RandomState(0)
x = rng.randint(10, size=(3, 4))
x
# [___CELL_SEPARATOR___]
x < 6
# [___CELL_SEPARATOR___]
print(x)
# [___CELL_SEPARATOR___]
# how many values less than 6?
np.count_nonzero(x < 6)
# [___CELL_SEPARATOR___]
np.sum(x < 6)
# [___CELL_SEPARATOR___]
# how many values less than 6 in each row?
np.sum(x < 6, axis=1)
# [___CELL_SEPARATOR___]
# are there any values greater than 8?
np.any(x > 8)
# [___CELL_SEPARATOR___]
# are there any values less than zero?
np.any(x < 0)
# [___CELL_SEPARATOR___]
# are all values less than 10?
np.all(x < 10)
# [___CELL_SEPARATOR___]
# are all values equal to 6?
np.all(x == 6)
# [___CELL_SEPARATOR___]
# are all values in each row less than 8?
np.all(x < 8, axis=1)
# [___CELL_SEPARATOR___]
(inches > 0.5)
# [___CELL_SEPARATOR___]
np.sum((inches > 0.5) ^ (inches < 1))
# [___CELL_SEPARATOR___]
np.sum(~( (inches <= 0.5) | (inches >= 1) ))
# [___CELL_SEPARATOR___]
print("Number days without rain:      ", np.sum(inches == 0))
print("Number days with rain:         ", np.sum(inches != 0))
print("Days with more than 0.5 inches:", np.sum(inches > 0.5))
print("Rainy days with < 0.2 inches  :", np.sum((inches > 0) &
                                                (inches < 0.2)))
# [___CELL_SEPARATOR___]
x
# [___CELL_SEPARATOR___]
x <= 3
# [___CELL_SEPARATOR___]
x[x <= 3]
# [___CELL_SEPARATOR___]
x[x <= 3] = -1
# [___CELL_SEPARATOR___]
print(x)
# [___CELL_SEPARATOR___]
# construct a mask of all rainy days
rainy = (inches > 0)

# construct a mask of all summer days (June 21st is the 172nd day)
days = np.arange(365)
summer = (days > 172) & (days < 262)

print("Median precip on rainy days in 2014 (inches):   ",
      np.median(inches[rainy]))
print("Median precip on summer days in 2014 (inches):  ",
      np.median(inches[summer]))
print("Maximum precip on summer days in 2014 (inches): ",
      np.max(inches[summer]))
print("Median precip on non-summer rainy days (inches):",
      np.median(inches[rainy & ~summer]))
# [___CELL_SEPARATOR___]
x = np.random.randint(4,size=(3,2))
print(x)
y = np.random.randint(4,size=(3,2))
print(y)
# [___CELL_SEPARATOR___]
(x == 1) | (y == 1)
# [___CELL_SEPARATOR___]
bool(42), bool(0)
# [___CELL_SEPARATOR___]
bool(42 and 0)
# [___CELL_SEPARATOR___]
bool(42 or 0)
# [___CELL_SEPARATOR___]
bin(42)
# [___CELL_SEPARATOR___]
bin(59)
# [___CELL_SEPARATOR___]
bin(8 | 7)
# [___CELL_SEPARATOR___]
bin(42 | 59)
# [___CELL_SEPARATOR___]
A = np.array([1, 0, 1, 0, 1, 0], dtype=bool)
B = np.array([1, 1, 1, 0, 1, 1], dtype=bool)
A | B
# [___CELL_SEPARATOR___]
A or B
# [___CELL_SEPARATOR___]
x = np.arange(10)
(x > 4) & (x < 8)
# [___CELL_SEPARATOR___]
(x > 4) and (x < 8)
# [___CELL_SEPARATOR___]
rand = np.random.RandomState(42)

x = rand.randint(100, size=10)
print(x)
# [___CELL_SEPARATOR___]
[x[3], x[7], x[2]]
# [___CELL_SEPARATOR___]
x[2:8]
# [___CELL_SEPARATOR___]
ind = [3, 7, 4]
x[ind]
# [___CELL_SEPARATOR___]
ind = np.array([[3, 7],
                [4, 5]])
x[ind]
# [___CELL_SEPARATOR___]
X = np.arange(12).reshape((3, 4))
X
# [___CELL_SEPARATOR___]
row = np.array([0, 1, 2])
col = np.array([2, 1, 3])
X[row, col]
# [___CELL_SEPARATOR___]
X[row[:, np.newaxis], col]
# [___CELL_SEPARATOR___]
row[:, np.newaxis] * col
# [___CELL_SEPARATOR___]
print(X)
# [___CELL_SEPARATOR___]
X[2, [2, 0, 1]]
# [___CELL_SEPARATOR___]
X
# [___CELL_SEPARATOR___]
X[1:, [2, 0, 1]]
# [___CELL_SEPARATOR___]
mask = np.array([1, 0, 1, 0], dtype=bool)
X[row[:, np.newaxis], mask]
# [___CELL_SEPARATOR___]
mean = [0, 0]
cov = [[1, 2],
       [2, 5]]
X = np.random.multivariate_normal(mean, cov, 100)
X.shape
# [___CELL_SEPARATOR___]
%matplotlib inline
import matplotlib.pyplot as plt
import seaborn; seaborn.set()  # for plot styling

plt.scatter(X[:, 0], X[:, 1]);
# [___CELL_SEPARATOR___]
i = np.random.randint(100,size=[20,])
X[i,:]
# [___CELL_SEPARATOR___]
indices = np.random.choice(X.shape[0], 20, replace=False)
indices
# [___CELL_SEPARATOR___]
selection = X[indices]  # fancy indexing here
selection.shape
# [___CELL_SEPARATOR___]
plt.scatter(X[:, 0], X[:, 1], alpha=0.3)
plt.scatter(selection[:, 0], selection[:, 1],
            facecolor='red', alpha=0.4,s=200);
# [___CELL_SEPARATOR___]
x = np.arange(10)
i = np.array([2, 1, 8, 4])
x[i] = 99
print(x)
# [___CELL_SEPARATOR___]
x[i] -= 10
print(x)
# [___CELL_SEPARATOR___]
x = np.zeros(10)

print(x.shape)
# [___CELL_SEPARATOR___]
x = np.zeros(10)
x[[0, 0]] = [4, 6]
print(x)
# [___CELL_SEPARATOR___]
i = [2, 3, 3, 4, 4, 4]
x[i] += 1
x
# [___CELL_SEPARATOR___]
np.add.at(x,[3,4,5],10)
print(x)
# [___CELL_SEPARATOR___]
x = np.zeros(10)
np.add.at(x, i, 1)
print(x)
# [___CELL_SEPARATOR___]
x = np.array([4,5,3,4,5,2,3])
np.bincount(x)
# [___CELL_SEPARATOR___]
np.random.seed(42)
x = np.random.randn(100)

# compute a histogram by hand
bins = np.linspace(-5, 5, 20)
counts = np.zeros_like(bins)

# find the appropriate bin for each x
i = np.searchsorted(bins, x)

# add 1 to each of these bins
np.add.at(counts, i, 1)
# [___CELL_SEPARATOR___]
np.bincount(np.searchsorted(bins,x))
# [___CELL_SEPARATOR___]
np.histogram(x,20)
# [___CELL_SEPARATOR___]
# plot the results
plt.plot(bins, counts, linestyle='steps');
# [___CELL_SEPARATOR___]
print("NumPy routine:")
%timeit counts, edges = np.histogram(x, bins)

print("Custom routine:")
%timeit np.add.at(counts, np.searchsorted(bins, x), 1)
# [___CELL_SEPARATOR___]
x = np.random.randn(1000000)
print("NumPy routine:")
%timeit counts, edges = np.histogram(x, bins)

print("Custom routine:")
%timeit np.add.at(counts, np.searchsorted(bins, x), 1)