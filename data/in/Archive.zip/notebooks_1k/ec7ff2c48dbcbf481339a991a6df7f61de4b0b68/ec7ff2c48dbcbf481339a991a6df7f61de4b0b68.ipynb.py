# default_exp core
# [___CELL_SEPARATOR___]
#hide
from nbdev.showdoc import *
# [___CELL_SEPARATOR___]
#export
import tensorflow as tf
import numpy as np
from glob import glob
import os
import pathlib

from typing import Union
# [___CELL_SEPARATOR___]
#export
def remove_dsstore(path):
    """Deletes .DS_Store files from path and sub-folders of path.
    """
    path = pathlib.Path(path)

    for e in path.glob('*.DS_Store'):
        os.remove(e)

    for e in path.glob('*/*.DS_Store'):
        os.remove(e)
        

def get_basename(path: tf.string):
    assert isinstance(path, tf.Tensor)
    return tf.strings.split(path, os.path.sep)[-1]
# [___CELL_SEPARATOR___]
