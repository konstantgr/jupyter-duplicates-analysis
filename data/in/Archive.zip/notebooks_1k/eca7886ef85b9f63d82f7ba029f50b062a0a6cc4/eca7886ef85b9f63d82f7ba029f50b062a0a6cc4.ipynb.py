#coding:utf-8
import numpy as np
%matplotlib  inline
import cv2
import matplotlib.pyplot as plt
# [___CELL_SEPARATOR___]
src = cv2.cvtColor(cv2.imread('../datas/f2.jpg'),cv2.COLOR_BGR2RGB)
gray = cv2.imread('../datas/f2.jpg',0)
# [___CELL_SEPARATOR___]
def gray_level(gray,level):
    step_value = 256 / (1 << level)
    rows,cols = gray.shape
    dst = np.zeros_like(gray)
    for i in range(rows):
        for j in range(cols):
            step = step_value
            pixel = gray[i,j]
            while pixel > step:
                step += step_value
            dst[i,j] = step
    dst[dst > 255] = 255
    return dst
# [___CELL_SEPARATOR___]
dst = gray_level(gray,2)
# [___CELL_SEPARATOR___]
plt.imshow(dst,'gray')
plt.title('Gray Level = 2')