import numpy as np
import pandas as pd
import accpm
%load_ext autoreload
%autoreload 1
%aimport accpm
# [___CELL_SEPARATOR___]
def funcobj(x):
    return (x[0]-5)**2 + (x[1]-5)**2
    
def func0(x):
    return x[0] - 20

def func1(x):
    return -x[0]
    
def func2(x):
    return x[1] - 20
    
def func3(x):
    return -x[1]

def grad_funcobj(x):
    return np.array([2*(x[0] - 5), 2*(x[1] - 5)])

def grad_func0(x):
    return np.array([1, 0])

def grad_func1(x):
    return np.array([-1, 0])

def grad_func2(x):
    return np.array([0, 1])
    
def grad_func3(x):
    return np.array([0, -1])
# [___CELL_SEPARATOR___]
A = np.array([[1, 0],[-1,0],[0,1],[0,-1]])
b = np.array([20, 0, 20, 0])
accpm.accpm(A, b, funcobj, grad_funcobj, alpha=0.01, beta=0.7, 
            start=1, tol=10e-3, maxiter = 200, testing=1)
# [___CELL_SEPARATOR___]
A = np.array([[1, 0],[-1,0],[0,1],[0,-1]])
b = np.array([20, 0, 20, 0])
accpm.accpm(A, b, funcobj, grad_funcobj,
           (func0, func1, func2, func3), (grad_func0, grad_func1, grad_func2, grad_func3),
            alpha=0.01, beta=0.7, start=1, tol=10e-3, maxiter=200, testing=True)
# [___CELL_SEPARATOR___]
A = np.array([[1, 0],[-1,0],[0,1],[0,-1]])
b = np.array([5, 0, 5, 0])
accpm.accpm(A, b, funcobj, grad_funcobj,
           (func0, func1, func2, func3), (grad_func0, grad_func1, grad_func2, grad_func3),
            alpha=0.01, beta=0.7, start=1, tol=10e-3, maxiter=200, testing=True)
# [___CELL_SEPARATOR___]
A = np.array([[1, 0],[-1,0],[0,1],[0,-1]])
b = np.array([30, 0, 30, 0])
accpm.accpm(A, b, funcobj, grad_funcobj,
           (func0, func1, func2, func3), (grad_func0, grad_func1, grad_func2, grad_func3),
            alpha=0.01, beta=0.7, start=1, tol=10e-3, maxiter=200, testing=True)
# [___CELL_SEPARATOR___]
A = np.array([[1, 0],[-1,0],[0,1],[0,-1]])
b = np.array([100, 0, 100, 0])
accpm.accpm(A, b, funcobj, grad_funcobj,
           (func0, func1, func2, func3), (grad_func0, grad_func1, grad_func2, grad_func3),
            alpha=0.01, beta=0.7, start=1, tol=10e-3, maxiter=200, testing=True)
# [___CELL_SEPARATOR___]
A = np.array([[1, 0],[-1,0],[0,1],[0,-1]])
b = np.array([1000, 0, 1000, 0])
accpm.accpm(A, b, funcobj, grad_funcobj,
           (func0, func1, func2, func3), (grad_func0, grad_func1, grad_func2, grad_func3),
            alpha=0.01, beta=0.7, start=1, tol=10e-3, maxiter=200, testing=True)
# [___CELL_SEPARATOR___]
A = np.array([[1, 0],[-1,0],[0,1],[0,-1]])
b = np.array([1000, 0, 1000, 0])
accpm.accpm(A, b, funcobj, grad_funcobj,
           (func0, func1, func2, func3), (grad_func0, grad_func1, grad_func2, grad_func3),
            alpha=0.01, beta=0.7, start=1, tol=10e-3, maxiter=500, testing=True)