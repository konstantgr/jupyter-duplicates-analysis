# read the data and set the datetime as the index
import seaborn as sns
import matplotlib.pyplot as plt
%matplotlib inline
plt.rcParams['figure.figsize'] = (8, 6)
plt.rcParams['font.size'] = 14
import pandas as pd
urls = ['../data/KDCA-201601.csv', '../data/KDCA-201602.csv', '../data/KDCA-201603.csv']
frames = [pd.read_csv(url) for url in urls]
weather = pd.concat(frames)
cols = 'WBAN	Date	Time	StationType	SkyCondition	Visibility	WeatherType	DryBulbFarenheit	DryBulbCelsius	WetBulbFarenheit	WetBulbCelsius	DewPointFarenheit	DewPointCelsius	RelativeHumidity	WindSpeed	WindDirection	ValueForWindCharacter	StationPressure	PressureTendency	PressureChange	SeaLevelPressure	RecordType	HourlyPrecip	Altimeter'
cols = cols.split()
weather = weather[cols]
weather.rename(columns={'DryBulbFarenheit':'temp',
                       'RelativeHumidity': 'humidity'}, inplace=True)
# weather['humidity'] = pd.to_numeric(weather.humidity, errors='coerce')

weather['datetime'] = pd.to_datetime(weather.Date.astype(str) + weather.Time.apply('{0:0>4}'.format))
weather['datetime_hour'] = weather.datetime.dt.floor(freq='h')
weather['month'] = weather.datetime.dt.month

bikes = pd.read_csv('../data/2016-Q1-Trips-History-Data.csv')
bikes['start'] = pd.to_datetime(bikes['Start date'], infer_datetime_format=True)
bikes['end'] = pd.to_datetime(bikes['End date'], infer_datetime_format=True)
bikes['datetime_hour'] = bikes.start.dt.floor(freq='h')
weather[['datetime', 'temp']].hist(bins=30)
print(weather.columns)
weather.head()
# [___CELL_SEPARATOR___]
bikes.merge(weather[['temp', 'datetime_hour', 'datetime']], on='datetime_hour')
# [___CELL_SEPARATOR___]
hours = bikes.groupby('datetime_hour').agg('count')
hours['datetime_hour'] = hours.index
hours.head()
hours['total'] = hours.start
hours = hours[['total', 'datetime_hour']]
hours.total.plot()
hours_weather = hours.merge(weather, on='datetime_hour')
hours_weather.plot(kind='scatter', x='temp', y='total')
sns.lmplot(x='temp', y='total', data=hours_weather, aspect=1.5, scatter_kws={'alpha':0.8})
# [___CELL_SEPARATOR___]
weekday = hours_weather[(hours_weather.datetime.dt.hour==11) & (hours_weather.datetime.dt.dayofweek<5) ]
weekday.plot(kind='scatter', x='temp', y='total')
# [___CELL_SEPARATOR___]
# import seaborn as sns

sns.lmplot(x='temp', y='total', data=weekday, aspect=1.5, scatter_kws={'alpha':0.8})
# [___CELL_SEPARATOR___]
# create X and y
feature_cols = ['temp']
X = hours_weather[feature_cols]
y = hours_weather.total
# [___CELL_SEPARATOR___]
# import, instantiate, fit
from sklearn.linear_model import LinearRegression
linreg = LinearRegression()
linreg.fit(X, y)
# [___CELL_SEPARATOR___]
# print the coefficients
print(linreg.intercept_)
print(linreg.coef_)
# [___CELL_SEPARATOR___]
# manually calculate the prediction
linreg.intercept_ + linreg.coef_ * 77
# [___CELL_SEPARATOR___]
# use the predict method
linreg.predict(77)
# [___CELL_SEPARATOR___]
# create a new column for Fahrenheit temperature
hours_weather['temp_C'] = (hours_weather.temp - 32) * 5/9
hours_weather.head()
# [___CELL_SEPARATOR___]
# Seaborn scatter plot with regression line
sns.lmplot(x='temp_C', y='total', data=hours_weather, aspect=1.5, scatter_kws={'alpha':0.2})
sns.lmplot(x='temp', y='total', data=hours_weather, aspect=1.5, scatter_kws={'alpha':0.2})
# [___CELL_SEPARATOR___]
# create X and y
feature_cols = ['temp_C']
X = hours_weather[feature_cols]
y = hours_weather.total

# instantiate and fit
linreg = LinearRegression()
linreg.fit(X, y)

# print the coefficients
print(linreg.intercept_, linreg.coef_)
# [___CELL_SEPARATOR___]
# convert 77 degrees Fahrenheit to Celsius
(77 - 32)* 5/9
# [___CELL_SEPARATOR___]
# predict rentals for 25 degrees Celsius
linreg.predict([[25], [30]])
# [___CELL_SEPARATOR___]
# remove the temp_F column
# bikes.drop('temp_C', axis=1, inplace=True)
# [___CELL_SEPARATOR___]
# explore more features
feature_cols = ['temp', 'month', 'humidity']
# [___CELL_SEPARATOR___]
# multiple scatter plots in Seaborn
# print(hours_weather.humidity != 'M')
hours_weather.humidity = hours_weather.humidity.apply(lambda x: -1 if isinstance(x, str) else x)
# hours_weather.loc[hours_weather.humidity.dtype != int].humidity = 100
sns.pairplot(hours_weather, x_vars=feature_cols, y_vars='total', kind='reg')
# [___CELL_SEPARATOR___]
# multiple scatter plots in Pandas
fig, axs = plt.subplots(1, len(feature_cols), sharey=True)
for index, feature in enumerate(feature_cols):
    hours_weather.plot(kind='scatter', x=feature, y='total', ax=axs[index], figsize=(16, 3))
# [___CELL_SEPARATOR___]
# cross-tabulation of season and month
pd.crosstab(hours_weather.month, hours_weather.datetime.dt.dayofweek)
# [___CELL_SEPARATOR___]
# box plot of rentals, grouped by season
hours_weather.boxplot(column='total', by='month')
# [___CELL_SEPARATOR___]
# line plot of rentals
hours_weather.total.plot()
# [___CELL_SEPARATOR___]
# correlation matrix (ranges from 1 to -1)
hours_weather.corr()
# [___CELL_SEPARATOR___]
# visualize correlation matrix in Seaborn using a heatmap
sns.heatmap(hours_weather.corr())
# [___CELL_SEPARATOR___]
# create a list of features
feature_cols = ['temp', 'month', 'humidity']
# [___CELL_SEPARATOR___]
# create X and y
X = hours_weather[feature_cols]
y = hours_weather.total

# instantiate and fit
linreg = LinearRegression()
linreg.fit(X, y)

# print the coefficients
print(linreg.intercept_, linreg.coef_)
# [___CELL_SEPARATOR___]
# pair the feature names with the coefficients
list(zip(feature_cols, linreg.coef_))
# [___CELL_SEPARATOR___]
# example true and predicted response values
true = [10, 7, 5, 5]
pred = [8, 6, 5, 10]
# [___CELL_SEPARATOR___]
# calculate these metrics by hand!
from sklearn import metrics
import numpy as np
print('MAE:', metrics.mean_absolute_error(true, pred))
print('MSE:', metrics.mean_squared_error(true, pred))
print('RMSE:', np.sqrt(metrics.mean_squared_error(true, pred)))
# [___CELL_SEPARATOR___]
# same true values as above
true = [10, 7, 5, 5]

# new set of predicted values
pred = [10, 7, 5, 13]

# MAE is the same as before
print('MAE:', metrics.mean_absolute_error(true, pred))

# MSE and RMSE are larger than before
print('MSE:', metrics.mean_squared_error(true, pred))
print('RMSE:', np.sqrt(metrics.mean_squared_error(true, pred)))
rmse = np.sqrt(metrics.mean_squared_error(true, pred))
rmse/pred
# [___CELL_SEPARATOR___]
from sklearn.cross_validation import train_test_split
import sklearn.metrics as metrics
import numpy as np

# define a function that accepts a list of features and returns testing RMSE
def train_test_rmse(feature_cols, data):
    X = data[feature_cols]
    y = data.total
    X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=123)
    linreg = LinearRegression()
    linreg.fit(X_train, y_train)
    y_pred = linreg.predict(X_test)
    return np.sqrt(metrics.mean_squared_error(y_test, y_pred))
# [___CELL_SEPARATOR___]
# compare different sets of features
print(train_test_rmse(['temp', 'month', 'humidity'], hours_weather))
print(train_test_rmse(['temp', 'month'], hours_weather))
print(train_test_rmse(['temp', 'humidity'], hours_weather))
print(train_test_rmse(['temp'], hours_weather))
print(train_test_rmse(['temp'], weekday))
# [___CELL_SEPARATOR___]
# split X and y into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(weekday[['temp']], weekday.total, random_state=123)

# create a NumPy array with the same shape as y_test
y_null = np.zeros_like(y_test, dtype=float)

# fill the array with the mean value of y_test
y_null.fill(y_test.mean())
y_null
# [___CELL_SEPARATOR___]
# compute null RMSE
np.sqrt(metrics.mean_squared_error(y_test, y_null))
# [___CELL_SEPARATOR___]
# create dummy variables
season_dummies = pd.get_dummies(hours_weather.month, prefix='month')

# print 5 random rows
season_dummies.sample(n=5, random_state=1)
# [___CELL_SEPARATOR___]
# concatenate the original DataFrame and the dummy DataFrame (axis=0 means rows, axis=1 means columns)
hw_dum = pd.concat([hours_weather, season_dummies], axis=1)

# print 5 random rows
hw_dum.sample(n=5, random_state=1)
# [___CELL_SEPARATOR___]
# include dummy variables for season in the model
feature_cols = ['temp','month_1', 'month_2', 'month_3', 'humidity']
X = hw_dum[feature_cols]
y = hw_dum.total
linreg = LinearRegression()
linreg.fit(X, y)
list(zip(feature_cols, linreg.coef_))
# [___CELL_SEPARATOR___]
# compare original season variable with dummy variables
print(train_test_rmse(['temp', 'month', 'humidity'], hw_dum))
print(train_test_rmse(['temp', 'month_2', 'month', 'humidity'], hw_dum))
print(train_test_rmse(['temp', 'month_2', 'month_1', 'humidity'], hw_dum))
# [___CELL_SEPARATOR___]
# hour as a numeric feature
hw_dum['hour'] = hw_dum.datetime.dt.hour
# [___CELL_SEPARATOR___]
# hour as a categorical feature
hour_dummies = pd.get_dummies(hw_dum.hour, prefix='hour')
# hour_dummies.drop(hour_dummies.columns[0], axis=1, inplace=True)
hw_dum = pd.concat([hw_dum, hour_dummies], axis=1)
# [___CELL_SEPARATOR___]
# daytime as a categorical feature
hw_dum['daytime'] = ((hw_dum.hour > 6) & (hw_dum.hour < 21)).astype(int)
# [___CELL_SEPARATOR___]
print(train_test_rmse(['hour'], hw_dum),
    train_test_rmse(hw_dum.columns[hw_dum.columns.str.startswith('hour_')], hw_dum)
    ,train_test_rmse(['daytime'], hw_dum))