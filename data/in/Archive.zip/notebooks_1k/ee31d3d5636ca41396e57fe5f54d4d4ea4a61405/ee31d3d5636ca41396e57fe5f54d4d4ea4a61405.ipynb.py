import numpy as np

# 入力
x = np.array([2, 3, 1])

# 正解
t = np.array([20])
# [___CELL_SEPARATOR___]
# 1-2層間のパラメータ
w1 = np.array([[3, 1, 2], [-2, -3, -1]])
b1 = np.array([0, 0])

# 2-3層間のパラメータ
w2 = np.array([[3, 2]])
b2 = np.array([0])
# [___CELL_SEPARATOR___]
# 中間層の計算
u1 = w1.dot(x) + b1
h1 = 1. / (1 + np.exp(-u1))

# 出力の計算
u2 = w2.dot(h1) + b2
y = 1. / (1 + np.exp(-u2))

print(y)
# [___CELL_SEPARATOR___]
# dL / dy
g_Ly = -2 / 1 * (t - y)

# dy / du_2
g_yu2 = y * (1 - y)

# du_2 / dw_2
g_u2w2 = h1
# [___CELL_SEPARATOR___]
# dL / dw_2: 求めたい勾配
g_Lw2 = g_Ly * g_yu2 * g_u2w2

print(g_Lw2)
# [___CELL_SEPARATOR___]
g_u2h1 = w2
g_h1u1 = h1 * (1 - h1)
g_u1w1 = x

# 上から du1 / dw1 の直前までを一旦計算
g_Lu1 = g_Ly * g_yu2 * g_u2h1 * g_h1u1

# g_u1w1は (3,) というshapeなので，g_u1w1[None]として(1, 3)に変形
g_u1w1 = g_u1w1[None]

# dL / dw_1: 求めたい勾配
g_Lw1 = g_Lu1.T.dot(g_u1w1)

print(g_Lw1)