import pandas as pd
import scipy as sp
import daft

import matplotlib.pyplot as plt
import numpy as np

from abtools import ABtest, BernoulliModel

%matplotlib inline
# [___CELL_SEPARATOR___]
p = .05
size = 200000
delta_true = .025

a = sp.stats.bernoulli.rvs(p=p, size=size, random_state=8228)
b = sp.stats.bernoulli.rvs(p=p*(1+delta_true), size=size, random_state=8228)

print('A - Mean: %.4f, std: %.2f' % (a.mean(), a.std()))
print('B - Mean: %.4f, std: %.2f' % (b.mean(), b.std()))
print('B better A on %.4f = %.4f%%' % (b.mean()- a.mean(), (b.mean()/a.mean()-1)*100))
# [___CELL_SEPARATOR___]
test = ABtest([a, b], BernoulliModel, 5000)

test.test_all()
# [___CELL_SEPARATOR___]
test.probabilities_df
# [___CELL_SEPARATOR___]
test.plot()
# [___CELL_SEPARATOR___]
