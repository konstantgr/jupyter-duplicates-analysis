%matplotlib notebook

import numpy
import pandas
import datetime
import sys
import time
import matplotlib.pyplot as ma
import statsmodels.tsa.seasonal as st
import statsmodels.tsa.arima_model as arima
import statsmodels.tsa.stattools as tools
# [___CELL_SEPARATOR___]
try: 
    ts = pandas.read_csv('../../datasets/srv-1-ntt-1h.csv')
except:
    print("I am unable to connect to read .csv file", sep=',', header=1)

ts.index = pandas.to_datetime(ts['ts'])

# delete unnecessary columns
del ts['id']
del ts['ts']
del ts['min']
del ts['max']
del ts['sum']
del ts['cnt']

# print table info
ts.info()
# [___CELL_SEPARATOR___]
ts = ts['2018-06-16':'2018-07-15']
# [___CELL_SEPARATOR___]
def print_values_stats():
    print("Zero Values:\n",sum([(1 if x == 0 else 0) for x in ts.values]),"\n\nMissing Values:\n",ts.isnull().sum(),"\n\nFilled in Values:\n",ts.notnull().sum(), "\n")

idx = pandas.date_range(ts.index.min(), ts.index.max(), freq="1h")
ts = ts.reindex(idx, fill_value=None)
print("Before interpolation:\n")
print_values_stats()
ts = ts.replace(0, numpy.nan)
ts = ts.interpolate(limit_direction="both")
print("After interpolation:\n")
print_values_stats()
# [___CELL_SEPARATOR___]
# Idea: Plot figure now and do not wait on ma.show() at the end of the notebook
ma.ion()
ma.show()
fig1 = ma.figure(1)
ma.plot(ts, color="blue")
ma.draw()
try:
    ma.pause(0.001) # throws NotImplementedError, ignore it
except:
    pass
# [___CELL_SEPARATOR___]
dates = ts.index #  save dates for further use
ts = [x[0] for x in ts.values]
# [___CELL_SEPARATOR___]
train_data_length = 24*7
ts_train = ts[:train_data_length]
ts_test = ts[train_data_length+1:]
# [___CELL_SEPARATOR___]
def check_stationarity(ts, critic_value=0.05):
    try:
        result = tools.adfuller(ts)
        return result[0] < 0.0 and result[1] < critic_value
    except:
        # Program may raise an exception when there are NA values in TS 
        return False

integrate_param = 0
ts_copy = pandas.Series(ts_train, copy=True) # Create copy for stationarizing

while not check_stationarity(ts_copy) and integrate_param < 2:
    integrate_param += 1
    ts_copy = ts_copy - ts_copy.shift()
    ts_copy.dropna(inplace=True) # Remove initial NA values
    
print("Estimated integrated (I) parameter: ", integrate_param, "\n")
# [___CELL_SEPARATOR___]
def plot_bar(ts, horizontal_line=None):
    ma.bar(range(0, len(ts)), ts, width=0.5)
    ma.axhline(0)
    if horizontal_line != None:
        ma.axhline(horizontal_line, linestyle="-")
        ma.axhline(-horizontal_line, linestyle="-")

    ma.draw()
    try:
        ma.pause(0.001) # throws NotImplementedError, ignore it
    except:
        pass


NlagsACF = 200
NLagsPACF = 40
# ACF
ma.figure(2)
plot_bar(tools.acf(ts_train, nlags=NlagsACF), 1.96 / numpy.sqrt(len(ts)))
# PACF
ma.figure(3)
plot_bar(tools.pacf(ts_train, nlags=NLagsPACF), 1.96 / numpy.sqrt(len(ts)))
# [___CELL_SEPARATOR___]
ARIMA_order = (1,1,0)
M_train_data = sys.maxsize
N_values_to_forecast = 1
# [___CELL_SEPARATOR___]
predictions = []
confidence = []

print("Forecasting started...")
start_time = time.time()
ts_len = len(ts)

for i in range(train_data_length+1, ts_len, N_values_to_forecast):
    try:
        start = i-M_train_data if i-M_train_data >= 0 else 0
        arima_model = arima.ARIMA(ts[start:i], order=ARIMA_order).fit(disp=0)
        forecast = arima_model.forecast(steps=N_values_to_forecast)
        for j in range(0, N_values_to_forecast):
            predictions.append(forecast[0][j])
            confidence.append(forecast[2][j])
    except:
        print("Error during forecast: ", i, i+N_values_to_forecast)
        # Push back last successful predictions
        for j in range(0, N_values_to_forecast):
            predictions.append(predictions[-1] if len(predictions) > 0 else 0)
            confidence.append(confidence[-1] if len(confidence) > 0 else 0)

print("Forecasting finished")
print("Time elapsed: ", time.time() - start_time)
# [___CELL_SEPARATOR___]
values_sum = 0
for value in zip(ts_test, predictions):
    actual = value[0]
    predicted = value[1]
    values_sum += abs((actual - predicted) / actual)

values_sum *= 100/len(predictions)
print("MAPE: ", values_sum, "%\n")
# [___CELL_SEPARATOR___]
fig2 = ma.figure(4)
ma.plot(ts_test, color="blue")
ma.plot(predictions, color="red")
ts_len = len(ts)
date_offset_indices = ts_len // 6
num_date_ticks = ts_len // date_offset_indices + 1
ma.xticks(range(0, ts_len, date_offset_indices), [x.date().strftime('%Y-%m-%d') for x in dates[::date_offset_indices]])
ma.draw()