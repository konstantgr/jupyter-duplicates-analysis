addpath(genpath('~/code/neuropixel-utils'))
# [___CELL_SEPARATOR___]
setenv('NEUROPIXEL_MAP_FILE', which('neuropixPhase3A_kilosortChanMap.mat')); 
# [___CELL_SEPARATOR___]
setenv('NEUROPIXEL_DATAROOT', '~/data/neuropixel');
# [___CELL_SEPARATOR___]
subject = 'TestSubject';
dateStr = '2018-12-02';
rawBinFile = 'TestSubject_20181202_01.imec.ap.bin';
imecFile = Neuropixel.generatePath(subject, 'raw_datasets', dateStr, rawBinFile)
# [___CELL_SEPARATOR___]
imec = Neuropixel.ImecDataset(imecFile)
# [___CELL_SEPARATOR___]
imec.channelMap
# [___CELL_SEPARATOR___]
fprintf('Duration of recording %s is %g minutes\n', imec.fileStem, imec.nSamplesAP / imec.fsAP / 60)
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
NeuropixelExpt.DataLoad.setImecSyncBitNames(imec);

if ~isempty(p.Results.badChannels)
    imec.markBadChannels(p.Results.badChannels);
end

rmsBadChannels = imec.markBadChannelsByRMS('rmsRange', [3 100]);
debug('Marking %d channels bad based on rms\n', numel(rmsBadChannels));


% save the bad channels and sync bit names to the meta file
imec.writeModifiedAPMeta();

% CAR the file and flush the unused sync bits to the cleaned_datasets
% folder
cleanedPath = NeuropixelExpt.generatePath(subject, 'cleaned_datasets', dateStr, p.Results.cleanedBinFile);

debug('Writing CAR version at %s\n', cleanedPath);
extraMeta = struct();
extraMeta.run_clearUnusedSyncBits = true;
extraMeta.run_detectAndMarkStimArtifactWindows = true;
fnList = {@NeuropixelExpt.DataClean.clearUnusedSyncBits; @Neuropixel.DataProcessFn.commonAverageReference};
imec = imec.saveTranformedDataset(cleanedPath, ...
    'goodChannelsOnly', false, 'writeSyncSeparate', false, ...
    'transformAP', fnList, 'extraMeta', extraMeta);

% sym link into ks directory
ksPath = NeuropixelExpt.generatePath(subject, 'ks', dateStr, p.Results.cleanedBinFile);
debug('Sym-linking to %s\n', ksPath);
imec = imec.symLinkAPIntoDirectory(ksPath);

% and run KiloSort
debug('Running KiloSort\n');
Neuropixel.sortNpix2(imec);

info.rawPath = imecFile;
info.cleanedPath = cleanedPath;
info.ksPath = ksPath;

end