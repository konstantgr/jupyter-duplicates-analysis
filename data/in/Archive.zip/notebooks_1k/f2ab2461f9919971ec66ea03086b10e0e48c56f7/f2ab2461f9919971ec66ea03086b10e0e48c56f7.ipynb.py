import requests
from bs4 import BeautifulSoup 
import re
import pandas as pd
# [___CELL_SEPARATOR___]
base_url = 'http://www.datatau.com'
# [___CELL_SEPARATOR___]
#Let us use request to get the url
dataTau = requests.get(base_url)
# [___CELL_SEPARATOR___]
# Check if the page has been scraped - we should see Response 200
dataTau
# [___CELL_SEPARATOR___]
dataTau = open('dataTau.html', 'rb').read()
# [___CELL_SEPARATOR___]
# Let us see the text content of the page
dataTau
# [___CELL_SEPARATOR___]
# Start the beautifulsoup library and create a soup!
soup = BeautifulSoup(dataTau,'html.parser')
# [___CELL_SEPARATOR___]
# See the pretty form HTML - Not so pretty though!
print (soup.prettify())
# [___CELL_SEPARATOR___]
title_class = soup.select('td .title')
# [___CELL_SEPARATOR___]
len(title_class)
# [___CELL_SEPARATOR___]
title_class[0:2]
# [___CELL_SEPARATOR___]
title_class[-1]
# [___CELL_SEPARATOR___]
title_class = soup.select('td .title a')
# [___CELL_SEPARATOR___]
len(title_class)
# [___CELL_SEPARATOR___]
title_class[0]
# [___CELL_SEPARATOR___]
title_class[0].get_text()
# [___CELL_SEPARATOR___]
title_class[-1]
# [___CELL_SEPARATOR___]
title_class = soup.select('td .title > a:nth-of-type(1)')
# [___CELL_SEPARATOR___]
title_class[0].get_text()
# [___CELL_SEPARATOR___]
date_class = soup.select('.subtext')
# [___CELL_SEPARATOR___]
len(date_class)
# [___CELL_SEPARATOR___]
date_class[0]
# [___CELL_SEPARATOR___]
date_class[0].get_text()
# [___CELL_SEPARATOR___]
# Let us create an empty dataframe to store the data
df = pd.DataFrame(columns=['title','date'])
df.count()
# [___CELL_SEPARATOR___]
def get_data_from_tau(url):
    print(url)
    dataTau = requests.get(url)
    soup = BeautifulSoup(dataTau.content,'html.parser')
    title_class = soup.select('td .title > a:nth-of-type(1)')
    date_class = soup.select('.subtext')
    print(len(title_class),len(date_class))
    for i in range(len(title_class)-1):
        df.loc[df.shape[0]] = [title_class[i].get_text(),date_class[i].get_text()]
    print('updated df with data')
    return title_class[len(title_class) - 1]
# [___CELL_SEPARATOR___]
url = base_url
for i in range(0,6):
    more_url = get_data_from_tau(url)
    url = base_url+more_url['href']
# [___CELL_SEPARATOR___]
df.shape
# [___CELL_SEPARATOR___]
df.head()
# [___CELL_SEPARATOR___]
df.to_csv('data_tau.csv', encoding = "utf8", index = False)
# [___CELL_SEPARATOR___]
