import time
import argparse
import numpy as np

import torch
import torch.nn.functional as F
import torch.optim as optim

from pygcn.utils import load_data, accuracy
from pygcn.models import GCN

import numpy as np
import matplotlib.pyplot as plt
import plotly.express as px
import pandas as pd

import networkx as nx
import itertools

from sklearn.feature_extraction.text import TfidfVectorizer
import nltk
from nltk.stem import PorterStemmer 
from nltk.tokenize import word_tokenize 
from nltk.corpus import stopwords
from sklearn.svm import SVC
from sklearn.model_selection import train_test_split
from sklearn.decomposition import PCA
# [___CELL_SEPARATOR___]
# Training settings
CUDA = False
fastmode = False
seed = 2
lr = 0.01
weight_decay = 5e-4
hidden = 3
dropout = 0.5
epochs = 75

np.random.seed(seed)
torch.manual_seed(seed)
# [___CELL_SEPARATOR___]
df = pd.read_csv("CSIdata/all_events_s01e07.csv")
df = df.dropna()
df['Ep'] = "all_events_s01e07.csv"
df.head()
# [___CELL_SEPARATOR___]
list_ep = ['all_events_s01e08.csv', 'all_events_s01e19.csv','all_events_s01e20.csv', 'all_events_s02e01.csv','all_events_s02e04.csv',]

# [___CELL_SEPARATOR___]
max_conv = max(df['conv'])

for ep in list_ep:
    df2 = pd.read_csv("CSIdata/%s"%ep)
    df2 = df2.dropna()
    df2['Ep'] = ep
    df2['conv'] = df2['conv'] + max_conv
    df = pd.concat([df, df2])
    max_conv = max(df2['conv'])
# [___CELL_SEPARATOR___]
df
# [___CELL_SEPARATOR___]
core_csi = ["grissom", "sara", "brass", "det._o'riley", "nick", "warrick"]

label_dict = {}

k = 1
for ep in np.unique(df['Ep']):
    for sp in np.unique(df[df["Ep"] == ep]["speaker"]):
        if sp in core_csi:
            label_dict[sp] = 0
        else:
            label_dict[sp] = k
    k += 1
# [___CELL_SEPARATOR___]
label_dict
# [___CELL_SEPARATOR___]
G = nx.Graph()

list_spks = []

for conv in np.unique(df["conv"]):
    sub_df = df[df["conv"] == conv]
    list_spk = np.unique(sub_df['speaker'])
    for elem in list(itertools.combinations(list_spk, 2)):
        list_spks.append(elem[0])
        list_spks.append(elem[1])
        G.add_node(elem[0])
        G.nodes()[elem[0]]['name'] = elem[0]
        G.add_node(elem[1])
        G.nodes()[elem[1]]['name'] = elem[1]
        G.add_edge(elem[0],elem[1])
        try:
            G[elem[0]][elem[1]]['weight'] += 1
        except KeyError:
            G[elem[0]][elem[1]]['weight'] = 1
list_spks = list(set(list_spks))
# [___CELL_SEPARATOR___]
df = df[df['speaker'].isin(list_spks)]
# [___CELL_SEPARATOR___]
stop_words = set(stopwords.words('english'))

def fil_sent(sent):
    filtered_sentence = ' '.join([w for w in sent.split() if not w in stop_words])
    return filtered_sentence

ps = PorterStemmer() 
   
def process(sent):
    return fil_sent(' '.join([ps.stem(x) for x in word_tokenize(sent)]))
# [___CELL_SEPARATOR___]
all_info = []

for conv in np.unique(df['conv']):
    sub_df = df[df['conv'] == conv]
    for spk in np.unique(sub_df['speaker']):
        sub_sub_df = sub_df[sub_df['speaker'] == spk]
        words = " ".join(sub_sub_df['word'])
        all_info.append([int(conv), spk, words])
# [___CELL_SEPARATOR___]
feat = pd.DataFrame(all_info)
feat.columns = ["Conv", "Person", "Sent"]
feat['Sent'] = feat['Sent'].apply(lambda x: process(x))
feat
# [___CELL_SEPARATOR___]
dict_w = {}
k = 0
for w in feat['Sent']:
    for word in w.split():
        dict_w[word] = k
        k += 1
# [___CELL_SEPARATOR___]
len(dict_w)
# [___CELL_SEPARATOR___]
df_feat = feat.groupby("Person")["Person", "Sent"].transform(lambda x: ' '.join(x)).drop_duplicates()
df_feat['Person'] = df_feat['Person'].apply(lambda x: x.split()[0])
df_feat = df_feat.reset_index().drop(['index'], axis=1)
df_feat.head()
# [___CELL_SEPARATOR___]
k = 0
dict_spk = {}

for val in df_feat['Person']:
    dict_spk[val] = k
    k += 1
# [___CELL_SEPARATOR___]
k = 0
spk_dict = {}

for val in df_feat['Person']:
    spk_dict[k] = val
    k += 1
# [___CELL_SEPARATOR___]
vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform(df_feat['Sent'])
X
# [___CELL_SEPARATOR___]
def return_feat(sent):
    sent = sent.split()
    f = np.zeros(len(dict_w))
    list_words_idx = [dict_w[k] for k in sent]
    for w in list_words_idx:
        f[w] += 1
    return f
# [___CELL_SEPARATOR___]
features = torch.Tensor(X.todense())
#torch.Tensor(list(df_feat['Sent'].apply(lambda x: return_feat(x))))
# [___CELL_SEPARATOR___]
features.shape
# [___CELL_SEPARATOR___]
def return_label(x):
    return label_dict[x]

    #if x in label_1: #["grissom", "sara", "brass", "det._o'riley", "nick", "warrick", "csi_tech", "detective", "disco_placid", 'dr._albertrobbins', 'dr._leever', 'dr._phillipkane', 'eddiewillows', 'fbi_man', 'hankpeddigrew_(emergency_service_man)', 'officer', 'officer_arvington', 'officer_metcalf', 'sheriff_brianmobley']:
        #return 1
    #else:
        #return 0
# [___CELL_SEPARATOR___]
labels = torch.LongTensor(df_feat['Person'].apply(lambda x: return_label(x)).values)
# [___CELL_SEPARATOR___]
labels.shape
# [___CELL_SEPARATOR___]
labels
# [___CELL_SEPARATOR___]
links = []
weights = []

for val in range(len(nx.adj_matrix(G).todense())):
    node_w = []
    node_l = []
    k = 0
    for x in np.array(nx.adj_matrix(G).todense()[val])[0]:
        if x > 0:
            node_w.append(x)
            node_l.append(k)
        k += 1
    links.append([list(node_l)]) 
    weights.append(list(node_w/sum(node_w)))
# [___CELL_SEPARATOR___]
list_tensors = []

for j in range(len(links)):
    i = torch.LongTensor(links[j])
    v = torch.FloatTensor(weights[j])
    list_tensors.append(torch.sparse.FloatTensor(i, v, torch.Size([len(df_feat),])))
# [___CELL_SEPARATOR___]
adj = torch.stack(list_tensors)
adj
# [___CELL_SEPARATOR___]
df_train, df_test = train_test_split(df_feat)
# [___CELL_SEPARATOR___]
df_val, df_test2 = train_test_split(df_test, test_size=0.5)
# [___CELL_SEPARATOR___]
idx_train = torch.LongTensor(list(df_train.index))
idx_train
# [___CELL_SEPARATOR___]
idx_test = torch.LongTensor(list(df_test2.index))
idx_test
# [___CELL_SEPARATOR___]
idx_val = torch.LongTensor(list(df_val.index))
idx_val
# [___CELL_SEPARATOR___]
# Model and optimizer
model = GCN(nfeat=features.shape[1],
            nhid=hidden,
            nclass=labels.max().item() + 1,
            dropout=dropout)

optimizer = optim.Adam(model.parameters(),
                       lr=lr, weight_decay=weight_decay)
# [___CELL_SEPARATOR___]
def train(epoch):
    
    t = time.time()
    model.train()
    optimizer.zero_grad()
    output = model(features, adj)
    loss_train = F.nll_loss(output[idx_train], labels[idx_train])
    acc_train = accuracy(output[idx_train], labels[idx_train])
    loss_train.backward()
    optimizer.step()

    if not fastmode:
        model.eval()
        output = model(features, adj)
    
    loss_val = F.nll_loss(output[idx_val], labels[idx_val])
    acc_val = accuracy(output[idx_val], labels[idx_val])
    print('Epoch: {:04d}'.format(epoch+1),
          'loss_train: {:.4f}'.format(loss_train.item()),
          'acc_train: {:.4f}'.format(acc_train.item()),
          'loss_val: {:.4f}'.format(loss_val.item()),
          'acc_val: {:.4f}'.format(acc_val.item()),
          'time: {:.4f}s'.format(time.time() - t))
    return model.gc1.ret_emb(), output.detach().numpy(), acc_train, acc_val
# [___CELL_SEPARATOR___]
def test():
    model.eval()
    output = model(features, adj)
    loss_test = F.nll_loss(output[idx_test], labels[idx_test])
    acc_test = accuracy(output[idx_test], labels[idx_test])
    print("Test set results:",
          "loss= {:.4f}".format(loss_test.item()),
          "accuracy= {:.4f}".format(acc_test.item()))
# [___CELL_SEPARATOR___]
# Train model
t_total = time.time()
list_emb = []
label = []
acc_train = []
acc_val = []

for epoch in range(epochs):
    list_emb.append(train(epoch)[0])
    label.append(train(epoch)[1])
    acc_train.append(train(epoch)[2])
    acc_val.append(train(epoch)[3])
    
print("Optimization Finished!")
print("Total time elapsed: {:.4f}s".format(time.time() - t_total))
# [___CELL_SEPARATOR___]
test()
# [___CELL_SEPARATOR___]
np.array(list_emb).shape
# [___CELL_SEPARATOR___]
plt.figure(figsize=(12,8))
plt.plot(acc_train, label="Train")
plt.plot(acc_val, label="Validation")
plt.legend()
plt.show()
# [___CELL_SEPARATOR___]
labels = []

for k in range(len(label)):
    labels.append(np.argmax(np.array(label)[k], axis=1))
# [___CELL_SEPARATOR___]
labels
# [___CELL_SEPARATOR___]
list_emb
# [___CELL_SEPARATOR___]
mat = np.matrix(list_emb[0])
for k in range(1, epoch):
    mat = np.concatenate([mat, np.matrix(list_emb[k])])
# [___CELL_SEPARATOR___]
pca = PCA(n_components=3)
mat_pc = pca.fit_transform(mat)
# [___CELL_SEPARATOR___]
mat_pc
# [___CELL_SEPARATOR___]
mat.shape
# [___CELL_SEPARATOR___]
mat_pc.shape
# [___CELL_SEPARATOR___]
len(list(list_emb))
# [___CELL_SEPARATOR___]
if hidden == 3 :
    df_list = []
    k = 0 

    df_list.append([0, "Nobody", 0, 0, 0, "0"])
    df_list.append([0, "Nobody", 0, 0, 0, "1"])
    df_list.append([0, "Nobody", 0, 0, 0, "2"])
    df_list.append([0, "Nobody", 0, 0, 0, "3"])
    df_list.append([0, "Nobody", 0, 0, 0, "4"])
    df_list.append([0, "Nobody", 0, 0, 0, "5"])
    df_list.append([0, "Nobody", 0, 0, 0, "6"])

    for i in range(epochs):
        for k in range(len(list_emb[i])):
            df_list.append([i, spk_dict[k], list_emb[i][k][0], list_emb[i][k][1], list_emb[i][k][2], str(labels[i][k])])

else:
    df_list = []
    k = 0 

    df_list.append([0, "Nobody", 0, 0, 0, "0"])
    df_list.append([0, "Nobody", 0, 0, 0, "1"])
    df_list.append([0, "Nobody", 0, 0, 0, "2"])
    df_list.append([0, "Nobody", 0, 0, 0, "3"])
    df_list.append([0, "Nobody", 0, 0, 0, "4"])
    df_list.append([0, "Nobody", 0, 0, 0, "5"])
    df_list.append([0, "Nobody", 0, 0, 0, "6"])

    for i in range(epochs):
        for k in range(len(list_emb[i])):
            df_list.append([i, spk_dict[k], mat_pc[i*k + i][0], mat_pc[i*k + i][1], mat_pc[i*k + i][2], str(labels[i][k])])
# [___CELL_SEPARATOR___]
df = pd.DataFrame(df_list)
df.columns = ["Epoch", "Character", "X", "Y", "Z", "Label"]
df['Size'] = 1
df.head()
# [___CELL_SEPARATOR___]
df['Label'].value_counts()
# [___CELL_SEPARATOR___]
max(df['X']), min(df['X'])
# [___CELL_SEPARATOR___]
max(df['Y']), min(df['Y'])
# [___CELL_SEPARATOR___]
max(df['Z']), min(df['Z'])
# [___CELL_SEPARATOR___]
df.shape
# [___CELL_SEPARATOR___]
fig = px.scatter_3d(df, x="X", y="Y", z="Z", hover_data = ["Character"], animation_frame="Epoch", color="Label", size_max=3) #size="Size", size_max=1,
fig.update_layout(title="Embedding evolution over epochs")
fig.show()
# [___CELL_SEPARATOR___]
