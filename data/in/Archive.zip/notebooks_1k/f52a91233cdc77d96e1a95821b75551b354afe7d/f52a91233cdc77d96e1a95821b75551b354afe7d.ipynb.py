#classical inputs
import sys, os, pathlib

import matplotlib.pyplot as plt
from sklearn import preprocessing, decomposition
from scipy import sparse, stats, spatial
import scipy.sparse.linalg
import seaborn as sns
import matplotlib
from sklearn.cluster import KMeans
from sklearn.metrics import f1_score
import numpy as np
import networkx as nx


#setting the path to folder with modules
sys.path.insert(0, str(pathlib.Path(os.getcwd()).parents[0] / 'python'))

#custom functions
from GetWeights import *
from Load_Datasets import *
from ProcessCategorical import *
from DropZeroLinesAndGetDistanes import *
from PlotMatrix import *
from BubbleReorderMatrix import *
from matchLabel import *

#Loading information about movies (transforming JSON files into pandas frame)
FileAddress_movies ="../Datasets/tmdb_5000_movies.csv"
FileAddress_credits="../Datasets/tmdb_5000_credits.csv"
# [___CELL_SEPARATOR___]
#Loading information about movies
Movies = Load_Datasets(FileAddress_movies,FileAddress_credits)

Drops = ['homepage','status','id']
for drop in Drops:
    Movies = Movies.drop(drop, 1)

#pandas entries contain string arrays from which can be easily converted to lists using string.split(",")
#new datafile is generated
Movies.to_csv("../Datasets/Transformed.csv")
# [___CELL_SEPARATOR___]
list(Movies)
# [___CELL_SEPARATOR___]
#Example 
print("Avatar 1st crew member is "+Movies['crew_names']['Avatar'].split(",")[0]
      +", he works at departement "+Movies['crew_departments']['Avatar'].split(",")[0]
      +", and his job is "+Movies['crew_jobs']['Avatar'].split(",")[0])
# [___CELL_SEPARATOR___]
len(Movies)
# [___CELL_SEPARATOR___]
Movies.head(1)
# [___CELL_SEPARATOR___]
% matplotlib inline
fontsizes = 15
matplotlib.rcParams.update({'font.size': fontsizes})
fig, axes = plt.subplots(figsize=(15, 5))

# Budget is plotted in log scale on y axis
axes.set(yscale="symlog")

# Here we will set appropriate range of values x-axis and binsize so that ticks on x-coordinate correspond to 
# the end of every second bin
# for every other data i.e. reveunue, average vote, etc. the values of bin_size will be specific
# hence this procedure will be conducted for each column of interest

bin_size = 0.1*1e8
bins_hist = np.arange(min(Movies["budget"]), max(Movies["budget"]), bin_size)
g = sns.distplot(Movies['budget'], bins = bins_hist, kde=False, rug=False)
plt.xlim(0*1e8,3.4*1e8)
ticks = np.arange(0*1e8,3.4*1e8,0.2*1e8)
axes.set_xticks(ticks)
g.set(title='Histogram by the movies budget')
g.xaxis.set_major_formatter(matplotlib.ticker.ScalarFormatter(useMathText=True, useOffset=False))
plt.show()
# [___CELL_SEPARATOR___]
fig, axes = plt.subplots(figsize=(15, 5))
# Revenue is plotted in log scale on y axis
axes.set( yscale="symlog")

# Here we will set appropriate range of values on x-axis and binsize so that ticks on x-coordinate correspond to
# the end of every second bin

bin_size = 0.05*1e9
bins_hist = np.arange(min(Movies["revenue"]), max(Movies["revenue"]), bin_size)
g = sns.distplot(Movies['revenue'], bins = bins_hist, kde=False, rug=False)
plt.xlim(0,1.9*1e9)
g.set(title='Histogram by the movies revenue')
ticks = np.arange(0*1e9,2*1e9,0.1*1e9)
axes.set_xticks(ticks)
g.xaxis.set_major_formatter(matplotlib.ticker.ScalarFormatter(useMathText=True, useOffset=False))
plt.show()
# [___CELL_SEPARATOR___]
fig, axes = plt.subplots(figsize=(15, 5))

# Here we will set appropriate range of values on x-axis and binsize so that ticks on x-coordinate correspond to
# the end of every second bin

bin_size = 0.2
bins_hist = np.arange(min(Movies["vote_average"]), max(Movies["vote_average"]), bin_size)
g = sns.distplot(Movies['vote_average'], bins = bins_hist, kde=False, rug=False)
plt.xlim(0,10)
ticks = np.arange(0,10,0.4)
axes.set_xticks(ticks)
g.set(title='Histogram by average vote', xlabel = "average vote")
plt.show()
# [___CELL_SEPARATOR___]
fig, axes = plt.subplots(figsize=(15, 5))

# Here we will set appropriate range of values on x-axis and binsize so that ticks on x-coordinate correspond to
# the end of every fourth bin

bin_size = 100
bins_hist = np.arange(min(Movies["vote_count"]), max(Movies["vote_count"]), bin_size)
g = sns.distplot(Movies['vote_count'], bins = bins_hist, kde=False, rug=False)
plt.xlim(0,5000)
ticks = np.arange(0,5000, 400)
axes.set_xticks(ticks)
g.set(title='Histogram by vote count', xlabel = "vote count")
plt.show()
# [___CELL_SEPARATOR___]
fig, axes = plt.subplots(figsize=(15, 5))

# Here we will set appropriate range of values on x-axis and binsize so that ticks on x-coordinate correspond to
# the end of every second bin

bin_size = 5
bins_hist = np.arange(min(Movies["popularity"]), max(Movies["popularity"]), bin_size)
g = sns.distplot(Movies['popularity'], bins = bins_hist, kde=False, rug=False )
plt.xlim(0,180)
ticks = np.arange(0,180,10)
axes.set_xticks(ticks)
g.set(title='Histogram of movies popularity')
plt.show()
# [___CELL_SEPARATOR___]
num_of_elements = lambda x: len(x.split(","))
num_of_actors = Movies["actors_id"].apply(num_of_elements)

fig, axes = plt.subplots(figsize=(15, 5))

# Here we will set appropriate range of values on x-axis and binsize so that ticks on x-coordinate correspond to
# the end of every second bin

bin_size = 2
bins_hist = np.arange(min(num_of_actors), max(num_of_actors), bin_size)
g = sns.distplot(num_of_actors, bins=bins_hist, kde=False, rug=False )
plt.xlim(0,120)
ticks = np.arange(0,120,10)
axes.set_xticks(ticks)
g.set(title='Histogram of number of actors in movie', xlabel = "number of actors")
plt.show()
# [___CELL_SEPARATOR___]
num_of_crew = Movies["crew_names_id"].apply(num_of_elements)

fig, axes = plt.subplots(figsize=(15, 5))

# Here we will set appropriate range of values on x-axis and binsize so that ticks on x-coordinate correspond to
# the end of every fifth bin

bin_size = 2
bins_hist = np.arange(min(num_of_actors), max(num_of_actors), bin_size)
g = sns.distplot(num_of_crew, bins = bins_hist, kde=False, rug=False )
plt.xlim(0,160)
ticks = np.arange(0,160,10)
axes.set_xticks(ticks)
g.set(title='Histogram of number of crew members in movie', xlabel = "number of crew members")
plt.show()
# [___CELL_SEPARATOR___]
def most_freq_items_with_id(how_much, col, col_id):
    # how_much: how_much top frequent items fo we search for, type:int
    # col: name of the column in Movies dataframe which has also corresponding id column i.e. "production_companies", type:string
    # col_id: name of the column in Movies dataframe with ids
    
    # Due to the fact that the id's as integers are more reliable data than the string type of data
    # we will find most frequent item's ids, and then look for the items name given in the column Movies[col]
    # of course we assume that we have obtained correct match between (items name, items id)

    # Here we will find the number of occurency of each items_id in database,
    # and store it in dictionary items_id_dict in pairs (items_id(type:int):items_name(type:string))
    # we will store in dictionary freq_items_ids in pairs (items_id(type:int):number_of_occurency(type:int))

    items_id_dict = {}
    freq_items_ids = {}
    
    for i in range(len(Movies)):
        for j in range(len(Movies.iloc[i][col_id].split(","))):
            if (len(Movies.iloc[i][col_id].split(",")[j])>0):
                items_id_int_key = int(Movies.iloc[i][col_id].split(",")[j])
                freq_items_ids[items_id_int_key] = freq_items_ids.get(items_id_int_key, 0) + 1
                items_id_dict[items_id_int_key] = Movies.iloc[i][col].split(",")[j]
    
    # Here we will find most how_much frequent items names
    # We will "sort" the dictionary of occurency by values, retrieve the ids of most frequent ones
    # and find corresponding names and store in most_freq_items
 
    how_much_items = how_much; 
    most_freq_ids = sorted(freq_items_ids, key=freq_items_ids.get)[-how_much_items:] #list
    most_freq_items = [items_id_dict[key]  for key in most_freq_ids]

    fig, ax = plt.subplots(figsize=(15,5))

    # in freq_items_plot is stored number_of-occurency in dataset of most frequent items
    freq_items_plot = [freq_items_ids[most_freq_ids[how_much_items-i-1]] for i in range(how_much_items)]
    plt.bar(range(how_much_items), freq_items_plot)
    string_title = col.replace("_"," ")
    plt.title("Most {} frequent ".format(how_much_items)+string_title)
    plt.xticks(range(how_much_items),(most_freq_items[::-1]), rotation=45, rotation_mode="anchor", ha="right")
    for i in ax.patches:
        ax.text(i.get_x()+.1, i.get_height(),str(round((i.get_height()))), fontsize=15, color='black')
    plt.show()
# [___CELL_SEPARATOR___]
how_much_production = 15
column = "production_companies"
column_id = "production_companies_id"
most_freq_items_with_id(how_much_production, column, column_id)
# [___CELL_SEPARATOR___]
how_much_actors = 15
column = "actors"
column_id = "actors_id"
most_freq_items_with_id(how_much_production, column, column_id)
# [___CELL_SEPARATOR___]
def most_freq_items(how_much, col):
    # how_much: how_much top frequent items fo we search for, type:int
    # col: name of the column in Movies dataframe i.e. "keywords", type:string
    # string_title: string for title "Most how_much frequent"+string_title i.e. string_title="keywords", type:string
    
    # This function will be used to find most frequent keywords, crew_names and genres
    # Here we will find the number of occurency of each keyword in database,
    # and store it in dictionary items_dict in pairs (item(type:str):number_of_occurency(type:int))
    items_dict = {}

    for i in range(len(Movies)):
        if(len(Movies.iloc[i][col])>0):
            for j in range(len(Movies.iloc[i][col].split(","))):
                if (len(Movies.iloc[i][col].split(","))>0):
                    item = Movies.iloc[i][col].split(",")[j]
                    items_dict[item] = items_dict.get(item, 0) + 1
    # Here we will find most how_much_items frequent keywords
    # We will "sort" the dictionary by values, retrieve the ids, and find the most frequent items from original dictionary
    
    how_much_items = how_much
    most_freq_items = sorted(items_dict, key=items_dict.get)[-how_much_items:]
    
    fig, ax = plt.subplots(figsize=(15,5))
    
    freq_items_plot = [items_dict[most_freq_items[len(most_freq_items)-1-i]] for i in range(how_much_items)]
    plt.bar(range(how_much_items), freq_items_plot)
    string_title = col.replace("_"," ")
    plt.title("Most {} frequent ".format(how_much_items) + string_title)
    if string_title == "main genres":
        plt.title("Histogram of main genres")
    plt.xticks(range(how_much_items),(most_freq_items[::-1]), fontsize=15, rotation=45, rotation_mode="anchor", ha="right")
    for i in ax.patches:
        ax.text(i.get_x()+.1, i.get_height(),str(round((i.get_height()))), fontsize=15, color='black')
    plt.show()
# [___CELL_SEPARATOR___]
how_much_keywords = 15
column = "keywords"

most_freq_items(how_much_keywords, column)
# [___CELL_SEPARATOR___]
how_much_crew = 15
column = "crew_names"

most_freq_items(how_much_crew, column)
# [___CELL_SEPARATOR___]
how_much_genre = 15
column = "genres"

most_freq_items(how_much_genre, column)
# [___CELL_SEPARATOR___]
how_much_genre = 15
column = "primary_genre"
most_freq_items(how_much_genre, column)
# [___CELL_SEPARATOR___]
genres_list = ["Drama","Action","Comedy","Adventure"]
genre_main = lambda x: x if (x in genres_list) else "Others"
main_genre = Movies["primary_genre"].apply(genre_main)
Movies["main_genres"] = main_genre
# [___CELL_SEPARATOR___]
def get_genre(genre_list):
    genre_list = genre_list.split(",")
    for genre in genre_list:
        if genre =="Drama":
            return "Drama"
        if genre == "Action":
            return "Action"
        if genre == "Comedy":
            return "Comedy"
        #if genre == "Thriller":
        #    return "Thriller"
    return "Other"

list_genres = Movies["genres"].apply(get_genre)
print(len(list_genres))
Movies["main_genres"] = list_genres
# [___CELL_SEPARATOR___]
Movies["main_genres"].value_counts()
# [___CELL_SEPARATOR___]
import matplotlib.pyplot as plt
how_much_genre = 4
column = "main_genres"
most_freq_items(how_much_genre, column)
# [___CELL_SEPARATOR___]
sns.pairplot(Movies[["budget","popularity","revenue","runtime","vote_average","vote_count"]].dropna())
plt.show()
# [___CELL_SEPARATOR___]
sns.heatmap(Movies.corr(), annot=True, fmt=".2f")
plt.show()
# [___CELL_SEPARATOR___]
# How many movies have tagline
len(Movies["tagline"].dropna())
# [___CELL_SEPARATOR___]
how_much_production = 30
column = "production_companies"
column_id = "production_companies_id"
most_freq_items_with_id(how_much_production, column, column_id)
# [___CELL_SEPARATOR___]
how_much_lang = 30
column = "original_language"
most_freq_items(how_much_lang, column)
# [___CELL_SEPARATOR___]
Drops = ['release_date','runtime','budget','popularity', "original_language", "tagline", 'spoken_languages']
for drop in Drops:
    Movies = Movies.drop(drop, 1)
# [___CELL_SEPARATOR___]
#simplistic example
#DropLines=[]
Remains= (Movies.drop(DropLines))
Cat_remains = pd.DataFrame()
Cat_remains['Is_drama']   = Remains["main_genres"].apply(lambda x: 1 if x=='Drama'  else 0)
Cat_remains['Is_Comedy']  = Remains["main_genres"].apply(lambda x: 1 if x=='Comedy' else 0)
Cat_remains['Is_Action']  = Remains["main_genres"].apply(lambda x: 1 if x=='Action' else 0)
Cat_remains['Is_Other']   = Remains["main_genres"].apply(lambda x: 1 if x=='Other'  else 0)

#calculation of distances betseen movies in the genre spece using cosine metric, lines which contain only zeroes
#are removed from the dataset since zero vectors are not valid input for cosine distance calculation
Simple_distances, DL, NF = DropZeroLinesAndGetDistanes([Cat_remains,Cat_remains,Cat_remains])

PlotMatrix(Simple_distances[0])
#calculation the weight matrix from distances using gaussian kernel
SimpleW =  GetWeights(Simple_distances[0],5000-967)
simpleWEIGHTS = SimpleW
np.savez_compressed("../Datasets/simpleWEIGHTS.npz", simpleWEIGHTS, simpleWEIGHTS=simpleWEIGHTS)

# [___CELL_SEPARATOR___]
Simple_genres = preprocessing.LabelEncoder().fit_transform((Movies.drop(DropLines)['main_genres']))
print(Simple_distances[0][0][-1])
print(simpleWEIGHTS[0][-1])
print(Simple_genres[0])
print(Simple_genres[-1])
# [___CELL_SEPARATOR___]
#getting genres encoding
genres = preprocessing.LabelEncoder().fit_transform((Movies.drop(DropLines)['main_genres']))
#saving the matrix
np.savez_compressed("../Datasets/Simple_genres.npz", genres, genres=genres)
Sorted_simpleWEIGHTS = BubbleReorderMatrix(SimpleW,genres)  
plt.spy(Sorted_simpleWEIGHTS, markersize=0.005)
# [___CELL_SEPARATOR___]
simpleWEIGHTS = SimpleW

weights_sparse = simpleWEIGHTS

#laplacian preparation
degrees = np.count_nonzero(weights_sparse, axis=0)
D = np.diag(degrees)
laplacian_comb = D - weights_sparse

#calculation of eigenvalues and eigenvectors
how_much_genre = 4
eigenvalues, eigenvectors = scipy.sparse.linalg.eigsh(laplacian_comb, how_much_genre, which='SM')

#applying the kmeans algorithm
kmeans = KMeans(n_clusters=how_much_genre).fit(eigenvectors)
simple_l =kmeans.labels_
(Movies.drop(DropLines)).iloc[simple_l==3]
plt.hist(simple_l)
#generating the score estimate
genres = preprocessing.LabelEncoder().fit_transform((Movies.drop(DropLines)['main_genres']))
print("Score is ",f1_score(genres, matchLabel(simple_l,genres),average='micro'))
#Calculate metrics globally by counting the total true positives, false negatives and false positives.

# [___CELL_SEPARATOR___]
#visualization of movies
genres = preprocessing.LabelEncoder().fit_transform((Movies.drop(DropLines)['main_genres']))

features_pca = decomposition.PCA(n_components=2).fit_transform(eigenvectors)
plt.scatter(features_pca[:, 0], features_pca[:, 1], c=simple_l, cmap='RdBu', alpha=0.5)
plt.show()
# [___CELL_SEPARATOR___]
genres = preprocessing.LabelEncoder().fit_transform((Movies.drop(DropLines)['main_genres']))

features_pca = decomposition.PCA(n_components=2).fit_transform(eigenvectors)
plt.scatter(features_pca[:, 0], features_pca[:, 1], c=genres, cmap='RdBu', alpha=0.5)
plt.show()
# [___CELL_SEPARATOR___]
plt.scatter(eigenvectors[:, 1], eigenvectors[:, 2], c=simple_l, cmap='RdBu', alpha=0.5)
plt.show()
# [___CELL_SEPARATOR___]
plt.scatter(eigenvectors[:, 1], eigenvectors[:, 2], c=genres, cmap='RdBu', alpha=0.5)
plt.show()
# [___CELL_SEPARATOR___]
#Example:
#Actors=['Bruce Willis','Jim Carry'] --> Is_BruceWillis =1
#                                        Is_JimCarry    =1
#                                        Is_JuliaRoberts=0
#                                        ....           =0
# [___CELL_SEPARATOR___]
Movies['actors']               = Movies['actors'].apply(lambda x: x.replace(" ", "_"))
Movies['keywords']             = Movies['keywords'].apply(lambda x: x.replace(" ", "_"))
Movies['crew_names']           = Movies['crew_names'].apply(lambda x: x.replace(" ", "_"))
Movies['production_companies'] = Movies['production_companies'].apply(lambda x: x.replace(" ", "_"))

Frames = []
for feature in ['prime_actors','prime_keywords','prime_crew_names']:
    Frames.append(((ProcessCategorical(Movies,feature)).fillna(0)))
         
print("DONE")

all_distances, DropLines, newFrames = DropZeroLinesAndGetDistanes(Frames)
genres = preprocessing.LabelEncoder().fit_transform((Movies.drop(DropLines)['main_genres']))

%matplotlib inline
#distaces in Actors
#PlotMatrix(all_distances[0])
#distaces in keywords
#PlotMatrix(all_distances[1])
#distaces in crew
#PlotMatrix(all_distances[2])

CatDistances = (all_distances[0] + all_distances[1] + all_distances[2])/3
#categorical distances
PlotMatrix(CatDistances)
# [___CELL_SEPARATOR___]
#CatDistance distribution
fig, axes = plt.subplots(figsize=(15, 5))
axes.set(yscale="symlog")
plt.rcParams['figure.figsize'] = (17, 9)
plt.hist(CatDistances.reshape(-1), bins=100);
# [___CELL_SEPARATOR___]
#getting raw categorical weights
NEIGHBORS = 80 #!WARNING extremly sensitive parameter    
RawCatweights = GetWeights(CatDistances,NEIGHBORS)


#Combining numerical and categoriacl features, leading to now improvment
features = pd.DataFrame()

#including

#for col in ['revenue', 'vote_average',  'vote_count']:
#    features[col]      = (Movies.drop(DropLines))[col] 
#features -= features.mean(axis=0)
#features /= features.std(axis=0)

for df in newFrames:
    features[df.columns] = df[df.columns]
# [___CELL_SEPARATOR___]
Catfeatures_pca = decomposition.PCA(n_components=80).fit_transform(features)
PCA_Cat_distances =scipy.spatial.distance.squareform(scipy.spatial.distance.pdist(Catfeatures_pca, metric='cosine') )
# [___CELL_SEPARATOR___]
#PCA_Cat_distances distribution
fig, axes = plt.subplots(figsize=(15, 5))
#axes.set(yscale="symlog")
plt.rcParams['figure.figsize'] = (17, 9)
plt.hist(PCA_Cat_distances.reshape(-1), bins=100);
# [___CELL_SEPARATOR___]
#getting PCA categorical weights
NEIGHBORS = 50 #!WARNING extremly sensitive parameter    50 works
PCACatweights = GetWeights(PCA_Cat_distances,NEIGHBORS)
# [___CELL_SEPARATOR___]
plt.spy(PCACatweights, markersize=0.09)
# [___CELL_SEPARATOR___]
genres = preprocessing.LabelEncoder().fit_transform((Movies.drop(DropLines)['main_genres']))            
Sorted_Full_WEIGHTS = BubbleReorderMatrix(PCACatweights,genres) 
np.savez_compressed("../Datasets/WEIGHTS.npz", PCACatweights, PCACatweights=PCACatweights)

plt.spy(Sorted_Full_WEIGHTS, markersize=0.8)
#PlotMatrix(WEIGHTS)
# [___CELL_SEPARATOR___]
weights_sparse = PCACatweights

degrees = np.count_nonzero(weights_sparse, axis=0)
D = np.diag(degrees)
laplacian_comb = D - weights_sparse

how_much_genre = 4
eigenvalues, eigenvectors = scipy.sparse.linalg.eigsh(laplacian_comb, how_much_genre, which='SM')


kmeans = KMeans(n_clusters=how_much_genre).fit(eigenvectors)
l =kmeans.labels_
#(Movies.drop(DropLines)).iloc[l==3]
# [___CELL_SEPARATOR___]
genres = preprocessing.LabelEncoder().fit_transform((Movies.drop(DropLines)['main_genres']))
#for i in range(len(genres)):
#    print(genres[i],l[i])
# [___CELL_SEPARATOR___]
plt.hist(l)
# [___CELL_SEPARATOR___]
plt.hist(genres)
genres = preprocessing.LabelEncoder().fit_transform((Movies.drop(DropLines)['main_genres']))

# [___CELL_SEPARATOR___]
eigenvalues
# [___CELL_SEPARATOR___]
plt.hist(eigenvalues)
# [___CELL_SEPARATOR___]
plt.plot(eigenvalues, '.-', markersize=15);
# [___CELL_SEPARATOR___]
f1_score(genres, matchLabel(l,genres),average='micro')
#Calculate metrics globally by counting the total true positives, false negatives and false positives.
# [___CELL_SEPARATOR___]
genres = preprocessing.LabelEncoder().fit_transform((Movies.drop(DropLines)['main_genres']))
print("Score is ",f1_score(genres, matchLabel(l,genres),average='micro'))

# [___CELL_SEPARATOR___]
bestScore=0
for i in range(4):
    for j in range(4):
        if j == i:
            continue
        for k in range(4):
            if k==j:
                continue
            if k==i:
                continue 
            for m in range(4):
                if m==j:
                    continue
                if m==i:
                    continue
                if m==k:
                    continue
                for entry in range(len(l)):
                    if l[entry] == 0:
                        l[entry]=i
                    if l[entry] == 1:
                        l[entry]=k
                    if l[entry] == 2:   
                        l[entry]=j
                    if l[entry] == 3:
                        l[entry]=m
                    if bestScore < f1_score(genres, l,average='micro'):
                        bestScore = f1_score(genres, l,average='micro')
                        
print("Score is ",bestScore)
# [___CELL_SEPARATOR___]
features_pca = decomposition.PCA(n_components=2).fit_transform(eigenvectors)
genres = preprocessing.LabelEncoder().fit_transform(l)
plt.scatter(features_pca[:, 0], features_pca[:, 1], c=l, cmap='RdBu', alpha=0.5)
plt.show()
# [___CELL_SEPARATOR___]
features_pca = decomposition.PCA(n_components=2).fit_transform(eigenvectors)
genres = preprocessing.LabelEncoder().fit_transform(l)
plt.scatter(features_pca[:, 0], features_pca[:, 1], c=genres, cmap='RdBu', alpha=0.5)
plt.show()
# [___CELL_SEPARATOR___]
plt.scatter(eigenvectors[:, 1], eigenvectors[:, 2], c=l, cmap='RdBu', alpha=0.5)
plt.show()
# [___CELL_SEPARATOR___]
DropLines
# [___CELL_SEPARATOR___]
costs = np.load('../Datasets/costs_parallelized.npz')
costs = costs['costs']
np.fill_diagonal(costs,0)

Movies = pd.read_csv('../Datasets/Transformed.csv')
Movies = Movies.loc[Movies['vote_average'] > 0]
# [___CELL_SEPARATOR___]
plt.spy(costs)
plt.show()
# [___CELL_SEPARATOR___]
for i in range(Movies.loc[Movies['vote_average'] > 0].shape[0]):
    best_movie = np.argmax(costs[i])
    
    print('Original film: {} || Predicted movie: {}'.format(Movies.iloc[i]['title'],Movies.iloc[best_movie]['title']))
# [___CELL_SEPARATOR___]
G = nx.DiGraph()
for i in range(Movies.loc[Movies['vote_average'] > 0].shape[0]):
    G.add_node(i)
    G.add_edge(i,np.argmax(costs[i]))
# [___CELL_SEPARATOR___]
% matplotlib inline
degree_distribution=sorted(nx.degree(G).values(),reverse=True) # degree distribution sorted from highest to lowest
plt.hist(degree_distribution, range=(0,100), log=True)
# [___CELL_SEPARATOR___]
import networkx as nx
import plotly.plotly as py
from plotly.graph_objs import *

    
nx.draw_networkx(G, with_labels=False)
plt.rcParams["figure.figsize"] = (40, 40)
plt.rcParams["font.size"] = 14

plt.show() # display
# [___CELL_SEPARATOR___]
nx.draw_networkx(nx.from_numpy_matrix(PCACatweights),node_size=15, width=0.05)
plt.rcParams["figure.figsize"] = (40, 40)
plt.rcParams["font.size"] = 14

plt.show() # display
# [___CELL_SEPARATOR___]
