import os
import sys
import numpy as np
import multiprocessing
import tensorflow as tf
import numpy as np
import pandas as pd
import re
from keras.preprocessing.text import Tokenizer
from keras.preprocessing.sequence import pad_sequences
from keras.utils import to_categorical
from keras.layers import Dense, Input, GlobalMaxPooling1D
from keras.layers import Conv1D, MaxPooling1D, Embedding
from keras.models import Model
import keras.backend as K
from keras.callbacks import EarlyStopping
from keras.models import Sequential
from keras.layers.core import Dense, Dropout, Flatten
from keras.layers.convolutional import Conv1D
from keras.optimizers import Adam
from nltk.stem.lancaster import LancasterStemmer
from nltk.tokenize import RegexpTokenizer
from fastText import load_model
# [___CELL_SEPARATOR___]
BASE_DIR = ''
# TEXT_DATA_DIR = os.path.join(BASE_DIR, '20_newsgroup')
MAX_SEQUENCE_LENGTH = 1000
MAX_NUM_WORDS = 20000
EMBEDDING_DIM = 300
VALIDATION_SPLIT = 0.2
FT_MODEL = 'wiki.simple.bin'
# [___CELL_SEPARATOR___]
%%time
# first, build index mapping words in the embeddings set
# to their embedding vector
# Use this in case you are using a vec file.

print('Indexing word vectors.')

filename, file_extension = os.path.splitext(FT_MODEL)

if file_extension == '.vec':
    embeddings_index = {}
    with open(os.path.join(FT_MODEL)) as f:
        for line in f:
            values = line.split()
            word = values[0]
            coefs = np.asarray(values[1:], dtype='float32')
            embeddings_index[word] = coefs
            
    print('Found %s word vectors.' % len(embeddings_index))
# [___CELL_SEPARATOR___]
def clean_str(string):
    """
    Tokenization/string cleaning.
    Original from https://github.com/yoonkim/CNN_sentence/blob/master/process_data.py
    """
    string = re.sub(r"[^A-Za-z0-9(),!?\'\`]", " ", string)
    string = re.sub(r"\'s", " \'s", string)
    string = re.sub(r"\'ve", " \'ve", string)
    string = re.sub(r"n\'t", " n\'t", string)
    string = re.sub(r"\'re", " \'re", string)
    string = re.sub(r"\'d", " \'d", string)
    string = re.sub(r"\'ll", " \'ll", string)
    string = re.sub(r",", " , ", string)
    string = re.sub(r"!", " ! ", string)
    string = re.sub(r"\(", " \( ", string)
    string = re.sub(r"\)", " \) ", string)
    string = re.sub(r"\?", " \? ", string)
    string = re.sub(r"\s{2,}", " ", string)
    
    return string.strip().lower()
# [___CELL_SEPARATOR___]
df = pd.read_csv('yelp_review.csv')
# [___CELL_SEPARATOR___]
%%time
df['text'] = df['text'].apply(clean_str)
texts = df.text.values
labels = df.stars.values
texts = texts[:MAX_NUM_WORDS]
labels = labels[:MAX_NUM_WORDS]
# [___CELL_SEPARATOR___]
df.head()
# [___CELL_SEPARATOR___]
print('Found %s texts.' % len(texts))
# [___CELL_SEPARATOR___]
# finally, vectorize the text samples into a 2D integer tensor
tokenizer = Tokenizer(num_words=MAX_NUM_WORDS)
tokenizer.fit_on_texts(texts)
sequences = tokenizer.texts_to_sequences(texts)
# [___CELL_SEPARATOR___]
word_index = tokenizer.word_index
print('Found %s unique tokens.' % len(word_index))
# [___CELL_SEPARATOR___]
data = pad_sequences(sequences, maxlen=MAX_SEQUENCE_LENGTH)
# [___CELL_SEPARATOR___]
labels = to_categorical(np.asarray(labels))
print('Shape of data tensor:', data.shape)
print('Shape of label tensor:', labels.shape)
# [___CELL_SEPARATOR___]
labels = np.asarray(labels)
print('Shape of data tensor:', data.shape)
print('Shape of label tensor:', labels.shape)
# [___CELL_SEPARATOR___]
# split the data into a training set and a validation set
indices = np.arange(data.shape[0])
np.random.shuffle(indices)
data = data[indices]
labels = labels[indices]
num_validation_samples = int(VALIDATION_SPLIT * data.shape[0])
# [___CELL_SEPARATOR___]
x_train = data[:-num_validation_samples]
y_train = labels[:-num_validation_samples]
x_val = data[-num_validation_samples:]
y_val = labels[-num_validation_samples:]
# [___CELL_SEPARATOR___]
print('Preparing embedding matrix.')

# load the fasttext model
f = load_model(FT_MODEL)

# prepare embedding matrix
num_words = min(MAX_NUM_WORDS, len(word_index) + 1)
embedding_matrix = np.zeros((num_words, EMBEDDING_DIM))
for word, i in word_index.items():
    if i >= MAX_NUM_WORDS:
        continue
#     embedding_vector = embeddings_index.get(word)
    embedding_vector = f.get_word_vector(word)
    if embedding_vector is not None:
        # words not found in embedding index will be all-zeros.
        embedding_matrix[i] = embedding_vector
# [___CELL_SEPARATOR___]
# load pre-trained word embeddings into an Embedding layer
# note that we set trainable = False so as to keep the embeddings fixed
embedding_layer = Embedding(num_words,
                            EMBEDDING_DIM,
                            weights=[embedding_matrix],
                            input_length=MAX_SEQUENCE_LENGTH,
                            trainable=False)
# [___CELL_SEPARATOR___]
print('Training model.')

# train a 1D convnet with global maxpooling
sequence_input = Input(shape=(MAX_SEQUENCE_LENGTH,), dtype='int32')
embedded_sequences = embedding_layer(sequence_input)
x = Conv1D(128, 5, activation='relu')(embedded_sequences)
x = MaxPooling1D(5)(x)
x = Conv1D(128, 5, activation='relu')(x)
x = MaxPooling1D(5)(x)
x = Conv1D(128, 5, activation='relu')(x)
x = GlobalMaxPooling1D()(x)
x = Dense(128, activation='relu')(x)
preds = Dense(6, activation='softmax')(x)
# [___CELL_SEPARATOR___]
model = Model(sequence_input, preds)
model.compile(loss='categorical_crossentropy',
              optimizer=Adam(lr=0.0001, decay=1e-6),
              metrics=['acc'])
# [___CELL_SEPARATOR___]
%%time
model.fit(x_train, y_train,
          batch_size=128,
          shuffle=True,
          epochs=10,
          validation_data=(x_val, y_val))
# [___CELL_SEPARATOR___]
scores = model.evaluate(x_val, y_val)
print("\n%s: %.2f%%" % (model.metrics_names[1], scores[1]*100))
# [___CELL_SEPARATOR___]
print(model.summary())