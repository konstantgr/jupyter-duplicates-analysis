import numpy as np
import pickle
# [___CELL_SEPARATOR___]
testset_title = np.load('../data/aaai-19/whole/test/test_title.npy')
testset_body = np.load('../data/aaai-19/whole/test/test_body.npy')
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
with open('../data/aaai-19/whole/dic_mincutN.pkl') as f:
    dic = pickle.load(f)
delimiter = ' ' +  str(dic['<EOP>']) + ' '
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
from Vocab import *
voca = Vocab(dic)
# [___CELL_SEPARATOR___]
print voca.index2sent(testset_title[0])
# [___CELL_SEPARATOR___]
print voca.index2sent(testset_body[0])
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
