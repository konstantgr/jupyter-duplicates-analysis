from graph_adjacency_matrix import *

g = AdjacencyMatrixGraph(4)

g.add_edge(0,1)
g.add_edge(0,2)
g.add_edge(2,3)

for i in range(4):
    print("Adjacent to : ", i, g.get_adjacent_vertices(i))
    

for i in range(4):
    print("Indegree : ", i, g.get_indegree(i))


for i in range(4):
    for j in g.get_adjacent_vertices(i):
        print("Edge weight : ", i, " ", j, " weight : ", g.get_edge_weight(i,j))

g.display()
# [___CELL_SEPARATOR___]
from graph_adjacency_matrix import *

g = AdjacencyMatrixGraph(4, directed = True)

g.add_edge(0,1)
g.add_edge(0,2)
g.add_edge(2,3)

for i in range(4):
    print("Adjacent to : ", i, g.get_adjacent_vertices(i))
    

for i in range(4):
    print("Indegree : ", i, g.get_indegree(i))


for i in range(4):
    for j in g.get_adjacent_vertices(i):
        print("Edge weight : ", i, " ", j, " weight : ", g.get_edge_weight(i,j))

g.display()
# [___CELL_SEPARATOR___]
from graph_adjacency_set import *

g = AdjacencySetGraph(4, directed = False)

g.add_edge(0,1,1)
g.add_edge(0,2,1)
g.add_edge(2,3,1)

for i in range(4):
    print("Adjacent to : ", i, g.get_adjacent_vertices(i))
    

for i in range(4):
    print("Indegree : ", i, g.get_indegree(i))


for i in range(4):
    for j in g.get_adjacent_vertices(i):
        print("Edge weight : ", i, " ", j, " weight : ", g.get_edge_weight(i,j))

g.display()
# [___CELL_SEPARATOR___]
from graph_adjacency_set import *

g = AdjacencySetGraph(4, directed = True)

g.add_edge(0,1,1)
g.add_edge(0,2,1)
g.add_edge(2,3,1)

for i in range(4):
    print("Adjacent to : ", i, g.get_adjacent_vertices(i))
    

for i in range(4):
    print("Indegree : ", i, g.get_indegree(i))


for i in range(4):
    for j in g.get_adjacent_vertices(i):
        print("Edge weight : ", i, " ", j, " weight : ", g.get_edge_weight(i,j))

g.display()
# [___CELL_SEPARATOR___]
from graph_breadth_first import *

g = AdjacencyMatrixGraph(9) 

g.add_edge(0,1)
g.add_edge(1,2)
g.add_edge(2,7)
g.add_edge(2,4)
g.add_edge(2,3)
g.add_edge(1,5)
g.add_edge(5,6)
g.add_edge(6,3)
g.add_edge(3,4)
g.add_edge(6,8)

breadth_first(g,2)
# [___CELL_SEPARATOR___]
from graph_breadth_first import *

g = AdjacencyMatrixGraph(9, directed = True) 

g.add_edge(0,1)
g.add_edge(1,2)
g.add_edge(2,7)
g.add_edge(2,4)
g.add_edge(2,3)
g.add_edge(1,5)
g.add_edge(5,6)
g.add_edge(6,3)
g.add_edge(3,4)
g.add_edge(6,8)

breadth_first(g,0)
# [___CELL_SEPARATOR___]
import numpy as np
from graph_depth_first import *

g = AdjacencyMatrixGraph(9) 

g.add_edge(0,1)
g.add_edge(1,2)
g.add_edge(2,7)
g.add_edge(2,4)
g.add_edge(2,3)
g.add_edge(1,5)
g.add_edge(5,6)
g.add_edge(6,3)
g.add_edge(3,4)
g.add_edge(6,8)

visited = np.zeros(g.numVertices)

depth_first(g,visited)
# [___CELL_SEPARATOR___]
import numpy as np
from graph_depth_first import *

g = AdjacencyMatrixGraph(9, directed = True) 

g.add_edge(0,1)
g.add_edge(1,2)
g.add_edge(2,7)
g.add_edge(2,4)
g.add_edge(2,3)
g.add_edge(1,5)
g.add_edge(5,6)
g.add_edge(6,3)
g.add_edge(3,4)
g.add_edge(6,8)

visited = np.zeros(g.numVertices)

depth_first(g,visited)
# [___CELL_SEPARATOR___]
from topological_sort import *
from graph_adjacency_matrix import *

g = AdjacencyMatrixGraph(9, directed=True) # DAG

g.add_edge(0,1)
g.add_edge(1,2)
g.add_edge(2,7)
g.add_edge(2,4)
g.add_edge(2,3)
g.add_edge(1,5)
g.add_edge(5,6)
g.add_edge(3,6)
g.add_edge(3,4)
g.add_edge(6,8)

topological_sort(g)
# [___CELL_SEPARATOR___]
from topological_sort import *
from graph_adjacency_matrix import *

g = AdjacencyMatrixGraph(9, directed=True) # DAG

g.add_edge(0,1)
g.add_edge(1,2)
g.add_edge(2,0)
g.add_edge(2,7)
g.add_edge(2,4)
g.add_edge(2,3)
g.add_edge(1,5)
g.add_edge(5,6)
g.add_edge(3,6)
g.add_edge(3,4)
g.add_edge(6,8)

topological_sort(g)
# [___CELL_SEPARATOR___]
from graph_adjacency_set import *
from shortest_path import *

g = AdjacencySetGraph(8, directed= False)

g.add_edge(0,1,1)
g.add_edge(1,2,1)
g.add_edge(1,3,1)
g.add_edge(2,3,1)
g.add_edge(1,4,1)
g.add_edge(3,5,1)
g.add_edge(5,4,1)
g.add_edge(3,6,1)
g.add_edge(6,7,1)
g.add_edge(0,7,1)

shortest_path(graph=g,source=0,destination=5)
shortest_path(graph=g,source=0,destination=6)
shortest_path(graph=g,source=7,destination=4)
# [___CELL_SEPARATOR___]
from graph_adjacency_set import *
from shortest_path import *

g = AdjacencySetGraph(8, directed= True)

g.add_edge(0,1,1)
g.add_edge(1,2,1)
g.add_edge(1,3,1)
g.add_edge(2,3,1)
g.add_edge(1,4,1)
g.add_edge(3,5,1)
g.add_edge(5,4,1)
g.add_edge(3,6,1)
g.add_edge(6,7,1)
g.add_edge(0,7,1)

shortest_path(graph=g,source=0,destination=5)
shortest_path(graph=g,source=0,destination=6)
shortest_path(graph=g,source=7,destination=4)
# [___CELL_SEPARATOR___]
from graph_adjacency_matrix import *
from dijkstra import *

g = AdjacencyMatrixGraph(8, directed= False)

g.add_edge(0,1,1)
g.add_edge(1,2,2)
g.add_edge(1,3,6)
g.add_edge(2,3,2)
g.add_edge(1,4,3)
g.add_edge(3,5,1)
g.add_edge(5,4,5)
g.add_edge(3,6,1)
g.add_edge(6,7,1)
g.add_edge(0,7,8)

shortest_path(graph=g,source=0,destination=6)
shortest_path(graph=g,source=4,destination=7)
shortest_path(graph=g,source=7,destination=0)
# [___CELL_SEPARATOR___]
from graph_adjacency_matrix import *
from dijkstra import *

g = AdjacencyMatrixGraph(8, directed= True)

g.add_edge(0,1,1)
g.add_edge(1,2,2)
g.add_edge(1,3,6)
g.add_edge(2,3,2)
g.add_edge(1,4,3)
g.add_edge(3,5,1)
g.add_edge(5,4,5)
g.add_edge(3,6,1)
g.add_edge(6,7,1)
g.add_edge(0,7,8)

shortest_path(graph=g,source=0,destination=6)
shortest_path(graph=g,source=4,destination=7)
shortest_path(graph=g,source=7,destination=0)
# [___CELL_SEPARATOR___]
from graph_adjacency_matrix import *
from prim import *

g = AdjacencyMatrixGraph(8, directed= False)

g.add_edge(0,1,1)
g.add_edge(1,2,2)
g.add_edge(1,3,2)
g.add_edge(2,3,2)
g.add_edge(1,4,3)
g.add_edge(3,5,1)
g.add_edge(5,4,3)
g.add_edge(3,6,1)
g.add_edge(6,7,1)
g.add_edge(0,7,1)

print("-------Test Run : 1------")
spanning_tree(graph=g,source=1)
print("-------Test Run : 2------")
spanning_tree(graph=g,source=3)
# [___CELL_SEPARATOR___]
from graph_adjacency_matrix import *
from kruskal import *

g = AdjacencyMatrixGraph(8, directed= False)

g.add_edge(0,1,1)
g.add_edge(1,2,2)
g.add_edge(1,3,2)
g.add_edge(2,3,2)
g.add_edge(1,4,3)
g.add_edge(3,5,1)
g.add_edge(5,4,2)
g.add_edge(3,6,1)
g.add_edge(6,7,1)
g.add_edge(0,7,1)

spanning_tree(graph=g)