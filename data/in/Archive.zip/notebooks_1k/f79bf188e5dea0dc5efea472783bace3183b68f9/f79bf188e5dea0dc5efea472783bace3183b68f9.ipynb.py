try:
    import spacy
except:
    !pip install spacy
try:
    import spacy_langdetect
except:
    !pip install spacy-langdetect
try:
    import flair
except:
    !pip install flair
try:
    import geonamescache
except:
    !pip install geonamescache
try:
    import spacy_fastlang
except:    
    !pip install spacy_fastlang
    #!pip install sense2vec==1.0.0a1
try:
    import gensim
except:
    !pip install gensim
try:
    import wordcloud
except:
    !pip install wordcloud
try:
    import nltk
except:
    !pip install nltk

try:
    import visualise_spacy_tree
except:
    !pip install visualise-spacy-tree

try:
    import textacy
except:
    !pip install textacy

!python -m spacy download en_core_web_sm
!python -m spacy download en_core_web_md
# [___CELL_SEPARATOR___]
import spacy

from collections import Counter, defaultdict,OrderedDict

import pandas as pd
import os
import csv
import itertools
import re
import json
import numpy as np
import matplotlib.pyplot as plt
import datetime
import string
import re

from spacy_langdetect import LanguageDetector
import plac
from spacy.lang.en import English
from spacy.matcher import PhraseMatcher
from spacy.tokens import Doc, Span, Token
from spacy.pipeline import EntityRuler
from spacy.pipeline import merge_entities
import visualise_spacy_tree

import textacy

from IPython.display import Image,display

from langdetect import detect, detect_langs
from nltk.tokenize import sent_tokenize
import nltk
nltk.download('punkt')
# [___CELL_SEPARATOR___]
os.listdir("/project_data/data_asset/iata/sun/")
# [___CELL_SEPARATOR___]
all_countries = pd.read_csv("/project_data/data_asset/all_countries_with_aliases.csv")

all_countries_aliases = dict()
for idx, r in all_countries[~all_countries.Aliases.isna()].iterrows():
    a = dict()
    a['alpha_2_code'] = r['Alpha-2 code']
    a['alpha_3_code'] = r['Alpha-3 code']
    a['name'] = r['Name']
    all_countries_aliases.update({r['Name'].lower():a})
    
    cnames = r['Aliases'].split(' # ')
    if len(cnames) > 0:
        for c in cnames:
            if len(c.strip())>3:
                a = dict()
                a['alpha_2_code'] = r['Alpha-2 code']
                a['alpha_3_code'] = r['Alpha-3 code']
                a['name'] = r['Name']
                all_countries_aliases.update({c.strip().lower():a})
                
all_patterns = list()
for k in all_countries_aliases.keys():
    c_patterns = k.split()

    
    c_patterns_list = []
    for c in c_patterns:
        d = dict()
        d['LOWER'] = c
        c_patterns_list.append(d)
    
    
    pattern_dict = dict()
    pattern_dict["label"] = "GPE"
    pattern_dict["pattern"] = c_patterns_list
    pattern_dict["id"] = all_countries_aliases[k]['alpha_3_code']
    
    all_patterns.append(pattern_dict)
# [___CELL_SEPARATOR___]


eu = ["Belgium",
    "Bulgaria",
    "Denmark",
    "Germany",
    "Estonia",
    "Finland",
    "France",
    "Greece",
    "Ireland",
    "Italy",
    "Croatia",
    "Latvia",
    "Lithuania",
    "Luxembourg",
    "Malta",
    "Netherlands",
    "Austria",
    "Poland",
    "Portugal",
    "Romania",
    "Sweden",
    "Slovakia",
    "Slovenia",
    "Spain",
    "Czech Republic",
    "Hungary",
    "United Kingdom",
    "Cyprus"]

eea_c = eu+[
    "Iceland",
    "Liechtenstein",
    "Norway","Switzerland"
]

schengen = ["Austria", "Belgium", "Czech Republic", "Denmark", "Estonia", "Finland", "France", "Germany", "Greece", "Hungary", "Iceland", "Italy", "Latvia",
            "Liechtenstein", "Lithuania", "Luxembourg", "Malta", "Netherlands", "Norway", "Poland", "Portugal", "Slovakia", "Slovenia", "Spain", "Sweden", "Switzerland"]

scandinavian = ["Denmark","Norway","Sweden"]

eum = []
for c in eu:
    #print(all_countries[all_countries['Name'].str.contains(c)]['Alpha-3 code'].values[0])
    eum.append(all_countries[all_countries['Name'].str.contains(c)]['Alpha-3 code'].values[0])

eea = []
for c in eea_c:
    #print(all_countries[all_countries['Name'].str.contains(c)]['Alpha-3 code'].values[0])
    eea.append(all_countries[all_countries['Name'].str.contains(c)]['Alpha-3 code'].values[0])

sch = []
for c in schengen:
    #print(all_countries[all_countries['Name'].str.contains(c)]['Alpha-3 code'].values[0])
    sch.append(all_countries[all_countries['Name'].str.contains(c)]['Alpha-3 code'].values[0])

svc = []
for c in scandinavian:
    #print(all_countries[all_countries['Name'].str.contains(c)]['Alpha-3 code'].values[0])
    svc.append(all_countries[all_countries['Name'].str.contains(c)]['Alpha-3 code'].values[0])
    
neum = list(set(all_countries['Alpha-3 code'].unique()).difference(set(eum)))
nsch = list(set(all_countries['Alpha-3 code'].unique()).difference(set(sch)))
neu = list(set(all_countries['Alpha-3 code'].unique()).difference(set(eea)))


# [___CELL_SEPARATOR___]
all_patterns.extend([{'label': 'GPE',
  'pattern': [{'LOWER': 'republic'}, {'LOWER': 'of'}, {'LOWER': 'costarica'}],
  'id': 'CRI'},
  {'label': 'GPE',
  'pattern': [{'LOWER': 'saint'}, {'LOWER': 'christopher'}, {'LOWER': 'and'}, {'LOWER': 'nevis'}],
  'id': 'KNA'}, 
{'label': 'GPE',
  'pattern': [{'LOWER': 'vatican'}, {'LOWER': 'city'}],
  'id': 'VAT'},
{'label': 'GPE',
  'pattern': [{'LOWER': 'vatican'}],
  'id': 'VAT'},
{'label': 'GPE',
  'pattern': [{'LOWER': 'member'}, {'LOWER': 'states'}, {'LOWER': 'of'},{'LOWER': 'the'}, {'LOWER': 'european'}, {'LOWER': 'union'}],
  'id': 'EUM'},
{'label': 'GPE',
  'pattern': [{'LOWER': 'eu'}, {'LOWER': 'member'}, {'LOWER': 'state'}],
  'id': 'EUM'},
{'label': 'GPE',
  'pattern': [{'LOWER': 'european'}, {'LOWER': 'union'}, {'LOWER': 'member'}, {'LOWER': 'states'}],
  'id': 'EUM'},
{'label': 'GPE',
  'pattern': [{'LOWER': 'european'}, {'LOWER': 'union'}],
  'id': 'EUM'},
{'label': 'GPE',
  'pattern': [{'LOWER': 'eu'}, {'LOWER': 'member'}, {'LOWER': 'states'}],
  'id': 'EUM'},
{'label': 'GPE',
  'pattern': [{'LOWER': 'eu'}],
  'id': 'EUM'},
{'label': 'GPE',
  'pattern': [{'LOWER': 'schengen'}],
  'id': 'SCH'},
{'label': 'GPE',
  'pattern': [{'LOWER': 'south-korea'}],
  'id': 'KOR'},
{'label': 'GPE',
  'pattern': [{'LOWER': 'uk'}],
  'id': 'GBR'},
 {'label': 'GPE',
  'pattern': [{'LOWER': 'great'}, {'LOWER': 'britain'}],
  'id': 'GBR'},
 {'label': 'GPE',
  'pattern': [{'LOWER': 'great'}, {'LOWER': 'britain'}, {'LOWER': 'and'}, {'LOWER': 'northern'}, {'LOWER': 'ireland'}],
  'id': 'GBR'},
{'label': 'GPE',
  'pattern': [{'LOWER': 'tunesia'}],
  'id': 'TUN'},
{'label': 'GPE',
  'pattern': [{'LOWER': 'scandinavian'}, {'LOWER': 'countries'}],
  'id': 'SVC'},
{'label': 'GPE',
  'pattern': [{'LOWER': 'hongkong'}],
  'id': 'HKG'},
{'label': 'GPE',
  'pattern': [{'LOWER': 'usa'}],
  'id': 'USA'},
{'label': 'GPE',
  'pattern': [{'LOWER': 'uae'}],
  'id': 'ARE'},
{'label': 'GPE',
  'pattern': [{'LOWER': 'u.s.a'}],
  'id': 'USA'},
{'label': 'GPE',
  'pattern': [{'LOWER': 'u.s.'}],
  'id': 'USA'},
{'label': 'GPE',
  'pattern': [{'LOWER': 'prc'}],
  'id': 'CHN'},
{'label': 'GPE',
  'pattern': [{'LOWER': 'third'},{'LOWER': 'country'}],
  'id': 'NEU'},
{'label': 'GPE',
  'pattern': [{'LOWER': 'third'},{'LOWER': 'countries'}],
  'id': 'NEU'},
{'label': 'GPE',
  'pattern': [{'LOWER': 'third-country'}],
  'id': 'NEU'},
{'label': 'GPE',
  'pattern': [{'LOWER': 'non-eu'}],
  'id': 'NEUM'},
{'label': 'GPE',
  'pattern': [{'LOWER': 'non'},{'LOWER': 'eu'}],
  'id': 'NEUM'},
{'label': 'GPE',
  'pattern': [{'LOWER': 'non-european'},{'LOWER': 'union'},{'LOWER': 'member'},{'LOWER': 'states'}],
  'id': 'NEUM'},
{'label': 'GPE',
  'pattern': [{'LOWER': 'non-schengen'}],
  'id': 'NSCH'},
{'label': 'GPE',
  'pattern': [{'LOWER': 'non'},{'LOWER': 'schengen'}],
  'id': 'NSCH'}])
# [___CELL_SEPARATOR___]
european_regions =  ['EUM','SCH','SVC','NEU','NEUM','NSCH']

european_regions_dt = {'EUM':eum,'SCH':sch,'SVC':svc,'NEU':neu,'NEUM':neum,'NSCH':nsch}

#nlp = English()
nlp = spacy.load('en_core_web_sm')
ruler = EntityRuler(nlp,overwrite_ents=True)
#patterns = [{"label": "ORG", "pattern": "Apple", "id": "apple"},
#            {"label": "GPE", "pattern": [{"LOWER": "san"}, {"LOWER": "francisco"}], "id": "san-francisco"},
#            {"label": "GPE", "pattern": [{"LOWER": "san"}, {"LOWER": "fran"}], "id": "san-francisco"}]
ruler.add_patterns(all_patterns)
nlp.add_pipe(ruler)


# [___CELL_SEPARATOR___]
nlp.add_pipe(merge_entities)
# [___CELL_SEPARATOR___]
# Adding stop words
new_stop_words = ["create","source","euecyiyn",'etczyoyx','tel']

# Add airport codes to stop words
#new_stop_words.extend([ac.lower() for ac in list(apt_covid_notam_lt_df.airportCode.values)])


for new_word in new_stop_words:
    nlp.vocab[new_word].is_stop = True

mapping = {"acc": "area control", "acft": "aircraft", "ad": "aerodrome", "aic": "aeronautical information circular",
           "aip": "aeronautical information publication", "ais": "aeronautical information services",
           "alt": "altitude", "altn": "alternate", "ap": "airport", "aro": "air traffic services reporting office",
           "arr": "arrival", "atc": "air traffic control", "ats": "air traffic services", "attn": "attention",
           "auth": "authorized", "avbl": "available", "bfr": "before", "cat": "category", "chg": "change","civ":"civil",
           "clsd": "closed", "cov": "cover", "cta": "control area", "ctc": "contact", "ctr": "control zone",
           "dem.": "democratic", "dep": "depart", "emerg": "emergency", "enr": "en route", "exc": "except",
           "fed.": "federation", "fir": "flight information region", "fis": "flight information service",
           "flt": "flight", "flts": "flights", "flw": "follows", "fm": "from", "fpl": "filed flight plan",
           "fri": "friday", "gen": "general", "hr": "hour", "intl": "international", "isl.": "islands",
           "ldg": "landing", "mil": "military", "mon": "monday", "op": "operation","ops": "operations", 
           "opr": "operating","pax": "passenger",
           "ppr": "prior permission required", "ref": "refernce to", "rep.": "republic", "req": "request",
           "rffs": "rescue and fire fighting services", "rmk": "remark", "rte": "route", "rwy": "runway",
           "sat": "saturday", "ser": "service", "svc": "service message", "taf": "terminal aerodrome forecast",
           "tfc": "traffic", "thu": "thursday", "tma": "terminal control area", "tue": "tuesday",
           "twr": "aerodrome control tower", "vfr": "visual flight rules"}
# [___CELL_SEPARATOR___]
def clean_message_keep_punct(message):
    #############################
    ## mapping, lower, language #
    #############################
    
    message = re.sub(r'(http|https|www)\S+', '.', message)
    
    # Mapping short terms to actual word
    for s_, w in mapping.items():
        message = re.sub(r'\b{}\b'.format(s_),w,message)
    
    #Remove internal restrictions messages:
    phrases = re.findall('^\*{5}(.*)',message,re.M)
    for ph in phrases:
        if "internal" in ph.lower():
            message = message.split("*****"+ph)[0]
            #print(message)

    message = re.sub("\*{5}(.*)","",message)
    
    # Remove from eu and third country messages
    message = re.sub("(\*{3}.*?[:])",".",message)
    message = re.sub("(\*{2}.*?[:])",".",message)
    

    #Start of string other than character or digit
    #message = re.sub(r'[^ 0-9a-z]', ' ', message)
    #message = message.translate(message.maketrans('', '', string.punctuation)) #extra punctuations removal
    message = re.sub("[\(\[].*?[\)\]]", "", str(message))
    message = re.sub("[\[]", "", str(message))
    
    # Replace numbered points with comma
    message = re.sub("(\s\d+\.)",", ", str(message))
    # Remove unnecessary white space
    message = " ".join(message.split())
    
    return message
# [___CELL_SEPARATOR___]
pos_verbs_to_filter = ["permit","allow", "accept","open","lift","exempt","resume","reopen","authorise"]
neg_verbs_to_filter = ["ban", "exclude", 
                   "refuse","expel", "deny", "prohibit", "cancel","suspend","close","forbid"]
restrict_verb = ["restrict"]

neg_nouns = ["suspension","cancellation","ban"]
pos_nouns = ["opening","enter","resumption","exemption","exempt","alleviation","resume"]

# If the country border is closed to all countries the following nouns and noun_chunks are commonly used
nouns_to_filter = ["passenger", "foreigner", "traveller", "flight","airport","arrival","departure"]
noun_chunks_ = ["all borders","all flights","civil flight","civil flights","all airports","general aviation","ga","commercial flights","all international"]#"the border"

na_extension = ["shall hold a negative covid-19 test","unless belong to one of the following","this does not apply"]
# [___CELL_SEPARATOR___]
def all_country_closure(c,other_countries_in_this_sentence):
    '''
    look for the nouns and identify if the word "all" is associated with it. 
    Then label the restriction as "all" countries
    '''
    countries = []
    if (c.lemma_ == "to") | (c.lemma_ == "for")| (c.lemma_ == "from"):
        for c_ in c.children:
            if c_.lemma_ in nouns_to_filter:
                for c__ in c_.children:
                    if (c__.lemma_ == "all")& (len(other_countries_in_this_sentence) == 0):
                        countries = "all"
    if c.lemma_ in nouns_to_filter:
        for c_ in c.children:
            if (c_.lemma_ == "all")& (len(other_countries_in_this_sentence) == 0):
                countries = "all"
    #print(countries)
    if len(countries) != 0:
        return countries
    else:
        return None

def country_restrictions(asp_active_df):
    each_country = dict()
    for cc in asp_active_df.iso3.unique():#['ITA']:#
        master_dict= dict()
        each_country[cc] = []
        relevant_messages = []
        print(cc)
        for idx, r in asp_active_df[asp_active_df.iso3==cc].iterrows():

            current_country = r['iso3']

            doc = nlp(r['cleaned_message_with_punct']) 

            # Get all country names mentioned in the message
            other_countries = [t.ent_id_ for t in doc if (t.ent_type_ == "GPE") & (t.ent_id_ != '') & (t.ent_id_ != current_country)]

            #nltk sent tokenise is better
            for sent_ in sent_tokenize(doc.text):
                doc_ = nlp(sent_)
            #for doc_ in doc.sents:
                tag = []
                tag_single = ""
                countries = []
                countries_dt = {}
                specific_country = []
                for t in doc_:
                    other_countries_in_this_sentence = [t.ent_id_ for t in doc_ if (t.ent_type_ == "GPE") & (t.ent_id_ != '') & (t.ent_id_ != current_country)]
                    # If one of the positive verbs is present then we tag it as open unless a negation is present in the children
                    # Sometimes open is used as adjective int he sentence
                    if ((t.pos_ == "VERB") & ((t.lemma_ in pos_verbs_to_filter))) | ((t.pos_ == "ADJ") & (t.lemma_ == "open")):
                        tag_ = "open"
                        # if negation is present in one of the children associated with the verb we invert the tag
                        for c_ in t.children:
                            if c_.dep_ == "neg":
                                tag_ = "close"
                            #print(c_)
                            countries_ = all_country_closure(c_,other_countries_in_this_sentence)
                            if countries_ is not None:
                                countries.append(countries_)
                                countries_dt[countries_] = tag_
                        tag.append(tag_)
                        tag_single = tag_
                        for potential_country in t.subtree:
                            if (potential_country.ent_type_=="GPE")&(potential_country.ent_id_ != '')& (potential_country.ent_id_ != current_country)& ('following' not in [tc.text for tc in potential_country.lefts]):
                                specific_country.append(potential_country.ent_id_)

                    # If one of the negative verbs is present then we tag it as close unless a negation is present in the children
                    elif ((t.pos_ == "VERB") & (t.lemma_ in neg_verbs_to_filter)):
                        tag_ = "close"
                        # if negation is present in one of the children associated with the verb we invert the tag
                        for c_ in t.children:
                            if c_.dep == "neg":
                                tag_ = "open"

                            countries_ = all_country_closure(c_,other_countries_in_this_sentence)
                            #print(countries_)
                            if countries_ is not None:
                                countries.append(countries_)
                                countries_dt[countries_] = tag_
                        tag.append(tag_)
                        tag_single = tag_
                        for potential_country in t.subtree:
                            if (potential_country.ent_type_=="GPE")&(potential_country.ent_id_ != '')& (potential_country.ent_id_ != current_country)& ('following' not in [tc.text for tc in potential_country.lefts]):
                                specific_country.append(potential_country.ent_id_)

                    # If one of the positive nouns is present then we tag it as open unless a negation is present in the children
                    if ((t.pos_ == "NOUN") & (t.lemma_ in pos_nouns)):
                        tag_ = "open"
                        # if negation is present in one of the children associated with the noun we invert the tag
                        for c_ in t.children:
                            if c_.dep_ == "neg":
                                tag_ = "close"
                            countries_ = all_country_closure(c_,other_countries_in_this_sentence)
                            if countries_ is not None:
                                countries.append(countries_)
                                countries_dt[countries_] = tag_
                        tag.append(tag_)
                        tag_single = tag_
                        for potential_country in t.subtree:
                            if (potential_country.ent_type_=="GPE")&(potential_country.ent_id_ != '')& (potential_country.ent_id_ != current_country)& ('following' not in [tc.text for tc in potential_country.lefts]):
                                specific_country.append(potential_country.ent_id_)

                    # If one of the negative nouns is present then we tag it as close unless a negation is present in the children
                    elif ((t.pos_ == "NOUN") & (t.lemma_ in neg_nouns)):
                        tag_ = "close"
                        # if negation is present in one of the children associated with the verb we invert the tag
                        for c_ in t.children:
                            if c_.dep == "neg":
                                tag_ = "open"
                            countries_ = all_country_closure(c_,other_countries_in_this_sentence)
                            if countries_ is not None:
                                countries.append(countries_)
                                countries_dt[countries_] = tag_
                        tag.append(tag_)
                        tag_single = tag_
                        for potential_country in t.subtree:
                            if (potential_country.ent_type_=="GPE")&(potential_country.ent_id_ != '')& (potential_country.ent_id_ != current_country)& ('following' not in [tc.text for tc in potential_country.lefts]):
                                specific_country.append(potential_country.ent_id_)

                    #if ((t.pos_ == "VERB") & (t.lemma_ in restrict_verb)):
                    #    tag_ = 'restrict'
                    #    tag.append('restrict')
                    #    tag_single = tag_

                    # In cases where the complete restriction is mentioned using one of the noun chunks we identify those mentions and then label the restriction to "all" countries
                    for current_nc in doc_.noun_chunks: 
                        for nc_ in noun_chunks_:
                            if nc_ == current_nc.text:
                                for vs in current_nc.root.ancestors:
                                    if ((vs.pos_ == "VERB")& ((t.lemma_ in pos_verbs_to_filter)| (t.lemma_ in pos_verbs_to_filter)))& (len(other_countries_in_this_sentence) == 0):
                                        countries.append("all")
                                        countries_dt["all"] = tag_single
                                    if ((vs.pos_ == "NOUN")& ((t.lemma_ in pos_nouns)| (t.lemma_ in neg_nouns)))& (len(other_countries_in_this_sentence) == 0):
                                        countries.append("all")
                                        countries_dt["all"] = tag_single

                # Potential country tags
                if ((tag_single == "open")|(tag_single == "close")) & (len(specific_country)>0):
                    for sc in specific_country:
                        countries_dt[sc] = tag_single

                # In some messages the word "non" is used to denote negation for countries. These mentions are identified and the tag is inverted
                for ix,sus_c in enumerate(doc_):
                    if (sus_c.ent_type_=="GPE")&(sus_c.ent_id_ != '')& (sus_c.ent_id_ != current_country) &(sus_c.ent_id_ not in countries_dt.keys())& ('following' not in [tc.text for tc in sus_c.lefts]):
                        country_prefix = ''
                        for ix_ in range(ix-5,ix):
                            # Negation for NON mentions
                            if (doc_[ix_].lemma_ == "non"):
                                if sus_c.ent_id_ in ['EUM','SCH']:
                                    country_prefix = "N"
                                else:
                                    country_prefix = "negate"
                        if country_prefix == "N":
                            countries.append('N'+sus_c.ent_id_)
                            countries_dt['N'+sus_c.ent_id_] = tag_single#f_tag
                        elif country_prefix == "negate":
                            countries.append(sus_c.ent_id_)
                            if tag_single == "open":
                                countries_dt[sus_c.ent_id_] = "close"#f_tag
                            elif tag_single == "close":
                                countries_dt[sus_c.ent_id_] = "open"
                            else:
                                countries_dt[sus_c.ent_id_] = "na"
                        else:
                            countries.append(sus_c.ent_id_)
                            if tag_single == "open":
                                countries_dt[sus_c.ent_id_] = "open"#f_tag
                            elif tag_single == "close":
                                countries_dt[sus_c.ent_id_] = "close"
                            else:
                                countries_dt[sus_c.ent_id_] = "na"

                # Negation for exceptions
                # Tag is inverted for countries that precede with one of the following words: except, exception, outside, out, other, unless
                negation_countries =[]
                for idx,s in enumerate(doc_):
                    if (s.lemma_ =="except")|(s.lemma_ == "exception")|(s.lemma_ == "outside")|(s.lemma_ == "out")|(s.lemma_ == "other")|(s.lemma_ == "unless")|(s.lemma_ == "apart"):
                        for _ in range(idx+1,idx+25):
                            #print(_)
                            try:
                                if (doc_[_].ent_type_=="GPE")&(doc_[_].ent_id_ != '')& (doc_[_].ent_id_ != current_country)& ('following' not in [tc.text for tc in doc_[_].lefts]):
                                    for child in doc_[_].subtree:
                                        if (child.ent_type_=="GPE")&(child.ent_id_ != '')& (child.ent_id_ != current_country):
                                            # print(child,child.ent_id_,countries_dt[child.ent_id_])
                                            negation_countries.append(child.ent_id_)
                            except Exception as e:
                                pass
                                #print(str(e))
                if len(negation_countries) > 0:
                    #print("NEGATION")
                    for neg_country in set(negation_countries):
                        if neg_country in countries_dt.keys():
                            if ("EUM" in neg_country)|("SCH" in neg_country):
                                countries_dt["N"+ neg_country] = countries_dt[neg_country]
                                del countries_dt[neg_country]
                            elif countries_dt[neg_country] == 'open':
                                countries_dt[neg_country] = 'close'
                            elif countries_dt[neg_country] == 'close':
                                countries_dt[neg_country] = 'open'
                            else:
                                countries_dt[neg_country] == 'na'

                #if the exact intent of the restriction is uncles tag it as "na"
                for s in na_extension:
                        if s in doc_.text:
                            tag.append("na")

                # To overocme contradicting messages we set the flag to na
                if (len(set(tag)) >1) &(len(countries_dt.keys()) > 0):
                    for key_, value_ in countries_dt.items():
                        countries_dt[key_] = "na"

                # consolidate the restrictions by country
                if len(countries_dt.keys()) > 0 :
                    each_country[cc].append(countries_dt)
                    #print(doc_.text)
                    #spacy.displacy.render(doc_, style="ent", jupyter=True)
                    #print("Tag: {}".format(tag))
                    #print("Countries affected: {}".format(countries))
                    #print("Countries affected dict: {}".format(countries_dt))
                    ##print("tags - {}".format(f_tag))
                    #print("tag single - {}".format(tag_single))
                    ##print("Home country: {}, {}, {}".format(r['iso3'], r['adm0_name']))
                    #print("----")
                    #relevant_messages.append(doc_.text)
    return each_country
# [___CELL_SEPARATOR___]
def integrate_restriction_to_dataframe(each_country):
    master_dict = dict()
    for main_c in each_country.keys():
        master_dict[main_c] = dict()
        for dt in each_country[main_c]:
            for k,v in dt.items():
                if not k in master_dict[main_c].keys():
                    master_dict[main_c][k] = []
                master_dict[main_c][k].append(v)


    # Remove 'all' if other country is mentioned
    for country__ in master_dict.keys():
        if (len(master_dict[country__].keys()) > 1) & ('all' in master_dict[country__].keys()):
                master_dict[country__].pop("all")
    
    for country__ in master_dict.keys():
        non_eu_countries = {'NEU','NEUM','NSCH'}.intersection(set(master_dict[country__].keys()))
        set_all_non_eu_to_na = 0
        if len(non_eu_countries) > 0:
            for cc in non_eu_countries:
                if (set(master_dict[country__][cc]) == {'na'})|(set(master_dict[country__][cc]) == {'restrict'}) | (len(set(master_dict[country__][cc])) >1):
                    #print(master_dict[country__][cc],cc)
                    #print("NEU--")
                    set_all_non_eu_to_na = 1

            if set_all_non_eu_to_na == 1:
                for cc in non_eu_countries:
                    #print(country__,cc)
                    #print(master_dict[country__][cc])
                    master_dict[country__][cc] = ['na']

    for country__ in master_dict.keys():
        eu_countries = {'EUM','SCH'}.intersection(set(master_dict[country__].keys()))
        set_all_eu_to_na = 0
        if len(eu_countries) > 0:
            for cc in eu_countries:
                if (set(master_dict[country__][cc]) == {'na'})|(set(master_dict[country__][cc]) == {'restrict'}) | (len(set(master_dict[country__][cc])) >1):
                    #print(master_dict[country__][cc],cc)
                    #print("EU--")
                    set_all_eu_to_na = 1

        if set_all_eu_to_na == 1:
            for cc in eu_countries:
                #print(country__)
                #print(master_dict[country__][cc],cc)
                master_dict[country__][cc] = ['na']

    res_dt = dict()

    for k in master_dict.keys():
        res_dt[k] = dict()
        european_c_ = list(set(european_regions).intersection(set(master_dict[k].keys())))
        if len(european_c_) > 0:
            for e_c_ in european_c_:
                countries = european_regions_dt[e_c_]
                for ec_ in countries:
                    #if :
                    #    res_dt[k][ec_] = -1#"conditions" #-1#
                    if set(master_dict[k][e_c_]) == {'open'}:
                        res_dt[k][ec_] = 3#"open" #1#
                    elif set(master_dict[k][e_c_]) == {'close'}:
                        res_dt[k][ec_] = 0#"close" #0#
                    elif (set(master_dict[k][e_c_]) == {"na"})|(set(master_dict[k][e_c_]) == {"restrict"})|(len(set(master_dict[k][e_c_])) > 1):
                        res_dt[k][ec_] = 1#"other" #-2#


        if "all" in master_dict[k].keys():
            for all_c in all_countries['Alpha-3 code'].unique():
                #if :
                #    res_dt[k][all_c] = -1#"conditions" #-1#
                if set(master_dict[k]["all"]) == {'open'}:
                    res_dt[k][all_c] = 3#"open" #1#
                elif set(master_dict[k]["all"]) == {'close'}:
                    res_dt[k][all_c] = 0#"close" #0#
                elif (set(master_dict[k]["all"]) == {"na"})|(set(master_dict[k]["all"]) == {"restrict"})|(len(set(master_dict[k]["all"])) > 1):
                    res_dt[k][all_c] = 1#"other" #-2#

                #restrictions_dict[cc][all_c]['message'].append(relevant_messages)

        for sub_o in master_dict[k].keys():
            if (sub_o not in european_regions) &(sub_o != 'all'):
                #if len(set(master_dict[k][sub_o])) > 1:
                #    res_dt[k][sub_o] = 2#"special" #2#
                if set(master_dict[k][sub_o]) == {'open'}:
                    res_dt[k][sub_o] = 3#"open" #1#
                elif set(master_dict[k][sub_o]) == {'close'}:
                    res_dt[k][sub_o] = 0#"close" #0#
                elif (set(master_dict[k][sub_o]) == {"na"})|(set(master_dict[k][sub_o]) == {"restrict"}) |(len(set(master_dict[k][sub_o])) > 1) :
                    res_dt[k][sub_o] = 2
                #elif (set(master_dict[k][sub_o]) == {"na"})|(set(master_dict[k][sub_o]) == {"restrict"}):
                #    res_dt[k][sub_o] = -2#"other" #-2#
                #restrictions_dict[cc][k]['message'].append(relevant_messages)
        res_dt[k][k] = 4#'home' #3#
        res_dt[k]['XYZ'] = 0

    res_df = pd.DataFrame(res_dt)

    closure_df = pd.DataFrame()
    for col_c in res_df.columns:

        df_ = pd.DataFrame(res_df[col_c])
        df_['home'] = col_c
        df_.reset_index(inplace=True)
        df_.rename(columns={'index':'other',col_c:'restriction'},inplace=True)
        closure_df = pd.concat([closure_df,df_])
    

    return closure_df
# [___CELL_SEPARATOR___]
DATA_FOLDER = "/project_data/data_asset/iata/sun/"
# [___CELL_SEPARATOR___]
files_dt = dict()
files_dt['download_date'] = []
files_dt['download_week'] = []
files_dt['file_location'] = []
for file_ in os.listdir(DATA_FOLDER):
    #print(file_)
    files_dt['download_date'].append(datetime.datetime.strptime(file_.split("_")[-1].split(".csv")[0],"%Y%m%d"))
    files_dt['download_week'].append(datetime.datetime.strptime(file_.split("_")[-1].split(".csv")[0],"%Y%m%d").isocalendar()[1])
    files_dt['file_location'].append(os.path.join(DATA_FOLDER,file_))

# The file with the latest date for the selected week is considered
files_df = pd.DataFrame(files_dt)
weekly_files_df = files_df[files_df['download_date'] == files_df.groupby("download_week",sort="as")["download_date"].transform("max")]
# [___CELL_SEPARATOR___]
weekly_files_df
# [___CELL_SEPARATOR___]
closure_timeline_df = pd.DataFrame()

for idx,r in weekly_files_df.iterrows():
    df = pd.read_csv(r['file_location'])
    df = df.dropna(subset=['info'])
    df['cleaned_message_with_punct'] = None

    for idx,row in df.iterrows():
        if row['info'] is not None:
            #Make everything to lower case
            message = row['info'].lower().strip()

            message_ = clean_message_keep_punct(message)

            df.at[idx,"cleaned_message_with_punct"] = message_
    
    # Each file's restrictions
    each_country_dict = country_restrictions(df)
    
    # Integrate the restrictions to a dataframe
    closure_df = integrate_restriction_to_dataframe(each_country_dict)
    
    # Include the restrictions the other way round too
    closure_df['external_countries'] = closure_df['home']
    closure_df['external_restriction'] = closure_df['restriction']
    for a,r_ in closure_df.groupby('other'):
        if not a in list(r_['external_countries']):
            new_row = pd.DataFrame({'other':a,'external_countries':a,'external_restriction':4},index=[0])
            closure_df = closure_df.append(new_row,ignore_index=True)
    
    #Add time information
    closure_df['download_date'] = r['download_date']
    closure_df['active_week'] = r['download_week']
    
    print(len(closure_df))
    
    
    
    closure_timeline_df = pd.concat([closure_timeline_df,closure_df])
# [___CELL_SEPARATOR___]
closure_timeline_df.to_csv("/project_data/data_asset/iata_country_closure_timeline.csv",index=False)
# [___CELL_SEPARATOR___]
closure_timeline_df.head()
# [___CELL_SEPARATOR___]
