import os
import collections

from tf.fabric import Fabric
from tf.app import use
# [___CELL_SEPARATOR___]
BASE = os.path.expanduser('~/github')
ORG = 'etcbc'
REPO = 'bhsa'
VERSION = 'c'

REPO_PATH = f'{BASE}/{ORG}/{REPO}'
TF_IN = f'{REPO_PATH}/tf/{VERSION}'
TF_OUT = f'{REPO_PATH}/_temp/lex/{VERSION}'
# [___CELL_SEPARATOR___]
lexFeatures = '''
  gloss
  nametype
  voc_lex
  voc_lex_utf8
'''.strip().split()
# [___CELL_SEPARATOR___]
generic = dict(
  author='Eep Talstra Centre for Bible and Computer',
  dataset='BHSA',
  datasetName='Biblia Hebraica Stuttgartensia Amstelodamensis',
  email='shebanq@ancient-data.org',
  encoders='Constantijn Sikkel (QDF), and Dirk Roorda (TF)',
  version='c',
  website='https://shebanq.ancient-data.org',
)
# [___CELL_SEPARATOR___]
featureMeta = {feat: dict(valueType='str') for feat in lexFeatures}
# [___CELL_SEPARATOR___]
metaData = {'': generic}
metaData.update(featureMeta)
metaData
# [___CELL_SEPARATOR___]
TFin = Fabric(locations=TF_IN)
# [___CELL_SEPARATOR___]
api = TFin.load(lexFeatures)
api.makeAvailableIn(globals())
# [___CELL_SEPARATOR___]
nodeFeatures = collections.defaultdict(dict)

for feat in lexFeatures:
  print(f'{feat} ...')
  for lx in F.otype.s('lex'):
    value = Fs(feat).v(lx)
    if value is not None:
      for w in L.d(lx, otype='word'):
        nodeFeatures[feat][w] = value
      nodeFeatures[feat][lx] = value
# [___CELL_SEPARATOR___]
TFout = Fabric(locations=TF_OUT)
# [___CELL_SEPARATOR___]
TFout.save(nodeFeatures=nodeFeatures, edgeFeatures={}, metaData=metaData)
# [___CELL_SEPARATOR___]
A = use('bhsa', hoist=globals(), check=True)
# [___CELL_SEPARATOR___]
query = '''
word g_word~^.@(?!\d) voc_lex~^.E.E.$
'''

query2 = '''
word g_word~^.@(?!\d)
'''

query3 = '''
word voc_lex~^.E.E.$
'''
# [___CELL_SEPARATOR___]
results = A.search(query)
# [___CELL_SEPARATOR___]
results = A.search(query2)
# [___CELL_SEPARATOR___]
results = A.search(query3)