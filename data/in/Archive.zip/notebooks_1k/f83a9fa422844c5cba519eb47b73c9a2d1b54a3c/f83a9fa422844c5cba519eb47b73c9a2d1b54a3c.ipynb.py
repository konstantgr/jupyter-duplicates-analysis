import tensorflow as tf

# [___CELL_SEPARATOR___]
dataset = tf.data.Dataset.from_tensor_slices([1, 2, 3]) 
for element in dataset: 
    print(element)
# [___CELL_SEPARATOR___]
import numpy as np
a = np.array([1,2,3, 4])

dataset = tf.data.Dataset.from_tensor_slices(a) 
for element in dataset: 
    print(element)
# [___CELL_SEPARATOR___]
dataset = tf.data.TextLineDataset(["1.txt", "2.txt"]) 
for element in dataset: 
    print(element)
# [___CELL_SEPARATOR___]
dataset = tf.data.TFRecordDataset(["file1.tfrecords", "file2.tfrecords"])
# [___CELL_SEPARATOR___]
#https://storage.googleapis.com/download.tensorflow.org/data/fsns-20160927/testdata/fsns-00000-of-00001

dataset = tf.data.TFRecordDataset(filenames = ["fsns.tfrec"])
# [___CELL_SEPARATOR___]
raw_example = next(iter(dataset))
parsed = tf.train.Example.FromString(raw_example.numpy())
parsed.features.feature['image/text']

# [___CELL_SEPARATOR___]
dataset = tf.data.Dataset.list_files("*.txt")
for element in dataset: 
    print(element)
# [___CELL_SEPARATOR___]
def fib(n):
    a, b = 0, 1
    for _ in range(n):
        yield a
        a, b = b, a + b
# [___CELL_SEPARATOR___]
for e in fib(4):
    print (e)
# [___CELL_SEPARATOR___]
dataset = tf.data.Dataset.from_generator(
    fib, args=[8], output_types=tf.int32, output_shapes = (), )
for element in dataset: 
    print(element)