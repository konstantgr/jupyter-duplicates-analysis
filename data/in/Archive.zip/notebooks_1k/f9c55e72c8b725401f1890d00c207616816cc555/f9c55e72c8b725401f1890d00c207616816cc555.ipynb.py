%matplotlib inline

import math
import matplotlib
import numpy as np
import pandas as pd
import seaborn as sns
import time

from datetime import date, datetime, time, timedelta
from matplotlib import pyplot as plt
from pylab import rcParams
from sklearn.metrics import mean_squared_error
from tqdm import tqdm_notebook

#### Input params ##################
stk_path = "./data/VTI_20130102_20181231.csv"
H_list = [1, 21, 42, 63]        # Forecast horizon we will be testing, in days. Note there are about 252 trading days in a year
train_size = 252*3              # Use 3 years of data as train set. Note there are about 252 trading days in a year
val_size = 252                  # Use 1 year of data as validation set

fontsize = 14
ticklabelsize = 14
####################################

train_val_size = train_size + val_size # Size of train+validation set
print("No. of days in train+validation set = " + str(train_val_size))
# [___CELL_SEPARATOR___]
print("We will start forecasting on day %d" % (train_val_size+1))
# [___CELL_SEPARATOR___]
def get_mape(y_true, y_pred): 
    """
    Compute mean absolute percentage error (MAPE)
    """
    y_true, y_pred = np.array(y_true), np.array(y_pred)
    return np.mean(np.abs((y_true - y_pred) / y_true)) * 100

def get_mae(a, b):
    """
    Comp mean absolute error e_t = E[|a_t - b_t|]. a and b can be lists.
    Returns a vector of len = len(a) = len(b)
    """
    return np.mean(abs(np.array(a)-np.array(b)))

def get_rmse(a, b):
    """
    Comp RMSE. a and b can be lists.
    Returns a scalar.
    """
    return math.sqrt(np.mean((np.array(a)-np.array(b))**2))

def get_preds_last_val(data, H):
    """
    Given a series data, use its last value to forecast for the next H timesteps
    """
    return np.array([data[-1]]*H)
    
# [___CELL_SEPARATOR___]
df = pd.read_csv(stk_path, sep = ",")

# Convert Date column to datetime
df.loc[:, 'Date'] = pd.to_datetime(df['Date'],format='%Y-%m-%d')

# Change all column headings to be lower case, and remove spacing
df.columns = [str(x).lower().replace(' ', '_') for x in df.columns]

# Sort by datetime
df.sort_values(by='date', inplace=True, ascending=True)

df.head(10)
# [___CELL_SEPARATOR___]
df['date'].min(), df['date'].max() 
# [___CELL_SEPARATOR___]
# Plot adjusted close over time
rcParams['figure.figsize'] = 10, 8 # width 10, height 8

ax = df.plot(x='date', y='adj_close', style='b-', grid=True)
ax.set_xlabel("date")
ax.set_ylabel("USD")
# [___CELL_SEPARATOR___]
i = train_val_size # Predict for day i, for the next H-1 days. Note indexing of days start from 0.
H = 21 # We will test with this value of H and observe the results
print("Predicting on day %d, date %s, with forecast horizon H = %d" % (i, df.iloc[i]['date'], H))
# [___CELL_SEPARATOR___]
# Run prediction
preds_list = get_preds_last_val(df['adj_close'][i-train_val_size:i].values, H)
# [___CELL_SEPARATOR___]
print("For forecast horizon %d, predicting on day %d, date %s, the RMSE is %f" % (H, i, df['date'][i], get_rmse(df[i:i+H]['adj_close'], preds_list)))
print("For forecast horizon %d, predicting on day %d, date %s, the mean MAPE is %f" % (H, i, df['date'][i], get_mape(df[i:i+H]['adj_close'], preds_list)))
print("For forecast horizon %d, predicting on day %d, date %s, the mean MAE is %f" % (H, i, df['date'][i], get_mae(df[i:i+H]['adj_close'], preds_list)))
# [___CELL_SEPARATOR___]
# Plot the predictions
rcParams['figure.figsize'] = 10, 8 # width 10, height 8
matplotlib.rcParams.update({'font.size': 14})

ax = df.plot(x='date', y='adj_close', style='bx-', grid=True)

# Plot the predictions
ax.plot(df['date'][i:i+H], preds_list, marker='x')
    
ax.set_xlabel("date")
ax.set_ylabel("USD")
ax.legend(['adj_close', 'predictions'])
ax.set_ylim([105, 120])
ax.set_xlim([date(2016, 11, 1), date(2017, 2, 28)])
# [___CELL_SEPARATOR___]
rmse = [] # root mean square error
mape = [] # mean absolute percentage error
mae = []  # mean absolute error
preds_dict = {}
H = 21 # We will test with this value of H and observe the results
i_list = range(train_val_size, len(df)-21, 42)
for i in i_list:
# for i in tqdm_notebook(range(train_val_size, len(df)-H, int(H/2))): # Do a forecast on day i
    print("Predicting on day %d, date %s" % (i, df['date'][i]))
    preds_list = get_preds_last_val(df['adj_close'][i-train_val_size:i].values, H)
    
    # Collect the predictions
    preds_dict[i] = preds_list
    
    # Compute error metrics
    rmse.append(get_rmse(df[i:i+H]['adj_close'], preds_list))
    mape.append(get_mape(df[i:i+H]['adj_close'], preds_list))
    mae.append(get_mae(df[i:i+H]['adj_close'], preds_list))

print("Altogether we made %d forecasts, each of length %d days" % (len(rmse), H))
# [___CELL_SEPARATOR___]
print("For forecast horizon %d, the mean RMSE is %f" % (H, np.mean(rmse)))
print("For forecast horizon %d, the mean MAPE is %f" % (H, np.mean(mape)))
print("For forecast horizon %d, the mean MAE is %f" % (H, np.mean(mae)))
# [___CELL_SEPARATOR___]
results = pd.DataFrame({'day': i_list,
                        'rmse': rmse,
                        'mape': mape,
                        'mae': mae})
results
# [___CELL_SEPARATOR___]
# Plot the predictions
rcParams['figure.figsize'] = 10, 8 # width 10, height 8

ax = df.plot(x='date', y='adj_close', style='b-', grid=True)

# Plot the predictions
for key in preds_dict:
    ax.plot(df['date'][key:key+H], preds_dict[key])

ax.legend(['adj_close', 'predictions'])
ax.set_xlabel("date")
ax.set_ylabel("USD")
# [___CELL_SEPARATOR___]
# Plot the predictions, and zoom in
rcParams['figure.figsize'] = 10, 8 # width 10, height 8

ax = df.plot(x='date', y='adj_close', style='b-', grid=True)

# Plot the predictions
for key in preds_dict:
    ax.plot(df['date'][key:key+H], preds_dict[key])
    
ax.set_xlabel("date")
ax.set_ylabel("USD")
ax.legend(['adj_close', 'predictions'])
ax.set_ylim([105, 150])
ax.set_xlim([date(2017, 1, 1), date(2018, 12, 31)])
# [___CELL_SEPARATOR___]
rmse_list = [] # rmse for each H in H_list
mape_list = [] # mape for each H in H_list
mae_list = []  # mae for each H in H_list

for H in tqdm_notebook(H_list):
    rmse = [] # root mean square error
    mape = [] # mean absolute percentage error
    mae = []  # mean absolute error

    for i in tqdm_notebook(range(train_val_size, len(df)-H, max(1, int(H/2)))): # Do a forecast on day i
        preds_list = get_preds_last_val(df['adj_close'][i-train_val_size:i].values, H)
    
        # Compute error metrics
        rmse.append(get_rmse(df[i:i+H]['adj_close'], preds_list))
        mape.append(get_mape(df[i:i+H]['adj_close'], preds_list))
        mae.append(get_mae(df[i:i+H]['adj_close'], preds_list))
        
    rmse_list.append(np.mean(rmse))
    mape_list.append(np.mean(mape))
    mae_list.append(np.mean(mae))
    
# [___CELL_SEPARATOR___]
# Plot the error metrics for various forecast horizons
plt.figure(figsize=(12, 8), dpi=80)
plt.plot(H_list, rmse_list, 'x-')
plt.plot(H_list, mape_list, 'ro-')
plt.plot(H_list, mae_list, 'gs-')
plt.xlabel('Forecast horizon (days)')
plt.ylabel('Error metrics')
plt.legend(['RMSE', 'MAPE(%)', 'MAE'], loc = 'upper left')
plt.grid()

matplotlib.rcParams.update({'font.size': 14})
# [___CELL_SEPARATOR___]
