from netgan.netgan import *
import tensorflow as tf
from netgan import utils
import scipy.sparse as sp
import numpy as np
from matplotlib import pyplot as plt
from sklearn.metrics import roc_auc_score, average_precision_score
import time

%matplotlib inline
# [___CELL_SEPARATOR___]
_A_obs, _X_obs, _z_obs = utils.load_npz('data/cora_ml.npz')
_A_obs = _A_obs + _A_obs.T
_A_obs[_A_obs > 1] = 1
lcc = utils.largest_connected_components(_A_obs)
_A_obs = _A_obs[lcc,:][:,lcc]
_N = _A_obs.shape[0]
# [___CELL_SEPARATOR___]
val_share = 0.1
test_share = 0.05
seed = 481516234
# [___CELL_SEPARATOR___]
loader = np.load('pretrained/cora_ml/split.npy').item()
# [___CELL_SEPARATOR___]
train_ones = loader['train_ones']
val_ones = loader['val_ones']
val_zeros = loader['val_zeros']
test_ones = loader['test_ones']
test_zeros = loader['test_zeros']
# [___CELL_SEPARATOR___]
train_graph = sp.coo_matrix((np.ones(len(train_ones)),(train_ones[:,0], train_ones[:,1]))).tocsr()
assert (train_graph.toarray() == train_graph.toarray().T).all()
# [___CELL_SEPARATOR___]
rw_len = 16
batch_size = 128
# [___CELL_SEPARATOR___]
walker = utils.RandomWalker(train_graph, rw_len, p=1, q=1, batch_size=batch_size)
# [___CELL_SEPARATOR___]
netgan = NetGAN(_N, rw_len, walk_generator= walker.walk, gpu_id=3, use_gumbel=True, disc_iters=3,
                W_down_discriminator_size=32, W_down_generator_size=128,
                l2_penalty_generator=1e-7, l2_penalty_discriminator=5e-5,
                generator_layers=[40], discriminator_layers=[30], temp_start=5, temperature_decay=0.99998, learning_rate=0.0003, legacy_generator=True)
# [___CELL_SEPARATOR___]
saver = tf.train.Saver()
saver.restore(netgan.session, "pretrained/cora_ml/pretrained_gen.ckpt")
# [___CELL_SEPARATOR___]
sample_many = netgan.generate_discrete(10000, reuse=True, legacy=True)
# [___CELL_SEPARATOR___]
samples = []
# [___CELL_SEPARATOR___]
for _ in range(60):
    if (_+1) % 500 == 0:
        print(_+1)
    samples.append(sample_many.eval({netgan.tau: 0.5}))
# [___CELL_SEPARATOR___]
rws = np.array(samples).reshape([-1, rw_len])
scores_matrix = utils.score_matrix_from_random_walks(rws, _N).tocsr()
# [___CELL_SEPARATOR___]
A_select = sp.csr_matrix((np.ones(len(train_ones)), (train_ones[:,0], train_ones[:,1])))
# [___CELL_SEPARATOR___]
A_select = train_graph
# [___CELL_SEPARATOR___]
sampled_graph = utils.graph_from_scores(scores_matrix, A_select.sum())
plt.spy(sampled_graph, markersize=.2)
plt.show()
# [___CELL_SEPARATOR___]
plt.spy(A_select, markersize=.2)
plt.show()
# [___CELL_SEPARATOR___]
utils.edge_overlap(A_select.toarray(), sampled_graph)/A_select.sum()
# [___CELL_SEPARATOR___]
utils.compute_graph_statistics(sampled_graph)
# [___CELL_SEPARATOR___]
utils.compute_graph_statistics(A_select.toarray())