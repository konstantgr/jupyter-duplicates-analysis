import pandas as pd
import numpy as np

from plotnine import *
from plotnine.data import *

%matplotlib inline
# [___CELL_SEPARATOR___]
mpg.head()
# [___CELL_SEPARATOR___]
(
    ggplot(mpg, aes(x='factor(cyl)', y='cty')) 
    + geom_violin()
    + xlab('cylinders')
    + ylab('miles/galon')
)
# [___CELL_SEPARATOR___]
(
    ggplot(mpg, aes(x='factor(cyl)', y='cty')) 
    + geom_violin()
    + geom_jitter(width=.05, height=0)
    + xlab('cylinders')
    + ylab('miles/galon')
)
# [___CELL_SEPARATOR___]
(
    ggplot(mpg, aes(x='factor(cyl)', y='cty')) 
    + geom_violin(scale='count')
    + xlab('cylinders')
    + ylab('miles/galon')
)