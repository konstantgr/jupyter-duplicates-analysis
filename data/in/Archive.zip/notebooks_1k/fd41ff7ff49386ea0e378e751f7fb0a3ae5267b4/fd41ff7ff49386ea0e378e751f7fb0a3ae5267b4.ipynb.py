# !pip install keras
# !pip install tensorflow
# !pip install plotly
# !pip install gensim
# !pip install Word2Vec
# !pip install get_tmpfile
# !pip install gensim.test.utils
# !pip install boto
# !pip install google-compute-engine


# [___CELL_SEPARATOR___]
# Keras
from keras.preprocessing.text import Tokenizer
from keras.preprocessing.sequence import pad_sequences
from keras.models import Sequential
from keras.layers import Dense, Flatten, LSTM, Conv1D, MaxPooling1D, Dropout, Activation
from keras.layers.embeddings import Embedding
from keras.models import model_from_json
from keras.preprocessing.text import text_to_word_sequence




## Plot
import plotly.offline as py
import plotly.graph_objs as go
py.init_notebook_mode(connected=True)
import matplotlib as plt
# import matplotlib.pyplot

# NLTK
import nltk
from nltk.corpus import stopwords
nltk.download('stopwords')
from nltk.stem import SnowballStemmer


# Other
import re
import string
import numpy as np
import pandas as pd
from sklearn.manifold import TSNE
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import LabelBinarizer
from sklearn.model_selection import train_test_split
from sklearn.utils import shuffle
# from numpy import util


# Word2Vec
from gensim.test.utils import common_texts, get_tmpfile # not working
from gensim.models import Word2Vec

import re
from collections import Counter
import os








# [___CELL_SEPARATOR___]
final_csv = pd.read_csv(
    '/s3/bucket/finance/finance_text_classification/data/final_shuffled_25000.csv')
# [___CELL_SEPARATOR___]
final_csv
# [___CELL_SEPARATOR___]
from nltk.corpus import stopwords 
df = final_csv
stop_words = set(stopwords.words('english'))
month = ['january', 'february', 'march', 'april', 'may', 'june', 'july','august', 'september', 'october','november', 'december']

# remove stop words
stop_words_removed_8K = []

list_of_original_content = list(df["8K_Content"])

for i in range(len(list_of_original_content)):
    list_to_append = []
    split_content = list_of_original_content[i].split()
#     print(split_content)
    for j in range(len(split_content)):
#         print(split_content[j])
        if split_content[j].lower() not in stop_words and split_content[j].lower() not in month:
            list_to_append += [split_content[j]]
#     print(list_to_append)
    list_to_append = " ".join(list_to_append)
    stop_words_removed_8K.append(list_to_append)

        
tokenizer = Tokenizer(num_words=30000, filters='!"#$%&()*+,-./:;<=>?@[\]^_`{|}~ 123456789', lower=True, split=' ', 
                      char_level=False, oov_token=None, document_count=0)
tokenizer.fit_on_texts(stop_words_removed_8K)


seq_len = 300 # set sequence length
sequences = tokenizer.texts_to_sequences(stop_words_removed_8K)
data = pad_sequences(sequences, 
                     maxlen=seq_len, padding='post', 
                     truncating='post') # takes about 5-10 mins
# [___CELL_SEPARATOR___]
# vocab size
vocabulary_size = max(tokenizer.word_index.values())
print(vocabulary_size)
# [___CELL_SEPARATOR___]
final_csv['8K_Content_sequences'] = data.tolist()
# [___CELL_SEPARATOR___]
final_csv
# [___CELL_SEPARATOR___]


X_train = final_csv['8K_Content_sequences'][final_csv['Year'] <= 2008]
X_dev = final_csv['8K_Content_sequences'][(final_csv['Year'] >= 2009) & 
                                       (final_csv['Year'] <= 2010)]
X_test = final_csv['8K_Content_sequences'][final_csv['Year'] >= 2011]

y_train = final_csv[['down','stay','up']][final_csv['Year'] <= 2008]
y_dev = final_csv[['down','stay','up']][(final_csv['Year'] >= 2009) & 
                                       (final_csv['Year'] <= 2010)]
y_test = final_csv[['down','stay','up']][final_csv['Year'] >= 2011]
# [___CELL_SEPARATOR___]

model_lstm = Sequential()
model_lstm.add(Embedding(vocabulary_size, 100, input_length=seq_len))
model_lstm.add(LSTM(100, dropout=0.2, recurrent_dropout=0.2))
model_lstm.add(Dense(3, activation='softmax'))
model_lstm.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
# [___CELL_SEPARATOR___]
# train network

# model_lstm.fit(np.array(X_train[:5].values.tolist()), np.array(y_train[:5].values.tolist()), validation_split=0.4, epochs=5)

model_lstm.fit(np.array(X_train.values.tolist()), 
               np.array(y_train.values.tolist()), 
               validation_data=(np.array(X_dev.values.tolist()), 
                                np.array(y_dev.values.tolist())), 
               epochs=5)

#TODO: change validation split to validation_data

# takes about 3 mins per epoch using 2/3 of full dataset
# takes about 3 hours per epoch using full dataset (less testing set) 

# [___CELL_SEPARATOR___]
# test network

model_lstm.evaluate(np.array(X_test.values.tolist()), 
                    np.array(y_test.values.tolist()))
                    
# [___CELL_SEPARATOR___]
# predict
model_lstm_preds = model_lstm.predict(np.array(X_test.values.tolist()))
# [___CELL_SEPARATOR___]
model_lstm_preds
# [___CELL_SEPARATOR___]
# pred_down = []
# pred_stay = []
# pred_up = []

# for i in model_lstm_preds:
#     if np.argmax(i) == 0:
#         pred_down.append(1)
#         pred_stay.append(0)
#         pred_up.append(0)
#     elif np.argmax(i) == 1:
#         pred_down.append(0)
#         pred_stay.append(1)
#         pred_up.append(0)
#     else: 
#         pred_down.append(0)
#         pred_stay.append(0)
#         pred_up.append(1)
# [___CELL_SEPARATOR___]
predictions = pd.read_csv('lstm_predictions_updated.csv')

# predictions[['x', 'y_down', 'y_stay', 'y_up', 
#              'pred_down', 'pred_stay', 'pred_up']].to_csv(
#     'lstm_predictions_updated.csv')
# [___CELL_SEPARATOR___]
predictions.head()
# [___CELL_SEPARATOR___]
actual = []

for i in predictions[['y_down', 'y_stay', 'y_up']].idxmax(1):
    actual.append(i.split('_')[1])
# [___CELL_SEPARATOR___]
preds = []

for i in predictions[['pred_down', 'pred_stay', 'pred_up']].idxmax(1):
    preds.append(i.split('_')[1])
# [___CELL_SEPARATOR___]
predictions['actual'] = actual
predictions['preds'] = preds
# [___CELL_SEPARATOR___]
from sklearn.metrics import confusion_matrix
y_test = predictions['actual']
y_pred = predictions['preds']
confusion_matrix(y_true, y_pred)
# [___CELL_SEPARATOR___]
class_names = y_test.unique()
class_names
# [___CELL_SEPARATOR___]
import numpy as np
import matplotlib.pyplot as plt

def plot_confusion_matrix(y_true, y_pred, classes,
                          normalize=False,
                          title=None,
                          cmap=plt.cm.Blues):
    """
    This function prints and plots the confusion matrix.
    Normalization can be applied by setting `normalize=True`.
    """
    if not title:
        if normalize:
            title = 'Normalized confusion matrix'
        else:
            title = 'Confusion matrix, without normalization'

    # Compute confusion matrix
    cm = confusion_matrix(y_true, y_pred)
    # Only use the labels that appear in the data
    classes = ['down', 'stay', 'up']
    if normalize:
        cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
        print("Normalized confusion matrix")
    else:
        print('Confusion matrix, without normalization')

    print(cm)

    fig, ax = plt.subplots()
    im = ax.imshow(cm, interpolation='nearest', cmap=cmap)
    ax.figure.colorbar(im, ax=ax)
    # We want to show all ticks...
    ax.set(xticks=np.arange(cm.shape[1]),
           yticks=np.arange(cm.shape[0]),
           # ... and label them with the respective list entries
           xticklabels=classes, yticklabels=classes,
           title=title,
           ylabel='True label',
           xlabel='Predicted label')

    # Rotate the tick labels and set their alignment.
    plt.setp(ax.get_xticklabels(), rotation=45, ha="right",
             rotation_mode="anchor")

    # Loop over data dimensions and create text annotations.
    fmt = '.2f' if normalize else 'd'
    thresh = cm.max() / 2.
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            ax.text(j, i, format(cm[i, j], fmt),
                    ha="center", va="center",
                    color="white" if cm[i, j] > thresh else "black")
    fig.tight_layout()
    return ax


np.set_printoptions(precision=2)

# Plot non-normalized confusion matrix
plot_confusion_matrix(y_test, y_pred, classes=class_names,
                      title='Confusion matrix, without normalization')

# Plot normalized confusion matrix
plot_confusion_matrix(y_test, y_pred, classes=class_names, normalize=True,
                      title='Normalized confusion matrix')

plt.show()
# [___CELL_SEPARATOR___]
tp = 58
fp = 183 + 63
tn = 4737 + 468 + 237 + 77
fn = 61 + 480

print('accuracy is:', (58 + 4737 + 77) / (77 + 468 + 63 + 237 + 4737 + 183 + 61 + 480 + 58))
print('precision is:',  tp / (tp + fp))
print('recall is:', tp / (tp + fn))
# [___CELL_SEPARATOR___]
# predictions.to_csv('predictions_lstm.csv', index=False)
# [___CELL_SEPARATOR___]
pd.read_csv('predictions_lstm_updated.csv')
# [___CELL_SEPARATOR___]
final_csv['8K_Content'][final_csv['Year'] >= 2011]
# [___CELL_SEPARATOR___]
# reverse_word_map = dict(map(reversed, tokenizer.word_index.items()))
# def sequence_to_text(list_of_indices):
#     # Looking up words in dictionary
#     words = [reverse_word_map.get(letter) for letter in list_of_indices]
#     return(words)
# my_texts = list(map(sequence_to_text, X_test))

# [___CELL_SEPARATOR___]
# set model # for saving the model and weights to json and h5
model_num = 1
# [___CELL_SEPARATOR___]
# predictions to csv
np.savetxt('predictions_lstm_%d_cleaned.csv' %model_num, model_lstm_preds, delimiter=',')
print("Saved predictions to disk: ", 'predictions_lstm_%d_cleaned.csv' %model_num)
# [___CELL_SEPARATOR___]
# save model

# serialize model to JSON
model_lstm_json = model_lstm.to_json()
with open("model_lstm.json" %model_num, "w") as json_file:
    json_file.write(model_lstm_json)
# serialize weights to HDF5
model_lstm.save_weights("model_lstm.h5" %model_num)
print("Saved model to disk: ", 'model_lstm_%d_cleaned.json and model_lstm_%d_cleaned.h5' %(model_num, model_num))
# [___CELL_SEPARATOR___]
# load model
# note: latest file updated 11/30. 3,000 word sequence.

# load json and create model
json_file = open('model_lstm_%d_cleaned.json' %model_num, 'r')
loaded_model_json = json_file.read()
json_file.close()
loaded_model = model_from_json(loaded_model_json)

# load weights into new model
loaded_model.load_weights("model_lstm_%d_cleaned.h5" %model_num)
print("Loaded model from disk: ", 'model_lstm_%d_cleaned.json and model_lstm_%d_cleaned.h5' %(model_num, model_num))
# [___CELL_SEPARATOR___]
# evaluate loaded model on test data
loaded_model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
# loaded_model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
score = loaded_model.evaluate(np.array(X_test.values.tolist()), 
                              np.array(y_test.values.tolist()), verbose=0)
print("%s: %.2f%%" % (loaded_model.metrics_names[1], score[1]*100))