import os
import glob

import pylab as plt
import matplotlib
from IPython.display import display, HTML

import numpy as np
from scipy.sparse import lil_matrix
import pandas as pd
from pandas import HDFStore

import rpy2.robjects as robjects
from rpy2.robjects import pandas2ri
pandas2ri.activate()

from collections import defaultdict
import math

%matplotlib inline
# [___CELL_SEPARATOR___]
peaks = pd.read_csv('../data/intensities_pos.csv', index_col=0)
peaks.head()
peaks.columns = peaks.columns.values.astype(int)
# [___CELL_SEPARATOR___]
samples_peaks = pd.read_csv('../data/metadata_samples.csv', index_col=0)
samples_peaks.head()
# [___CELL_SEPARATOR___]
rna = pd.read_csv('../data/rna_all.csv', index_col=0)
display(rna.head())
# [___CELL_SEPARATOR___]
samples_rna = pd.read_csv('../data/metadata_rna.csv', index_col=0)
display(samples_rna)
# [___CELL_SEPARATOR___]
time = 7
parasite = 'INFEC'
treatment = 'Unsorted'
# [___CELL_SEPARATOR___]
pos = (samples_peaks['Time'] == time) & (samples_peaks['Parasite'] == parasite) & \
      (samples_peaks['Treatment'] == treatment)
    
groups_peaks = samples_peaks[pos]
display(groups_peaks)
# [___CELL_SEPARATOR___]
pos = (samples_rna['Time'] == time) & (samples_rna['Parasite'] == parasite) & \
      (samples_rna['Treatment'] == treatment)
    
groups_rna = samples_rna[pos]
display(groups_rna)
print groups_rna.index.values
# [___CELL_SEPARATOR___]
print peaks.columns
# [___CELL_SEPARATOR___]
pp = peaks.loc[groups_peaks.index.values]
print pp.shape
print pp.columns

pp = pp.dropna(axis=1, how='any')
print pp.shape
display(pp)
# [___CELL_SEPARATOR___]
metadata_peaks = pd.read_csv('../data/metadata_peaks.csv', index_col=0)

# keep only peaks we've selected from before
metadata_peaks = metadata_peaks[metadata_peaks.index.isin(pp.columns)]

# drop rows containing NA, i.e. in the PiMP Annotation column
metadata_peaks = metadata_peaks.dropna()

display(metadata_peaks)
# [___CELL_SEPARATOR___]
selected = pp.columns
overlap = selected.isin(metadata_peaks.index)
pp = (pp.transpose().loc[overlap]).transpose()

display(pp)
# [___CELL_SEPARATOR___]
rr = rna.loc[groups_rna.index.values]
print rr.shape

pos = (rr != 0).any(axis=0)
rr = rr.loc[:, pos]

print rr.shape
display(rr)
# [___CELL_SEPARATOR___]
# corr = np.corrcoef(pp.values[0:3, :], rr.values, rowvar=False)
# print corr.shape
# [___CELL_SEPARATOR___]
# https://stackoverflow.com/questions/30143417/computing-the-correlation-coefficient-between-two-multi-dimensional-arrays

def generate_correlation_map(x, y):
    """Correlate each n with each m.

    Parameters
    ----------
    x : np.array
      Shape N X T.

    y : np.array
      Shape M X T.

    Returns
    -------
    np.array
      N X M array in which each element is a correlation coefficient.

    """
    mu_x = x.mean(1)
    mu_y = y.mean(1)
    n = x.shape[1]
    if n != y.shape[1]:
        raise ValueError('x and y must ' +
                         'have the same number of timepoints.')
    s_x = x.std(1, ddof=n - 1)
    s_y = y.std(1, ddof=n - 1)
    cov = np.dot(x,
                 y.T) - n * np.dot(mu_x[:, np.newaxis],
                                  mu_y[np.newaxis, :])
    return cov / np.dot(s_x[:, np.newaxis], s_y[np.newaxis, :])
# [___CELL_SEPARATOR___]
corr = generate_correlation_map(pp.values[0:3, :].transpose(), rr.values.transpose())
print corr.shape
# [___CELL_SEPARATOR___]
plt.figure(figsize=(12, 12))
plt.imshow(corr, aspect='auto')
plt.colorbar()
plt.title('Peaks vs transcripts correlations')
# [___CELL_SEPARATOR___]
corr_df = pd.DataFrame(data=corr, index=pp.columns, columns=rr.columns)
display(corr_df)
# [___CELL_SEPARATOR___]
selected_genes = corr_df.columns.values
print selected_genes
print len(selected_genes)
# [___CELL_SEPARATOR___]
df = pd.read_csv('../data/genemania/combined/COMBINED.DEFAULT_NETWORKS.BP_COMBINING.txt', sep='\t')
print df.shape
# [___CELL_SEPARATOR___]
df = df.loc[(df['Gene_A'].isin(selected_genes)) & df['Gene_B'].isin(selected_genes)]
df = df.sort_values(['Gene_A', 'Gene_B'])
print df.shape
# [___CELL_SEPARATOR___]
# create an empty s-by-s adj matrix
s = len(selected_genes)
adj = lil_matrix((s, s))
print adj.shape

# build index
idx = {}
for i, val in enumerate(selected_genes):
    idx[val] = i

# populate adj matrix
count = 0
total = df.shape[0]
for i, row in df.iterrows():
    
    if count % 100000 == 0:
        print 'Processing %.2f%%' % (float(count) / total * 100)

    first = row['Gene_A']
    first_pos = idx[first]

    second = row['Gene_B']
    second_pos = idx[second]
    
    val = row['Weight']
    adj[first_pos, second_pos] = val
    
    count += 1
# [___CELL_SEPARATOR___]
plt.imshow(adj.todense(), aspect='auto')
plt.colorbar()
plt.title('Genes vs genes interaction weights')
# [___CELL_SEPARATOR___]
nnz = adj.count_nonzero()
total = adj.shape[0] * adj.shape[1]

print nnz
print total
percent = float(nnz) / total * 100
print np.sqrt(total*percent/100)
print percent
# [___CELL_SEPARATOR___]
adj_df = pd.DataFrame(adj.todense(), index=selected_genes, columns=selected_genes)
# [___CELL_SEPARATOR___]
peak_corr = generate_correlation_map(pp.values[0:3, :].transpose(), pp.values[0:3, :].transpose())
print peak_corr.shape
# [___CELL_SEPARATOR___]
plt.figure(figsize=(12, 12))
plt.imshow(peak_corr, aspect='auto')
plt.colorbar()
plt.title('Peaks vs peaks correlations')
# [___CELL_SEPARATOR___]
peak_corr_df = pd.DataFrame(data=peak_corr, index=pp.columns, columns=pp.columns)
display(peak_corr_df)
# [___CELL_SEPARATOR___]
from collections import OrderedDict
# [___CELL_SEPARATOR___]
robjects.r['load']('../data/kegg/pathways2Compounds.RData')
a = robjects.r['pathways2Compounds']
x = OrderedDict(zip(a.names, map(list,list(a))))

print x.keys()[0:10]
print
print x['path:map00010']
print len(x)
# [___CELL_SEPARATOR___]
s, s = peak_corr.shape
print s

peak_names_to_indices = defaultdict(set)
idx = 0
idx_to_pid = {}
for peakid, row in metadata_peaks.iterrows():
    try:
        pimp_annots = row['PiMP Annotation']
        name = row['PiMP Annotation'].split(',')
        for n in name:
            peak_names_to_indices[n].add(idx)
            assert idx < s, 'idx=%d, s=%d' % (idx, s)
            idx_to_pid[idx] = peakid
    except AttributeError: # skip peaks that don't have identifications
        continue
    finally:
        idx += 1
# [___CELL_SEPARATOR___]
data = []
peak_pathway_adj = np.zeros_like(peak_corr)
for pathway_id in x:

    # ix = int(id_str.split(':')[1].replace('map', ''))
    members = set()    
    metabolite_names = x[pathway_id]
    for name in metabolite_names:        
        indices = peak_names_to_indices[name]
        if len(indices) > 0:

            members.add((name, tuple(indices),))
            
            # populate matrix
            for i in indices:
                assert i < s, 'i=%d, s=%d' % (i, s)                
                for j in indices:
                    peak_pathway_adj[i, j] = 1
                    
    if len(members)>0:
        for metabolite_name, peak_indices in members:
            for i in indices:
                data.append((pathway_id, metabolite_name, idx_to_pid[i]))
        
pathway_peaks_df = pd.DataFrame(data, columns=['pathway_id', 'metabolite_name', 'peak_id'])
display(pathway_peaks_df)
# [___CELL_SEPARATOR___]
nnz = np.count_nonzero(peak_pathway_adj)
total = s*s 
print nnz
print total
print float(nnz)/total*100
# [___CELL_SEPARATOR___]
peak_pathway_adj_df = pd.DataFrame(data=peak_pathway_adj, index=pp.columns, columns=pp.columns)
display(peak_pathway_adj_df)
# [___CELL_SEPARATOR___]
plt.figure(figsize=(12, 12))
plt.imshow(peak_pathway_adj_df, aspect='auto')
plt.colorbar()
plt.title('Peaks vs peaks pathway adjacency')
# [___CELL_SEPARATOR___]
robjects.r['load']('../data/kegg/pathways.RData')
df = robjects.r['pathways']

pathway_names = []
for ix, row in df.iterrows():
    pathway_names.append((row['id'], row['name'],))
    
pathway_names_df = pd.DataFrame(pathway_names, columns=['pathway_id', 'pathway_name']).set_index('pathway_id')
display(pathway_names_df)
# [___CELL_SEPARATOR___]
filename = '../data/data_%d_%s_%s.h5' % (time, parasite, treatment)
hdf = HDFStore(filename, complevel=9, complib='bzip2')
hdf.put('peak_vs_transcript', corr_df)
hdf.put('peak_vs_peak', peak_corr_df)
hdf.put('transcript_vs_transcript', adj_df)
hdf.put('pathway_peaks_df', pathway_peaks_df)
hdf.put('pathway_names_df', pathway_names_df)
hdf.put('peak_pathway_adj_df', peak_pathway_adj_df)
hdf.close()
# [___CELL_SEPARATOR___]
