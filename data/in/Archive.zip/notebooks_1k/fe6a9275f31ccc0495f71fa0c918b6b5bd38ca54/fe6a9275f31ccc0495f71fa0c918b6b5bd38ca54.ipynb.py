import pandas as pd
import matplotlib.pyplot as plt
# [___CELL_SEPARATOR___]
df = pd.read_csv('d:/tmp/news-article/Full-Economic-News-DFE-839861.csv', encoding='latin1',
                usecols=['relevance', 'text'])
df.head()
# [___CELL_SEPARATOR___]
df.drop(df.loc[df.relevance=='not sure'].index, inplace=True)
df.relevance.unique()
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
from sklearn.preprocessing import LabelEncoder

encoder = LabelEncoder()
df['y'] = encoder.fit_transform(df.relevance)
df.head()
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
import spacy
from spacy.lemmatizer import Lemmatizer
from spacy.lang.en import LEMMA_INDEX, LEMMA_EXC, LEMMA_RULES

nlp = spacy.load('en_core_web_sm')
lemmatizer = Lemmatizer(LEMMA_INDEX, LEMMA_EXC, LEMMA_RULES)

# transformation function to use in pd.DataFrame.apply()
def tokenize_text(text):
    """Tokenizes the text by lemmatizing and removing stop words
    Args:
        text - the input text
    Returns:
        a list of tokens
    """
    # process the text
    doc = nlp(text)
    
    # https://spacy.io/api/token
    lemmas = [lemmatizer(token.text, token.pos_) for token in doc
              if not token.is_stop and token.is_alpha]

    # create a string
    return ' '.join([item for sublist in lemmas for item in sublist])
# [___CELL_SEPARATOR___]
# Test
%time tokenize_text(df.text[0])
# [___CELL_SEPARATOR___]
# Tokenize the column (takes about 10 minutes)
%time df_tokenized = df.text.apply(tokenize_text)

# Save the tokenized columns to CSV, so that we don't have to tokenize again
# https://pandas.pydata.org/pandas-docs/stable/generated/pandas.DataFrame.to_csv.html

df['tokenized'] = df_tokenized

df.to_csv('d:/tmp/news-article/Full-Economic-News-DFE-839861.tokenized.csv', encoding='latin1',
          index=False)
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
df = pd.read_csv('d:/tmp/news-article/Full-Economic-News-DFE-839861.tokenized.csv', encoding='latin1')
df.head()
# [___CELL_SEPARATOR___]
from sklearn.feature_extraction.text import TfidfVectorizer

# Apply the vectorizer on all tokenized rows
vectorizer = TfidfVectorizer(lowercase=False, decode_error='ignore')

X = vectorizer.fit_transform(df.tokenized)

# print a few features
print(vectorizer.get_feature_names()[:10])
# [___CELL_SEPARATOR___]
# check the distribution of the relevant / irrelevant articles
df.groupby(['y']).size()
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
from sklearn.manifold import TSNE

# Sample a portion of the dataset for t-SNE (otherwise too slow)
density = 0.5

df_display = pd.DataFrame(X.todense())
df_display['y'] = df.y

# random sample
sample = df_display.sample(frac=density, random_state=42)

# only take the X for t-SNE
sample_X = sample.iloc[:, :-1] # pick all but the last column ('y')

tsne = TSNE(n_components=2, random_state=42)

%time X_2d = tsne.fit_transform(sample_X)

print(X_2d.shape)

fig, ax = plt.subplots(figsize=(15, 10))
ax.scatter(X_2d[:, 0], X_2d[:, 1], c=sample.y)

ax.set(title='t-SNE plot for News Articles (X) and Relevance (y), density %.2f' % density,
       xlabel='X_2d[:, 0]', ylabel='X_2d[:, 1]')
ax.grid()
plt.show()
# [___CELL_SEPARATOR___]
tsne = TSNE(n_components=1, random_state=42)
%time X_1d = tsne.fit_transform(sample_X)

print(X_1d.shape)

fig, ax = plt.subplots(figsize=(15, 10))
ax.scatter(X_1d, sample.y)

ax.set(title='t-SNE 1D plot for News Articles (X) and Relevance (y), density %.2f' % density,
       xlabel='X_1d', ylabel='y')
ax.grid()
plt.show()
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
from sklearn.model_selection import train_test_split

X_train, X_test, y_train, y_test = train_test_split(X, df.y, random_state=42)
# [___CELL_SEPARATOR___]
from sklearn.dummy import DummyClassifier
from sklearn.linear_model import LogisticRegression, SGDClassifier
from sklearn.tree import DecisionTreeClassifier
#from sklearn.neural_network import MLPClassifier
from sklearn.neighbors import KNeighborsClassifier

# Can't deal with sparse matrices (memory intensive):
# - Naive Bayes

from sklearn.metrics import classification_report

classifiers = [
    DummyClassifier(random_state=42),
    LogisticRegression(random_state=42),
    SGDClassifier(tol=1e-3, max_iter=1000, random_state=42),
    DecisionTreeClassifier(random_state=42),
    #MLPClassifier(random_state=42), # slow and not so good...
    KNeighborsClassifier()    
]

for clf in classifiers:
    print(type(clf))
    %time clf.fit(X_train, y_train)
    pred = clf.predict(X_test)
    print(classification_report(y_test, pred))
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
# Example of plotting the ROC curves to compare classifiers
from sklearn.metrics import roc_curve, auc

fig, (ax0, ax1) = plt.subplots(nrows=2, ncols=1, figsize=(20, 20))

#
# plot the classifiers
#
for clf in classifiers:
    # some classifiers provide .decision_function(), others provide .predict_proba()
    if hasattr(clf, 'decision_function'):
        y_confidence = clf.decision_function(X_test)
    
        # positive label = class 0
        fpr0, tpr0, _ = roc_curve(y_test, y_confidence, pos_label=0)

        # positive label = class 1
        fpr1, tpr1, _ = roc_curve(y_test, y_confidence, pos_label=1)    
    else:
        y_confidence = clf.predict_proba(X_test)

        # positive label = class 0
        fpr0, tpr0, _ = roc_curve(y_test, y_confidence[:, 0], pos_label=0)

        # positive label = class 1
        fpr1, tpr1, _ = roc_curve(y_test, y_confidence[:, 1], pos_label=1)    

    ax1.plot(fpr1, tpr1, label='%s (area = %f)' % (clf.__class__, auc(fpr1, tpr1)))
    ax0.plot(fpr0, tpr0, label='%s (area = %f)' % (clf.__class__, auc(fpr0, tpr0)))        


# put the plots together
ax0.set(xlabel='false positive rate', ylabel='true positive rate',
       title='ROC curves (positive label="irrelevant")')
ax0.legend()
ax0.grid()

ax1.set(xlabel='false positive rate', ylabel='true positive rate',
       title='ROC curves (positive label="relevant")')
ax1.legend()
ax1.grid()

plt.show()
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
sample_news = ["""A sell-off in Chinese markets knocked Asian stocks on Wednesday as U.S. threats of tariffs on an additional $200 billion worth of Chinese goods pushed the world’s two biggest economies ever closer to a full-scale trade war.
FILE PHOTO: People walk past an electronic board showing Japan's Nikkei average outside a brokerage in Tokyo, Japan, March 23, 2018. REUTERS/Toru Hanai
Washington proposed the extra tariffs after efforts to negotiate a solution to the dispute failed to reach an agreement, senior administration officials said on Tuesday.

The United States had just imposed tariffs on $34 billion worth of Chinese goods on Friday, drawing immediate retaliatory duties from Beijing on U.S. imports in the first shots of a heated trade war. U.S. President Donald Trump had warned then that his country may ultimately impose tariffs on more than $500 billion worth of Chinese imports - roughly the total amount of U.S. imports from China last year.

“With no early end appearing to be in sight for the escalating ‘tit-for-tat’ world trade frictions and rising trade protectionism, global trade wars have become one of the key downside risks to world growth and trade in the second half of 2018 and for 2019,” wrote Rajiv Biswas, Asia Pacific chief economist at IHS Markit.

MSCI’s broadest index of Asia-Pacific shares outside Japan fell 1.1 percent. The index had gained for the past two sessions, having enjoyed a lull from the trade war fears that lashed global markets last week."""
,
"""TOKYO (Reuters) - Japanese regulators on Wednesday said Apple Inc (AAPL.O) may have breached antitrust rules by forcing mobile service providers to sell its iPhones cheaply and charge higher monthly fees, denying consumers a fair choice.

FILE PHOTO: A member of Apple staff takes pictures as new iPhone X begins to sell at an Apple Store in Beijing, China November 3, 2017. REUTERS/Damir Sagolj/File Photo
The Fair Trade Commission (FTC) said that Apple had forced NTT Docomo Inc (9437.T) , KDDI Corp (9433.T) and SoftBank Group Corp (9984.T) to offer subsidies and sell iPhones at a discount.

Apple Inc
190.35
AAPL.ONASDAQ
-0.00(-0.00%)
AAPL.O
AAPL.O9437.T9433.T9984.T
The FTC, which began looking into Apple’s sales practices in 2016, did not punish Apple as the U.S. company had agreed to revise its contracts with the carriers, it said
TOKYO (Reuters) - Japanese regulators on Wednesday said Apple Inc (AAPL.O) may have breached antitrust rules by forcing mobile service providers to sell its iPhones cheaply and charge higher monthly fees, denying consumers a fair choice.

FILE PHOTO: A member of Apple staff takes pictures as new iPhone X begins to sell at an Apple Store in Beijing, China November 3, 2017. REUTERS/Damir Sagolj/File Photo
The Fair Trade Commission (FTC) said that Apple had forced NTT Docomo Inc (9437.T) , KDDI Corp (9433.T) and SoftBank Group Corp (9984.T) to offer subsidies and sell iPhones at a discount.

Apple Inc
190.35
AAPL.ONASDAQ
-0.00(-0.00%)
AAPL.O
AAPL.O9437.T9433.T9984.T
The FTC, which began looking into Apple’s sales practices in 2016, did not punish Apple as the U.S. company had agreed to revise its contracts with the carriers, it said
"""
,
"""Stocks fell, the dollar gained and commodities slid with emerging-market assets after the U.S. fired a new shot in its brewing trade war with China.

S&P 500 futures slumped with the Stoxx Europe 600 Index and MSCI Asia Pacific Index following the Trump administration’s release of the biggest list yet of Chinese goods it may hit with tariff increases. The Asian nation vowed to retaliate, and shares in Shanghai led the retreat as the yuan weakened.

The potential escalation spurred advances in the dollar and Treasuries, while emerging-market stocks and currencies both declined. Metals bore the brunt of the reaction in commodities, with copper, nickel and zinc all sliding.
"""
]

df_sample_news = pd.DataFrame(data={'text': sample_news})

# first tokenize and lemmatize your test text
df_sample_news['tokenized_text'] = df_sample_news.text.apply(tokenize_text)
df_sample_news
# [___CELL_SEPARATOR___]
# Apply TfidfVectorizer to get the test input vector
sample_news = vectorizer.transform(df_sample_news.tokenized_text).todense()
print(sample_news.shape)
# [___CELL_SEPARATOR___]
# Run predict to see if your model correctly classified the text as relevant to the US Economy

for clf in classifiers:
    print(clf.__class__)
    predictions = clf.predict(sample_news)
    
    if hasattr(clf, 'predict_proba'):
        probabilities = clf.predict_proba(sample_news)
        for prediction, probability in (zip(predictions, probabilities)):
            print(prediction, probability)
    else:
        distances = clf.decision_function(sample_news)
        for prediction, distance in (zip(predictions, distances)):
            print(prediction, distance)
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
# check the distribution of the relevant / irrelevant articles
df.groupby(['y']).size()
# [___CELL_SEPARATOR___]
# let's cut the irrelevant articles by 1/4
# Alternatively, you can also collect and label more relevant articles
df_irrelevant = df[df.y == 0].sample(frac=0.25, random_state=42)
df_irrelevant.shape
# [___CELL_SEPARATOR___]
# keep all the relevant articles
df_relevant = df[df.y == 1]
df_relevant.shape
# [___CELL_SEPARATOR___]
# make our balanced dataset
df_balanced = pd.concat([df_irrelevant, df_relevant], axis=0) # concat rows
df_balanced.groupby(['y']).size()
# [___CELL_SEPARATOR___]
df_balanced.columns
# [___CELL_SEPARATOR___]
# Featurize, fit, metrics, predict, ...

# featurize
vectorizer_balanced = TfidfVectorizer(lowercase=False, decode_error='ignore')
X = vectorizer_balanced.fit_transform(df_balanced.tokenized)

# fit
X_train, X_test, y_train, y_test = train_test_split(X, df_balanced.y, random_state=42)
clf = LogisticRegression(random_state=42)
clf.fit(X_train, y_train)

# metrics
print(classification_report(y_test, clf.predict(X_test)))

# predict
sample_news = vectorizer_balanced.transform(df_sample_news.tokenized_text).todense()
predictions = clf.predict(sample_news)

if hasattr(clf, 'predict_proba'):
    print('Prediction [P(y=0|X) P(y=1|X)]')
    probabilities = clf.predict_proba(sample_news)
    for prediction, probability in (zip(predictions, probabilities)):
        print(prediction, probability)
else:
    print('Prediction [Distance(y=0|X) Distance(y=1|X)]')
    distances = clf.decision_function(sample_news)
    for prediction, distance in (zip(predictions, distances)):
        print(prediction, distance)
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
vectorizer_ngram = TfidfVectorizer(ngram_range=(1, 2))

# Featurize, fit, metrics, predict, ...

# featurize

X = vectorizer_ngram.fit_transform(df_balanced.tokenized)

# fit
X_train, X_test, y_train, y_test = train_test_split(X, df_balanced.y, random_state=42)
clf = LogisticRegression()
clf.fit(X_train, y_train)

# metrics
print(classification_report(y_test, clf.predict(X_test)))

# predict
sample_news = vectorizer_ngram.transform(df_sample_news.tokenized_text).todense()
predictions = clf.predict(sample_news)
if hasattr(clf, 'predict_proba'):
    print('Prediction [P(y=0|X) P(y=1|X)]')
    probabilities = clf.predict_proba(sample_news)
    for prediction, probability in (zip(predictions, probabilities)):
        print(prediction, probability)
else:
    print('Prediction [Score (negative: class 0, positive: class 1)]')
    scores = clf.decision_function(sample_news)
    for prediction, score in (zip(predictions, scores)):
        print(prediction, score)
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
# Replot ROC curve
fig, (ax0, ax1) = plt.subplots(nrows=2, ncols=1, figsize=(20, 20))

# some classifiers provide .decision_function(), others provide .predict_proba()
if hasattr(clf, 'decision_function'):
    y_confidence = clf.decision_function(X_test)

    # positive label = class 0
    fpr0, tpr0, _ = roc_curve(y_test, y_confidence, pos_label=0)

    # positive label = class 1
    fpr1, tpr1, _ = roc_curve(y_test, y_confidence, pos_label=1)    
else:
    y_confidence = clf.predict_proba(X_test)

    # positive label = class 0
    fpr0, tpr0, _ = roc_curve(y_test, y_confidence[:, 0], pos_label=0)

    # positive label = class 1
    fpr1, tpr1, _ = roc_curve(y_test, y_confidence[:, 1], pos_label=1)    

ax1.plot(fpr1, tpr1, label='%s (area = %f)' % (clf.__class__, auc(fpr1, tpr1)))
ax0.plot(fpr0, tpr0, label='%s (area = %f)' % (clf.__class__, auc(fpr0, tpr0)))        

# put the plots together
ax0.set(xlabel='false positive rate', ylabel='true positive rate',
       title='ROC curves (positive label="irrelevant")')
ax0.legend()
ax0.grid()

ax1.set(xlabel='false positive rate', ylabel='true positive rate',
       title='ROC curves (positive label="relevant")')
ax1.legend()
ax1.grid()

plt.show()
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
# print out what the "positive score" class is for our SGD classifier
print(classifiers[2])

print(classifiers[2].classes_[1])
# [___CELL_SEPARATOR___]
from sklearn.base import clone

# clone the "baseline" SGDClassifier so that we can train one with N-grams
# with the same classifier hyper-parameters.
#
# clone does not copy the weights
sgd_ngram = clone(classifiers[2])

sgd_ngram.fit(X_train, y_train)

# metrics
print(classification_report(y_test, sgd_ngram.predict(X_test)))

# predict
sample_news = vectorizer_ngram.transform(df_sample_news.tokenized_text).todense()
predictions = clf.predict(sample_news)

print('Prediction [Score (negative: class 0, positive: class 1)]')
scores = sgd_ngram.decision_function(sample_news)
for prediction, score in (zip(predictions, scores)):
    print(prediction, score)
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
fig, ax = plt.subplots()

y_confidence = sgd_ngram.decision_function(X_test)

# How to debug python scripts in Jupyter Notebook
#
# 1. Uncomment this in code (which enables the debugger)
# import pdb; pdb.set_trace()
#
# 2. Type these in the debugger
# import sklearn.metrics
# break sklearn.metrics.roc_curve
# break sklearn.metrics.ranking._binary_clf_curve
# c
#
# 3. debug, use https://docs.python.org/3.6/library/pdb.html#module-pdb as a reference
#
# 4. Quit the debugger
# q
# 

# positive label = class 1
pos_label=1

fpr1, tpr1, thresholds1 = roc_curve(y_test, y_confidence, pos_label=pos_label)    

ax.plot(fpr1, tpr1)
ax.set(xlabel='false positive rate', ylabel='true positive rate',
       title='ROC: positive Label: 1 (AUC = %f)' % auc(fpr1, tpr1))
ax.grid()
plt.show()
# [___CELL_SEPARATOR___]
print('Positive label: 1')
print('------ First 10 --------')
print('False positive rate\n', fpr1[:10],
      '\nTrue positive rate\n', tpr1[:10],
      '\nScore\n', thresholds1[:10])

print('------ Last 10 --------')
print('False positive rate\n', fpr1[-10:],
      '\nTrue positive rate\n', tpr1[-10:],
      '\nScore\n', thresholds1[-10:])
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
pos_label=0

fig, ax = plt.subplots()
fpr0, tpr0, thresholds0 = roc_curve(y_test, y_confidence, pos_label=pos_label)

ax.plot(fpr0, tpr0)
ax.set(xlabel='false positive rate', ylabel='true positive rate',
       title='ROC: positive Label: %d (AUC = %f)' % (pos_label, auc(fpr0, tpr0)))
ax.grid()
plt.show()
# [___CELL_SEPARATOR___]
print('Positive label: 0')
print('------ First 10 --------')
print('False positive rate\n', fpr0[:10],
      '\nTrue positive rate\n', tpr0[:10],
      '\nScore\n', thresholds0[:10])

print('------ Last 10 --------')
print('False positive rate\n', fpr0[-10:],
      '\nTrue positive rate\n', tpr0[-10:],
      '\nScore\n', thresholds0[-10:])
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
y_pred = sgd_ngram.predict(X_test)

print(classification_report(y_test, y_pred))
# [___CELL_SEPARATOR___]
from sklearn.metrics import confusion_matrix
import seaborn as sns
cm = confusion_matrix(y_test, y_pred)

fig, ax = plt.subplots()

# https://seaborn.pydata.org/generated/seaborn.heatmap.html#seaborn.heatmap
sns.heatmap(cm, annot=True, ax=ax, fmt='d')
ax.set(xlabel='Predicted labels', ylabel='True labels', title='Confusion Matrix (Logistic Regression + SGD)') 
ax.xaxis.set_ticklabels(['irrelevant', 'relevant'])
ax.yaxis.set_ticklabels(['irrelevant', 'relevant'])
plt.show()
# [___CELL_SEPARATOR___]
# Positive label = 0 (irrelevant)
# tpr = recall = tp / (tp + fn)
tpr_class_0 = 317 / (317 + 106)

# fpr = fn / (tp + fn) = 1 - tpr
fpr_class_0 = 106 / (317 + 106)

print('Positive label: 0', 'tpr', tpr_class_0, 'fpr', fpr_class_0)
# [___CELL_SEPARATOR___]
# Positive label = 1 (relevant)

# tpr = recall = tp / (tp + fn)
tpr_class_1 = 209 / (209 + 134)

# fpr = fn / (tp + fn) = 1 - tpr
fpr_class_1 = 134 / (209 + 134)

print('Positive label: 1', 'tpr', tpr_class_1, 'fpr', fpr_class_1)
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
from sklearn.svm import SVC

svc = SVC(random_state=42)
svc.fit(X_train, y_train)
pred = svc.predict(X_test)

print(classification_report(y_test, pred))
# [___CELL_SEPARATOR___]
# The C parameter tells the SVM optimization how much
# you want to avoid misclassifying each training example.
#
# For large values of C, the optimization will choose a
# smaller-margin hyperplane if that hyperplane
# does a better job of getting all the training points
# classified correctly. 
#
# Conversely, a very small value of C will cause the optimizer
# to look for a larger-margin separating hyperplane, even if
# that hyperplane misclassifies more points.
#
# For very tiny values of C, you should get misclassified examples,
# often even if your training data is linearly separable.
#
# https://stats.stackexchange.com/questions/31066/what-is-the-influence-of-c-in-svms-with-linear-kernel

Cs = [0.001, 0.01, 0.1, 1, 10]

# Scaling term for Radial Basis Function kernel:
#   exp(-gamma ||x - x'||^2)
#
# This projects the X into a linearly separable space
#
# http://scikit-learn.org/stable/modules/svm.html#svm-kernels
gammas = [0.001, 0.01, 0.1, 1]

svc_params = {'C': Cs, 'gamma' : gammas}
    
grid_search = GridSearchCV(SVC(kernel='rbf'), param_grid=svc_params, verbose=True)
%time grid_search.fit(X_train, y_train)

pred = grid_search.predict(X_test)

print(grid_search.best_params_)
print(classification_report(y_test, pred))
# [___CELL_SEPARATOR___]
best_svm = grid_search.best_estimator_

best_svm
# [___CELL_SEPARATOR___]
from sklearn.manifold import TSNE

# Plot the T-SNE projection of the test dataset
# show the predictions in color

tsne_plot = TSNE(n_components=2, random_state=42)

%time X_test_2d = tsne_plot.fit_transform(X_test.todense())
print(X_test_2d.shape)
# [___CELL_SEPARATOR___]
# Plot the T-SNE projection of the test dataset
# Mark the correct and wrong predictions

fig, ax = plt.subplots(figsize=(15, 10))
ax.scatter(X_test_2d[y_test == pred, 0], X_test_2d[y_test == pred, 1],
           marker='o', label='right')
ax.scatter(X_test_2d[y_test != pred, 0], X_test_2d[y_test != pred, 1],
           marker='x', label='wrong')

ax.set(title='SVM Classifier: t-SNE plot for News Articles (X) and Relevance (y)',
       xlabel='X_test_2d[:, 0]', ylabel='X_test_2d[:, 1]')
ax.grid()
ax.legend()
plt.show()
# [___CELL_SEPARATOR___]
