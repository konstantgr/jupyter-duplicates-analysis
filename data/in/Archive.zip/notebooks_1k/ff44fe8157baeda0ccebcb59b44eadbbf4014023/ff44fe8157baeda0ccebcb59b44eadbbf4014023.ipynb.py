from platform import python_version

python_version()
# [___CELL_SEPARATOR___]
d = {'foo':10,'bar':30,'baz':20}
# [___CELL_SEPARATOR___]
for key,val in d.items():
    print('{} => {}'.format(key,val))
# [___CELL_SEPARATOR___]
allowed_values = [1, 2]

d = {'foo':1, 'bar':2, 'baz':3, 'quux':4 }

filtered_items = [(k,v) for (k,v) in d.items() if v in allowed_values]

dict(filtered_items)
# >> {'bar': 2, 'foo': 1}
# [___CELL_SEPARATOR___]
sorted(d.items(),key=lambda x:x[1])
# [___CELL_SEPARATOR___]
sorted(d.items(),key=lambda x:x[0])
# [___CELL_SEPARATOR___]
from collections import OrderedDict
# [___CELL_SEPARATOR___]
d = {'foo':10, 'bar':30,'baz':20}

sorted_list_of_tuples = sorted(d.items(),key=lambda x:x[1])

od = OrderedDict(sorted_list_of_tuples)

for key,val in od.items():
    print('{} => {}'.format(key,val))
# [___CELL_SEPARATOR___]
from collections import ChainMap

d1 = {'a':1, 'b': 2}

d2 = {'b':100, 'c': 200}

d3 = ChainMap({}, d1, d2)

print(d3["a"])
print(d3["b"])
print(d3["c"])
# [___CELL_SEPARATOR___]
d = dict()

d['foo'] = 10
d['bar'] = 32
d['baz'] = 32

for key,val in d.items():
    print('{} => {}'.format(key,val))
# [___CELL_SEPARATOR___]
od = OrderedDict()

od['foo'] = 10
od['bar'] = 32
od['baz'] = 5

for key,val in od.items():
    print('{} => {}'.format(key,val))
# [___CELL_SEPARATOR___]

# [___CELL_SEPARATOR___]
